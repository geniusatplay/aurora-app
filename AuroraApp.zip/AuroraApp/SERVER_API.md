# Aurora Sync API — contract for the future server

The app ships **on-device only**. This document fixes the shape of the server so that a backend
can be built independently and plugged in later by implementing `SyncGateway` (see
`app/src/main/java/com/aurora/msg/data/sync/SyncGateway.kt`). Nothing else in the app changes.

Design principles
* JSON over HTTPS, bearer tokens, idempotent upserts keyed by client-generated UUIDs.
* Health data about a named person → GDPR / US state privacy law apply. Store the minimum,
  encrypt at rest, give users export + delete. Sync must be **opt-in** in the app.
* Numbers are transmitted exactly as the pod does (fixed-point integers), so the server never
  rounds anything.

Base URL: `https://api.<your-domain>/v1`

## Auth

| Method | Path | Body | Returns |
|---|---|---|---|
| POST | `/auth/register` | `{ "email", "password", "displayName" }` | `AuthToken` |
| POST | `/auth/login` | `{ "email", "password" }` | `AuthToken` |
| POST | `/auth/refresh` | `{ "refreshToken" }` | `AuthToken` |
| DELETE | `/me` | — | 204 · deletes the account and **all** data |
| GET | `/me/export` | — | ZIP of CSV/JSON, one file per night |

```json
AuthToken { "accessToken": "…", "refreshToken": "…", "expiresAt": 1787653632000, "userId": "usr_…" }
```

All other calls: `Authorization: Bearer <accessToken>`.

## Sessions (nights)

| Method | Path | Notes |
|---|---|---|
| PUT | `/sessions/{clientId}` | Idempotent upsert. `clientId` = the app's UUID for the night. Returns `{ "serverId" }`. |
| GET | `/sessions?since=<epochMs>` | Sessions changed since; for multi-device restore. |
| GET | `/sessions/{serverId}` | Session + summary. |
| DELETE | `/sessions/{serverId}` | Also deletes its epochs/hrv. |
| PUT | `/sessions/{serverId}/epochs` | Body `{ "epochs": [ … ≤ 500 … ] }`, chunked; idempotent on `(sessionId, tS)`. |
| PUT | `/sessions/{serverId}/hrv` | Body `{ "points": [ … ] }`, idempotent on `(sessionId, windowEndS)`. |
| PUT | `/sessions/{serverId}/events` | Activity markers `{ "events": [ … ] }`. |

### Session
```json
{
  "clientId": "3f1c…",
  "startedAtEpochMs": 1787648400000,
  "endedAtEpochMs":   1787676000000,
  "slot": 9,
  "source": "BLE" | "DEMO",
  "replayState": "NONE" | "PARTIAL" | "COMPLETE",
  "crcFailures": 0,
  "firmware": "1.0.0",
  "summary": {
    "sessionLenS": 27600, "epochsLogged": 920, "sweatEvents": 4, "longestSweatS": 870,
    "peakDahX100": 1882, "hrMean": 61, "hrMin": 53, "hrMax": 93,
    "pctWake": 12, "pctLight": 55, "pctDeep": 33, "battPct": 64
  }
}
```

### Epoch (one 30 s record — mirrors the 34-byte log record, CRC already verified by the app)
```json
{ "tS": 1800, "hrBpm": 61, "hrQuality": 88, "skinTempX100": 3341, "skinRhX100": 3020,
  "ambTempX100": 2150, "ambRhX100": 4200, "motionIndex": 5, "sleepState": 2, "sweatFlag": 0,
  "battPct": 90, "flags": 98, "dahX100": 312, "hrvMeanIbi": 1000, "hrvSdnnX10": 520,
  "hrvRmssdX10": 460, "hrvPnn50": 21, "hrvQuality": 91, "hrvFlags": 1, "vcellCv": 130 }
```

### HRV point
```json
{ "windowEndS": 720, "meanIbi": 1000, "sdnnX10": 520, "rmssdX10": 460, "pnn50": 21,
  "accepted": 110, "rejected": 6, "quality": 91, "flags": 1 }
```

### Activity event
```json
{ "tS": 5400, "kind": "NIGHT_SWEATS", "label": "Night sweats", "source": "DEMO" | "USER" | "POD" }
```

## Errors
`{ "error": "code", "message": "human readable" }` with standard HTTP status codes.
`409` on an upsert means the server copy is newer; the app should pull and merge.

## Suggested stack
Any. A minimal implementation is a single Postgres database with tables mirroring the Room
entities (`sessions`, `session_summary`, `epochs`, `hrv_points`, `activity_events`) plus
`users`. Epoch volume is ~1 000 rows per night per user.

## Client implementation checklist (when the server exists)
1. Implement `SyncGateway` (e.g. with Ktor or Retrofit — add the dependency then).
2. Swap it in `AppGraph.sync`.
3. Add a "Cloud backup" toggle in Settings (off by default) and push sessions where `syncedAt == null`.
4. Replace local password hashes with server tokens in `AuthRepository`.
