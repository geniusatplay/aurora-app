package com.aurora.msg.protocol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Hardware protocol v1 (PROTOCOL.txt, verified on hardware). The hex vectors were produced
 * by the web app's encoder, which agrees field-for-field with the bridge's reference
 * decoder pod_agent.py on 1600 fuzzed packets — so these pin all three implementations.
 */
class HwProtocolTest {

    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    @Test fun timeSyncMatchesSpecWorkedExample() {
        // PROTOCOL §6: epoch 1786579200 → 03 00 09 7D 6A
        assertEquals("0300097d6a", HwOp.timeSync(1786579200).joinToString("") { "%02x".format(it) })
        assertEquals("061e", HwOp.setPeriod(30).joinToString("") { "%02x".format(it) })
    }

    @Test fun vitalsReferenceRowFromTheLiveRun() {
        val v = HwVitals.parse(hex("a10364000000050ab317a905d902642833ffdb36"))
        assertEquals(3, v.seq); assertEquals(100L, v.uptimeS)
        assertEquals(2565, v.skinTempX100); assertEquals(6067, v.skinRhX100); assertEquals(1449, v.absHumX100)
        assertEquals(729, v.hrX10); assertEquals(100, v.spo2Pct); assertEquals(40, v.quality); assertEquals(51, v.flags)
        assertNull("0xFF battery = unknown", v.battPct)
        assertTrue(v.finger && v.sessionActive && v.hrLocked && v.timeValid && !v.flushActive)
        assertEquals(72.9f, v.hrShowBpm!!, 0.001f); assertEquals(100, v.spo2Show)
    }

    @Test fun sentinelsDecodeAsAbsentNeverZero() {
        val v = HwVitals.parse(hex("a1ff00286bee008000000000ffffff00204dbd87"))
        assertEquals(4_000_000_000L, v.uptimeS) // u32 above Int.MAX
        assertNull(v.skinTempX100); assertNull(v.hrX10); assertNull(v.spo2Pct); assertNull(v.hrShowBpm)
        assertEquals(77, v.battPct)
        val w = HwVitals.parse(hex("a10934050000f3fd17189b05ffff622701ff71db"))
        assertEquals(-525, w.skinTempX100)
        assertEquals(98, w.spo2Pct); assertNull("quality 39 < 40 → SpO2 hidden", w.spo2Show)
        assertNull("no HR_LOCKED → no HR", w.hrShowBpm)
    }

    @Test fun corruptedPacketsAreRejected() {
        val b = hex("a10364000000050ab317a905d902642833ffdb36"); b[7] = (b[7].toInt() xor 0x10).toByte()
        try { HwVitals.parse(b); fail() } catch (_: HwPacketException) {}
        try { HwVitals.parse(hex("a2" + "00".repeat(19))); fail("wrong header") } catch (_: HwPacketException) {}
        try { HwVitals.parse(ByteArray(19)); fail("wrong length") } catch (_: HwPacketException) {}
    }

    @Test fun hrvSessionReplayReferenceVectors() {
        val h = HwHrv.parse(hex("a596000000720353049c03402d619e"))
        assertEquals(150L, h.uptimeS); assertEquals(882, h.meanRrMs); assertEquals(1107, h.sdnnX10)
        assertEquals(924, h.rmssdX10); assertEquals(64, h.beats); assertEquals(45, h.quality); assertTrue(h.usable)
        val s = HwSession.parse(hex("a26bbbb96a3c0000000000ad05cd0964ff02dfb8"))
        assertEquals(1790557035L, s.startEpoch); assertEquals(60L, s.durationS); assertEquals(1453, s.peakAbsHumX100)
        assertEquals(2509, s.meanSkinTempX100); assertEquals(100, s.score); assertNull(s.battPct); assertEquals(2, s.logRecords)
        val r = HwRecord.parseFrame(hex("0700100e0000c20bae1554066402614236ffd046"))
        assertEquals(7, r.seq); assertEquals(3600L, r.uptimeS); assertEquals(3010, r.skinTempX100); assertEquals(612, r.hrX10)
        assertEquals(0x36, r.flags)
        val bad = hex("0700100e0000c20bae1554066402614236ffd046"); bad[5] = 1
        try { HwRecord.parseFrame(bad); fail() } catch (_: HwPacketException) {}
    }

    @Test fun encodersRoundTrip() {
        val v = HwVitals(200, 12345, null, 5000, 1500, null, null, 12, 0x20, null)
        assertEquals(v, HwVitals.parse(v.encode()))
        val s = HwSession(null, 5, 1, 1800, -120, 0, null, 255)
        assertEquals(s, HwSession.parse(s.encode()))
        val r = HwRecord(479, 99999, -1, 1, 2, 655, 95, 80, 0x3F, 50)
        assertEquals(r, HwRecord.parseFrame(r.encodeFrame()))
    }

    // ------------------------------------------------------------------ adapter

    private fun vit(seq: Int, up: Long, flags: Int, ah: Int = 1450, hr: Int? = 700, spo2: Int? = 97, q: Int = 60, skin: Int? = 3300) =
        HwVitals(seq, up, skin, 5500, ah, hr, spo2, q, flags, null).encode()

    @Test fun adapterMapsHonestlyAndPinsSessionTime() {
        var now = 1_790_000_000L
        val a = HwAdapter { now }
        val idle = a.onVitals(vit(1, 500, HwFlags.TIME_VALID or HwFlags.FINGER, hr = 700))
        assertEquals("no HR_LOCKED → 0 (internal 'no reading')", 0, idle.vitals.hrBpm)
        assertFalse(idle.vitals.logging); assertTrue(idle.vitals.timeSynced); assertTrue(idle.vitals.ppgActive)
        assertEquals(500L, idle.vitals.tS)
        assertNull(idle.batteryPct)
        assertFalse(HwAdapter.hasAmbient(idle.vitals.ambTempX100))
        assertEquals(1_790_000_000L - 500, a.epochOffsetS)

        now += 1
        val s0 = a.onVitals(vit(2, 501, HwFlags.TIME_VALID or HwFlags.FINGER or HwFlags.HR_LOCKED or HwFlags.SESSION_ACTIVE))
        assertTrue(s0.vitals.logging); assertEquals(0L, s0.vitals.tS); assertEquals(70, s0.vitals.hrBpm)
        assertTrue(s0.ext.spo2Valid); assertEquals(970, s0.ext.spo2X10)
        val s1 = a.onVitals(vit(3, 531, HwFlags.SESSION_ACTIVE or HwFlags.HR_LOCKED, q = 30))
        assertEquals(30L, s1.vitals.tS)
        assertFalse("quality 30 → SpO2 not valid", s1.ext.spo2Valid)
        assertEquals(1450, s1.vitals.absHumX100)

        // flush edges → internal sweat flag
        val f1 = a.onVitals(vit(4, 532, HwFlags.SESSION_ACTIVE or HwFlags.FLUSH_ACTIVE, ah = 1750))
        assertEquals(SweatFlag.START, f1.vitals.sweatFlag); assertTrue(f1.vitals.dahDirectX100!! > 250)
        val f2 = a.onVitals(vit(5, 533, HwFlags.SESSION_ACTIVE or HwFlags.FLUSH_ACTIVE, ah = 1760))
        assertEquals(SweatFlag.ONGOING, f2.vitals.sweatFlag)
        val f3 = a.onVitals(vit(6, 534, HwFlags.SESSION_ACTIVE, ah = 1460))
        assertEquals(SweatFlag.NONE, f3.vitals.sweatFlag)

        val sum = a.onSession(HwSession(1_790_000_001L, 33, 1, 1760, 3300, 100, null, 2).encode())
        assertEquals(33L, sum.sessionLenS); assertEquals(1, sum.sweatEvents); assertEquals(70, sum.hrMeanBpm)
        assertTrue(sum.peakDahX100 > 250); assertEquals(0, sum.pctDeep + sum.pctLight + sum.pctWake)
    }

    @Test fun joiningARunningSessionUsesFe02RunningDuration() {
        val a = HwAdapter { 2_000_000_000L }
        val first = a.onVitals(vit(1, 10_000, HwFlags.SESSION_ACTIVE or HwFlags.TIME_VALID))
        // Start unknown yet → LOGGING withheld so nothing is stored at a wrong session time.
        assertFalse(first.vitals.logging); assertTrue(a.needsSessionPin)
        // FE02 read after connecting: session has been running 3600 s
        a.onSession(HwSession(1_999_996_400L, 3600, 0, 1500, 3300, 0, null, 60).encode())
        val v = a.onVitals(vit(2, 10_001, HwFlags.SESSION_ACTIVE or HwFlags.TIME_VALID))
        assertEquals(3601L, v.vitals.tS); assertTrue(v.vitals.logging); assertFalse(a.needsSessionPin)
        val h = a.onHrv(HwHrv(10_001, 900, 500, 400, 12, 70).encode())
        assertEquals(3601L, h.windowEndTimeS); assertTrue(h.isValid)
        assertFalse(a.onHrv(HwHrv(10_002, 900, 500, 400, 4, 70).encode()).isValid)
    }

    @Test fun replayKeepsTheSessionWindowAndFillsThe30sGrid() {
        val now = 1_800_000_000L
        val a = HwAdapter { now }
        a.onVitals(vit(1, 20_000, HwFlags.TIME_VALID))            // offset = now − 20000
        val start = 20_000L - 3000                                 // session started 3000 s ago
        a.onSession(HwSession(now - 3000, 600, 0, 1500, 3300, 0, null, 30).encode())
        a.beginReplay()
        // 30 rows at 60 s: 10 before the session, 11 inside (0..600 s), 9 after
        var seq = 0
        for (k in -10 until 20) {
            val up = start + k * 60L
            val inside = k in 0..10
            val flags = HwFlags.TIME_VALID or (if (inside) HwFlags.SESSION_ACTIVE or HwFlags.HR_LOCKED else 0)
            assertTrue(a.onReplayFrame(HwRecord(seq++, up, 3300, 5500, 1500 + if (k == 5) 300 else 0, 650, 97, 70,
                flags or (if (k == 5) HwFlags.FLUSH_ACTIVE else 0), null).encodeFrame()))
        }
        val bad = HwRecord(seq, start, 1, 1, 1, 1, 1, 1, 1, 1).encodeFrame(); bad[10] = 0x55
        assertFalse(a.onReplayFrame(bad))
        val res = a.finishReplay()
        assertEquals(30, res.framesReceived); assertEquals(1, res.crcFailures)
        assertEquals(11, res.sessionRows)
        // 11 rows at 60 s → 0..600 s held onto 30 s epochs = 21 or 22 epochs, starting at 0
        assertEquals(0L, res.records.first().tS)
        assertTrue(res.records.size in 21..22)
        assertTrue(res.records.zipWithNext().all { (x, y) -> y.tS - x.tS == 30L })
        assertTrue(res.records.all { it.hrBpm == 65 && it.hasExt && it.spo2Pct == 97f && it.edaUs == null })
        assertEquals(SweatFlag.START, res.records.first { it.tS == 300L }.sweatFlag)
        assertTrue(res.records.first { it.tS == 300L }.dahX100 >= 250)

        // round-trip through the internal replay path the manager uses
        val frames = a.internalFrames(res.records)
        val asm = ReplayAssembler()
        var result: ReplayAssembler.Result? = null
        for (f in frames) { val e = asm.feed(f); if (e is ReplayAssembler.Event.Finished) result = e.result }
        assertNotNull(result); assertTrue(result!!.complete); assertEquals(42, result.header.recordSize)
        assertEquals(res.records, result.records)
    }

    @Test fun replayWithoutClockFallsBackToLastSessionRun() {
        val a = HwAdapter { 1_000L }
        a.onVitals(vit(1, 900, 0))
        a.onSession(HwSession(null, 120, 0, 1500, 3300, 0, null, 5).encode())
        a.beginReplay()
        listOf(0, 0, HwFlags.SESSION_ACTIVE, HwFlags.SESSION_ACTIVE, HwFlags.SESSION_ACTIVE).forEachIndexed { i, f ->
            a.onReplayFrame(HwRecord(i, 600L + i * 60, 3300, 5500, 1500, null, null, 0, f, null).encodeFrame())
        }
        val res = a.finishReplay()
        assertEquals(3, res.sessionRows); assertEquals(0L, res.records.first().tS)
        assertTrue("no lock → hr 0", res.records.all { it.hrBpm == 0 && it.spo2Pct == null })
    }

    @Test fun commandsTranslateToHardwareOpcodes() {
        val a = HwAdapter()
        assertEquals(HwAdapter.Plan.Write::class, a.plan(PodCommand.StartSession)::class)
        assertEquals(1, (a.plan(PodCommand.StartSession) as HwAdapter.Plan.Write).bytes[0].toInt())
        assertEquals(2, (a.plan(PodCommand.StopSession) as HwAdapter.Plan.Write).bytes[0].toInt())
        // The paper spec's 0x04 was "haptic"; on hardware 0x04 is REPLAY — must map to identify.
        assertEquals(7, (a.plan(PodCommand.HapticTest(250)) as HwAdapter.Plan.Write).bytes[0].toInt())
        assertEquals(5, (a.plan(PodCommand.FormatFlash) as HwAdapter.Plan.Write).bytes.let { assertEquals(1, it.size); it[0].toInt() })
        assertEquals(HwAdapter.Plan.Replay, a.plan(PodCommand.ReplaySlot(3)))
        assertEquals(HwAdapter.Plan.ReadSummary, a.plan(PodCommand.PushSummary))
        assertEquals(HwAdapter.Plan.Unsupported, a.plan(PodCommand.FuelGaugeRelearn))
        assertEquals(HwAdapter.Plan.Unsupported, a.plan(PodCommand.AbortReplay))
    }

    // ------------------------------------------------------------------ REAL pod packets
    // Captured from the glove over Web Bluetooth on 2026-09-28 (hardware check: 11/11 pass,
    // 76 packets, 0 CRC failures, all re-decoded by pod_agent.py with 0 mismatches).

    @Test fun realPodPacketsDecode() {
        val v = HwVitals.parse(hex("a130ae030000ed096718c0057c02632833ff1179"))
        assertEquals(48, v.seq); assertEquals(942L, v.uptimeS); assertEquals(2541, v.skinTempX100)
        assertEquals(6247, v.skinRhX100); assertEquals(1472, v.absHumX100); assertEquals(636, v.hrX10)
        assertEquals(99, v.spo2Pct); assertEquals(40, v.quality); assertEquals(51, v.flags); assertNull(v.battPct)
        val h = HwHrv.parse(hex("a5b6030000a30356039004402bbc77"))
        assertEquals(950L, h.uptimeS); assertEquals(931, h.meanRrMs); assertEquals(854, h.sdnnX10); assertEquals(1168, h.rmssdX10)
        val s = HwSession.parse(hex("a2b7beb96a290000000000e405f00964ff1809fc"))
        assertEquals(1790557879L, s.startEpoch); assertEquals(41L, s.durationS); assertEquals(1508, s.peakAbsHumX100)
        assertEquals(2544, s.meanSkinTempX100); assertEquals(24, s.logRecords); assertNull(s.battPct)
        val r = HwRecord.parseFrame(hex("00003c000000cd095418a105ffffff0000ff0a54"))
        assertEquals(0, r.seq); assertEquals(60L, r.uptimeS); assertNull(r.hrX10); assertNull(r.spo2Pct)
    }

    @Test fun realPodReplayIsWindowedToTheSession() {
        val a = HwAdapter { 1_790_557_924L }
        a.onVitals(hex("a15cda030000f109f818e505b702622831ffc6c9"))      // uptime 986 → offset
        a.onSession(hex("a2b7beb96a290000000000e405f00964ff1809fc"))       // 41 s session, 24 records
        a.beginReplay()
        listOf(
            "00003c000000cd095418a105ffffff0000ff0a54",
            "010078000000cb097d18a905ffffff0022ff9331",
            "0200b4000000cf096018a605ffffff0020ff448a",
            "0300f0000000cd096018a405ffffff0020fff20f",
            "04002c010000ca096218a205ffffff0020ff00c1",
            "050068010000ce095618a305ffffff0020ff5387",
            "0600a4010000d0093a189d05ffffff0020ff3fc1",
            "0700e0010000d0095c18a505ffffff0020ff6bad",
            "08001c020000d0096f18aa05ffffff0020ffc8fb",
            "090058020000d2095318a505ffffff2821ffa97e",
            "0a0094020000d5094a18a505ffffff0020ff22ce",
            "0b00d0020000d6094618a505ffffff0020ff3920",
            "0c000c030000d6093918a2056102622831fffe46",
            "0d0048030000df09bc18c8058902632831ff9798",
            "0e0084030000ee096f18c2057c02632831ffaa27",
            "0f00ad030000ed096718c0057c02642831ff4049",
            "1000b2030000ef096318c0057c02632b33ff90d6",
            "1100b7030000ee097718c4057c02623533ff0be5",
            "1200bc030000f0097218c5058902633533ffaf1a",
            "1300c1030000f209c118d9059702633533ff4482",
            "1400c6030000f009d218db05a702633533ff4269",
            "1500cb030000f109ea18e205b602623533ffd182",
            "1600d0030000f009ec18e105b702643533ff9582",
            "1700d5030000f109ee18e305b702633533ff17a9"
        ).forEach { assertTrue(a.onReplayFrame(hex(it))) }
        val res = a.finishReplay()
        assertEquals(24, res.framesReceived); assertEquals(0, res.crcFailures); assertEquals(0, res.missing)
        assertEquals("rows 16..23 carry SESSION_ACTIVE inside the window", 8, res.sessionRows)
        assertEquals(listOf(0L, 30L), res.records.map { it.tS })
        assertTrue(res.records.all { it.hrBpm in 60..70 && it.spo2Pct != null && !HwAdapter.hasAmbient(it.ambTempX100) })
    }

    @Test fun storedDahNeverWrapsBelowZero() {
        val a = HwAdapter { 1_000_000L }
        a.onVitals(vit(1, 1000, HwFlags.TIME_VALID))
        a.onSession(HwSession(1_000_000L - 900, 300, 0, 1500, 3300, 0, null, 10).encode())
        a.beginReplay()
        // humidity falls below its starting baseline — must store 0, not wrap to ~655 g/m³
        listOf(1600, 1500, 1400, 1300).forEachIndexed { i, ah ->
            a.onReplayFrame(HwRecord(i, 100L + i * 60, 3300, 5500, ah, null, null, 0, HwFlags.SESSION_ACTIVE, null).encodeFrame())
        }
        val res = a.finishReplay()
        assertTrue(res.records.isNotEmpty())
        val frames = a.internalFrames(res.records)
        val asm = ReplayAssembler(); var out: ReplayAssembler.Result? = null
        for (f in frames) { val e = asm.feed(f); if (e is ReplayAssembler.Event.Finished) out = e.result }
        assertTrue(out!!.records.all { it.dahX100 in 0..500 })
    }
}
