package com.aurora.msg.protocol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolTest {

    @Test
    fun crc16CcittFalse_knownVector() {
        // Standard check value for CRC-16/CCITT-FALSE over "123456789" is 0x29B1
        assertEquals(0x29B1, Crc16.ccittFalse("123456789".toByteArray()))
    }

    @Test
    fun timeSyncCommand_matchesSpecExample() {
        // Spec §6 example bytes "03 00 6E 8D 6A" decode (LE) to 0x6A8D6E00 = 1787653632.
        // (The spec's prose says 1786579200, which is 0x6A7D0900 — the prose number is a typo; the bytes are authoritative.)
        val bytes = PodCommand.TimeSync(1787653632L).encode()
        assertEquals(listOf(0x03, 0x00, 0x6E, 0x8D, 0x6A), bytes.map { it.toInt() and 0xFF })
    }

    @Test
    fun hapticAndReplayAndFormat_matchSpecExamples() {
        assertEquals(listOf(0x04, 0xFA, 0x00), PodCommand.HapticTest(250).encode().map { it.toInt() and 0xFF })
        assertEquals(listOf(0x06, 0x03), PodCommand.ReplaySlot(3).encode().map { it.toInt() and 0xFF })
        assertEquals(listOf(0x08, 0xA5, 0x5A), PodCommand.FormatFlash.encode().map { it.toInt() and 0xFF })
    }

    @Test
    fun liveVitals_roundTrip_signedTemperature() {
        val v = LiveVitals(
            tS = 3600, hrBpm = 64, hrQuality = 88, skinTempX100 = -150, skinRhX100 = 6250,
            ambTempX100 = 2105, ambRhX100 = 4400, motionIndex = 12, sleepState = SleepState.DEEP,
            sweatFlag = SweatFlag.START, battPct = 77, flags = PodFlags.LOGGING or PodFlags.TIME_SYNCED,
        )
        val parsed = LiveVitals.parse(v.encode())
        assertEquals(v, parsed)
        assertEquals(-1.5f, parsed.skinTempC, 0.001f)
        assertTrue(parsed.logging && parsed.timeSynced)
    }

    @Test
    fun logRecord_crcVerifiedAndCorruptionDropped() {
        val rec = sampleRecord(tS = 30)
        val bytes = rec.encode()
        assertEquals(34, bytes.size)
        assertNotNull(LogRecord.parse(bytes))
        bytes[7] = (bytes[7].toInt() xor 0x10).toByte() // flip a temperature bit
        assertNull("corrupted record must be dropped", LogRecord.parse(bytes))
    }

    @Test
    fun hrvGate_onlyValidFlag() {
        val bad = HrvSummary(600, 900, 452, 452, 20, 90, 3, 80, HrvFlags.MOTION)
        val good = bad.copy(flags = HrvFlags.VALID or HrvFlags.WALL_CLOCK)
        assertFalse(bad.isValid)
        assertTrue(good.isValid)
        assertEquals(45.2f, good.rmssdMs, 0.001f)
        assertEquals(good, HrvSummary.parse(good.encode()))
    }

    @Test
    fun replay_reassemblesMisalignedFrames_andDerivesRecordSize() {
        val records = (0 until 25).map { sampleRecord(tS = it * 30L) }
        val image = records.fold(ByteArray(0)) { acc, r -> acc + r.encode() }
        val frames = ReplayAssembler.frames(slot = 5, recordBytes = image, recordCount = records.size)
        val asm = ReplayAssembler()
        var finished: ReplayAssembler.Result? = null
        frames.forEach { f ->
            when (val ev = asm.feed(f)) {
                is ReplayAssembler.Event.HeaderReceived -> {
                    assertEquals(34, ev.header.recordSize)
                    assertEquals(5, ev.header.slot)
                }
                is ReplayAssembler.Event.Finished -> finished = ev.result
                is ReplayAssembler.Event.Error -> throw AssertionError(ev.message)
                is ReplayAssembler.Event.Data -> Unit
            }
        }
        val r = finished ?: throw AssertionError("no end frame")
        assertTrue(r.complete)
        assertEquals(25, r.records.size)
        assertEquals(0, r.crcFailures)
        assertEquals(records, r.records)
    }

    @Test
    fun replay_flagsOlderRecordFormatInsteadOfMisparsing() {
        val image = ByteArray(24 * 10)
        val frames = ReplayAssembler.frames(0, image, 10) // 24-byte records: earlier build
        val asm = ReplayAssembler()
        var result: ReplayAssembler.Result? = null
        frames.forEach { f -> (asm.feed(f) as? ReplayAssembler.Event.Finished)?.let { result = it.result } }
        assertTrue(result!!.unsupportedFormat)
        assertTrue(result!!.records.isEmpty())
    }

    @Test
    fun extendedVitals_roundTrip_andValidGating() {
        val v = ExtendedVitals(tS = 7200, edaX100 = 435, spo2X10 = 968, perfusionX100 = 210, extFlags = ExtFlags.EDA_VALID or ExtFlags.PI_VALID)
        val bytes = v.encode()
        assertEquals(20, bytes.size)
        assertEquals(v, ExtendedVitals.parse(bytes))
        // A field is shown ONLY when its VALID bit is set (brief §1).
        assertEquals(4.35f, v.edaUs!!, 0.001f)
        assertNull("SPO2_VALID not set — must not surface a number", v.spo2Pct)
        assertEquals(2.10f, v.perfusionPct!!, 0.001f)
        // Wrong length → null, not an exception (brief §1).
        assertNull(ExtendedVitals.parse(ByteArray(11)))
    }

    @Test
    fun logRecordV2_roundTrip_crcCorruptionDropped_v1StillParses() {
        val v2 = sampleRecord(tS = 60).copy(
            edaX100 = 812, spo2X10 = 955, perfusionX100 = 320,
            extFlags = ExtFlags.EDA_VALID or ExtFlags.SPO2_VALID or ExtFlags.PI_VALID,
        )
        val bytes = v2.encode()
        assertEquals(42, bytes.size)
        assertEquals(v2, LogRecord.parse(bytes, 0, LogRecord.SIZE_V2))
        assertEquals(8.12f, v2.edaUs!!, 0.001f)
        // CRC now sits at bytes 40–41 and covers 0–39: corruption anywhere must drop the record.
        val corrupt = bytes.copyOf().also { it[35] = (it[35].toInt() xor 0x01).toByte() } // spo2 byte
        assertNull("corrupted v2 record must be dropped", LogRecord.parse(corrupt, 0, LogRecord.SIZE_V2))
        // Unsupported size → null, never a misparse.
        assertNull(LogRecord.parse(bytes, 0, 38))
        // v1 records are untouched by the extension: 34 B, ext fields absent.
        val v1 = sampleRecord(tS = 90)
        val v1Bytes = v1.encode()
        assertEquals(34, v1Bytes.size)
        val parsed = LogRecord.parse(v1Bytes)!!
        assertEquals(v1, parsed)
        assertFalse(parsed.hasExt)
        assertNull(parsed.edaUs)
    }

    @Test
    fun replay_reassembles42ByteRecords_andDerivesSize() {
        val ext = ExtFlags.EDA_VALID or ExtFlags.SPO2_VALID or ExtFlags.PI_VALID
        val records = (0 until 25).map {
            sampleRecord(tS = it * 30L).copy(edaX100 = 300 + it, spo2X10 = 970, perfusionX100 = 180, extFlags = ext)
        }
        val image = records.fold(ByteArray(0)) { acc, r -> acc + r.encode() }
        val frames = ReplayAssembler.frames(slot = 2, recordBytes = image, recordCount = records.size)
        val asm = ReplayAssembler()
        var finished: ReplayAssembler.Result? = null
        frames.forEach { f ->
            when (val ev = asm.feed(f)) {
                is ReplayAssembler.Event.HeaderReceived -> assertEquals(42, ev.header.recordSize)
                is ReplayAssembler.Event.Finished -> finished = ev.result
                is ReplayAssembler.Event.Error -> throw AssertionError(ev.message)
                is ReplayAssembler.Event.Data -> Unit
            }
        }
        val r = finished ?: throw AssertionError("no end frame")
        assertTrue(r.complete)
        assertFalse(r.unsupportedFormat)
        assertEquals(0, r.crcFailures)
        assertEquals(records, r.records)
    }

    @Test
    fun sessionSummary_roundTrip() {
        val s = SessionSummary(28800, 960, 4, 720, 655, 61, 52, 88, 12, 55, 33, 64, 9)
        assertEquals(s, SessionSummary.parse(s.encode()))
        assertEquals(6.55f, s.peakDah, 0.001f)
    }

    private fun sampleRecord(tS: Long) = LogRecord(
        tS = tS, hrBpm = 60, hrQuality = 85, skinTempX100 = 3340, skinRhX100 = 4500,
        ambTempX100 = 2100, ambRhX100 = 4200, motionIndex = 5, sleepState = SleepState.LIGHT,
        sweatFlag = SweatFlag.NONE, battPct = 80, flags = PodFlags.LOGGING or PodFlags.TIME_SYNCED,
        dahX100 = 120, hrvMeanIbiMs = 1000, hrvSdnnMsX10 = 500, hrvRmssdMsX10 = 420,
        hrvPnn50Pct = 25, hrvQuality = 90, hrvFlags = HrvFlags.VALID, vcellCv = 130,
    )
}
