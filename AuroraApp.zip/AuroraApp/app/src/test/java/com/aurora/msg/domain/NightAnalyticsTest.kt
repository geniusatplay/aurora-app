package com.aurora.msg.domain

import com.aurora.msg.protocol.ExtFlags
import com.aurora.msg.protocol.HrvFlags
import com.aurora.msg.protocol.LogRecord
import com.aurora.msg.protocol.PodFlags
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.protocol.SweatFlag
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Bundle detection and pattern flags (brief §3) on hand-built synthetic nights, so every
 * threshold is exercised deliberately rather than through the demo simulator's noise.
 */
class NightAnalyticsTest {

    private val allValid = ExtFlags.EDA_VALID or ExtFlags.SPO2_VALID or ExtFlags.PI_VALID

    /** One quiet 30 s epoch: light sleep, HR 58, 33.4 °C, EDA 3.0 µS, SpO2 96.8 %. */
    private fun epoch(
        i: Int,
        hr: Int = 58,
        tempX100: Int = 3340,
        edaX100: Int = 300,
        spo2X10: Int = 968,
        sleep: SleepState = SleepState.LIGHT,
        motion: Int = 5,
        sweat: SweatFlag = SweatFlag.NONE,
        ambTempX100: Int = 2100,
        ambRhX100: Int = 4200,
    ) = LogRecord(
        tS = i * 30L, hrBpm = hr, hrQuality = 85, skinTempX100 = tempX100, skinRhX100 = 4500,
        ambTempX100 = ambTempX100, ambRhX100 = ambRhX100, motionIndex = motion, sleepState = sleep,
        sweatFlag = sweat, battPct = 80, flags = PodFlags.LOGGING, dahX100 = 120,
        hrvMeanIbiMs = 1000, hrvSdnnMsX10 = 500, hrvRmssdMsX10 = 420, hrvPnn50Pct = 25,
        hrvQuality = 90, hrvFlags = HrvFlags.VALID, vcellCv = 130,
        edaX100 = edaX100, spo2X10 = spo2X10, perfusionX100 = 200, extFlags = allValid,
    )

    /**
     * Two obvious bundles (sweat + temp + HR) and one sweat-ONLY spike that lacks the
     * temperature/HR confirmation — the spike must NOT count (a blanket is not a flash).
     */
    private fun syntheticNight(): List<LogRecord> = (0 until 200).map { i ->
        when (i) {
            // Bundle 1: epochs 40–45. EDA +5 µS; temp +0.6 °C and HR +15 confirm; a wake inside.
            in 40..45 -> epoch(
                i, edaX100 = 800,
                tempX100 = if (i >= 41) 3400 else 3340,
                hr = if (i >= 42) 73 else 58,
                sleep = if (i == 44) SleepState.WAKE else SleepState.LIGHT,
            )
            // Bundle 2: epochs 100–107. EDA +6 µS; temp +0.8 °C and HR +20 confirm; NO wake.
            in 100..107 -> epoch(i, edaX100 = 900, tempX100 = 3420, hr = 78)
            // Sweat-only spike: epochs 160–163. Same EDA rise but temp and HR stay flat.
            in 160..163 -> epoch(i, edaX100 = 900)
            else -> epoch(i)
        }
    }

    @Test
    fun detectBundles_confirmsTwo_rejectsSweatOnlySpike() {
        val bundles = NightAnalytics.detectBundles(syntheticNight())
        assertEquals("temp/HR must confirm a sweat spike before it counts", 2, bundles.size)

        val b1 = bundles[0]
        assertEquals(40 * 30L, b1.startTs)
        assertEquals(46 * 30L, b1.endTs) // span end is exclusive: last elevated epoch + 30 s
        assertEquals(500, b1.peakEdaDeltaX100) // 8.0 − 3.0 µS over the pre-onset baseline
        assertTrue(b1.tempDeltaX100 >= 30)
        assertTrue(b1.hrDelta >= 8)
        assertTrue("wake epoch inside the bundle", b1.hadWake)
        assertFalse("3 min is no long soak", b1.longSoak)

        val b2 = bundles[1]
        assertEquals(100 * 30L, b2.startTs)
        assertEquals(600, b2.peakEdaDeltaX100)
        assertFalse("no wake and no motion near bundle 2", b2.hadWake)
    }

    @Test
    fun detectBundles_emptyAndQuietNights() {
        assertTrue(NightAnalytics.detectBundles(emptyList()).isEmpty())
        assertTrue(NightAnalytics.detectBundles((0 until 100).map { epoch(it) }).isEmpty())
    }

    @Test
    fun detectBundles_mergesSpansWithShortGap() {
        // Two elevated spans 10 epochs apart (< 20-epoch merge gap) = ONE event that dipped.
        val records = (0 until 120).map { i ->
            when (i) {
                in 50..54 -> epoch(i, edaX100 = 800, tempX100 = 3400, hr = 73)
                in 65..69 -> epoch(i, edaX100 = 800, tempX100 = 3400, hr = 73)
                else -> epoch(i)
            }
        }
        val bundles = NightAnalytics.detectBundles(records)
        assertEquals(1, bundles.size)
        assertEquals(50 * 30L, bundles[0].startTs)
        assertEquals(70 * 30L, bundles[0].endTs)
    }

    @Test
    fun detectBundles_v1FallbackUsesSweatFlags() {
        // No ext channel at all: records are v1-shaped; the sweat_flag span drives the onset.
        val records = (0 until 120).map { i ->
            when (i) {
                50 -> epoch(i, sweat = SweatFlag.START, tempX100 = 3400, hr = 73).copy(edaX100 = null, spo2X10 = null, perfusionX100 = null, extFlags = null)
                in 51..55 -> epoch(i, sweat = SweatFlag.ONGOING, tempX100 = 3400, hr = 73).copy(edaX100 = null, spo2X10 = null, perfusionX100 = null, extFlags = null)
                else -> epoch(i).copy(edaX100 = null, spo2X10 = null, perfusionX100 = null, extFlags = null)
            }
        }
        val bundles = NightAnalytics.detectBundles(records)
        assertEquals(1, bundles.size)
        assertEquals("v1 has no conductance channel — delta is 0 by definition", 0, bundles[0].peakEdaDeltaX100)
    }

    @Test
    fun nightScore_boundaries() {
        fun bundle(longSoak: Boolean = false) =
            FlashBundle(startTs = 0, endTs = 300, peakEdaDeltaX100 = 400, tempDeltaX100 = 50, hrDelta = 10, hadWake = false, longSoak = longSoak)
        assertEquals(NightScore.QUIET, NightAnalytics.nightScore(emptyList()))
        assertEquals(NightScore.QUIET, NightAnalytics.nightScore(List(1) { bundle() }))
        assertEquals(NightScore.MILD, NightAnalytics.nightScore(List(2) { bundle() }))
        assertEquals(NightScore.MILD, NightAnalytics.nightScore(List(4) { bundle() }))
        assertEquals(NightScore.MEANINGFUL, NightAnalytics.nightScore(List(5) { bundle() }))
        // Any long soak promotes the night regardless of count.
        assertEquals(NightScore.MEANINGFUL, NightAnalytics.nightScore(listOf(bundle(longSoak = true))))
    }

    @Test
    fun notFlashPattern_hrUpO2DownNoSweat_setsFlag() {
        // Three separate 5-min windows: HR +12 bpm, SpO2 −4 %, EDA flat → not-a-flash pattern.
        val records = (0 until 150).map { i ->
            when (i) {
                in 40..49, in 70..79, in 100..109 -> epoch(i, hr = 70, spo2X10 = 928)
                else -> epoch(i)
            }
        }
        val flags = NightAnalytics.nightFlags(records)
        assertTrue(flags.notFlashPattern)
        assertFalse(flags.warmRoom)
        assertFalse(flags.allNightHighHr)
    }

    @Test
    fun notFlashPattern_notRaisedWithoutO2Drop_orWithSweat() {
        // HR rises alone (no desaturation) — flag must stay down.
        val hrOnly = (0 until 150).map { i ->
            if (i in 40..49 || i in 70..79 || i in 100..109) epoch(i, hr = 70) else epoch(i)
        }
        assertFalse(NightAnalytics.nightFlags(hrOnly).notFlashPattern)
        // Same windows but sweat is elevated too — that is flash territory, not this flag.
        val withSweat = (0 until 150).map { i ->
            if (i in 40..49 || i in 70..79 || i in 100..109) epoch(i, hr = 70, spo2X10 = 928, edaX100 = 800) else epoch(i)
        }
        assertFalse(NightAnalytics.nightFlags(withSweat).notFlashPattern)
    }

    @Test
    fun warmRoom_andAllNightHighHr() {
        val warm = (0 until 100).map { i -> epoch(i, ambTempX100 = if (i < 60) 2700 else 2100) }
        assertTrue(NightAnalytics.nightFlags(warm).warmRoom)
        val rising = (0 until 90).map { i -> epoch(i, hr = if (i >= 60) 70 else 58) }
        assertTrue(NightAnalytics.nightFlags(rising).allNightHighHr)
    }

    @Test
    fun quietVsEvent_splitsChannelsByBundleSpans() {
        val records = syntheticNight()
        val bundles = NightAnalytics.detectBundles(records)
        val cmp = NightAnalytics.quietVsEvent(records, bundles)
        assertEquals(58f, cmp.hrBpm.quietMedian!!, 0.01f)
        assertNotNull(cmp.hrBpm.eventMedian)
        assertTrue("HR runs higher inside bundles", cmp.hrBpm.eventMedian!! > cmp.hrBpm.quietMedian!!)
        assertEquals(3.0f, cmp.edaUs.quietMedian!!, 0.05f)
        assertTrue(cmp.edaUs.eventPeak!! >= 8f)
        // v1 night: ext channels must come back null on both sides, so the sheet skips the rows.
        val v1 = records.map { it.copy(edaX100 = null, spo2X10 = null, perfusionX100 = null, extFlags = null) }
        val v1Cmp = NightAnalytics.quietVsEvent(v1, NightAnalytics.detectBundles(v1))
        assertTrue(v1Cmp.edaUs.isEmpty)
        assertTrue(v1Cmp.spo2Pct.isEmpty)
        assertNull(v1Cmp.perfusionPct.eventPeak)
        assertFalse(v1Cmp.hrBpm.isEmpty)
    }
}
