package com.aurora.msg.pod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LinkRecorderTest {

    @Test fun countsPacketsCrcFailuresGapsAndRate() {
        var t = 0L
        val r = LinkRecorder { t }
        assertNull(r.stats.value.rateHz)
        // 8-bit FE01 sequence counter with two holes (252; 1 and 2) across the wrap.
        for (seq in listOf(250, 251, 253, 254, 255, 0, 3)) {
            t += 1000
            r.record("FE01", byteArrayOf(0xA1.toByte(), seq.toByte()), true, RawPacketKind.Vitals(seq, null, null, null),
                seq = seq, counted = LinkRecorder.Counted.VITALS)
        }
        r.record("FE05", byteArrayOf(0xA5.toByte()), true, RawPacketKind.Hrv(400, 12), counted = LinkRecorder.Counted.HRV)
        r.record("FE01", byteArrayOf(0x00), false, RawPacketKind.Invalid("vitals CRC mismatch"))
        val s = r.stats.value
        assertEquals(8, s.packets)
        assertEquals(7, s.vitalsPackets)
        assertEquals(1, s.hrvPackets)
        assertEquals(1, s.crcFailures)
        assertEquals(3, s.seqGaps)
        assertEquals(1.0, s.rateHz!!, 1e-9)
        assertEquals(7000L, s.lastPacketAtMs)
    }

    @Test fun ringKeepsTheLastFiftyNewestLast() {
        val r = LinkRecorder { 0L }
        repeat(60) { r.record("FE04", byteArrayOf(it.toByte(), 0x0A), true, RawPacketKind.Replay(it)) }
        val ring = r.packets.value
        assertEquals(LinkRecorder.RING_CAPACITY, ring.size)
        assertEquals("3B 0A", ring.last().hex)
        assertEquals(RawPacketKind.Replay(10), ring.first().decoded)
    }

    @Test fun resetClearsEverything() {
        val r = LinkRecorder { 0L }
        r.record("FE01", byteArrayOf(1), true, RawPacketKind.Vitals(1, 60f, 1234, 3300), seq = 1, counted = LinkRecorder.Counted.VITALS)
        r.reset()
        assertEquals(LinkStats(), r.stats.value)
        assertEquals(0, r.packets.value.size)
        // After a reset the first sequence number is not compared with the old one.
        r.record("FE01", byteArrayOf(1), true, RawPacketKind.Vitals(90, null, null, null), seq = 90, counted = LinkRecorder.Counted.VITALS)
        assertEquals(0, r.stats.value.seqGaps)
    }
}
