package com.aurora.msg.data.repo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomPagesModelTest {

    private val m = CustomPagesModel

    @Test fun catalogueHasThirtyUniqueIds() {
        assertEquals(30, m.KNOWN_SECTION_IDS.size)
        assertEquals(30, m.KNOWN_SECTION_IDS.toSet().size)
        assertTrue(m.isKnown("live_hr"))
        assertTrue(m.isKnown("hardware_check"))
        assertFalse(m.isKnown("future_section"))
    }

    @Test fun createsLowestUnusedNumberUpToFive() {
        var pages = emptyList<CustomPage>()
        for (expected in 1..5) {
            val c = m.createNextPage(pages)!!
            assertEquals(expected, c.n)
            pages = c.pages
        }
        assertNull(m.createNextPage(pages))
        assertFalse(m.canCreatePage(pages))
        pages = m.deletePage(pages, 2)
        assertTrue(m.canCreatePage(pages))
        val c = m.createNextPage(pages)!!
        assertEquals(2, c.n)
        assertEquals(listOf(1, 2, 3, 4, 5), c.pages.map { it.n })
    }

    @Test fun addIsUniquePerPageButAllowedOnSeveralPages() {
        var pages = m.createNextPage(emptyList())!!.pages
        pages = m.createNextPage(pages)!!.pages
        pages = m.addSection(pages, 1, "live_hr")
        pages = m.addSection(pages, 1, "live_hr")
        pages = m.addSection(pages, 1, "night_timeline")
        pages = m.addSection(pages, 2, "live_hr")
        assertEquals(listOf("live_hr", "night_timeline"), m.page(pages, 1)!!.sections)
        assertEquals(listOf("live_hr"), m.page(pages, 2)!!.sections)
        // Adding to a missing page changes nothing
        assertEquals(pages, m.addSection(pages, 4, "live_hr"))
    }

    @Test fun removeSection() {
        var pages = listOf(CustomPage(1, listOf("live_hr", "pod_info", "last_night")))
        pages = m.removeSection(pages, 1, "pod_info")
        assertEquals(listOf("live_hr", "last_night"), pages[0].sections)
        assertEquals(pages, m.removeSection(pages, 1, "absent"))
    }

    @Test fun moveDownAndUp() {
        val pages = listOf(CustomPage(1, listOf("a_live_hr", "b", "c", "d").map { it }))
        val known: (String) -> Boolean = { true }
        assertEquals(listOf("b", "c", "a_live_hr", "d"), m.moveSection(pages, 1, 0, 2, known)[0].sections)
        assertEquals(listOf("d", "a_live_hr", "b", "c"), m.moveSection(pages, 1, 3, 0, known)[0].sections)
        // clamped target, ignored source
        assertEquals(listOf("b", "c", "d", "a_live_hr"), m.moveSection(pages, 1, 0, 99, known)[0].sections)
        assertEquals(pages, m.moveSection(pages, 1, 7, 0, known))
        assertEquals(pages, m.moveSection(pages, 1, 1, 1, known))
    }

    @Test fun unknownIdsKeepTheirSlotsWhenMoving() {
        val pages = listOf(CustomPage(1, listOf("live_hr", "future_x", "pod_info", "last_night")))
        // visible = [live_hr, pod_info, last_night]; move live_hr to the end
        val out = m.moveSection(pages, 1, 0, 2)
        assertEquals(listOf("pod_info", "future_x", "last_night", "live_hr"), out[0].sections)
        assertEquals(listOf("pod_info", "last_night", "live_hr"), m.visibleSections(out[0]))
    }

    @Test fun moveByDelta() {
        val pages = listOf(CustomPage(1, listOf("live_hr", "pod_info", "last_night")))
        assertEquals(listOf("pod_info", "live_hr", "last_night"), m.moveSectionBy(pages, 1, "live_hr", 1)[0].sections)
        assertEquals(listOf("live_hr", "last_night", "pod_info"), m.moveSectionBy(pages, 1, "last_night", -1)[0].sections)
        assertEquals(pages, m.moveSectionBy(pages, 1, "live_hr", -1))
        assertEquals(pages, m.moveSectionBy(pages, 1, "last_night", 1))
    }

    @Test fun encodeShape() {
        val pages = listOf(CustomPage(2, listOf("pod_info")), CustomPage(1, listOf("live_hr", "night_timeline")))
        assertEquals("""[{"n":1,"sections":["live_hr","night_timeline"]},{"n":2,"sections":["pod_info"]}]""", m.encode(pages))
        assertEquals("[]", m.encode(emptyList()))
        assertEquals("""[{"n":3,"sections":[]}]""", m.encode(listOf(CustomPage(3))))
    }

    @Test fun roundTripKeepsUnknownIds() {
        val pages = listOf(CustomPage(1, listOf("live_hr", "from_a_newer_version", "quote\"back\\slash")), CustomPage(5))
        assertEquals(pages, m.decode(m.encode(pages)))
    }

    @Test fun decodeIsTolerant() {
        val json = """
            [ {"sections": ["pod_info", "pod_info", 7, null], "n": 3, "extra": {"x": [1, true]}},
              {"n": 1},
              {"n": 1, "sections": ["dup"]},
              {"n": 0, "sections": []}, {"n": 6}, {"n": 2.5}, "junk", 4,
              {"n": 2.0, "sections": ["live_hr"]} ]
        """
        val pages = m.decode(json)
        assertEquals(listOf(CustomPage(1), CustomPage(2, listOf("live_hr")), CustomPage(3, listOf("pod_info"))), pages)
    }

    @Test fun decodeGarbageIsEmpty() {
        assertEquals(emptyList<CustomPage>(), m.decode(null))
        assertEquals(emptyList<CustomPage>(), m.decode(""))
        assertEquals(emptyList<CustomPage>(), m.decode("{\"n\":1}"))
        assertEquals(emptyList<CustomPage>(), m.decode("[{\"n\":1,"))
        assertEquals(emptyList<CustomPage>(), m.decode("[1] trailing"))
        assertEquals(emptyList<CustomPage>(), m.decode("not json"))
    }

    @Test fun nextPageNumberFillsGaps() {
        assertEquals(1, m.nextPageNumber(emptyList()))
        assertEquals(2, m.nextPageNumber(listOf(CustomPage(1), CustomPage(3))))
        assertNull(m.nextPageNumber((1..5).map { CustomPage(it) }))
    }
}
