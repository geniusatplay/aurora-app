package com.aurora.msg.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.aurora.msg.data.repo.ThemeMode

/* ------------------------------------------------------------------ Aurora Pink system */

object Aurora {
    val Blossom = Color(0xFFFFE3EE)   // page background tint
    val Petal = Color(0xFFFFB8D1)     // chips, secondary surfaces
    val Rose = Color(0xFFFF6FA6)      // primary accent
    val Fuchsia = Color(0xFFE8308A)   // hero / emphasis / primary series
    val Magenta = Color(0xFFB3125F)   // pressed / gradient stop
    val Plum = Color(0xFF5E0A3A)      // deep accent text
    val Ink = Color(0xFF17111A)       // black accent
    val Cloud = Color(0xFFFFFFFF)
    val Mist = Color(0xFFF7F2F5)
    val Ash = Color(0xFF5A4F5C)       // secondary text (6.9:1 on white)
    val DarkCard = Color(0xFF241826)
    val DarkBg = Color(0xFF15101A)

    // Chart series (validated: Fuchsia ↔ Periwinkle pass CVD separation in light & dark)
    val SeriesSkin = Fuchsia
    val SeriesAmbient = Color(0xFF5B6ECF)
    val SeriesSweat = Rose
    val SeriesHeart = Ink
    val SeriesHrv = Color(0xFF7A1F5C)
    val SeriesMotion = Color(0xFFB98BA8)
    // Extended-sensor channels (brief §6, validated hues; colour follows the entity, never the scheme)
    val SeriesConductance = Color(0xFF0F8C6C)      // light
    val SeriesConductanceDark = Color(0xFF1FA07F)
    val SeriesBloodFlow = Color(0xFFC97B1B)        // light
    val SeriesBloodFlowDark = Color(0xFFC27C22)
    val SeriesOxygen = Color(0xFF7A4FBF)           // light
    val SeriesOxygenDark = Color(0xFF9668D8)
    // Sleep — ordinal, one hue light → dark
    val SleepWake = Color(0xFFFFD6E4)
    val SleepLight = Color(0xFFFF8DB8)
    val SleepDeep = Color(0xFF8E1352)
    val SleepUnknown = Color(0xFFE6DDE2)

    val Good = Color(0xFF1F8A5A)
    val Warn = Color(0xFFB8740A)
    val Bad = Color(0xFFC62840)

    val HeroGradient = Brush.linearGradient(listOf(Color(0xFFFF7FB4), Fuchsia, Magenta))
    val SoftGradient = Brush.verticalGradient(listOf(Color(0xFFFFEEF4), Blossom))

    /** High-contrast hero: solid deep magenta → plum (no pastel stop, white text ≥ 7:1). */
    val ContrastGradient = Brush.linearGradient(listOf(Magenta, Plum))
    /** Light theme hero: still pink, but on a clean white page. */
    val LightGradient = Brush.linearGradient(listOf(Color(0xFFFF8DB8), Fuchsia, Color(0xFFC81A6F)))
}

/** Chart colours that adapt to theme. */
data class ChartColors(
    val grid: Color,
    val axisText: Color,
    val plotSurface: Color,
    val tooltipBg: Color,
    val tooltipText: Color,
    val heart: Color,
    /** Extended-sensor channels — light/dark variants of the same hue; high contrast keeps the light hues (its bolder treatment comes from strokes). */
    val conductance: Color = Aurora.SeriesConductance,
    val bloodFlow: Color = Aurora.SeriesBloodFlow,
    val oxygen: Color = Aurora.SeriesOxygen,
)

/** Extra theme tokens the Material scheme doesn't carry. */
data class AuroraExtras(
    val heroBrush: Brush,
    val pillBg: Color,
    val pillFg: Color,
    val track: Color,
    val highContrast: Boolean,
)

val LocalChartColors = staticCompositionLocalOf {
    ChartColors(
        grid = Color(0x22000000), axisText = Aurora.Ash, plotSurface = Aurora.Cloud,
        tooltipBg = Aurora.Ink, tooltipText = Aurora.Cloud, heart = Aurora.Ink,
    )
}

val LocalAuroraExtras = staticCompositionLocalOf {
    AuroraExtras(Aurora.HeroGradient, Aurora.Petal, Aurora.Plum, Aurora.Mist, false)
}

/** Convenience accessor: `AuroraThemeExtras.heroBrush` etc. */
val AuroraThemeExtras: AuroraExtras
    @Composable get() = LocalAuroraExtras.current

/* ------------------------------------------------------------------ schemes */

private val PinkLight: ColorScheme = lightColorScheme(
    primary = Aurora.Fuchsia, onPrimary = Aurora.Cloud,
    primaryContainer = Aurora.Petal, onPrimaryContainer = Aurora.Plum,
    secondary = Aurora.Rose, onSecondary = Aurora.Cloud,
    secondaryContainer = Color(0xFFFFD1E1), onSecondaryContainer = Aurora.Plum,
    tertiary = Aurora.Plum, onTertiary = Aurora.Cloud,
    tertiaryContainer = Color(0xFFF3D7E6), onTertiaryContainer = Aurora.Plum,
    background = Aurora.Blossom, onBackground = Aurora.Ink,
    surface = Aurora.Cloud, onSurface = Aurora.Ink,
    surfaceVariant = Aurora.Mist, onSurfaceVariant = Aurora.Ash,
    outline = Color(0xFFD9C3CE), outlineVariant = Color(0xFFEFDDE6),
    error = Aurora.Bad, onError = Aurora.Cloud,
    errorContainer = Color(0xFFFFDAD9), onErrorContainer = Color(0xFF5A0010),
    inverseSurface = Aurora.Ink, inverseOnSurface = Aurora.Cloud,
    surfaceContainer = Color(0xFFFFF4F8), surfaceContainerHigh = Color(0xFFFFEAF1),
    surfaceContainerLow = Color(0xFFFFF8FA), surfaceContainerLowest = Aurora.Cloud,
)

private val PinkDark: ColorScheme = darkColorScheme(
    primary = Aurora.Rose, onPrimary = Aurora.Ink,
    primaryContainer = Aurora.Magenta, onPrimaryContainer = Aurora.Blossom,
    secondary = Aurora.Petal, onSecondary = Aurora.Ink,
    secondaryContainer = Color(0xFF4A2038), onSecondaryContainer = Aurora.Blossom,
    tertiary = Aurora.Petal, onTertiary = Aurora.Ink,
    tertiaryContainer = Color(0xFF3B1830), onTertiaryContainer = Aurora.Blossom,
    background = Aurora.DarkBg, onBackground = Color(0xFFF7E9F0),
    surface = Aurora.DarkCard, onSurface = Color(0xFFF7E9F0),
    surfaceVariant = Color(0xFF32222F), onSurfaceVariant = Color(0xFFD9C6D0),
    outline = Color(0xFF6B5262), outlineVariant = Color(0xFF3E2B38),
    error = Color(0xFFFF7A8A), onError = Aurora.Ink,
    errorContainer = Color(0xFF5A1A24), onErrorContainer = Color(0xFFFFDAD9),
    inverseSurface = Aurora.Blossom, inverseOnSurface = Aurora.Ink,
    surfaceContainer = Color(0xFF2B1C2A), surfaceContainerHigh = Color(0xFF33222F),
    surfaceContainerLow = Color(0xFF1E1420), surfaceContainerLowest = Aurora.DarkBg,
)

/** Clean light theme: white page, soft grey cards, pink accents. */
private val CleanLight: ColorScheme = lightColorScheme(
    primary = Color(0xFFD1206F), onPrimary = Aurora.Cloud,
    primaryContainer = Color(0xFFFFD9E6), onPrimaryContainer = Aurora.Plum,
    secondary = Color(0xFF7A1F5C), onSecondary = Aurora.Cloud,
    secondaryContainer = Color(0xFFF1E4EB), onSecondaryContainer = Aurora.Plum,
    tertiary = Aurora.Plum, onTertiary = Aurora.Cloud,
    tertiaryContainer = Color(0xFFEFE3EA), onTertiaryContainer = Aurora.Plum,
    background = Color(0xFFFAFAFB), onBackground = Color(0xFF1B1B1F),
    surface = Aurora.Cloud, onSurface = Color(0xFF1B1B1F),
    surfaceVariant = Color(0xFFF1F0F3), onSurfaceVariant = Color(0xFF4B4650),
    outline = Color(0xFFC9C4CC), outlineVariant = Color(0xFFE6E2E8),
    error = Aurora.Bad, onError = Aurora.Cloud,
    errorContainer = Color(0xFFFFDAD9), onErrorContainer = Color(0xFF5A0010),
    inverseSurface = Color(0xFF2E2A30), inverseOnSurface = Aurora.Cloud,
    surfaceContainer = Color(0xFFF4F3F6), surfaceContainerHigh = Color(0xFFEEEDF1),
    surfaceContainerLow = Color(0xFFF9F8FA), surfaceContainerLowest = Aurora.Cloud,
)

/** High contrast: pure black on white, strong outlines, deep accents (all text ≥ 7:1). */
private val HighContrast: ColorScheme = lightColorScheme(
    primary = Color(0xFF9E0A52), onPrimary = Aurora.Cloud,
    primaryContainer = Color(0xFFFFC6DB), onPrimaryContainer = Color(0xFF000000),
    secondary = Color(0xFF3E0A2A), onSecondary = Aurora.Cloud,
    secondaryContainer = Color(0xFFFFE0EC), onSecondaryContainer = Color(0xFF000000),
    tertiary = Color(0xFF000000), onTertiary = Aurora.Cloud,
    tertiaryContainer = Color(0xFFEFEFEF), onTertiaryContainer = Color(0xFF000000),
    background = Aurora.Cloud, onBackground = Color(0xFF000000),
    surface = Aurora.Cloud, onSurface = Color(0xFF000000),
    surfaceVariant = Color(0xFFF2F2F2), onSurfaceVariant = Color(0xFF1A1A1A),
    outline = Color(0xFF000000), outlineVariant = Color(0xFF6A6A6A),
    error = Color(0xFFA0001E), onError = Aurora.Cloud,
    errorContainer = Color(0xFFFFD6D9), onErrorContainer = Color(0xFF000000),
    inverseSurface = Color(0xFF000000), inverseOnSurface = Aurora.Cloud,
    surfaceContainer = Color(0xFFF5F5F5), surfaceContainerHigh = Color(0xFFEBEBEB),
    surfaceContainerLow = Color(0xFFFAFAFA), surfaceContainerLowest = Aurora.Cloud,
)

/* ------------------------------------------------------------------ type */

/**
 * Small text is deliberately heavier and a point larger than Material defaults:
 * labels/captions were hard to read on pink surfaces.
 */
val AuroraTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 56.sp, lineHeight = 60.sp, letterSpacing = (-1).sp),
    displayMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 44.sp, lineHeight = 48.sp, letterSpacing = (-0.5).sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.2.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.3.sp),
)

val AuroraShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

/* ------------------------------------------------------------------ theme */

@Composable
fun AuroraTheme(mode: ThemeMode = ThemeMode.AURORA, content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (mode) {
        ThemeMode.AURORA -> systemDark
        ThemeMode.DARK -> true
        ThemeMode.LIGHT, ThemeMode.HIGH_CONTRAST -> false
    }
    val scheme = when (mode) {
        ThemeMode.AURORA -> if (systemDark) PinkDark else PinkLight
        ThemeMode.DARK -> PinkDark
        ThemeMode.LIGHT -> CleanLight
        ThemeMode.HIGH_CONTRAST -> HighContrast
    }
    val chart = when {
        mode == ThemeMode.HIGH_CONTRAST -> ChartColors(
            grid = Color(0x55000000), axisText = Color(0xFF000000), plotSurface = Aurora.Cloud,
            tooltipBg = Color(0xFF000000), tooltipText = Aurora.Cloud, heart = Color(0xFF000000),
        )
        dark -> ChartColors(
            grid = Color(0x30FFFFFF), axisText = Color(0xFFD9C6D0), plotSurface = Aurora.DarkCard,
            tooltipBg = Aurora.Blossom, tooltipText = Aurora.Ink, heart = Color(0xFFF7E9F0),
            conductance = Aurora.SeriesConductanceDark, bloodFlow = Aurora.SeriesBloodFlowDark, oxygen = Aurora.SeriesOxygenDark,
        )
        else -> ChartColors(
            grid = Color(0x1F5E0A3A), axisText = Aurora.Ash, plotSurface = Aurora.Cloud,
            tooltipBg = Aurora.Ink, tooltipText = Aurora.Cloud, heart = Aurora.Ink,
        )
    }
    val extras = when (mode) {
        ThemeMode.HIGH_CONTRAST -> AuroraExtras(Aurora.ContrastGradient, Color(0xFFFFC6DB), Color(0xFF000000), Color(0xFFDDDDDD), true)
        ThemeMode.LIGHT -> AuroraExtras(Aurora.LightGradient, Color(0xFFFFD9E6), Aurora.Plum, Color(0xFFEDEDF0), false)
        else -> if (dark) AuroraExtras(Aurora.HeroGradient, Color(0xFF4A2038), Aurora.Blossom, Color(0xFF3A2A38), false)
        else AuroraExtras(Aurora.HeroGradient, Aurora.Petal, Aurora.Plum, Aurora.Mist, false)
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(LocalChartColors provides chart, LocalAuroraExtras provides extras) {
        MaterialTheme(colorScheme = scheme, typography = AuroraTypography, shapes = AuroraShapes, content = content)
    }
}
