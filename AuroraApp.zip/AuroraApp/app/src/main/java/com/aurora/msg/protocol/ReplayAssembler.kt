package com.aurora.msg.protocol

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Night-log replay reassembly — spec §9. "The part most likely to be got wrong."
 *
 *  frame = [uint16 seq][18 bytes payload]
 *  seq 0xFFFF  header : total_bytes(u32) record_count(u16) slot(u8) + 11 reserved
 *  seq 0..N    data   : next 18 bytes of the file
 *  seq 0xFFFE  end    : frames_sent(u16)
 *
 * 18 divides neither 34 (v1) nor 42 (v2): payloads are concatenated into ONE buffer and only
 * then sliced. Record size is derived from the header (total_bytes / record_count), never
 * hard-coded; 34 and 42 are the only sizes this build understands (brief §1).
 */
class ReplayAssembler {

    data class Header(val totalBytes: Long, val recordCount: Int, val slot: Int) {
        val recordSize: Int get() = if (recordCount == 0) 0 else (totalBytes / recordCount).toInt()
        val expectedFrames: Int get() = ((totalBytes + FRAME_PAYLOAD - 1) / FRAME_PAYLOAD).toInt()
    }

    data class Progress(val framesReceived: Int, val expectedFrames: Int, val bytesReceived: Int) {
        val fraction: Float get() = if (expectedFrames == 0) 0f else (framesReceived.toFloat() / expectedFrames).coerceIn(0f, 1f)
        val percent: Int get() = (fraction * 100).toInt()
    }

    data class Result(
        val header: Header,
        val records: List<LogRecord>,
        val crcFailures: Int,
        val framesReceived: Int,
        val framesSent: Int,
        val sequenceGaps: Int,
        val unsupportedFormat: Boolean,
    ) {
        val complete: Boolean get() = framesSent == framesReceived && sequenceGaps == 0
    }

    sealed class Event {
        data class HeaderReceived(val header: Header) : Event()
        data class Data(val progress: Progress) : Event()
        data class Finished(val result: Result) : Event()
        data class Error(val message: String) : Event()
    }

    var header: Header? = null
        private set
    private val buffer = ByteArrayOutputStream()
    private var framesReceived = 0
    private var nextSeq = 0
    private var sequenceGaps = 0

    val progress: Progress
        get() = Progress(framesReceived, header?.expectedFrames ?: 0, buffer.size())

    fun reset() {
        header = null
        buffer.reset()
        framesReceived = 0
        nextSeq = 0
        sequenceGaps = 0
    }

    /** Feed one 20-byte notification. Returns the event it produced. */
    fun feed(frame: ByteArray): Event {
        if (frame.size < 2) return Event.Error("Frame too short (${frame.size} B)")
        val b = ByteBuffer.wrap(frame).order(ByteOrder.LITTLE_ENDIAN)
        val seq = b.u16()
        return when (seq) {
            SEQ_HEADER -> {
                if (frame.size < 9) return Event.Error("Header frame too short")
                val total = b.u32()
                val count = b.u16()
                val slot = b.u8()
                reset()
                header = Header(total, count, slot)
                Event.HeaderReceived(header!!)
            }
            SEQ_END -> {
                val hdr = header ?: return Event.Error("End frame before header")
                val framesSent = if (frame.size >= 4) b.u16() else framesReceived
                Event.Finished(slice(hdr, framesSent))
            }
            else -> {
                if (header == null) return Event.Error("Data frame before header")
                if (seq != nextSeq) {
                    if (seq > nextSeq) sequenceGaps += (seq - nextSeq)
                }
                nextSeq = seq + 1
                val payloadLen = minOf(FRAME_PAYLOAD, frame.size - 2)
                buffer.write(frame, 2, payloadLen)
                framesReceived++
                Event.Data(progress)
            }
        }
    }

    private fun slice(hdr: Header, framesSent: Int): Result {
        val bytes = buffer.toByteArray()
        val size = hdr.recordSize
        // Firmware 1.0.0 writes 34-byte (v1) records; ext-sensor firmware writes 42-byte (v2)
        // records (brief §1). Anything else is a format this build does not understand.
        if (size != LogRecord.SIZE && size != LogRecord.SIZE_V2) {
            return Result(hdr, emptyList(), 0, framesReceived, framesSent, sequenceGaps, unsupportedFormat = true)
        }
        val records = ArrayList<LogRecord>(hdr.recordCount)
        var failures = 0
        var off = 0
        val limit = minOf(bytes.size, hdr.totalBytes.toInt())
        while (off + size <= limit) {
            val rec = LogRecord.parse(bytes, off, size)
            if (rec == null) failures++ else records.add(rec)
            off += size
        }
        return Result(hdr, records, failures, framesReceived, framesSent, sequenceGaps, unsupportedFormat = false)
    }

    companion object {
        const val SEQ_HEADER = 0xFFFF
        const val SEQ_END = 0xFFFE
        const val FRAME_SIZE = 20
        const val FRAME_PAYLOAD = 18

        /** Build the frame stream for a slot image — used by the demo simulator and tests. */
        fun frames(slot: Int, recordBytes: ByteArray, recordCount: Int): List<ByteArray> {
            val out = ArrayList<ByteArray>()
            val hdr = ByteBuffer.allocate(FRAME_SIZE).order(ByteOrder.LITTLE_ENDIAN)
            hdr.putShort(SEQ_HEADER.toShort()).putInt(recordBytes.size).putShort(recordCount.toShort()).put(slot.toByte())
            out.add(hdr.array())
            var seq = 0
            var off = 0
            while (off < recordBytes.size) {
                val f = ByteBuffer.allocate(FRAME_SIZE).order(ByteOrder.LITTLE_ENDIAN)
                f.putShort(seq.toShort())
                val n = minOf(FRAME_PAYLOAD, recordBytes.size - off)
                f.put(recordBytes, off, n)
                out.add(f.array())
                off += n
                seq++
            }
            val end = ByteBuffer.allocate(FRAME_SIZE).order(ByteOrder.LITTLE_ENDIAN)
            end.putShort(SEQ_END.toShort()).putShort(seq.toShort())
            out.add(end.array())
            return out
        }
    }
}
