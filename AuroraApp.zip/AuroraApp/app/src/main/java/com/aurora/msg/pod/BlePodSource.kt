package com.aurora.msg.pod

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.ParcelUuid
import android.util.Log
import com.aurora.msg.R
import com.aurora.msg.protocol.AuroraUuids
import com.aurora.msg.protocol.DeviceInfo
import com.aurora.msg.protocol.ExtendedVitals
import com.aurora.msg.protocol.HrvSummary
import com.aurora.msg.protocol.HwAdapter
import com.aurora.msg.protocol.LiveVitals
import com.aurora.msg.protocol.PodCapabilities
import com.aurora.msg.protocol.PodCommand
import com.aurora.msg.protocol.SessionSummary
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

/**
 * Real Aurora Pod over BLE. Phone is the central; pod is the peripheral.
 *
 * Speaks HARDWARE PROTOCOL v1 (PROTOCOL.txt, verified on hardware 2026-09-28) on the wire
 * and hands the rest of the app its internal model via [HwAdapter]: packets are CRC-checked
 * and translated here, commands are mapped to the pod's opcodes here (they differ from the
 * paper spec — e.g. 0x04 is REPLAY on the pod, not "haptic"), and the pod's RAM log replay
 * is collected, windowed to the session and re-emitted as the internal replay stream.
 *
 * Every GATT operation is serialised through [gattMutex] — Android's BLE stack drops
 * concurrent requests silently. Nothing relies on MTU negotiation (all packets ≤ 20 B).
 *
 * All permission checks are done by the UI before calling connect/scan; the
 * @SuppressLint annotations acknowledge that.
 */
@SuppressLint("MissingPermission")
class BlePodSource(private val context: Context, private val scope: CoroutineScope) : PodSource {

    override val isDemo = false

    private val manager get() = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? get() = manager.adapter

    private val _connection = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connection.asStateFlow()
    private val _scan = MutableStateFlow<List<ScannedPod>>(emptyList())
    override val scanResults: StateFlow<List<ScannedPod>> = _scan.asStateFlow()
    private val _deviceInfo = MutableStateFlow<DeviceInfo?>(null)
    override val deviceInfo: StateFlow<DeviceInfo?> = _deviceInfo.asStateFlow()
    private val _battery = MutableStateFlow<Int?>(null)
    override val batteryPct: StateFlow<Int?> = _battery.asStateFlow()

    private val _vitals = MutableSharedFlow<LiveVitals>(extraBufferCapacity = 64)
    override val vitals: SharedFlow<LiveVitals> = _vitals.asSharedFlow()
    private val _extVitals = MutableSharedFlow<ExtendedVitals>(extraBufferCapacity = 64)
    override val extVitals: SharedFlow<ExtendedVitals> = _extVitals.asSharedFlow()
    /** Set after service discovery: FE06 exists only on ext-sensor firmware (brief §1). */
    private val _hasExt = MutableStateFlow(false)
    override val hasExtendedSensors: StateFlow<Boolean> = _hasExt.asStateFlow()
    private val _hrv = MutableSharedFlow<HrvSummary>(extraBufferCapacity = 16)
    override val hrv: SharedFlow<HrvSummary> = _hrv.asSharedFlow()
    private val _summary = MutableSharedFlow<SessionSummary>(extraBufferCapacity = 4)
    override val summary: SharedFlow<SessionSummary> = _summary.asSharedFlow()
    private val _replay = MutableSharedFlow<ByteArray>(extraBufferCapacity = 4096)
    override val replayFrames: SharedFlow<ByteArray> = _replay.asSharedFlow()

    private val _caps = MutableStateFlow(PodCapabilities.NONE)
    override val capabilities: StateFlow<PodCapabilities> = _caps.asStateFlow()
    /** The pod streams its whole RAM log (≤480 frames) before we can convert and emit. */
    override val replayHeaderTimeoutMs: Long get() = 90_000L

    private val hw = HwAdapter()
    private val _replayEmpty = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    override val replayEmpty: SharedFlow<Unit> = _replayEmpty.asSharedFlow()
    @Volatile private var replayDiag: Pair<Int, Int>? = null
    override fun takeReplayDiagnostics(): Pair<Int, Int>? = replayDiag.also { replayDiag = null }
    /** Set while we STOP a leftover pod session ourselves — its FE02 must not end the app's night. */
    @Volatile private var swallowNextSummary = false
    @Volatile private var pinReadAt = 0L
    @Volatile private var replayCollecting = false
    @Volatile private var lastReplayFrameAt = 0L
    private var replayJob: Job? = null
    /** Count of dropped packets (CRC / length / header failures) — PROTOCOL: must be 0. */
    @Volatile var badPackets = 0; private set

    private var gatt: BluetoothGatt? = null
    private var scanJob: Job? = null
    private val gattMutex = Mutex()
    private var pendingWrite: CompletableDeferred<Boolean>? = null
    private var pendingRead: CompletableDeferred<ByteArray?>? = null
    private var pendingDescriptor: CompletableDeferred<Boolean>? = null
    private var servicesDiscovered: CompletableDeferred<Boolean>? = null
    private val seen = HashMap<String, ScannedPod>()

    val bluetoothEnabled: Boolean get() = adapter?.isEnabled == true

    // ------------------------------------------------------------------ scanning

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.scanRecord?.deviceName ?: result.device.name ?: AuroraUuids.ADVERTISED_NAME
            seen[result.device.address] = ScannedPod(name, result.device.address, result.rssi)
            _scan.value = seen.values.sortedByDescending { it.rssi }
        }
        override fun onScanFailed(errorCode: Int) {
            _connection.value = ConnectionState.Error(R.string.app_err_scan_failed, errorCode)
        }
    }

    override fun startScan() {
        val a = adapter
        if (a == null || !a.isEnabled) { _connection.value = ConnectionState.Off; return }
        val scanner = a.bluetoothLeScanner ?: run { _connection.value = ConnectionState.Off; return }
        seen.clear(); _scan.value = emptyList()
        _connection.value = ConnectionState.Scanning
        // Filter by the Aurora service UUID that is in the advertising packet (spec §1).
        val filters = listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(AuroraUuids.SERVICE)).build())
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(filters, settings, scanCallback)
        scanJob?.cancel()
        scanJob = scope.launch { delay(15_000); stopScan() }
    }

    override fun stopScan() {
        scanJob?.cancel(); scanJob = null
        runCatching { adapter?.bluetoothLeScanner?.stopScan(scanCallback) }
        if (_connection.value is ConnectionState.Scanning) _connection.value = ConnectionState.Disconnected
    }

    // ------------------------------------------------------------------ connection

    override fun connect(address: String?) {
        val a = adapter ?: run { _connection.value = ConnectionState.Off; return }
        val addr = address ?: _scan.value.firstOrNull()?.address ?: run {
            _connection.value = ConnectionState.Error(R.string.app_err_no_pod); return
        }
        stopScan()
        val device: BluetoothDevice = runCatching { a.getRemoteDevice(addr) }.getOrElse {
            _connection.value = ConnectionState.Error(R.string.app_err_bad_address); return
        }
        _connection.value = ConnectionState.Connecting(device.name ?: AuroraUuids.ADVERTISED_NAME)
        gatt?.close()
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } else device.connectGatt(context, false, gattCallback)
    }

    override fun disconnect() {
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        _hasExt.value = false // sensor roster is per-connection knowledge
        _caps.value = PodCapabilities.NONE
        replayJob?.cancel(); replayCollecting = false
        _connection.value = ConnectionState.Disconnected
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                servicesDiscovered = CompletableDeferred()
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                failAllPending()
                g.close()
                if (gatt === g) gatt = null
                _hasExt.value = false
                _caps.value = PodCapabilities.NONE
                replayJob?.cancel(); replayCollecting = false
                _connection.value = if (status == BluetoothGatt.GATT_SUCCESS) ConnectionState.Disconnected
                else ConnectionState.Error(R.string.app_err_connection_lost, status)
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val ok = status == BluetoothGatt.GATT_SUCCESS && g.getService(AuroraUuids.SERVICE) != null
            if (!ok) {
                _connection.value = ConnectionState.Error(R.string.app_err_not_aurora)
                g.disconnect()
            }
            servicesDiscovered?.complete(ok)
            if (ok) scope.launch { onLinkReady(g) }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            pendingWrite?.complete(status == BluetoothGatt.GATT_SUCCESS); pendingWrite = null
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            pendingDescriptor?.complete(status == BluetoothGatt.GATT_SUCCESS); pendingDescriptor = null
        }

        @Deprecated("Pre-API-33 path")
        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                @Suppress("DEPRECATION")
                pendingRead?.complete(if (status == BluetoothGatt.GATT_SUCCESS) c.value else null); pendingRead = null
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            pendingRead?.complete(if (status == BluetoothGatt.GATT_SUCCESS) value else null); pendingRead = null
        }

        @Deprecated("Pre-API-33 path")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                @Suppress("DEPRECATION")
                dispatch(c.uuid, c.value ?: return)
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            dispatch(c.uuid, value)
        }
    }

    private fun dispatch(uuid: UUID, value: ByteArray) {
        runCatching<Unit> {
            when (uuid) {
                AuroraUuids.VITALS -> hw.onVitals(value).let { out ->
                    _battery.value = out.batteryPct            // null = unknown: no gauge
                    _vitals.tryEmit(out.vitals)
                    _extVitals.tryEmit(out.ext)                // SpO2 estimate rides the ext channel
                    // Joined a running session but FE02 hasn't told us when it began: ask again.
                    val g = gatt
                    if (hw.needsSessionPin && g != null && System.currentTimeMillis() - pinReadAt > 3_000) {
                        pinReadAt = System.currentTimeMillis()
                        scope.launch { read(g, AuroraUuids.SERVICE, AuroraUuids.SUMMARY)?.let { runCatching { hw.onSession(it) } } }
                    }
                }
                AuroraUuids.HRV -> _hrv.tryEmit(hw.onHrv(value))
                // A NOTIFY on FE02 happens on SESSION_STOP — that is the morning card.
                AuroraUuids.SUMMARY -> hw.onSession(value).let { if (swallowNextSummary) swallowNextSummary = false else _summary.tryEmit(it) }
                AuroraUuids.LOG -> if (replayCollecting) {
                    lastReplayFrameAt = System.currentTimeMillis()
                    if (!hw.onReplayFrame(value)) badPackets++
                }
                else -> Unit
            }
        }.onFailure { badPackets++; Log.w(TAG, "Dropped packet on $uuid: ${it.message}") }
    }

    private fun failAllPending() {
        pendingWrite?.complete(false); pendingWrite = null
        pendingRead?.complete(null); pendingRead = null
        pendingDescriptor?.complete(false); pendingDescriptor = null
        servicesDiscovered?.complete(false); servicesDiscovered = null
    }

    /** Runs right after service discovery: enable the pod's notifications, learn its state. */
    private suspend fun onLinkReady(g: BluetoothGatt) {
        val name = g.device.name ?: AuroraUuids.ADVERTISED_NAME
        hw.reset(); badPackets = 0
        // The glove exposes no Device Information / Battery services; nothing to read there.
        // softwareRevision left blank: the pod reports no firmware string, so no "mismatch" toast.
        _deviceInfo.value = DeviceInfo(manufacturer = "Aurora", model = name, hardwareRevision = "XIAO nRF52840 · protocol v1")
        _battery.value = null
        // FIRST learn whether a session is already running (FE02 carries the RUNNING
        // duration) so the very first vitals packet already has the right session time.
        // NOT emitted as a summary — the manager treats an FE02 as "session over".
        read(g, AuroraUuids.SERVICE, AuroraUuids.SUMMARY)?.let { runCatching { hw.onSession(it) } }
        if (!enableNotify(g, AuroraUuids.SERVICE, AuroraUuids.VITALS)) {
            _connection.value = ConnectionState.Error(R.string.app_err_not_aurora); g.disconnect(); return
        }
        enableNotify(g, AuroraUuids.SERVICE, AuroraUuids.SUMMARY)
        enableNotify(g, AuroraUuids.SERVICE, AuroraUuids.HRV)
        enableNotify(g, AuroraUuids.SERVICE, AuroraUuids.LOG)
        _hasExt.value = false // no conductance / blood-flow on this pod (PROTOCOL §9)
        _caps.value = PodCapabilities.HARDWARE_V1
        _connection.value = ConnectionState.Connected(name, g.device.address)
    }

    // ------------------------------------------------------------------ GATT ops (serialised)

    private fun characteristic(g: BluetoothGatt, service: UUID, char: UUID): BluetoothGattCharacteristic? =
        g.getService(service)?.getCharacteristic(char)

    private suspend fun enableNotify(g: BluetoothGatt, service: UUID, char: UUID): Boolean = gattMutex.withLock {
        val c = characteristic(g, service, char) ?: return false
        if (!g.setCharacteristicNotification(c, true)) return false
        val d = c.getDescriptor(AuroraUuids.CCCD) ?: return false
        val deferred = CompletableDeferred<Boolean>()
        pendingDescriptor = deferred
        val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothGatt.GATT_SUCCESS
        } else {
            @Suppress("DEPRECATION")
            run { d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; g.writeDescriptor(d) }
        }
        if (!ok) { pendingDescriptor = null; return false }
        withTimeoutOrNull(3000) { deferred.await() } ?: false
    }

    private suspend fun read(g: BluetoothGatt, service: UUID, char: UUID): ByteArray? = gattMutex.withLock {
        val c = characteristic(g, service, char) ?: return null
        val deferred = CompletableDeferred<ByteArray?>()
        pendingRead = deferred
        if (!g.readCharacteristic(c)) { pendingRead = null; return null }
        withTimeoutOrNull(3000) { deferred.await() }
    }

    private suspend fun readString(g: BluetoothGatt, service: UUID, char: UUID): String =
        read(g, service, char)?.toString(Charsets.UTF_8)?.trimEnd('\u0000')?.trim() ?: ""

    override suspend fun write(command: PodCommand): Boolean {
        val g = gatt ?: return false
        if (command == PodCommand.AbortReplay) { replayJob?.cancel(); replayCollecting = false; return true }
        val podRunning = hw.lastVitals?.sessionActive == true
        return when (val plan = hw.plan(command)) {
            is HwAdapter.Plan.Write -> {
                if (command == PodCommand.StartSession && podRunning) {
                    // A session left running on the pod (another app, the web tool): end it
                    // quietly first so the new night's time base starts now.
                    swallowNextSummary = true
                    writeRaw(g, byteArrayOf(0x02)); delay(1_500)
                    swallowNextSummary = false
                }
                writeRaw(g, plan.bytes)
            }
            // Stop retry: while the pod still logs, the STOP didn't land — send it again (its
            // FE02 notify follows); only a stopped pod's summary may be read directly.
            HwAdapter.Plan.ReadSummary -> if (podRunning) writeRaw(g, byteArrayOf(0x02))
                else readSummary()?.let { _summary.tryEmit(it); true } ?: false
            HwAdapter.Plan.Replay -> { startReplay(g); true }
            HwAdapter.Plan.Unsupported -> false
        }
    }

    private suspend fun writeRaw(g: BluetoothGatt, bytes: ByteArray): Boolean = gattMutex.withLock {
        val c = characteristic(g, AuroraUuids.SERVICE, AuroraUuids.CONTROL) ?: return false
        val deferred = CompletableDeferred<Boolean>()
        pendingWrite = deferred
        val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            g.writeCharacteristic(c, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothGatt.GATT_SUCCESS
        } else {
            @Suppress("DEPRECATION")
            run { c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT; c.value = bytes; g.writeCharacteristic(c) }
        }
        if (!ok) { pendingWrite = null; return false }
        withTimeoutOrNull(3000) { deferred.await() } ?: false
    }

    /**
     * PROTOCOL §7: read FE02 (how many records, and the session window), send 0x04, collect
     * FE04 until the promised count arrives or the stream goes quiet, then convert the
     * session's rows and emit them as the internal replay stream. Nothing is emitted when
     * the session has no rows, so the manager reports "nothing stored" instead of replacing
     * the live epochs with an empty night.
     */
    private fun startReplay(g: BluetoothGatt) {
        replayJob?.cancel()
        replayJob = scope.launch {
            replayDiag = null
            val raw = read(g, AuroraUuids.SERVICE, AuroraUuids.SUMMARY)
            val promised = raw?.let { runCatching { hw.onSession(it) }.getOrNull() }?.let { hw.lastSession?.logRecords } ?: 0
            if (promised == 0) { _replayEmpty.tryEmit(Unit); return@launch }
            var result: HwAdapter.ReplayResult? = null
            // PROTOCOL §7: missing sequence numbers mean dropped notifications — re-issue 0x04 once.
            for (attempt in 0..1) {
                hw.beginReplay()
                replayCollecting = true
                lastReplayFrameAt = System.currentTimeMillis()
                if (!writeRaw(g, byteArrayOf(0x04))) { replayCollecting = false; break }
                val t0 = System.currentTimeMillis()
                // log_records is capped at 255 while the ring holds up to 480: at the cap, wait
                // for quiet. Stay under the manager's 90 s header timeout.
                while (System.currentTimeMillis() - t0 < 80_000) {
                    delay(250)
                    val quiet = System.currentTimeMillis() - lastReplayFrameAt
                    if (promised < 255 && hw.replayReceived >= promised && quiet > 400) break
                    if (quiet > 3_000) break
                }
                replayCollecting = false
                result = hw.finishReplay()
                if (result.missing == 0 && result.crcFailures == 0) break
            }
            val r = result
            if (r == null || r.records.isEmpty()) { _replayEmpty.tryEmit(Unit); return@launch }
            Log.i(TAG, "Replay: ${r.framesReceived} frames, ${r.crcFailures} CRC failures, " +
                "${r.missing} missing, ${r.sessionRows} session rows → ${r.records.size} epochs")
            replayDiag = r.missing to r.crcFailures
            for (f in hw.internalFrames(r.records)) _replay.emit(f)
        }
    }

    override suspend fun readSummary(): SessionSummary? {
        val g = gatt ?: return null
        return read(g, AuroraUuids.SERVICE, AuroraUuids.SUMMARY)?.let { runCatching { hw.onSession(it) }.getOrNull() }
    }

    override suspend fun readHrv(): HrvSummary? {
        val g = gatt ?: return null
        return read(g, AuroraUuids.SERVICE, AuroraUuids.HRV)?.let { runCatching { hw.onHrv(it) }.getOrNull() }
    }

    companion object { private const val TAG = "BlePodSource" }
}
