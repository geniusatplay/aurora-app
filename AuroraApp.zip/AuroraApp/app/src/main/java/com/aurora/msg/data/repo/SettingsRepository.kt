package com.aurora.msg.data.repo

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Shared by [SettingsRepository] and [CustomPagesRepository] — one DataStore per file. */
internal val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "aurora_settings")

/** Visual theme. AURORA follows the system light/dark switch; the others are fixed. */
enum class ThemeMode { AURORA, LIGHT, HIGH_CONTRAST, DARK }

/** App language. SYSTEM follows the phone; otherwise a BCP-47 tag. */
enum class AppLanguage(val tag: String) { SYSTEM(""), ENGLISH("en"), SPANISH("es"), VIETNAMESE("vi") }

/**
 * Vital Sheet visual style (brief §5): 1 Aurora cards · 2 Clinic sheet · 3 Timeline focus.
 * Frame styling only — data/series colors never change between schemes.
 */
enum class SheetScheme { SCHEME1, SCHEME2, SCHEME3 }

data class AppSettings(
    val userId: Long? = null,
    val themeMode: ThemeMode = ThemeMode.AURORA,
    val language: AppLanguage = AppLanguage.SYSTEM,
    val useFahrenheit: Boolean = false,
    val use24h: Boolean = true,
    val demoMode: Boolean = false,
    val onboarded: Boolean = false,
    val notificationsEnabled: Boolean = true,
    /** Overlay Low / Medium / High reference guides on charts and tiles. */
    val showRanges: Boolean = false,
    /** Vital Sheet style (brief §5); applies to the screen and its PDF. */
    val sheetScheme: SheetScheme = SheetScheme.SCHEME1,
) {
    fun tempLabel(): String = if (useFahrenheit) "°F" else "°C"
    fun toDisplayTemp(c: Float): Float = if (useFahrenheit) c * 9f / 5f + 32f else c
    /** Deltas convert without the +32 offset. */
    fun toDisplayDelta(dc: Float): Float = if (useFahrenheit) dc * 9f / 5f else dc
}

class SettingsRepository(private val context: Context) {
    private object Keys {
        val USER_ID = longPreferencesKey("user_id")
        val FAHRENHEIT = booleanPreferencesKey("fahrenheit")
        val H24 = booleanPreferencesKey("h24")
        val DEMO = booleanPreferencesKey("demo")
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val NOTIFS = booleanPreferencesKey("notifs")
        val THEME = stringPreferencesKey("theme")
        val LANG = stringPreferencesKey("lang")
        val RANGES = booleanPreferencesKey("ranges")
        val SHEET_SCHEME = stringPreferencesKey("sheet_scheme")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            userId = p[Keys.USER_ID],
            themeMode = p[Keys.THEME]?.let { v -> ThemeMode.entries.firstOrNull { it.name == v } } ?: ThemeMode.AURORA,
            language = p[Keys.LANG]?.let { v -> AppLanguage.entries.firstOrNull { it.name == v } } ?: AppLanguage.SYSTEM,
            useFahrenheit = p[Keys.FAHRENHEIT] ?: false,
            use24h = p[Keys.H24] ?: true,
            demoMode = p[Keys.DEMO] ?: false,
            onboarded = p[Keys.ONBOARDED] ?: false,
            notificationsEnabled = p[Keys.NOTIFS] ?: true,
            showRanges = p[Keys.RANGES] ?: false,
            sheetScheme = p[Keys.SHEET_SCHEME]?.let { v -> SheetScheme.entries.firstOrNull { it.name == v } } ?: SheetScheme.SCHEME1,
        )
    }

    suspend fun setUserId(id: Long?) = context.dataStore.edit { p ->
        if (id == null) p.remove(Keys.USER_ID) else p[Keys.USER_ID] = id
    }
    suspend fun setFahrenheit(v: Boolean) = context.dataStore.edit { it[Keys.FAHRENHEIT] = v }
    suspend fun set24h(v: Boolean) = context.dataStore.edit { it[Keys.H24] = v }
    suspend fun setDemoMode(v: Boolean) = context.dataStore.edit { it[Keys.DEMO] = v }
    suspend fun setOnboarded(v: Boolean) = context.dataStore.edit { it[Keys.ONBOARDED] = v }
    suspend fun setNotifications(v: Boolean) = context.dataStore.edit { it[Keys.NOTIFS] = v }
    suspend fun setThemeMode(v: ThemeMode) = context.dataStore.edit { it[Keys.THEME] = v.name }
    suspend fun setShowRanges(v: Boolean) = context.dataStore.edit { it[Keys.RANGES] = v }
    suspend fun setLanguage(v: AppLanguage) = context.dataStore.edit { it[Keys.LANG] = v.name }
    suspend fun setSheetScheme(v: SheetScheme) = context.dataStore.edit { it[Keys.SHEET_SCHEME] = v.name }
}
