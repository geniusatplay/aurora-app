package com.aurora.msg.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.msg.AuroraApp
import com.aurora.msg.data.db.UserEntity
import com.aurora.msg.data.repo.AppLanguage
import com.aurora.msg.data.repo.AppSettings
import com.aurora.msg.data.repo.SheetScheme
import com.aurora.msg.data.repo.ThemeMode
import com.aurora.msg.data.repo.AuthResult
import com.aurora.msg.data.repo.NightBundle
import com.aurora.msg.data.repo.NightCard
import com.aurora.msg.pod.DemoMode
import com.aurora.msg.protocol.PodCommand
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * One app-scoped ViewModel: thin glue between the graph and the screens.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {
    val graph = AuroraApp.graph(app)
    val pod get() = graph.pod
    val demo get() = graph.demo
    val sessions get() = graph.sessions

    val settings: StateFlow<AppSettings> = graph.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    /** null until DataStore has been read once, so the splash doesn't flash the sign-in screen. */
    private val _settingsLoaded = MutableStateFlow(false)
    val settingsLoaded: StateFlow<Boolean> = _settingsLoaded

    val user: StateFlow<UserEntity?> = settings.map { it.userId }.flatMapLatest { id ->
        flowOf(id?.let { graph.auth.user(it) })
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val nightCards: StateFlow<List<NightCard>> = settings.map { it.userId }.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else sessions.observeNightCards(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestNight: StateFlow<NightBundle?> = settings.map { it.userId }.flatMapLatest { id ->
        if (id == null) flowOf(null) else sessions.observeLatestNight(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeNight: StateFlow<NightBundle?> = pod.activeSession.flatMapLatest { s ->
        if (s == null) flowOf(null) else sessions.observeNight(s.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        viewModelScope.launch {
            graph.settings.settings.collect { s ->
                _settingsLoaded.value = true
                pod.setUser(s.userId)
            }
        }
    }

    fun night(sessionId: Long) = sessions.observeNight(sessionId)

    // ------------------------------------------------------------------ auth
    suspend fun signIn(email: String, password: String): AuthResult = graph.auth.signIn(email, password)
    suspend fun register(email: String, password: String, name: String): AuthResult = graph.auth.register(email, password, name)
    fun signOut() = viewModelScope.launch { pod.disconnect(); graph.auth.signOut() }

    // ------------------------------------------------------------------ settings
    fun setFahrenheit(v: Boolean) = viewModelScope.launch { graph.settings.setFahrenheit(v) }
    fun set24h(v: Boolean) = viewModelScope.launch { graph.settings.set24h(v) }
    fun setOnboarded() = viewModelScope.launch { graph.settings.setOnboarded(true) }
    fun setThemeMode(v: ThemeMode) = viewModelScope.launch { graph.settings.setThemeMode(v) }
    fun setShowRanges(v: Boolean) = viewModelScope.launch { graph.settings.setShowRanges(v) }
    fun setLanguage(v: AppLanguage) = viewModelScope.launch { graph.settings.setLanguage(v) }
    fun setSheetScheme(v: SheetScheme) = viewModelScope.launch { graph.settings.setSheetScheme(v) }

    // ------------------------------------------------------------------ pod
    fun startSession() = viewModelScope.launch { pod.startSession() }
    fun stopSession() = viewModelScope.launch { pod.stopSession() }
    fun hapticTest() = viewModelScope.launch { pod.hapticTest() }
    fun fuelGaugeRelearn() = viewModelScope.launch { pod.fuelGaugeRelearn() }
    fun formatFlash() = viewModelScope.launch { pod.formatFlash() }
    /**
     * Real Aurora Pod: identify by blinking its LED. HwAdapter maps HapticTest to the pod's
     * IDENTIFY opcode (no motor on the glove); written directly so no "buzz" message is shown.
     */
    fun blinkLed() = viewModelScope.launch { pod.source.value.write(PodCommand.HapticTest(250)) }

    // ------------------------------------------------------------------ demo
    fun demoStart(mode: DemoMode) = demo.startDemoNight(mode)
    fun demoStop() = demo.stopDemoNight()
    fun demoMode(mode: DemoMode) = demo.setMode(mode)
    fun demoSpeed(speed: Int) = demo.setSpeed(speed)
    fun demoSeed() = demo.seedHistory()
    fun demoEnable() = demo.enable()
    fun demoDisable() = demo.disable()

    // ------------------------------------------------------------------ data
    fun deleteSession(id: Long) = viewModelScope.launch { sessions.deleteSession(id) }
    fun deleteAll() = viewModelScope.launch { settings.value.userId?.let { sessions.deleteAll(it) } }
    suspend fun exportCsv(id: Long): String = sessions.exportCsv(id)
}
