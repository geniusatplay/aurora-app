package com.aurora.msg.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

/*
 * AURORA POD HARDWARE PROTOCOL v1 — the packets the real glove actually sends.
 *
 * Source of truth: "App device integration guide/PROTOCOL.txt" (STATUS: VERIFIED ON
 * HARDWARE, 2026-09-28) and the bridge's reference decoder pod_agent.py. This REPLACES
 * the original paper spec for anything that goes over the air; the rest of the app keeps
 * its internal model (LiveVitals / LogRecord / …) and [HwAdapter] translates between them.
 *
 * All integers little-endian. Every packet ends with CRC-16/CCITT-FALSE over all
 * preceding bytes; a replay RECORD carries its own CRC over its first 16 bytes.
 * The app MUST verify the CRC and discard packets that fail (PROTOCOL §0).
 */

class HwPacketException(message: String) : IllegalArgumentException(message)

object HwConst {
    const val HDR_VITALS = 0xA1
    const val HDR_SESSION = 0xA2
    const val HDR_HRV = 0xA5
    const val LEN_VITALS = 20
    const val LEN_SESSION = 20
    const val LEN_HRV = 15
    const val LEN_REPLAY = 20
    const val LEN_RECORD = 18

    const val HR_NONE = 0xFFFF
    const val SPO2_NONE = 0xFF
    const val BATT_UNKNOWN = 0xFF
    const val TEMP_NONE = -32768

    /** Below this quality SpO2 must not be rendered (PROTOCOL §3). */
    const val SPO2_MIN_QUALITY = 40
    /** HRV packets with fewer beats are ignored whole (PROTOCOL §4). */
    const val HRV_MIN_BEATS = 5
    /** RAM log capacity (PROTOCOL §7): 8 h at the default 60 s interval. */
    const val LOG_CAPACITY = 480
    const val DEFAULT_LOG_PERIOD_S = 60
}

/** FE01 flags bitfield (PROTOCOL §3). Different bit meanings from the internal [PodFlags]. */
object HwFlags {
    const val FINGER = 0x01
    const val SESSION_ACTIVE = 0x02
    /** Abs humidity above the pod's own baseline. PROVISIONAL (placeholder threshold). */
    const val FLUSH_ACTIVE = 0x04
    const val LOW_BATTERY = 0x08
    const val HR_LOCKED = 0x10
    const val TIME_VALID = 0x20

    fun has(flags: Int, bit: Int) = (flags and bit) != 0
}

/** FE03 opcodes (PROTOCOL §6). Only 1–7 exist; there are no acks — confirm by observing. */
object HwOp {
    const val SESSION_START = 0x01
    const val SESSION_STOP = 0x02
    const val TIME_SYNC = 0x03
    const val REPLAY_BEGIN = 0x04
    const val LOG_ERASE = 0x05
    const val SET_PERIOD = 0x06
    const val IDENTIFY = 0x07

    fun simple(op: Int) = byteArrayOf(op.toByte())

    /** 03 + u32 LE epoch. Big-endian would put the pod ~1500 years in the future. */
    fun timeSync(epochS: Long): ByteArray =
        ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN).put(TIME_SYNC.toByte()).putInt(epochS.toInt()).array()

    fun setPeriod(seconds: Int): ByteArray {
        require(seconds in 1..240) { "log interval must be 1..240 s" }
        return byteArrayOf(SET_PERIOD.toByte(), seconds.toByte())
    }
}

private fun ByteArray.leBuf(off: Int = 0, len: Int = size - off): ByteBuffer =
    ByteBuffer.wrap(this, off, len).order(ByteOrder.LITTLE_ENDIAN)

private fun crcOk(b: ByteArray, off: Int, len: Int): Boolean {
    val stored = (b[off + len - 2].toInt() and 0xFF) or ((b[off + len - 1].toInt() and 0xFF) shl 8)
    return Crc16.ccittFalse(b, off, len - 2) == stored
}

private fun check(b: ByteArray, len: Int, hdr: Int, what: String) {
    if (b.size != len) throw HwPacketException("$what len ${b.size} != $len")
    if ((b[0].toInt() and 0xFF) != hdr) throw HwPacketException("$what hdr 0x%02X != 0x%02X".format(b[0].toInt() and 0xFF, hdr))
    if (!crcOk(b, 0, len)) throw HwPacketException("$what CRC mismatch")
}

private fun seal(b: ByteArray, off: Int = 0, len: Int = b.size): ByteArray {
    val crc = Crc16.ccittFalse(b, off, len - 2)
    b[off + len - 2] = (crc and 0xFF).toByte(); b[off + len - 1] = ((crc shr 8) and 0xFF).toByte()
    return b
}

/* ------------------------------------------------------------------ FE01 live vitals, 20 B @1 Hz */
data class HwVitals(
    val seq: Int,
    val uptimeS: Long,
    /** °C ×100; null = no reading (-32768 on the wire). */
    val skinTempX100: Int?,
    val skinRhX100: Int,
    /** Absolute humidity at the skin, g/m³ ×100 — THE key signal. */
    val absHumX100: Int,
    /** bpm ×10; null = no lock (0xFFFF) — render blank, never zero. */
    val hrX10: Int?,
    /** null = invalid (0xFF). UNCALIBRATED estimate, trend only. */
    val spo2Pct: Int?,
    val quality: Int,
    val flags: Int,
    /** null = unknown (0xFF) — show no gauge. */
    val battPct: Int?,
) {
    val finger get() = HwFlags.has(flags, HwFlags.FINGER)
    val sessionActive get() = HwFlags.has(flags, HwFlags.SESSION_ACTIVE)
    val flushActive get() = HwFlags.has(flags, HwFlags.FLUSH_ACTIVE)
    val lowBattery get() = HwFlags.has(flags, HwFlags.LOW_BATTERY)
    val hrLocked get() = HwFlags.has(flags, HwFlags.HR_LOCKED)
    val timeValid get() = HwFlags.has(flags, HwFlags.TIME_VALID)

    /** HR to show: only when HR_LOCKED and present ("trust HR_LOCKED over presence of a value"). */
    val hrShowBpm: Float? get() = if (hrLocked && hrX10 != null) hrX10 / 10f else null
    /** SpO2 estimate to show: present and quality ≥ 40, else greyed out. */
    val spo2Show: Int? get() = if (spo2Pct != null && quality >= HwConst.SPO2_MIN_QUALITY) spo2Pct else null

    fun encode(): ByteArray {
        val b = ByteArray(HwConst.LEN_VITALS)
        val w = b.leBuf()
        w.put(HwConst.HDR_VITALS.toByte()).put(seq.toByte()).putInt(uptimeS.toInt())
            .putShort((skinTempX100 ?: HwConst.TEMP_NONE).toShort()).putShort(skinRhX100.toShort())
            .putShort(absHumX100.toShort()).putShort((hrX10 ?: HwConst.HR_NONE).toShort())
            .put((spo2Pct ?: HwConst.SPO2_NONE).toByte()).put(quality.toByte()).put(flags.toByte())
            .put((battPct ?: HwConst.BATT_UNKNOWN).toByte())
        return seal(b)
    }

    companion object {
        fun parse(b: ByteArray): HwVitals {
            check(b, HwConst.LEN_VITALS, HwConst.HDR_VITALS, "vitals")
            val r = b.leBuf(); r.get()
            val seq = r.get().toInt() and 0xFF
            val up = r.int.toLong() and 0xFFFFFFFFL
            val t = r.short.toInt()
            val rh = r.short.toInt() and 0xFFFF
            val ah = r.short.toInt() and 0xFFFF
            val hr = r.short.toInt() and 0xFFFF
            val spo2 = r.get().toInt() and 0xFF
            val q = r.get().toInt() and 0xFF
            val fl = r.get().toInt() and 0xFF
            val bat = r.get().toInt() and 0xFF
            return HwVitals(seq, up, if (t == HwConst.TEMP_NONE) null else t, rh, ah,
                if (hr == HwConst.HR_NONE) null else hr, if (spo2 == HwConst.SPO2_NONE) null else spo2,
                q, fl, if (bat == HwConst.BATT_UNKNOWN) null else bat)
        }
    }
}

/* ------------------------------------------------------------------ FE05 HRV, 15 B every 10 s */
data class HwHrv(
    val uptimeS: Long,
    val meanRrMs: Int,
    val sdnnX10: Int,
    val rmssdX10: Int,
    val beats: Int,
    val quality: Int,
) {
    /** Below 5 beats, ignore the whole packet (PROTOCOL §4). */
    val usable get() = beats >= HwConst.HRV_MIN_BEATS && meanRrMs > 0

    fun encode(): ByteArray {
        val b = ByteArray(HwConst.LEN_HRV)
        b.leBuf().put(HwConst.HDR_HRV.toByte()).putInt(uptimeS.toInt()).putShort(meanRrMs.toShort())
            .putShort(sdnnX10.toShort()).putShort(rmssdX10.toShort()).put(beats.toByte()).put(quality.toByte())
        return seal(b)
    }

    companion object {
        fun parse(b: ByteArray): HwHrv {
            check(b, HwConst.LEN_HRV, HwConst.HDR_HRV, "hrv")
            val r = b.leBuf(); r.get()
            return HwHrv(r.int.toLong() and 0xFFFFFFFFL, r.short.toInt() and 0xFFFF, r.short.toInt() and 0xFFFF,
                r.short.toInt() and 0xFFFF, r.get().toInt() and 0xFF, r.get().toInt() and 0xFF)
        }
    }
}

/* ------------------------------------------------------------------ FE02 session summary, 20 B */
data class HwSession(
    /** Unix seconds; null when the clock was never set (0 on the wire). */
    val startEpoch: Long?,
    /** While a session runs, this is the running duration (firmware §buildSession). */
    val durationS: Long,
    /** PROVISIONAL — placeholder threshold (PROTOCOL §9). */
    val flushEvents: Int,
    val peakAbsHumX100: Int,
    val meanSkinTempX100: Int,
    /** PLACEHOLDER until labelled data exists — never show as a claim. */
    val score: Int,
    val battPct: Int?,
    /** Records available for replay, capped at 255 (the log itself holds up to 480). */
    val logRecords: Int,
) {
    fun encode(): ByteArray {
        val b = ByteArray(HwConst.LEN_SESSION)
        b.leBuf().put(HwConst.HDR_SESSION.toByte()).putInt((startEpoch ?: 0L).toInt()).putInt(durationS.toInt())
            .putShort(flushEvents.toShort()).putShort(peakAbsHumX100.toShort()).putShort(meanSkinTempX100.toShort())
            .put(score.toByte()).put((battPct ?: HwConst.BATT_UNKNOWN).toByte()).put(logRecords.toByte())
        return seal(b)
    }

    companion object {
        fun parse(b: ByteArray): HwSession {
            check(b, HwConst.LEN_SESSION, HwConst.HDR_SESSION, "session")
            val r = b.leBuf(); r.get()
            val start = r.int.toLong() and 0xFFFFFFFFL
            val dur = r.int.toLong() and 0xFFFFFFFFL
            val fe = r.short.toInt() and 0xFFFF
            val peak = r.short.toInt() and 0xFFFF
            val mean = r.short.toInt()
            val score = r.get().toInt() and 0xFF
            val bat = r.get().toInt() and 0xFF
            val recs = r.get().toInt() and 0xFF
            return HwSession(if (start == 0L) null else start, dur, fe, peak, mean, score,
                if (bat == HwConst.BATT_UNKNOWN) null else bat, recs)
        }
    }
}

/* ------------------------------------------------------------------ FE04 replay frame [u16 seq][18 B record] */
data class HwRecord(
    val seq: Int,
    val uptimeS: Long,
    val skinTempX100: Int?,
    val skinRhX100: Int,
    val absHumX100: Int,
    val hrX10: Int?,
    val spo2Pct: Int?,
    val quality: Int,
    val flags: Int,
    val battPct: Int?,
) {
    fun encodeFrame(): ByteArray {
        val b = ByteArray(HwConst.LEN_REPLAY)
        b.leBuf().putShort(seq.toShort()).putInt(uptimeS.toInt()).putShort((skinTempX100 ?: HwConst.TEMP_NONE).toShort())
            .putShort(skinRhX100.toShort()).putShort(absHumX100.toShort()).putShort((hrX10 ?: HwConst.HR_NONE).toShort())
            .put((spo2Pct ?: HwConst.SPO2_NONE).toByte()).put(quality.toByte()).put(flags.toByte())
            .put((battPct ?: HwConst.BATT_UNKNOWN).toByte())
        return seal(b, 2, HwConst.LEN_RECORD)
    }

    companion object {
        /** One frame is exactly one record; the record carries its OWN CRC (PROTOCOL §7). */
        fun parseFrame(b: ByteArray): HwRecord {
            if (b.size != HwConst.LEN_REPLAY) throw HwPacketException("replay len ${b.size} != 20")
            val seq = (b[0].toInt() and 0xFF) or ((b[1].toInt() and 0xFF) shl 8)
            if (!crcOk(b, 2, HwConst.LEN_RECORD)) throw HwPacketException("replay record $seq CRC mismatch")
            val r = b.leBuf(2, HwConst.LEN_RECORD)
            val up = r.int.toLong() and 0xFFFFFFFFL
            val t = r.short.toInt()
            val rh = r.short.toInt() and 0xFFFF
            val ah = r.short.toInt() and 0xFFFF
            val hr = r.short.toInt() and 0xFFFF
            val spo2 = r.get().toInt() and 0xFF
            val q = r.get().toInt() and 0xFF
            val fl = r.get().toInt() and 0xFF
            val bat = r.get().toInt() and 0xFF
            return HwRecord(seq, up, if (t == HwConst.TEMP_NONE) null else t, rh, ah,
                if (hr == HwConst.HR_NONE) null else hr, if (spo2 == HwConst.SPO2_NONE) null else spo2,
                q, fl, if (bat == HwConst.BATT_UNKNOWN) null else bat)
        }
    }
}

/**
 * What the connected pod can actually measure. The UI hides cards/panels for channels the
 * pod does not have instead of drawing empty charts or fabricated values.
 * The real glove (PROTOCOL §9): no accelerometer (no movement, no sleep staging), one
 * humidity sensor (no room climate), no skin-conductance electrode, no blood-flow index,
 * SpO2 only as an uncalibrated estimate, battery unknown until a cell is fitted.
 */
data class PodCapabilities(
    val skinConductance: Boolean,
    val spo2Estimate: Boolean,
    val bloodFlow: Boolean,
    val roomClimate: Boolean,
    val movement: Boolean,
    val sleepStaging: Boolean,
    val battery: Boolean,
    /** Optical sensor runs all the time (hardware) vs 2-min bursts every 10 min (paper spec). */
    val continuousPpg: Boolean,
    /** Absolute humidity comes straight from the pod rather than skin-vs-room math. */
    val directAbsHumidity: Boolean,
    /** HRV is quantisation-limited (20 ms at 50 Hz): relative trends only, never clinical. */
    val hrvRelativeOnly: Boolean,
) {
    companion object {
        /** The demo simulator models the full paper spec + extension brief. */
        val DEMO = PodCapabilities(true, true, true, true, true, true, true, false, false, false)
        /** The real Aurora Pod, hardware protocol v1. */
        val HARDWARE_V1 = PodCapabilities(false, true, false, false, false, false, false, true, true, true)
        /** Before anything is known (not connected). */
        val NONE = PodCapabilities(false, false, false, false, false, false, false, false, false, false)
    }
}
