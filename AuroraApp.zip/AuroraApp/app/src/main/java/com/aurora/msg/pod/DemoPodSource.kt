package com.aurora.msg.pod

import com.aurora.msg.domain.NightAnalytics
import com.aurora.msg.protocol.Cadence
import com.aurora.msg.protocol.DeviceInfo
import com.aurora.msg.protocol.ExtendedVitals
import com.aurora.msg.protocol.HrvFlags
import com.aurora.msg.protocol.HrvSummary
import com.aurora.msg.protocol.LiveVitals
import com.aurora.msg.protocol.LogRecord
import com.aurora.msg.protocol.PodCommand
import com.aurora.msg.protocol.PodFlags
import com.aurora.msg.protocol.ReplayAssembler
import com.aurora.msg.protocol.SessionSummary
import com.aurora.msg.protocol.SweatFlag
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * A software Aurora Pod. Emits byte-identical FE01/FE02/FE04/FE05 packets so the whole
 * app — parsers, CRC, replay reassembly, database, charts — runs the real code path.
 *
 * Time model: every real second the simulation advances [speed] simulated seconds.
 */
class DemoPodSource(private val scope: CoroutineScope) : PodSource {

    override val isDemo = true

    private val _connection = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connection.asStateFlow()

    private val _scan = MutableStateFlow<List<ScannedPod>>(emptyList())
    override val scanResults: StateFlow<List<ScannedPod>> = _scan.asStateFlow()

    private val _deviceInfo = MutableStateFlow<DeviceInfo?>(null)
    override val deviceInfo: StateFlow<DeviceInfo?> = _deviceInfo.asStateFlow()

    private val _battery = MutableStateFlow<Int?>(null)
    override val batteryPct: StateFlow<Int?> = _battery.asStateFlow()

    private val _vitals = MutableSharedFlow<LiveVitals>(extraBufferCapacity = 64)
    override val vitals: SharedFlow<LiveVitals> = _vitals.asSharedFlow()
    private val _extVitals = MutableSharedFlow<ExtendedVitals>(extraBufferCapacity = 64)
    override val extVitals: SharedFlow<ExtendedVitals> = _extVitals.asSharedFlow()
    /** The demo pod always carries the extended sensors (brief §2). */
    override val hasExtendedSensors: StateFlow<Boolean> = MutableStateFlow(true).asStateFlow()
    override val capabilities: StateFlow<com.aurora.msg.protocol.PodCapabilities> =
        MutableStateFlow(com.aurora.msg.protocol.PodCapabilities.DEMO).asStateFlow()
    private val _hrv = MutableSharedFlow<HrvSummary>(extraBufferCapacity = 16)
    override val hrv: SharedFlow<HrvSummary> = _hrv.asSharedFlow()
    private val _summary = MutableSharedFlow<SessionSummary>(extraBufferCapacity = 4)
    override val summary: SharedFlow<SessionSummary> = _summary.asSharedFlow()
    private val _replay = MutableSharedFlow<ByteArray>(extraBufferCapacity = 4096)
    override val replayFrames: SharedFlow<ByteArray> = _replay.asSharedFlow()

    // ----- demo controls -----
    private val _mode = MutableStateFlow(DemoMode.UP)
    val mode: StateFlow<DemoMode> = _mode.asStateFlow()
    private val _speed = MutableStateFlow(10)
    val speed: StateFlow<Int> = _speed.asStateFlow()

    /** (t_s, mode) whenever the mode changes during a session — used to log activity markers. */
    private val _modeEvents = MutableSharedFlow<Pair<Long, DemoMode>>(extraBufferCapacity = 16)
    val modeEvents: SharedFlow<Pair<Long, DemoMode>> = _modeEvents.asSharedFlow()

    // ----- internal pod state -----
    private val scenario = DemoScenario()
    private var timeSynced = false
    private var logging = false
    private var simT = 0.0          // seconds since session start
    private var lastEpochT = 0L
    private var lastHrvT = 0L
    private var lastHrv: HrvSummary? = null
    private var hrvFreshPending = false
    private var sweatWasOn = false
    private var records = ArrayList<LogRecord>()
    private val slots = arrayOfNulls<ByteArray>(Cadence.NIGHT_SLOTS)
    private val slotCounts = IntArray(Cadence.NIGHT_SLOTS)
    private var nextSlot = 0
    private var lastSlot = 0
    private var tickJob: Job? = null
    private var replayJob: Job? = null

    fun setMode(m: DemoMode) {
        if (_mode.value == m) return
        _mode.value = m
        scenario.setMode(m)
        if (logging) _modeEvents.tryEmit(simT.toLong() to m)
    }

    fun setSpeed(s: Int) { _speed.value = s.coerceIn(1, 120) }

    val currentTs: Long get() = simT.toLong()
    val isLogging: Boolean get() = logging

    override fun startScan() {
        _connection.value = ConnectionState.Scanning
        _scan.value = listOf(ScannedPod("AuroraPod (demo)", DEMO_ADDRESS, -58))
    }

    override fun stopScan() {
        if (_connection.value is ConnectionState.Scanning) _connection.value = ConnectionState.Disconnected
    }

    override fun connect(address: String?) {
        _connection.value = ConnectionState.Connecting("AuroraPod (demo)")
        scope.launch {
            delay(600)
            _deviceInfo.value = DeviceInfo("Aurora Pod", "MSG-RevA", "AURORA-POD-CARRIER-RevA", "1.0.0")
            _battery.value = scenario.battPct
            _connection.value = ConnectionState.Connected("AuroraPod (demo)", DEMO_ADDRESS)
            startTicking()
        }
    }

    override fun disconnect() {
        tickJob?.cancel(); tickJob = null
        replayJob?.cancel(); replayJob = null
        _connection.value = ConnectionState.Disconnected
        // Like the real pod: recording continues in "flash" while disconnected.
        if (logging) startTicking(emitVitals = false)
    }

    override suspend fun write(command: PodCommand): Boolean {
        when (command) {
            is PodCommand.TimeSync -> timeSynced = true
            PodCommand.StartSession -> if (!logging) {
                logging = true
                simT = 0.0; lastEpochT = 0; lastHrvT = 0; lastHrv = null; hrvFreshPending = false
                sweatWasOn = false
                records = ArrayList()
                _modeEvents.tryEmit(0L to _mode.value)
                if (tickJob == null) startTicking(emitVitals = _connection.value.isConnected)
            }
            PodCommand.StopSession -> if (logging) {
                logging = false
                finishSession()
            }
            PodCommand.PushSummary -> lastSummary()?.let { _summary.tryEmit(it) }
            is PodCommand.ReplaySlot -> startReplay(command.slot)
            PodCommand.AbortReplay -> { replayJob?.cancel(); replayJob = null }
            PodCommand.FormatFlash -> { slots.fill(null); slotCounts.fill(0); nextSlot = 0 }
            is PodCommand.HapticTest, PodCommand.FuelGaugeRelearn -> Unit
        }
        return true
    }

    override suspend fun readSummary(): SessionSummary? = lastSummary()
    override suspend fun readHrv(): HrvSummary? = lastHrv

    // ------------------------------------------------------------------ ticking

    private fun startTicking(emitVitals: Boolean = true) {
        tickJob?.cancel()
        tickJob = scope.launch {
            while (isActive) {
                tick(emitVitals && _connection.value.isConnected)
                delay(1000)
            }
        }
    }

    private fun tick(emitVitals: Boolean) {
        val speed = _speed.value
        // Sub-step for numeric stability; at most 5 simulated seconds per step.
        val steps = maxOf(1, (speed + 4) / 5)
        val dt = speed.toFloat() / steps
        repeat(steps) {
            scenario.step(dt)
            if (logging) {
                simT += dt
                val t = simT.toLong()
                // One epoch every 30 simulated seconds
                if (t - lastEpochT >= Cadence.EPOCH_S) {
                    lastEpochT = (t / Cadence.EPOCH_S) * Cadence.EPOCH_S
                    records.add(buildRecord(lastEpochT))
                }
                // HRV window closes 120 s into every 600 s cycle
                val due = if (lastHrv == null) t >= Cadence.PPG_BURST_S else t - lastHrvT >= Cadence.HRV_PERIOD_S
                if (due) {
                    lastHrvT = t
                    val h = buildHrv(t)
                    lastHrv = h
                    hrvFreshPending = true
                    if (emitVitals) _hrv.tryEmit(h)
                }
            }
        }
        if (!logging && emitVitals) {
            // Not recording yet: still give the live screen an HRV preview every 2 simulated minutes.
            previewT += speed
            if (previewT - lastPreviewHrvT >= Cadence.PPG_BURST_S) {
                lastPreviewHrvT = previewT
                val h = buildHrv(previewT)
                lastHrv = h
                _hrv.tryEmit(h)
            }
        }
        _battery.value = scenario.battPct
        if (emitVitals) {
            val t = if (logging) simT.toLong() else previewT
            _vitals.tryEmit(buildVitals(t))
            // FE06 rides the same tick as FE01 (brief §1) — the demo pod always has it.
            _extVitals.tryEmit(buildExtVitals(t))
        }
    }

    private var previewT = 0L
    private var lastPreviewHrvT = 0L

    private fun flags(t: Long): Int {
        var f = 0
        if (ppgActive(t)) f = f or PodFlags.PPG_ACTIVE
        f = f or PodFlags.POD_DETECTED
        if (logging) f = f or PodFlags.LOGGING
        if (timeSynced) f = f or PodFlags.TIME_SYNCED
        if (scenario.battPct <= 15) f = f or PodFlags.LOW_BATT
        return f
    }

    /**
     * The real pod runs its optical sensor 2 min in every 10 to save battery. The demo pod is
     * mains-free and exists to show data, so it keeps the optical sensor on continuously: heart
     * rate updates every second and the first HRV window closes after 2 minutes, then every 10.
     */
    private fun ppgActive(t: Long): Boolean = true

    private fun sweatFlagNow(): SweatFlag {
        val on = scenario.sweating
        val flag = when {
            on && !sweatWasOn -> SweatFlag.START
            on -> SweatFlag.ONGOING
            else -> SweatFlag.NONE
        }
        sweatWasOn = on
        return flag
    }

    private var lastSweatFlagForVitals = SweatFlag.NONE

    private fun buildVitals(t: Long): LiveVitals {
        val ppg = ppgActive(t)
        // Vitals mirror the most recent epoch's sweat flag (START fires once, on the epoch it began).
        val sf = records.lastOrNull()?.sweatFlag?.let { last ->
            if (last == SweatFlag.START && lastSweatFlagForVitals == SweatFlag.START) SweatFlag.ONGOING else last
        } ?: SweatFlag.NONE
        lastSweatFlagForVitals = sf
        return LiveVitals(
            tS = t,
            hrBpm = if (ppg) scenario.hr.roundToInt() else 0,
            hrQuality = if (ppg) scenario.hrQuality() else 0,
            skinTempX100 = (scenario.skinTemp * 100).roundToInt(),
            skinRhX100 = (scenario.skinRh * 100).roundToInt(),
            ambTempX100 = (scenario.ambTemp * 100).roundToInt(),
            ambRhX100 = (scenario.ambRh * 100).roundToInt(),
            motionIndex = scenario.motionIndex(),
            sleepState = if (logging) scenario.sleepState else com.aurora.msg.protocol.SleepState.UNKNOWN,
            sweatFlag = sf,
            battPct = scenario.battPct,
            flags = flags(t),
        )
    }

    private fun buildExtVitals(t: Long): ExtendedVitals = ExtendedVitals(
        tS = t,
        edaX100 = scenario.edaX100(),
        spo2X10 = scenario.spo2X10(),
        perfusionX100 = scenario.perfusionX100(),
        extFlags = scenario.extFlags(),
    )

    private fun buildRecord(t: Long): LogRecord {
        val ppg = ppgActive(t)
        val h = lastHrv
        val fresh = hrvFreshPending
        hrvFreshPending = false
        return LogRecord(
            tS = t,
            hrBpm = if (ppg) scenario.hr.roundToInt() else 0,
            hrQuality = if (ppg) scenario.hrQuality() else 0,
            skinTempX100 = (scenario.skinTemp * 100).roundToInt(),
            skinRhX100 = (scenario.skinRh * 100).roundToInt(),
            ambTempX100 = (scenario.ambTemp * 100).roundToInt(),
            ambRhX100 = (scenario.ambRh * 100).roundToInt(),
            motionIndex = scenario.motionIndex(),
            sleepState = scenario.sleepState,
            sweatFlag = sweatFlagNow(),
            battPct = scenario.battPct,
            flags = flags(t) or (if (fresh) PodFlags.HRV_FRESH else 0),
            dahX100 = scenario.dahX100(),
            hrvMeanIbiMs = h?.meanIbiMs ?: 0,
            hrvSdnnMsX10 = h?.sdnnMsX10 ?: 0,
            hrvRmssdMsX10 = h?.rmssdMsX10 ?: 0,
            hrvPnn50Pct = h?.pnn50Pct ?: 0,
            hrvQuality = h?.quality ?: 0,
            hrvFlags = h?.flags ?: 0,
            vcellCv = ((3.3f + 0.9f * scenario.battPct / 100f - 2.5f) * 100).roundToInt().coerceIn(1, 255),
            // The demo pod writes v2 (42-byte) records — same values FE06 is notifying.
            edaX100 = scenario.edaX100(),
            spo2X10 = scenario.spo2X10(),
            perfusionX100 = scenario.perfusionX100(),
            extFlags = scenario.extFlags(),
        )
    }

    private fun buildHrv(windowEndS: Long): HrvSummary {
        val motionHigh = scenario.motionIndex() > 150
        val ibi = (60_000f / scenario.hr).roundToInt()
        val restful = scenario.sleepState != com.aurora.msg.protocol.SleepState.WAKE
        val rmssd = scenario.gauss(if (restful) 48f else 32f, 6f).coerceIn(8f, 120f)
        val sdnn = (rmssd * 1.15f + scenario.gauss(0f, 4f)).coerceIn(8f, 140f)
        val quality = if (motionHigh) (30 + scenario.nextFloat() * 25).toInt() else (78 + scenario.nextFloat() * 20).toInt()
        var f = 0 // relative (session-start) timestamps in demo, so WALL_CLOCK is not set
        f = if (motionHigh) f or HrvFlags.MOTION else f or HrvFlags.VALID
        if (!motionHigh && scenario.nextFloat() < 0.06f) f = HrvFlags.LOW_PERF // occasional weak-pulse window
        return HrvSummary(
            windowEndTimeS = windowEndS,
            meanIbiMs = ibi,
            sdnnMsX10 = (sdnn * 10).roundToInt(),
            rmssdMsX10 = (rmssd * 10).roundToInt(),
            pnn50Pct = (rmssd / 2.2f).roundToInt().coerceIn(0, 100),
            beatsAccepted = if (motionHigh) 40 else 110,
            beatsRejected = if (motionHigh) 60 else 6,
            quality = quality,
            flags = f,
        )
    }

    private fun finishSession() {
        // Close any open sweat span with a final NONE record so the summary is exact.
        val slot = nextSlot
        val image = records.fold(ByteArray(0)) { acc, r -> acc + r.encode() }
        slots[slot] = image
        slotCounts[slot] = records.size
        lastSlot = slot
        nextSlot = (nextSlot + 1) % Cadence.NIGHT_SLOTS
        val s = NightAnalytics.summarize(records, slot)
        _summary.tryEmit(s)
        tickJob?.cancel(); tickJob = null
        if (_connection.value.isConnected) startTicking()
    }

    private fun lastSummary(): SessionSummary? {
        val image = slots[lastSlot] ?: return if (logging) NightAnalytics.summarize(records, nextSlot) else null
        // Slot images are v2 (42 B) records now; derive the stride like the replay header does.
        val size = if (slotCounts[lastSlot] > 0) image.size / slotCounts[lastSlot] else LogRecord.SIZE
        val recs = ArrayList<LogRecord>()
        var off = 0
        while (off + size <= image.size) { LogRecord.parse(image, off, size)?.let { recs.add(it) }; off += size }
        return NightAnalytics.summarize(recs, lastSlot)
    }

    private fun startReplay(slot: Int) {
        replayJob?.cancel()
        val image = slots[slot] ?: return // empty slot: no header ever arrives (spec §9 step 3)
        val frames = ReplayAssembler.frames(slot, image, slotCounts[slot])
        replayJob = scope.launch {
            for (f in frames) {
                if (!isActive) break
                _replay.emit(f)
                delay(4) // faster than hardware (15 ms) but still visibly progressive
            }
        }
    }

    /** Preload a slot with a generated night so "download" works in demo. */
    fun installSlot(slot: Int, records: List<LogRecord>) {
        slots[slot] = records.fold(ByteArray(0)) { acc, r -> acc + r.encode() }
        slotCounts[slot] = records.size
        lastSlot = slot
        nextSlot = (slot + 1) % Cadence.NIGHT_SLOTS
    }

    companion object {
        const val DEMO_ADDRESS = "DE:MO:00:00:00:01"
    }
}
