package com.aurora.msg.pod

import androidx.annotation.StringRes
import com.aurora.msg.R
import com.aurora.msg.data.repo.SessionRepository
import com.aurora.msg.protocol.HwConst
import com.aurora.msg.protocol.SessionSummary
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * A localizable line of the hardware check: a string resource + its format args, resolved by
 * the UI ([raw] text, when set, is shown as-is and [res] is ignored). [DurationArg] args are
 * formatted there with the app's duration formatter.
 */
data class CheckText(val res: Int, val args: List<Any> = emptyList(), val raw: String? = null)

/** A duration (seconds) argument of a [CheckText], formatted by the UI. */
data class DurationArg(val seconds: Long)

/** One row of the hardware-check result list. */
data class HardwareCheckStep(val id: Int, val title: CheckText, val status: Status, val detail: CheckText?) {
    enum class Status { PASS, FAIL, SKIPPED }
}

/**
 * One-button hardware check for the custom-page `hardware_check` section — the Android port of
 * the verified web routine (web/aurora-live.src.html, hardwareCheck()) and of the iPhone
 * HardwareCheckRunner, driven through [PodConnectionManager] so the app's own command paths
 * (clock sync, START/STOP confirmed by observing FE01/FE02, replay download) are what gets tested.
 *
 * Sequence: clock confirmed → (real pod) 5 s bench log interval → session START via the
 * manager → ~40 s live stream counting packets / CRC failures / sequence gaps / HR locks /
 * HRV windows → STOP and await the FE02 summary → download the log → restore the 60 s log
 * interval. Every row is pass / fail / skipped and a pass is only ever reported with the
 * evidence that earns it. The short test night is deleted afterwards (no morning card,
 * nothing left in the history). On the real pod the test session REPLACES the pod's stored
 * log (it keeps one session) — the UI warns before running.
 *
 * Refuses to start while a real night is recording (the check would end it), while a log
 * download runs, or without a connected pod. Owned by the manager (`pod.hardwareCheck`).
 */
class HardwareCheckRunner(
    private val pod: PodConnectionManager,
    private val repo: SessionRepository,
    private val scope: CoroutineScope,
) {
    sealed class Phase {
        data object Idle : Phase()
        data class Running(val status: CheckText) : Phase()
        data class Finished(val passed: Int, val failed: Int, val skipped: Int) : Phase()
    }

    private val _phase = MutableStateFlow<Phase>(Phase.Idle)
    val phase: StateFlow<Phase> = _phase.asStateFlow()
    private val _steps = MutableStateFlow<List<HardwareCheckStep>>(emptyList())
    val steps: StateFlow<List<HardwareCheckStep>> = _steps.asStateFlow()
    /** Why the last Run tap was refused; null when it was not. */
    private val _refusal = MutableStateFlow<CheckText?>(null)
    val refusal: StateFlow<CheckText?> = _refusal.asStateFlow()

    val isRunning: Boolean get() = _phase.value is Phase.Running

    private var job: Job? = null
    private var nextStepId = 0

    /** Why a run cannot start right now, or null when it can. */
    fun refusalReason(): CheckText? = when {
        isRunning -> CheckText(R.string.hc_refuse_running)
        !pod.connectionState.value.isConnected -> CheckText(R.string.hc_refuse_not_connected)
        pod.activeSession.value != null -> CheckText(R.string.hc_refuse_recording)
        pod.replayStatus.value.isActive -> CheckText(R.string.hc_refuse_downloading)
        else -> null
    }

    /** Start the check. A refused start only sets [refusal]. */
    fun run() {
        val reason = refusalReason()
        if (reason != null) { _refusal.value = reason; return }
        _refusal.value = null
        _steps.value = emptyList()
        nextStepId = 0
        _phase.value = Phase.Running(CheckText(R.string.hc_status_clock))
        job = scope.launch { execute() }
    }

    // ------------------------------------------------------------------ the routine

    private suspend fun execute() {
        pod.setTestRun(true)
        val hardware = pod.isHardwareLink
        var testSessionId: Long? = null
        try {
            // 1. Clock set on connect (TIME_SYNCED / TIME_VALID), confirmed by the manager.
            setStatus(R.string.hc_status_clock)
            val synced = waitFor(10_000) { pod.timeSynced.value }
            add(CheckText(R.string.hc_step_clock), if (synced) Pass else Fail, if (synced) null else CheckText(R.string.hc_detail_clock_fail))

            // 2. Bench log interval so a 40 s session leaves rows to download (real pod only).
            val benchTitle = CheckText(R.string.hc_step_interval_bench, listOf(BENCH_LOG_INTERVAL_S))
            if (hardware) {
                val ok = pod.setLogInterval(BENCH_LOG_INTERVAL_S)
                add(benchTitle, if (ok) Pass else Fail, if (ok) null else CheckText(R.string.hc_detail_write_failed))
                if (ok) delay(500)
            } else {
                add(benchTitle, Skipped, CheckText(R.string.hc_detail_demo_no_interval))
            }

            // 3. Session start through the manager (START confirmed via the LOGGING flag).
            setStatus(R.string.hc_status_starting)
            val startedAt = System.currentTimeMillis()
            val started = pod.connectionState.value.isConnected && pod.startSession()
            testSessionId = pod.activeSession.value?.id
            val sid = testSessionId
            add(CheckText(R.string.hc_step_session_start), if (started && sid != null) Pass else Fail,
                if (started) null else CheckText(R.string.hc_detail_session_not_started))

            if (started && sid != null) {
                val src = pod.source.value
                // 4. Live stream.
                var hrLocked = 0; var hrMin = 0; var hrMax = 0
                val base = src.linkStats.value
                val streamStart = System.currentTimeMillis()
                val hrJob = scope.launch {
                    src.vitals.collect { v ->
                        if (v.hasHr) {
                            hrLocked++
                            hrMin = if (hrMin == 0) v.hrBpm else minOf(hrMin, v.hrBpm)
                            hrMax = max(hrMax, v.hrBpm)
                        }
                    }
                }
                var left = STREAM_SECONDS
                while (left > 0) {
                    if (!pod.connectionState.value.isConnected) break
                    setStatus(R.string.hc_status_streaming, left)
                    delay(1_000)
                    left--
                }
                hrJob.cancel()
                val secs = (System.currentTimeMillis() - streamStart) / 1000.0
                val now = src.linkStats.value
                val packets = now.vitalsPackets - base.vitalsPackets
                val crc = now.crcFailures - base.crcFailures
                val gaps = now.seqGaps - base.seqGaps
                val hrvWindows = now.hrvPackets - base.hrvPackets
                val wholeSecs = max(secs.roundToInt(), 1)
                add(CheckText(R.string.hc_step_rate), if (packets >= secs * 0.8) Pass else Fail,
                    CheckText(R.string.hc_detail_rate, listOf(packets, wholeSecs)))
                if (hardware) {
                    add(CheckText(R.string.hc_step_crc), if (crc == 0) Pass else Fail, CheckText(0, raw = "$crc"))
                    add(CheckText(R.string.hc_step_gaps), if (gaps == 0) Pass else Fail, CheckText(0, raw = "$gaps"))
                } else {
                    // The simulator has no radio link and no sequence counter: nothing to prove.
                    add(CheckText(R.string.hc_step_crc), Skipped, CheckText(R.string.hc_detail_demo_no_crc))
                    add(CheckText(R.string.hc_step_gaps), Skipped, CheckText(R.string.hc_detail_demo_no_seq))
                }
                if (hrLocked > 0) {
                    add(CheckText(R.string.hc_step_hr), Pass, CheckText(R.string.hc_detail_hr, listOf(hrLocked, hrMin, hrMax)))
                } else {
                    // No fingertip on the sensor is not a fault of the pod.
                    add(CheckText(R.string.hc_step_hr), Skipped, CheckText(R.string.hc_detail_hr_skipped))
                }
                when {
                    hrvWindows > 0 -> add(CheckText(R.string.hc_step_hrv), Pass, CheckText(R.string.hc_detail_hrv, listOf(hrvWindows)))
                    hardware -> add(CheckText(R.string.hc_step_hrv), Fail, CheckText(R.string.hc_detail_hrv_none))
                    // The demo closes an HRV window only every 10 simulated minutes.
                    else -> add(CheckText(R.string.hc_step_hrv), Skipped, CheckText(R.string.hc_detail_hrv_demo))
                }
                if (!pod.connectionState.value.isConnected) add(CheckText(R.string.hc_step_link_lost), Fail, null)

                // 5. STOP and await the FE02 summary (subscribe before the write — the demo
                //    answers synchronously inside write()).
                setStatus(R.string.hc_status_stopping)
                var rawSummary: SessionSummary? = null
                val stopRequestedAt = System.currentTimeMillis()
                val sumJob = scope.launch(start = CoroutineStart.UNDISPATCHED) { src.summary.collect { rawSummary = it } }
                val stopped = pod.connectionState.value.isConnected && pod.stopSession()
                sumJob.cancel()
                val s = rawSummary
                if (stopped && s != null) {
                    add(CheckText(R.string.hc_step_summary), Pass, CheckText(R.string.hc_detail_summary, listOf(DurationArg(s.sessionLenS))))
                    if (hardware) {
                        // The pod timed START → STOP itself; compare with the phone's clock.
                        val expected = (stopRequestedAt - startedAt) / 1000.0
                        val ok = abs(s.sessionLenS - expected) <= 6.0
                        add(CheckText(R.string.hc_step_duration), if (ok) Pass else Fail,
                            CheckText(R.string.hc_detail_duration, listOf(s.sessionLenS.toInt(), expected.roundToInt())))
                    }
                } else {
                    add(CheckText(R.string.hc_step_summary), Fail, CheckText(R.string.hc_detail_summary_none))
                }

                // 6. Download the log into the test night.
                if (stopped && pod.connectionState.value.isConnected) {
                    setStatus(R.string.hc_status_download)
                    val slot = repo.sessionById(sid)?.slot ?: s?.slot ?: 0
                    val before = pod.replayStatus.value
                    pod.downloadNight(sid, slot)
                    // The manager starts the replay asynchronously: wait for it to begin first.
                    waitFor(5_000) { val r = pod.replayStatus.value; r.isActive || r !== before }
                    val finished = waitFor(150_000) { !pod.replayStatus.value.isActive }
                    if (!finished) pod.cancelDownload()
                    when (val r = pod.replayStatus.value) {
                        is ReplayStatus.Done -> {
                            val ok = r.records > 0 && r.crcFailures == 0 && r.complete
                            add(CheckText(R.string.hc_step_log), if (ok) Pass else Fail, CheckText(R.string.hc_detail_log, listOf(r.records, r.crcFailures)))
                        }
                        is ReplayStatus.Failed -> add(CheckText(R.string.hc_step_log), Fail, CheckText(r.messageRes, r.args))
                        else -> add(CheckText(R.string.hc_step_log), Fail, if (finished) null else CheckText(R.string.hc_detail_log_timeout))
                    }
                } else {
                    add(CheckText(R.string.hc_step_log), Skipped, CheckText(R.string.hc_detail_log_skipped))
                }
            }

            // 7. Restore the normal log interval (always attempted on the real pod).
            val restoreTitle = CheckText(R.string.hc_step_interval_restore, listOf(DEFAULT_LOG_INTERVAL_S))
            if (hardware) {
                val ok = pod.connectionState.value.isConnected && pod.setLogInterval(DEFAULT_LOG_INTERVAL_S)
                add(restoreTitle, if (ok) Pass else Fail, if (ok) null else CheckText(R.string.hc_detail_restore_fail, listOf(DEFAULT_LOG_INTERVAL_S)))
            } else {
                add(restoreTitle, Skipped, CheckText(R.string.hc_detail_demo_no_interval))
            }
        } finally {
            // 8. Remove the test night (and, if it is somehow still recording, stop the pod and
            //    discard that FE02). Runs even when the routine was cancelled.
            testSessionId?.let { pod.discardTestSession(it) }
            pod.setTestRun(false)
            val all = _steps.value
            _phase.value = Phase.Finished(
                passed = all.count { it.status == Pass },
                failed = all.count { it.status == Fail },
                skipped = all.count { it.status == Skipped },
            )
            job = null
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun setStatus(@StringRes res: Int, vararg args: Any) {
        _phase.value = Phase.Running(CheckText(res, args.toList()))
    }

    private fun add(title: CheckText, status: HardwareCheckStep.Status, detail: CheckText?) {
        nextStepId += 1
        _steps.value = _steps.value + HardwareCheckStep(nextStepId, title, status, detail)
    }

    /** Polls [predicate] every 0.2 s until it holds or [timeoutMs] elapse. */
    private suspend fun waitFor(timeoutMs: Long, predicate: () -> Boolean): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (predicate()) return true
            if (!scope.isActive) break
            delay(200)
        }
        return predicate()
    }

    companion object {
        const val STREAM_SECONDS = 40
        const val BENCH_LOG_INTERVAL_S = 5
        const val DEFAULT_LOG_INTERVAL_S = HwConst.DEFAULT_LOG_PERIOD_S

        private val Pass = HardwareCheckStep.Status.PASS
        private val Fail = HardwareCheckStep.Status.FAIL
        private val Skipped = HardwareCheckStep.Status.SKIPPED
    }
}
