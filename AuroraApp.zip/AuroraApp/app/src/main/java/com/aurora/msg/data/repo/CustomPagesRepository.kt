package com.aurora.msg.data.repo

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

/**
 * The user's custom pages (CUSTOM_PAGES_BRIEF.md), persisted in the app's DataStore under the
 * key `custom_pages` as the JSON string `[{"n":1,"sections":["live_hr","night_timeline"]}, …]`.
 * All logic lives in the pure [CustomPagesModel]; every mutation is one atomic DataStore edit.
 */
class CustomPagesRepository(private val context: Context) {
    private val key = stringPreferencesKey("custom_pages")
    /** The one date range every trend section on every custom page shares (like the iPhone app). */
    private val trendsRangeKey = intPreferencesKey("custom_trends_range")

    val pages: Flow<List<CustomPage>> = context.dataStore.data
        .map { p -> CustomPagesModel.decode(p[key]) }
        .distinctUntilChanged()

    val trendsRangeDays: Flow<Int> = context.dataStore.data
        .map { p -> p[trendsRangeKey] ?: DEFAULT_TRENDS_RANGE_DAYS }
        .distinctUntilChanged()

    suspend fun setTrendsRangeDays(days: Int) {
        context.dataStore.edit { p -> p[trendsRangeKey] = days }
    }

    /** Creates the lowest unused page number and returns it; null when 5 pages exist. */
    suspend fun createNextPage(): Int? {
        var created: Int? = null
        context.dataStore.edit { p ->
            val result = CustomPagesModel.createNextPage(CustomPagesModel.decode(p[key]))
            if (result != null) {
                p[key] = CustomPagesModel.encode(result.pages)
                created = result.n
            }
        }
        return created
    }

    suspend fun deletePage(n: Int) = update { CustomPagesModel.deletePage(it, n) }
    suspend fun addSection(n: Int, id: String) = update { CustomPagesModel.addSection(it, n, id) }
    suspend fun removeSection(n: Int, id: String) = update { CustomPagesModel.removeSection(it, n, id) }

    /** [from] / [to] are positions in the page's VISIBLE (known) sections; [to] is the final index. */
    suspend fun moveSection(n: Int, from: Int, to: Int) = update { CustomPagesModel.moveSection(it, n, from, to) }

    /** Accessibility move up (-1) / move down (+1). */
    suspend fun moveSectionBy(n: Int, id: String, delta: Int) = update { CustomPagesModel.moveSectionBy(it, n, id, delta) }

    private suspend fun update(change: (List<CustomPage>) -> List<CustomPage>) {
        context.dataStore.edit { p ->
            val current = CustomPagesModel.decode(p[key])
            val next = change(current)
            if (next != current) p[key] = CustomPagesModel.encode(next)
        }
    }

    companion object { const val DEFAULT_TRENDS_RANGE_DAYS = 14 }
}
