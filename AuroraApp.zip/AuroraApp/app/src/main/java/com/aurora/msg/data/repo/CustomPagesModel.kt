package com.aurora.msg.data.repo

/**
 * One user-built page (CUSTOM_PAGES_BRIEF.md): its number 1…5 and the section IDs in order.
 * Section IDs are the catalogue's stable strings ([CustomPagesModel.KNOWN_SECTION_IDS]); IDs this
 * build does not know (written by a newer version) are kept untouched and skipped when rendering.
 */
data class CustomPage(val n: Int, val sections: List<String> = emptyList())

/**
 * Pure-Kotlin model behind [CustomPagesRepository] — no Android APIs, unit-tested offline.
 *
 * Stored as the JSON string `[{"n":1,"sections":["live_hr","night_timeline"]}, …]`, pages
 * sorted by n — the same shape the iPhone app (UserDefaults) and the web app (localStorage)
 * use. Every function takes the current list and returns the new one; nothing is mutated.
 *
 * Positions passed to [moveSection] index the VISIBLE list (the known sections the page
 * renders); unknown IDs keep their absolute slots in the stored array.
 */
object CustomPagesModel {
    const val MAX_PAGES = 5

    /** Stable section IDs shared by Android, iPhone and the web app — library order. */
    val KNOWN_SECTION_IDS: List<String> = listOf(
        // Live
        "live_hr", "live_moisture", "live_skin_temp", "live_skin_rh", "live_spo2", "live_quality",
        "live_status", "live_chart", "live_hrv", "live_conductance", "session_controls",
        // Nights
        "last_night", "morning_card", "night_timeline", "vital_sheet", "recent_nights", "sweat_events",
        // Trends
        "trends_overview", "trends_flashes", "trends_hr", "trends_time_in_bed", "trends_sleep",
        // Pod
        "pod_connection", "pod_info", "pod_log", "pod_controls", "demo_controls",
        // Diagnostics
        "link_health", "packet_inspector", "hardware_check",
    )

    private val knownSet: Set<String> = KNOWN_SECTION_IDS.toSet()

    fun isKnown(id: String): Boolean = id in knownSet

    // ------------------------------------------------------------------ queries

    fun page(pages: List<CustomPage>, n: Int): CustomPage? = pages.firstOrNull { it.n == n }

    /** The sections a page renders, in order (unknown IDs skipped). */
    fun visibleSections(page: CustomPage?, isKnown: (String) -> Boolean = ::isKnown): List<String> =
        page?.sections?.filter(isKnown) ?: emptyList()

    /** Lowest unused page number 1…5, or null when all five exist. */
    fun nextPageNumber(pages: List<CustomPage>): Int? {
        val used = pages.map { it.n }.toSet()
        return (1..MAX_PAGES).firstOrNull { it !in used }
    }

    fun canCreatePage(pages: List<CustomPage>): Boolean = nextPageNumber(pages) != null

    // ------------------------------------------------------------------ mutations (pure)

    /** Result of [createNextPage]: the new list and the number that was created. */
    data class Created(val pages: List<CustomPage>, val n: Int)

    /** Creates the lowest unused page number; null when 5 pages exist. */
    fun createNextPage(pages: List<CustomPage>): Created? {
        val n = nextPageNumber(pages) ?: return null
        return Created(sorted(pages + CustomPage(n)), n)
    }

    fun deletePage(pages: List<CustomPage>, n: Int): List<CustomPage> = pages.filter { it.n != n }

    /**
     * Appends a section to the end of a page. A section may be on several pages but only once
     * per page: unchanged when it is already there or the page does not exist.
     */
    fun addSection(pages: List<CustomPage>, n: Int, id: String): List<CustomPage> =
        pages.map { p -> if (p.n == n && id !in p.sections) p.copy(sections = p.sections + id) else p }

    fun removeSection(pages: List<CustomPage>, n: Int, id: String): List<CustomPage> =
        pages.map { p -> if (p.n == n) p.copy(sections = p.sections.filter { it != id }) else p }

    /**
     * Moves the section at visible position [from] so that it ends up at visible position [to]
     * (both indices into [visibleSections]; [to] is the final index, like a drag). Unknown IDs
     * stay in their stored slots. Out-of-range positions are clamped / ignored.
     */
    fun moveSection(
        pages: List<CustomPage>, n: Int, from: Int, to: Int,
        isKnown: (String) -> Boolean = ::isKnown,
    ): List<CustomPage> = pages.map { p ->
        if (p.n != n) return@map p
        val visible = p.sections.filter(isKnown)
        if (from !in visible.indices || visible.isEmpty()) return@map p
        val target = to.coerceIn(0, visible.lastIndex)
        if (target == from) return@map p
        val moved = visible.toMutableList().apply { add(target, removeAt(from)) }
        // Refill the known slots in their new order; unknown IDs keep their positions.
        val it = moved.iterator()
        p.copy(sections = p.sections.map { id -> if (isKnown(id) && it.hasNext()) it.next() else id })
    }

    /** Accessibility "Move up / Move down": shifts one section by [delta] visible positions. */
    fun moveSectionBy(
        pages: List<CustomPage>, n: Int, id: String, delta: Int,
        isKnown: (String) -> Boolean = ::isKnown,
    ): List<CustomPage> {
        val visible = visibleSections(page(pages, n), isKnown)
        val from = visible.indexOf(id)
        if (from < 0) return pages
        return moveSection(pages, n, from, (from + delta).coerceIn(0, visible.lastIndex), isKnown)
    }

    private fun sorted(pages: List<CustomPage>): List<CustomPage> = pages.sortedBy { it.n }

    // ------------------------------------------------------------------ JSON

    /**
     * Parses the stored JSON: pages sorted by n, numbers outside 1…5 and duplicate numbers
     * dropped, duplicate section IDs within a page dropped, non-string IDs ignored; a page
     * without a "sections" list is an empty page; anything unreadable → no pages.
     */
    fun decode(json: String?): List<CustomPage> {
        if (json.isNullOrBlank()) return emptyList()
        val root = try { MiniJson(json).parseDocument() } catch (e: IllegalArgumentException) { return emptyList() }
        if (root !is List<*>) return emptyList()
        val seen = HashSet<Int>()
        val out = ArrayList<CustomPage>()
        for (item in root) {
            val obj = item as? Map<*, *> ?: continue
            val num = obj["n"] as? Double ?: continue
            if (num != Math.floor(num)) continue
            val n = num.toInt()
            if (n < 1 || n > MAX_PAGES || !seen.add(n)) continue
            val ids = ArrayList<String>()
            (obj["sections"] as? List<*>)?.forEach { s -> if (s is String && s !in ids) ids.add(s) }
            out.add(CustomPage(n, ids))
        }
        return sorted(out)
    }

    /** `[{"n":1,"sections":[…]}, …]` — "n" first, pages sorted by n. */
    fun encode(pages: List<CustomPage>): String {
        val sb = StringBuilder("[")
        sorted(pages).forEachIndexed { i, p ->
            if (i > 0) sb.append(',')
            sb.append("{\"n\":").append(p.n).append(",\"sections\":[")
            p.sections.forEachIndexed { j, id ->
                if (j > 0) sb.append(',')
                appendJsonString(sb, id)
            }
            sb.append("]}")
        }
        return sb.append(']').toString()
    }

    private fun appendJsonString(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append("\\u").append(String.format("%04x", c.code))
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }

    /**
     * A tiny strict JSON reader (objects → Map, arrays → List, strings, numbers → Double,
     * true/false/null). Throws IllegalArgumentException on malformed input.
     */
    private class MiniJson(private val s: String) {
        private var i = 0

        fun parseDocument(): Any? {
            val v = value()
            ws()
            if (i != s.length) fail("trailing data")
            return v
        }

        private fun fail(msg: String): Nothing = throw IllegalArgumentException("JSON: $msg at $i")

        private fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }

        private fun value(): Any? {
            ws()
            if (i >= s.length) fail("unexpected end")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> literal("true", true)
                'f' -> literal("false", false)
                'n' -> literal("null", null)
                else -> if (c == '-' || c.isDigit()) num() else fail("unexpected '$c'")
            }
        }

        private fun literal(word: String, v: Any?): Any? {
            if (!s.startsWith(word, i)) fail("bad literal")
            i += word.length
            return v
        }

        private fun obj(): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>()
            i++ // {
            ws()
            if (i < s.length && s[i] == '}') { i++; return m }
            while (true) {
                ws()
                if (i >= s.length || s[i] != '"') fail("expected key")
                val k = str()
                ws()
                if (i >= s.length || s[i] != ':') fail("expected ':'")
                i++
                m[k] = value()
                ws()
                if (i >= s.length) fail("unterminated object")
                when (s[i]) {
                    ',' -> i++
                    '}' -> { i++; return m }
                    else -> fail("expected ',' or '}'")
                }
            }
        }

        private fun arr(): List<Any?> {
            val l = ArrayList<Any?>()
            i++ // [
            ws()
            if (i < s.length && s[i] == ']') { i++; return l }
            while (true) {
                l.add(value())
                ws()
                if (i >= s.length) fail("unterminated array")
                when (s[i]) {
                    ',' -> i++
                    ']' -> { i++; return l }
                    else -> fail("expected ',' or ']'")
                }
            }
        }

        private fun str(): String {
            val sb = StringBuilder()
            i++ // opening quote
            while (true) {
                if (i >= s.length) fail("unterminated string")
                val c = s[i++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        if (i >= s.length) fail("bad escape")
                        when (val e = s[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) fail("bad unicode escape")
                                val hex = s.substring(i, i + 4)
                                val code = hex.toIntOrNull(16) ?: fail("bad unicode escape")
                                sb.append(code.toChar())
                                i += 4
                            }
                            else -> fail("bad escape '$e'")
                        }
                    }
                    c < ' ' -> fail("control character in string")
                    else -> sb.append(c)
                }
            }
        }

        private fun num(): Double {
            val start = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
            return s.substring(start, i).toDoubleOrNull() ?: fail("bad number")
        }
    }
}
