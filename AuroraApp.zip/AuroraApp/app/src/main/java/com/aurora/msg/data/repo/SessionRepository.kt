package com.aurora.msg.data.repo

import com.aurora.msg.data.db.ActivityEventEntity
import com.aurora.msg.data.db.ActivityKind
import com.aurora.msg.data.db.AuroraDatabase
import com.aurora.msg.data.db.EpochEntity
import com.aurora.msg.data.db.EventSource
import com.aurora.msg.data.db.HrvPointEntity
import com.aurora.msg.data.db.PodSlotEntity
import com.aurora.msg.data.db.ReplayState
import com.aurora.msg.data.db.SessionEntity
import com.aurora.msg.data.db.SessionSource
import com.aurora.msg.data.db.SessionSummaryEntity
import com.aurora.msg.data.db.SweatEventEntity
import com.aurora.msg.domain.NightAnalytics
import com.aurora.msg.protocol.HrvSummary
import com.aurora.msg.protocol.HwAdapter
import com.aurora.msg.protocol.HwConst
import com.aurora.msg.protocol.LogRecord
import com.aurora.msg.protocol.SessionSummary
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.protocol.SweatFlag
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

/** Everything a Night Detail screen needs, observed live. */
data class NightBundle(
    val session: SessionEntity,
    val summary: SessionSummaryEntity?,
    val epochs: List<EpochEntity>,
    val hrv: List<HrvPointEntity>,
    val sweat: List<SweatEventEntity>,
    val events: List<ActivityEventEntity>,
)

data class NightCard(val session: SessionEntity, val summary: SessionSummaryEntity?)

class SessionRepository(private val db: AuroraDatabase) {

    // ------------------------------------------------------------------ mapping

    fun LogRecord.toEntity(sessionId: Long) = EpochEntity(
        sessionId = sessionId, tS = tS, hrBpm = hrBpm, hrQuality = hrQuality,
        skinTempX100 = skinTempX100, skinRhX100 = skinRhX100, ambTempX100 = ambTempX100, ambRhX100 = ambRhX100,
        motionIndex = motionIndex, sleepState = sleepState.code, sweatFlag = sweatFlag.code, battPct = battPct,
        flags = flags, dahX100 = dahX100, hrvMeanIbi = hrvMeanIbiMs, hrvSdnnX10 = hrvSdnnMsX10,
        hrvRmssdX10 = hrvRmssdMsX10, hrvPnn50 = hrvPnn50Pct, hrvQuality = hrvQuality, hrvFlags = hrvFlags, vcellCv = vcellCv,
        edaX100 = edaX100, spo2X10 = spo2X10, perfusionX100 = perfusionX100, extFlags = extFlags,
    )

    fun EpochEntity.toRecord() = LogRecord(
        tS = tS, hrBpm = hrBpm, hrQuality = hrQuality, skinTempX100 = skinTempX100, skinRhX100 = skinRhX100,
        ambTempX100 = ambTempX100, ambRhX100 = ambRhX100, motionIndex = motionIndex,
        sleepState = SleepState.fromCode(sleepState), sweatFlag = SweatFlag.fromCode(sweatFlag), battPct = battPct,
        flags = flags, dahX100 = dahX100, hrvMeanIbiMs = hrvMeanIbi, hrvSdnnMsX10 = hrvSdnnX10,
        hrvRmssdMsX10 = hrvRmssdX10, hrvPnn50Pct = hrvPnn50, hrvQuality = hrvQuality, hrvFlags = hrvFlags, vcellCv = vcellCv,
        edaX100 = edaX100, spo2X10 = spo2X10, perfusionX100 = perfusionX100, extFlags = extFlags,
    )

    private fun SessionSummary.toEntity(sessionId: Long) = SessionSummaryEntity(
        sessionId = sessionId, sessionLenS = sessionLenS, epochsLogged = epochsLogged, sweatEvents = sweatEvents,
        longestSweatS = longestSweatS, peakDahX100 = peakDahX100, hrMean = hrMeanBpm, hrMin = hrMinBpm, hrMax = hrMaxBpm,
        pctWake = pctWake, pctLight = pctLight, pctDeep = pctDeep, battPct = battPct, slot = slot,
    )

    // ------------------------------------------------------------------ session lifecycle

    /** Called the instant CMD_START_SESSION is confirmed (spec §8.2): the app owns the wall-clock start. */
    suspend fun startSession(userId: Long, source: SessionSource, startedAtMs: Long = System.currentTimeMillis()): SessionEntity {
        val id = db.sessions().insert(SessionEntity(userId = userId, startedAtEpochMs = startedAtMs, source = source))
        db.activityEvents().insert(ActivityEventEntity(sessionId = id, tS = 0, kind = ActivityKind.SESSION_START, label = "Session started", source = EventSource.POD))
        return db.sessions().byId(id)!!
    }

    suspend fun openSession(userId: Long): SessionEntity? = db.sessions().openSession(userId)

    /** Called on the FE02 summary after STOP. Saves the slot byte — the only way to replay later (spec §11). */
    suspend fun endSession(session: SessionEntity, summary: SessionSummary, endedAtMs: Long = System.currentTimeMillis()) {
        val endTs = ((endedAtMs - session.startedAtEpochMs) / 1000).coerceAtLeast(0)
        db.sessions().update(session.copy(endedAtEpochMs = endedAtMs, slot = summary.slot))
        db.summaries().upsert(summary.toEntity(session.id))
        db.podSlots().upsert(PodSlotEntity(summary.slot, session.id, endedAtMs))
        db.activityEvents().insert(ActivityEventEntity(sessionId = session.id, tS = endTs, kind = ActivityKind.SESSION_END, label = "Session ended", source = EventSource.POD))
        refreshSweatEvents(session.id)
    }

    /** A provisional 30 s epoch synthesised from live FE01 packets while the phone is connected. */
    suspend fun appendProvisionalEpoch(sessionId: Long, record: LogRecord) {
        db.epochs().insert(record.toEntity(sessionId))
        if (record.sweatFlag != SweatFlag.NONE || record.tS % 300 == 0L) refreshSweatEvents(sessionId)
    }

    suspend fun appendHrv(sessionId: Long, h: HrvSummary, windowEndS: Long) {
        db.hrv().insert(
            HrvPointEntity(
                sessionId = sessionId, windowEndS = windowEndS, meanIbi = h.meanIbiMs, sdnnX10 = h.sdnnMsX10,
                rmssdX10 = h.rmssdMsX10, pnn50 = h.pnn50Pct, accepted = h.beatsAccepted, rejected = h.beatsRejected,
                quality = h.quality, flags = h.flags,
            )
        )
    }

    suspend fun addActivityEvent(sessionId: Long, tS: Long, kind: ActivityKind, source: EventSource, label: String = kind.label) {
        db.activityEvents().insert(ActivityEventEntity(sessionId = sessionId, tS = tS, kind = kind, label = label, source = source))
    }

    /**
     * Authoritative data from a replay REPLACES provisional epochs. Summary is recomputed
     * if none exists (older nights, spec §15.3).
     */
    suspend fun storeReplay(sessionId: Long, records: List<LogRecord>, crcFailures: Int, complete: Boolean) {
        val session = db.sessions().byId(sessionId) ?: return
        if (records.isEmpty()) return // never let an empty download wipe a night
        if (records.all { !HwAdapter.hasAmbient(it.ambTempX100) }) {
            storeHardwareReplay(session, records, crcFailures, complete); return
        }
        db.epochs().deleteForSession(sessionId)
        db.hrv().deleteForSession(sessionId)
        db.epochs().insertAll(records.map { it.toEntity(sessionId) })
        db.hrv().insertAll(
            NightAnalytics.hrvSeries(records).map {
                HrvPointEntity(
                    sessionId = sessionId, windowEndS = it.tS, meanIbi = it.hrvMeanIbiMs, sdnnX10 = it.hrvSdnnMsX10,
                    rmssdX10 = it.hrvRmssdMsX10, pnn50 = it.hrvPnn50Pct, accepted = 0, rejected = 0,
                    quality = it.hrvQuality, flags = it.hrvFlags,
                )
            }
        )
        db.sessions().update(
            session.copy(replayState = if (complete) ReplayState.COMPLETE else ReplayState.PARTIAL, crcFailures = crcFailures)
        )
        if (db.summaries().bySession(sessionId) == null) {
            db.summaries().upsert(NightAnalytics.summarize(records, session.slot ?: 0).toEntity(sessionId))
        }
        refreshSweatEvents(sessionId)
    }

    /**
     * The real glove's log (hardware protocol v1) is COARSER than what the phone saw live:
     * one row per 60 s, no HRV, vs 30 s averages of 1 Hz data plus FE05 every 10 s. So it
     * only FILLS epochs the phone missed (disconnects) and never deletes provisional epochs
     * or HRV points. The morning-card HR range and peak are then recomputed over the merged
     * night, keeping the pod's own duration and (provisional) flush count.
     */
    private suspend fun storeHardwareReplay(session: SessionEntity, records: List<LogRecord>, crcFailures: Int, complete: Boolean) {
        val sessionId = session.id
        val existing = db.epochs().forSession(sessionId).mapTo(HashSet()) { it.tS }
        db.epochs().insertAll(records.filter { it.tS !in existing }.map { it.toEntity(sessionId) })
        db.sessions().update(
            session.copy(replayState = if (complete) ReplayState.COMPLETE else ReplayState.PARTIAL, crcFailures = crcFailures)
        )
        val merged = db.epochs().forSession(sessionId).map { it.toRecord() }
        val re = NightAnalytics.summarize(merged, session.slot ?: 0)
        val cur = db.summaries().bySession(sessionId)
        db.summaries().upsert(
            cur?.copy(hrMean = re.hrMeanBpm, hrMin = re.hrMinBpm, hrMax = re.hrMaxBpm,
                peakDahX100 = maxOf(cur.peakDahX100, re.peakDahX100))
                ?: re.toEntity(sessionId)
        )
        refreshSweatEvents(sessionId)
    }

    /** Insert a fully generated night (demo history). */
    suspend fun insertGeneratedNight(
        userId: Long, startedAtMs: Long, records: List<LogRecord>,
        events: List<Pair<Long, ActivityKind>>, slot: Int,
    ): Long {
        val lenS = records.lastOrNull()?.tS?.plus(30) ?: 0L
        val id = db.sessions().insert(
            SessionEntity(
                userId = userId, startedAtEpochMs = startedAtMs, endedAtEpochMs = startedAtMs + lenS * 1000,
                slot = slot, source = SessionSource.DEMO, replayState = ReplayState.COMPLETE,
            )
        )
        db.activityEvents().insertAll(
            listOf(ActivityEventEntity(sessionId = id, tS = 0, kind = ActivityKind.SESSION_START, label = "Session started", source = EventSource.POD)) +
                events.map { (t, k) -> ActivityEventEntity(sessionId = id, tS = t, kind = k, label = k.label, source = EventSource.DEMO) } +
                listOf(ActivityEventEntity(sessionId = id, tS = lenS, kind = ActivityKind.SESSION_END, label = "Session ended", source = EventSource.POD))
        )
        storeReplay(id, records, 0, complete = true)
        db.podSlots().upsert(PodSlotEntity(slot, id, startedAtMs + lenS * 1000))
        return id
    }

    private suspend fun refreshSweatEvents(sessionId: Long) {
        val records = db.epochs().forSession(sessionId).map { it.toRecord() }
        val spans = NightAnalytics.sweatSpans(records)
        db.sweatEvents().replaceForSession(sessionId, spans.map { SweatEventEntity(sessionId = sessionId, startS = it.startS, endS = it.endS, peakDahX100 = it.peakDahX100) })
    }

    // ------------------------------------------------------------------ queries

    fun observeSession(id: Long): Flow<SessionEntity?> = db.sessions().observe(id)

    @OptIn(ExperimentalCoroutinesApi::class)
    fun observeNight(sessionId: Long): Flow<NightBundle?> =
        db.sessions().observe(sessionId).flatMapLatest { s ->
            if (s == null) flowOf(null)
            else combine(
                db.summaries().observe(sessionId),
                db.epochs().observe(sessionId),
                db.hrv().observe(sessionId),
                db.sweatEvents().observe(sessionId),
                db.activityEvents().observe(sessionId),
            ) { sum, ep, hrv, sw, ev -> NightBundle(s, sum, ep, hrv, sw, ev) }
        }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun observeNightCards(userId: Long): Flow<List<NightCard>> =
        db.sessions().observeAll(userId).flatMapLatest { sessions ->
            if (sessions.isEmpty()) flowOf(emptyList())
            else db.summaries().observeFor(sessions.map { it.id }).map { sums ->
                val byId = sums.associateBy { it.sessionId }
                sessions.map { NightCard(it, byId[it.id]) }
            }
        }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun observeLatestNight(userId: Long): Flow<NightBundle?> =
        db.sessions().observeLatestCompleted(userId).flatMapLatest { s -> if (s == null) flowOf(null) else observeNight(s.id) }

    fun observeSlots(): Flow<List<PodSlotEntity>> = db.podSlots().observeAll()

    suspend fun sessionCount(userId: Long): Int = db.sessions().count(userId)
    suspend fun epochsFor(sessionId: Long): List<EpochEntity> = db.epochs().forSession(sessionId)
    suspend fun sessionById(id: Long): SessionEntity? = db.sessions().byId(id)

    suspend fun deleteSession(id: Long) = db.sessions().delete(id)
    suspend fun deleteAll(userId: Long) { db.sessions().deleteAllForUser(userId); db.podSlots().clear() }

    /** Simple CSV export of one night (for "take it to your doctor"). */
    suspend fun exportCsv(sessionId: Long): String {
        val s = db.sessions().byId(sessionId) ?: return ""
        val sb = StringBuilder("time_iso,t_s,hr_bpm,hr_quality,skin_temp_c,skin_rh,amb_temp_c,amb_rh,dah_g_m3,motion,sleep_state,sweat_flag,batt_pct,hrv_rmssd_ms,hrv_valid,eda_uS,spo2_pct,perfusion_pct\n")
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
        for (e in db.epochs().forSession(sessionId)) {
            val r = e.toRecord()
            sb.append(fmt.format(java.util.Date(s.startedAtEpochMs + e.tS * 1000))).append(',')
                .append(e.tS).append(',').append(e.hrBpm).append(',').append(e.hrQuality).append(',')
                .append("%.2f".format(r.skinTempC)).append(',').append("%.1f".format(e.skinRhX100 / 100f)).append(',')
                // The real glove has no room sensor: blank, never the -327.68 sentinel.
                .append(if (HwAdapter.hasAmbient(e.ambTempX100)) "%.2f".format(r.ambTempC) else "").append(',')
                .append(if (HwAdapter.hasAmbient(e.ambTempX100)) "%.1f".format(e.ambRhX100 / 100f) else "").append(',')
                .append("%.2f".format(r.dah)).append(',').append(e.motionIndex).append(',')
                .append(r.sleepState.name).append(',').append(r.sweatFlag.name).append(',')
                .append(if (e.battPct == HwConst.BATT_UNKNOWN) "" else e.battPct.toString()).append(',')
                .append(if (r.hrvFresh) "%.1f".format(e.hrvRmssdX10 / 10f) else "").append(',')
                .append(if (r.hrvFresh && r.hrvValid) 1 else 0).append(',')
                // Ext columns (brief §7): only CRC-verified AND VALID-flagged values; blank otherwise.
                .append(r.edaUs?.let { "%.2f".format(it) } ?: "").append(',')
                .append(r.spo2Pct?.let { "%.1f".format(it) } ?: "").append(',')
                .append(r.perfusionPct?.let { "%.2f".format(it) } ?: "").append('\n')
        }
        return sb.toString()
    }
}
