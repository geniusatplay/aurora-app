package com.aurora.msg.data.repo

import androidx.annotation.StringRes
import com.aurora.msg.R
import com.aurora.msg.data.db.UserDao
import com.aurora.msg.data.db.UserEntity
import java.security.MessageDigest
import java.security.SecureRandom

sealed class AuthResult {
    data class Success(val user: UserEntity) : AuthResult()
    data class Failure(@StringRes val messageRes: Int) : AuthResult()
}

/**
 * Local-only accounts. Passwords are salted SHA-256 (never stored in clear).
 * When a server exists, [SyncGateway.signIn] replaces this and the returned token is
 * stored instead of a local hash — the UI contract stays the same.
 */
class AuthRepository(private val users: UserDao, private val settings: SettingsRepository) {

    companion object {
        const val DEMO_EMAIL = "aurorademo@gmail.com"
        const val DEMO_PASSWORD = "pswd"
        const val DEMO_NAME = "Aurora Demo"
    }

    /** Creates the demo account on first launch. */
    suspend fun seedDemoAccount() {
        if (users.byEmail(DEMO_EMAIL) == null) {
            val salt = newSalt()
            users.insert(
                UserEntity(
                    email = DEMO_EMAIL,
                    passwordHash = hash(DEMO_PASSWORD, salt),
                    salt = salt,
                    displayName = DEMO_NAME,
                    createdAt = System.currentTimeMillis(),
                )
            )
        }
    }

    suspend fun signIn(email: String, password: String): AuthResult {
        val e = email.trim()
        if (e.isBlank() || password.isBlank()) return AuthResult.Failure(R.string.app_auth_enter_credentials)
        val user = users.byEmail(e) ?: return AuthResult.Failure(R.string.app_auth_no_account)
        if (hash(password, user.salt) != user.passwordHash) return AuthResult.Failure(R.string.app_auth_wrong_password)
        settings.setUserId(user.id)
        return AuthResult.Success(user)
    }

    suspend fun register(email: String, password: String, name: String): AuthResult {
        val e = email.trim()
        if (!e.contains('@') || !e.contains('.')) return AuthResult.Failure(R.string.app_auth_invalid_email)
        if (password.length < 4) return AuthResult.Failure(R.string.app_auth_password_short)
        if (users.byEmail(e) != null) return AuthResult.Failure(R.string.app_auth_email_exists)
        val salt = newSalt()
        val id = users.insert(
            UserEntity(
                email = e, passwordHash = hash(password, salt), salt = salt,
                displayName = name.ifBlank { e.substringBefore('@') }, createdAt = System.currentTimeMillis(),
            )
        )
        val user = users.byId(id) ?: return AuthResult.Failure(R.string.app_auth_create_failed)
        settings.setUserId(user.id)
        return AuthResult.Success(user)
    }

    suspend fun signOut() = settings.setUserId(null)

    suspend fun user(id: Long): UserEntity? = users.byId(id)

    private fun newSalt(): String {
        val b = ByteArray(16); SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    private fun hash(password: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val d = md.digest((salt + ":" + password).toByteArray(Charsets.UTF_8))
        return d.joinToString("") { "%02x".format(it) }
    }
}
