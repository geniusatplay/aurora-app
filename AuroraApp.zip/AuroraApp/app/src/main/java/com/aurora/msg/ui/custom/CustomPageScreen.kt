package com.aurora.msg.ui.custom

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.aurora.msg.R
import com.aurora.msg.data.repo.CustomPage
import com.aurora.msg.data.repo.CustomPagesModel
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.EmptyState
import kotlinx.coroutines.launch

/** Room left under the content so the + button never covers the last section. */
private val FabClearance = 88.dp

/**
 * A user-built page ("Page N"): its sections rendered top-to-bottom with real data, an
 * "Add section" button, and an overflow menu with Edit layout / Delete page. Edit mode turns
 * every section into a compact row with a drag handle (long-press and drag to reorder), a
 * remove ×, and Move up / Move down / Remove accessibility actions. "Done" exits.
 */
@Composable
fun CustomPageScreen(
    vm: AppViewModel,
    page: CustomPage,
    inner: PaddingValues,
    actions: SectionActions,
    onAddSection: () -> Unit,
    onDeletePage: () -> Unit,
) {
    val n = page.n
    // Unknown IDs (from a newer version) stay stored but are skipped here.
    val sections = CustomPagesModel.visibleSections(page) { SectionCatalog.find(it) != null }
    var editing by rememberSaveable(n) { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(sections.isEmpty()) { if (sections.isEmpty()) editing = false }

    val header: @Composable () -> Unit = {
        PageHeader(
            n = n, editing = editing, canEdit = sections.isNotEmpty(),
            onEdit = { editing = true }, onDone = { editing = false }, onDelete = { confirmDelete = true },
        )
    }

    if (editing) {
        Column(Modifier.fillMaxSize().padding(top = inner.calculateTopPadding())) {
            Box(Modifier.padding(horizontal = 16.dp)) { header() }
            Text(
                stringResource(R.string.cp_edit_hint), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 8.dp),
            )
            EditList(vm, n, sections, Modifier.weight(1f), bottomPadding = inner.calculateBottomPadding() + FabClearance)
        }
    } else {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding(), bottom = inner.calculateBottomPadding() + FabClearance),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            header()
            if (sections.isEmpty()) {
                AuroraCard {
                    EmptyState(stringResource(R.string.cp_empty_title), stringResource(R.string.cp_empty_body)) {
                        AddSectionButton(onAddSection)
                    }
                }
            } else {
                // A plain Column (not lazy): sections keep their state (scrub, pause, …) while
                // scrolled off screen; key() moves that state with a section when reordered.
                sections.forEach { id -> key(id) { SectionContent(id, vm, actions) } }
                Box(Modifier.fillMaxWidth().padding(top = 4.dp), contentAlignment = Alignment.Center) { AddSectionButton(onAddSection) }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.cp_delete_title, n)) },
            text = { Text(stringResource(R.string.cp_delete_body)) },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; editing = false; onDeletePage() }) {
                    Text(stringResource(R.string.cp_delete_confirm), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.common_cancel)) } },
        )
    }
}

@Composable
private fun PageHeader(n: Int, editing: Boolean, canEdit: Boolean, onEdit: () -> Unit, onDone: () -> Unit, onDelete: () -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            stringResource(R.string.cp_page_title, n), style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.weight(1f).semantics { heading() },
        )
        if (editing) {
            TextButton(onClick = onDone) { Text(stringResource(R.string.cp_done), fontWeight = FontWeight.SemiBold) }
        } else Box {
            IconButton(onClick = { menuOpen = true }) { Icon(Icons.Rounded.MoreVert, stringResource(R.string.cp_page_menu)) }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.cp_edit_layout)) },
                    leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                    enabled = canEdit,
                    onClick = { menuOpen = false; onEdit() },
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.cp_delete_page), color = MaterialTheme.colorScheme.error) },
                    leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) },
                    onClick = { menuOpen = false; onDelete() },
                )
            }
        }
    }
}

@Composable
private fun AddSectionButton(onClick: () -> Unit) {
    Button(onClick = onClick, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) {
        Icon(Icons.Rounded.Add, null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.cp_add_section))
    }
}

// ====================================================================== edit mode

/**
 * Compact rows with drag-to-reorder: long-press the ≡ handle and drag. The dragged row follows
 * the finger (translation computed from the list's live layout info), rows swap when its middle
 * crosses another row, and the new order is saved once on release. No third-party libraries.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EditList(vm: AppViewModel, n: Int, sections: List<String>, modifier: Modifier, bottomPadding: androidx.compose.ui.unit.Dp) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    // Local order while dragging; follows the stored order whenever it changes.
    val orderState = remember { mutableStateOf(sections) }
    LaunchedEffect(sections) { orderState.value = sections }
    val draggingId = remember { mutableStateOf<String?>(null) }
    val dragStartTop = remember { mutableIntStateOf(0) }
    val dragDelta = remember { mutableFloatStateOf(0f) }
    val dragFrom = remember { mutableIntStateOf(-1) }

    val moveUp = stringResource(R.string.cp_move_up)
    val moveDown = stringResource(R.string.cp_move_down)
    val remove = stringResource(R.string.cp_remove_section)
    val handleLabel = stringResource(R.string.cp_drag_handle)

    fun finishDrag() {
        val id = draggingId.value
        if (id != null) {
            val to = orderState.value.indexOf(id)
            val from = dragFrom.intValue
            if (from >= 0 && to >= 0 && to != from) vm.moveCustomSection(n, from, to)
        }
        draggingId.value = null
        dragDelta.floatValue = 0f
        dragFrom.intValue = -1
    }

    LazyColumn(
        modifier.fillMaxWidth(),
        state = listState,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPadding),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        itemsIndexed(orderState.value, key = { _, id -> id }) { _, id ->
            val def = SectionCatalog.find(id)
            if (def != null) {
                val dragging = draggingId.value == id
                val placement = if (dragging) Modifier.zIndex(1f) else Modifier.animateItem()
                val name = stringResource(def.nameRes)
                EditRow(
                    def = def,
                    dragging = dragging,
                    modifier = placement
                        .graphicsLayer {
                            translationY = if (draggingId.value == id) {
                                val now = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == id }?.offset ?: dragStartTop.intValue
                                dragStartTop.intValue + dragDelta.floatValue - now
                            } else 0f
                        }
                        .semantics(mergeDescendants = true) {
                            customActions = listOf(
                                CustomAccessibilityAction(moveUp) { vm.moveCustomSectionBy(n, id, -1); true },
                                CustomAccessibilityAction(moveDown) { vm.moveCustomSectionBy(n, id, 1); true },
                                CustomAccessibilityAction(remove) { vm.removeCustomSection(n, id); true },
                            )
                        },
                    handleModifier = Modifier
                        .semantics { contentDescription = "$handleLabel, $name" }
                        .pointerInput(id) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = {
                                    draggingId.value = id
                                    dragFrom.intValue = orderState.value.indexOf(id)
                                    dragStartTop.intValue = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == id }?.offset ?: 0
                                    dragDelta.floatValue = 0f
                                },
                                onDrag = { change, amount ->
                                    change.consume()
                                    dragDelta.floatValue += amount.y
                                    val order = orderState.value
                                    val info = listState.layoutInfo.visibleItemsInfo
                                    val cur = info.firstOrNull { it.key == id }
                                    // Only swap once the layout has caught up with the previous swap.
                                    if (cur != null && cur.index == order.indexOf(id)) {
                                        val middle = dragStartTop.intValue + dragDelta.floatValue + cur.size / 2f
                                        val target = info.firstOrNull { it.key != id && middle >= it.offset && middle <= it.offset + it.size }
                                        if (target != null && target.index in order.indices) {
                                            // The list keeps its position by the first visible item's key: when
                                            // that item takes part in the swap, pin the scroll position instead.
                                            val firstIndex = listState.firstVisibleItemIndex
                                            val firstOffset = listState.firstVisibleItemScrollOffset
                                            val pin = target.index == firstIndex || cur.index == firstIndex
                                            val next = order.toMutableList()
                                            next.add(target.index, next.removeAt(cur.index))
                                            orderState.value = next
                                            if (pin) scope.launch { listState.scrollToItem(firstIndex, firstOffset) }
                                        }
                                    }
                                },
                                onDragEnd = { finishDrag() },
                                onDragCancel = { finishDrag() },
                            )
                        },
                    onRemove = { vm.removeCustomSection(n, id) },
                    removeLabel = "$remove, $name",
                )
            }
        }
    }
}

@Composable
private fun EditRow(
    def: SectionDef,
    dragging: Boolean,
    modifier: Modifier,
    handleModifier: Modifier,
    onRemove: () -> Unit,
    removeLabel: String,
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.fillMaxWidth()
            .shadow(if (dragging) 8.dp else 0.dp, shape)
            .clip(shape)
            .background(if (dragging) MaterialTheme.colorScheme.surfaceContainerHigh else MaterialTheme.colorScheme.surface)
            .padding(start = 4.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(handleModifier.size(44.dp), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.DragHandle, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(def.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(def.nameRes), style = MaterialTheme.typography.titleSmall)
            Text(
                stringResource(def.category.titleRes) + " · " + stringResource(def.descRes),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        IconButton(onClick = onRemove) { Icon(Icons.Rounded.Close, removeLabel) }
    }
}
