package com.aurora.msg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.msg.R
import com.aurora.msg.data.repo.AppLanguage
import com.aurora.msg.data.repo.SheetScheme
import com.aurora.msg.data.repo.ThemeMode
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.Disclaimer
import com.aurora.msg.ui.components.SectionHeader
import com.aurora.msg.ui.theme.Aurora

@Composable
fun SettingsScreen(vm: AppViewModel, inner: PaddingValues) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val user by vm.user.collectAsStateWithLifecycle()
    var confirmWipe by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding(), bottom = inner.calculateBottomPadding() + 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Column(Modifier.statusBarsPadding().padding(top = 8.dp)) {
            Text(stringResource(R.string.settings_title), style = MaterialTheme.typography.headlineMedium)
            Text(user?.email ?: "", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // ----- Appearance
        SectionHeader(stringResource(R.string.settings_appearance), stringResource(R.string.settings_appearance_sub))
        AuroraCard {
            Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ThemeSwatch(ThemeMode.AURORA, stringResource(R.string.theme_aurora), settings.themeMode, Modifier.weight(1f)) { vm.setThemeMode(it) }
                ThemeSwatch(ThemeMode.LIGHT, stringResource(R.string.theme_light), settings.themeMode, Modifier.weight(1f)) { vm.setThemeMode(it) }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ThemeSwatch(ThemeMode.HIGH_CONTRAST, stringResource(R.string.theme_high_contrast), settings.themeMode, Modifier.weight(1f)) { vm.setThemeMode(it) }
                ThemeSwatch(ThemeMode.DARK, stringResource(R.string.theme_dark), settings.themeMode, Modifier.weight(1f)) { vm.setThemeMode(it) }
            }
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.settings_theme_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            ToggleRow(stringResource(R.string.settings_ranges), stringResource(R.string.settings_ranges_sub), settings.showRanges) { vm.setShowRanges(it) }
            if (settings.showRanges) {
                Text(stringResource(R.string.settings_ranges_table), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // ----- Vital Sheet style (brief §5) — frame styling only; data colours never change.
        AuroraCard(padding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)) {
            Text(stringResource(R.string.scheme_title), style = MaterialTheme.typography.titleSmall)
            Text(stringResource(R.string.scheme_sub), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            SchemeRow(SheetScheme.SCHEME1, stringResource(R.string.scheme_1), stringResource(R.string.scheme_1_desc), settings.sheetScheme) { vm.setSheetScheme(it) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            SchemeRow(SheetScheme.SCHEME2, stringResource(R.string.scheme_2), stringResource(R.string.scheme_2_desc), settings.sheetScheme) { vm.setSheetScheme(it) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            SchemeRow(SheetScheme.SCHEME3, stringResource(R.string.scheme_3), stringResource(R.string.scheme_3_desc), settings.sheetScheme) { vm.setSheetScheme(it) }
        }

        // ----- Language
        AuroraCard(padding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)) {
            Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleSmall)
            Text(stringResource(R.string.settings_language_sub), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            LanguageRow(AppLanguage.SYSTEM, stringResource(R.string.lang_system), settings.language) { vm.setLanguage(it) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            LanguageRow(AppLanguage.ENGLISH, "English", settings.language) { vm.setLanguage(it) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            LanguageRow(AppLanguage.SPANISH, "Español", settings.language) { vm.setLanguage(it) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            LanguageRow(AppLanguage.VIETNAMESE, "Tiếng Việt", settings.language) { vm.setLanguage(it) }
        }

        // ----- Units
        SectionHeader(stringResource(R.string.settings_units))
        AuroraCard(padding = PaddingValues(horizontal = 18.dp, vertical = 6.dp)) {
            ToggleRow(stringResource(R.string.settings_fahrenheit), stringResource(R.string.settings_fahrenheit_sub), settings.useFahrenheit) { vm.setFahrenheit(it) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            ToggleRow(stringResource(R.string.settings_24h), null, settings.use24h) { vm.set24h(it) }
        }

        // ----- Demo
        SectionHeader(stringResource(R.string.settings_demo))
        AuroraCard(padding = PaddingValues(horizontal = 18.dp, vertical = 6.dp)) {
            ToggleRow(stringResource(R.string.settings_demo_mode), stringResource(R.string.settings_demo_mode_sub), settings.demoMode) { if (it) vm.demoEnable() else vm.demoDisable() }
        }

        // ----- Data & privacy
        SectionHeader(stringResource(R.string.settings_privacy))
        AuroraCard {
            Text(stringResource(R.string.settings_privacy_title), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.settings_privacy_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { vm.signOut() }, shape = CircleShape, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.settings_sign_out)) }
                TextButton(onClick = { confirmWipe = true }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.settings_delete_all), color = MaterialTheme.colorScheme.error) }
            }
        }

        // ----- About
        SectionHeader(stringResource(R.string.settings_about))
        AuroraCard {
            Text(stringResource(R.string.settings_about_version), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.settings_about_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            Text(stringResource(R.string.settings_about_not_title), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.settings_about_not_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Disclaimer()
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text(stringResource(R.string.settings_wipe_title)) },
            text = { Text(stringResource(R.string.settings_wipe_body)) },
            confirmButton = { TextButton(onClick = { confirmWipe = false; vm.deleteAll() }) { Text(stringResource(R.string.settings_wipe_confirm), color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text(stringResource(R.string.common_keep)) } },
        )
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary))
    }
}

/** One Vital Sheet scheme choice: name + one-line description, check mark when active. */
@Composable
private fun SchemeRow(scheme: SheetScheme, label: String, description: String, current: SheetScheme, onSelect: (SheetScheme) -> Unit) {
    val selected = scheme == current
    Row(Modifier.fillMaxWidth().clickable { onSelect(scheme) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = if (selected) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium)
            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (selected) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun LanguageRow(lang: AppLanguage, label: String, current: AppLanguage, onSelect: (AppLanguage) -> Unit) {
    val selected = lang == current
    Row(Modifier.fillMaxWidth().clickable { onSelect(lang) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = if (selected) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        if (selected) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary)
    }
}

/** A small preview tile for each theme: page colour, card colour, accent dot. */
@Composable
private fun ThemeSwatch(mode: ThemeMode, label: String, current: ThemeMode, modifier: Modifier = Modifier, onSelect: (ThemeMode) -> Unit) {
    val selected = mode == current
    val (page, card, accent, text) = when (mode) {
        ThemeMode.AURORA -> listOf(Aurora.Blossom, Aurora.Cloud, Aurora.Fuchsia, Aurora.Ink)
        ThemeMode.LIGHT -> listOf(Color(0xFFFAFAFB), Aurora.Cloud, Color(0xFFD1206F), Color(0xFF1B1B1F))
        ThemeMode.HIGH_CONTRAST -> listOf(Aurora.Cloud, Color(0xFFF2F2F2), Color(0xFF9E0A52), Color(0xFF000000))
        ThemeMode.DARK -> listOf(Aurora.DarkBg, Aurora.DarkCard, Aurora.Rose, Color(0xFFF7E9F0))
    }
    Column(
        modifier.clip(MaterialTheme.shapes.medium)
            .border(if (selected) 2.5.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
            .clickable { onSelect(mode) },
    ) {
        Box(Modifier.fillMaxWidth().height(58.dp).background(page).padding(8.dp)) {
            Box(Modifier.fillMaxWidth().height(42.dp).clip(MaterialTheme.shapes.small).background(card).padding(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).background(accent, CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.width(40.dp).height(6.dp).clip(CircleShape).background(text.copy(alpha = 0.8f)))
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.width(22.dp).height(10.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.6f)))))
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            if (selected) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
        }
    }
}
