package com.aurora.msg.protocol

import java.util.UUID

/**
 * Every UUID the app needs. Spec §2 / §17.
 * Base pattern: 6E40FExx-B5A3-F393-E0A9-E50E24DCCA9E
 */
object AuroraUuids {
    val SERVICE: UUID = UUID.fromString("6E40FE00-B5A3-F393-E0A9-E50E24DCCA9E")

    /** FE01 · NOTIFY · 20 B · 1 Hz — Live Vitals */
    val VITALS: UUID = UUID.fromString("6E40FE01-B5A3-F393-E0A9-E50E24DCCA9E")

    /** FE02 · READ+NOTIFY · 20 B — Session Summary (the "morning card") */
    val SUMMARY: UUID = UUID.fromString("6E40FE02-B5A3-F393-E0A9-E50E24DCCA9E")

    /** FE03 · WRITE · 1–16 B — Control */
    val CONTROL: UUID = UUID.fromString("6E40FE03-B5A3-F393-E0A9-E50E24DCCA9E")

    /** FE04 · NOTIFY · 20 B — Night Log replay stream */
    val LOG: UUID = UUID.fromString("6E40FE04-B5A3-F393-E0A9-E50E24DCCA9E")

    /** FE05 · READ+NOTIFY · 15 B — HRV Summary, every 10 min */
    val HRV: UUID = UUID.fromString("6E40FE05-B5A3-F393-E0A9-E50E24DCCA9E")

    /**
     * FE06 · NOTIFY · 20 B · 1 Hz — Extended Vitals (EDA, SpO2, perfusion), brief §1.
     * Firmware 1.0.0 does NOT expose this characteristic; its absence after service
     * discovery is how the app knows the pod has no extended sensors.
     */
    val EXT_VITALS: UUID = UUID.fromString("6E40FE06-B5A3-F393-E0A9-E50E24DCCA9E")

    // Standard services
    val DEVICE_INFO_SERVICE: UUID = UUID.fromString("0000180A-0000-1000-8000-00805F9B34FB")
    val MANUFACTURER_NAME: UUID = UUID.fromString("00002A29-0000-1000-8000-00805F9B34FB")
    val MODEL_NUMBER: UUID = UUID.fromString("00002A24-0000-1000-8000-00805F9B34FB")
    val HARDWARE_REVISION: UUID = UUID.fromString("00002A27-0000-1000-8000-00805F9B34FB")
    val SOFTWARE_REVISION: UUID = UUID.fromString("00002A28-0000-1000-8000-00805F9B34FB")

    val BATTERY_SERVICE: UUID = UUID.fromString("0000180F-0000-1000-8000-00805F9B34FB")
    val BATTERY_LEVEL: UUID = UUID.fromString("00002A19-0000-1000-8000-00805F9B34FB")

    /** Client Characteristic Configuration descriptor, needed to enable notifications. */
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")

    const val ADVERTISED_NAME = "AuroraPod"

    /** The firmware revision this app was built and tested against (spec §12 step 5). */
    const val BUILT_AGAINST_FIRMWARE = "1.0.0"
}
