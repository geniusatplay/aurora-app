package com.aurora.msg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.aurora.msg.R
import com.aurora.msg.data.repo.AuthRepository
import com.aurora.msg.data.repo.AuthResult
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.theme.Aurora
import kotlinx.coroutines.launch

@Composable
fun SignInScreen(vm: AppViewModel) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var creating by remember { mutableStateOf(false) }
    var showPassword by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<Int?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun submit() {
        if (busy) return
        busy = true; error = null
        scope.launch {
            val r = if (creating) vm.register(email, password, name) else vm.signIn(email, password)
            if (r is AuthResult.Failure) error = r.messageRes
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().background(Aurora.HeroGradient).statusBarsPadding().imePadding().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(48.dp))
        Box(Modifier.size(84.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            Box(Modifier.size(56.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.9f)), contentAlignment = Alignment.Center) {
                Box(Modifier.size(22.dp).clip(CircleShape).background(Aurora.Fuchsia))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(stringResource(R.string.signin_app_name), style = MaterialTheme.typography.displayMedium, color = Color.White)
        Text(stringResource(R.string.signin_tagline), style = MaterialTheme.typography.titleMedium, color = Color.White.copy(alpha = 0.9f))
        Spacer(Modifier.height(36.dp))

        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).clip(MaterialTheme.shapes.extraLarge).background(MaterialTheme.colorScheme.surface).padding(22.dp),
        ) {
            Text(stringResource(if (creating) R.string.signin_create_title else R.string.signin_welcome_title), style = MaterialTheme.typography.headlineSmall)
            Text(
                stringResource(R.string.signin_privacy_note),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(18.dp))
            val fieldColors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary, focusedLabelColor = MaterialTheme.colorScheme.primary, cursorColor = MaterialTheme.colorScheme.primary,
            )
            if (creating) {
                OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.signin_name_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors, shape = MaterialTheme.shapes.medium)
                Spacer(Modifier.height(12.dp))
            }
            OutlinedTextField(
                email, { email = it }, label = { Text(stringResource(R.string.signin_email_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), colors = fieldColors, shape = MaterialTheme.shapes.medium,
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                password, { password = it }, label = { Text(stringResource(R.string.signin_password_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showPassword = !showPassword }) {
                        Icon(if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, stringResource(R.string.signin_toggle_password))
                    }
                },
                colors = fieldColors, shape = MaterialTheme.shapes.medium,
            )
            if (error != null) {
                Spacer(Modifier.height(10.dp))
                Text(stringResource(error!!), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = { submit() }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp), shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White),
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                else Text(stringResource(if (creating) R.string.signin_create_button else R.string.signin_signin_button), style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = { email = AuthRepository.DEMO_EMAIL; password = AuthRepository.DEMO_PASSWORD; creating = false; submit() },
                modifier = Modifier.fillMaxWidth().height(46.dp), shape = CircleShape,
            ) { Text(stringResource(R.string.signin_demo_button)) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(if (creating) R.string.signin_have_account else R.string.signin_new_here), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(2.dp))
                TextButton(onClick = { creating = !creating; error = null }) { Text(stringResource(if (creating) R.string.signin_signin_button else R.string.signin_create_one)) }
            }
        }
        Spacer(Modifier.height(20.dp))
        Box(Modifier.padding(horizontal = 28.dp)) {
            Text(
                stringResource(R.string.signin_disclaimer),
                style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f),
            )
        }
        Spacer(Modifier.height(28.dp))
    }
}
