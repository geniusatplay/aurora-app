package com.aurora.msg.domain

/**
 * Low / Medium / High reference guides for the overnight measurements.
 *
 * These are GENERAL-WELLNESS reference bands for a resting adult asleep in a glove, chosen so
 * a user can tell at a glance whether a number is unremarkable or worth a look. They are not
 * clinical thresholds and the app never turns them into a diagnosis (spec §14.2).
 * All values are in the app's canonical units (°C, bpm, g/m³, ms, motion counts / 30 s).
 */
enum class Level { LOW, MEDIUM, HIGH }

enum class Metric { SLEEP_HR, SKIN_RISE, SWEAT_DAH, MOVEMENT, HRV_RMSSD, SKIN_TEMP, ROOM_TEMP, SKIN_RH, ROOM_RH, CONDUCTANCE, SPO2, PERFUSION }

data class RangeGuide(
    val metric: Metric,
    /** Values below this are LOW. */
    val lowMax: Float,
    /** Values above this are HIGH; in between is MEDIUM. */
    val highMin: Float,
    /** For HRV a higher value is the reassuring one; used for colouring. */
    val higherIsBetter: Boolean = false,
) {
    fun levelOf(value: Float): Level = when {
        value < lowMax -> Level.LOW
        value > highMin -> Level.HIGH
        else -> Level.MEDIUM
    }
}

object Ranges {
    val sleepHeartRate = RangeGuide(Metric.SLEEP_HR, lowMax = 50f, highMin = 70f)
    /** Skin-temperature rise above the night's baseline, °C. A hot flash is typically ≥ 1 °C. */
    val skinRise = RangeGuide(Metric.SKIN_RISE, lowMax = 0.4f, highMin = 1.0f)
    /** Differential absolute humidity, g/m³ — the sweat number. */
    val sweat = RangeGuide(Metric.SWEAT_DAH, lowMax = 5f, highMin = 12f)
    val movement = RangeGuide(Metric.MOVEMENT, lowMax = 20f, highMin = 100f)
    val rmssd = RangeGuide(Metric.HRV_RMSSD, lowMax = 20f, highMin = 50f, higherIsBetter = true)
    val skinTemp = RangeGuide(Metric.SKIN_TEMP, lowMax = 32.5f, highMin = 34.5f)
    val roomTemp = RangeGuide(Metric.ROOM_TEMP, lowMax = 17f, highMin = 23f)
    val skinRh = RangeGuide(Metric.SKIN_RH, lowMax = 35f, highMin = 60f)
    val roomRh = RangeGuide(Metric.ROOM_RH, lowMax = 30f, highMin = 60f)
    /** Tonic skin conductance during sleep, µS. Sleeping baseline sits at 2–6 µS (brief §2). */
    val conductance = RangeGuide(Metric.CONDUCTANCE, lowMax = 2f, highMin = 6f)
    /**
     * Overnight blood oxygen, %. Here HIGH is the reassuring side — the label stays a neutral
     * Low/Medium/High, never a judgment (spec §14.2) — so higherIsBetter drives the colouring.
     */
    val spo2 = RangeGuide(Metric.SPO2, lowMax = 94f, highMin = 96f, higherIsBetter = true)
    /** PPG perfusion index, %. Typical resting sleep sits at 1.0–3.5 % (brief §2). */
    val perfusion = RangeGuide(Metric.PERFUSION, lowMax = 1f, highMin = 3.5f)

    fun forMetric(m: Metric): RangeGuide = when (m) {
        Metric.SLEEP_HR -> sleepHeartRate
        Metric.SKIN_RISE -> skinRise
        Metric.SWEAT_DAH -> sweat
        Metric.MOVEMENT -> movement
        Metric.HRV_RMSSD -> rmssd
        Metric.SKIN_TEMP -> skinTemp
        Metric.ROOM_TEMP -> roomTemp
        Metric.SKIN_RH -> skinRh
        Metric.ROOM_RH -> roomRh
        Metric.CONDUCTANCE -> conductance
        Metric.SPO2 -> spo2
        Metric.PERFUSION -> perfusion
    }
}
