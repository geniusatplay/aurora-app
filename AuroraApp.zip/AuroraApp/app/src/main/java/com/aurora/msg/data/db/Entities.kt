package com.aurora.msg.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Local user account. Passwords are salted SHA-256; a server can replace this with tokens later. */
@Entity(tableName = "users", indices = [Index(value = ["email"], unique = true)])
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val email: String,
    val passwordHash: String,
    val salt: String,
    val displayName: String,
    val createdAt: Long,
)

enum class SessionSource { BLE, DEMO }
enum class ReplayState { NONE, PARTIAL, COMPLETE }

/**
 * One recording (usually one night). startedAtEpochMs is the wall-clock time the app
 * stored when CMD_START_SESSION was confirmed — the pod never stores this (spec §8.2).
 */
@Entity(
    tableName = "sessions",
    foreignKeys = [ForeignKey(entity = UserEntity::class, parentColumns = ["id"], childColumns = ["userId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("userId"), Index("startedAtEpochMs")],
)
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val startedAtEpochMs: Long,
    val endedAtEpochMs: Long? = null,
    /** Which of the 14 pod slots holds this night; from FE02. Null for demo/unknown. */
    val slot: Int? = null,
    val source: SessionSource,
    val replayState: ReplayState = ReplayState.NONE,
    val crcFailures: Int = 0,
    val note: String = "",
    /** For future server sync. */
    val syncedAt: Long? = null,
)

/** The 20-byte FE02 morning card, stored as-is. */
@Entity(
    tableName = "session_summary",
    foreignKeys = [ForeignKey(entity = SessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
)
data class SessionSummaryEntity(
    @PrimaryKey val sessionId: Long,
    val sessionLenS: Long,
    val epochsLogged: Int,
    val sweatEvents: Int,
    val longestSweatS: Int,
    val peakDahX100: Int,
    val hrMean: Int,
    val hrMin: Int,
    val hrMax: Int,
    val pctWake: Int,
    val pctLight: Int,
    val pctDeep: Int,
    val battPct: Int,
    val slot: Int,
)

/**
 * One 30-second epoch (the 34-byte v1 / 42-byte v2 log record, CRC already verified).
 * The ext columns (brief §7) are null on every v1 row — DB v1 rows migrate as all-null.
 */
@Entity(
    tableName = "epochs",
    foreignKeys = [ForeignKey(entity = SessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId", "tS"], unique = true)],
)
data class EpochEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val tS: Long,
    val hrBpm: Int,
    val hrQuality: Int,
    val skinTempX100: Int,
    val skinRhX100: Int,
    val ambTempX100: Int,
    val ambRhX100: Int,
    val motionIndex: Int,
    val sleepState: Int,
    val sweatFlag: Int,
    val battPct: Int,
    val flags: Int,
    val dahX100: Int,
    val hrvMeanIbi: Int,
    val hrvSdnnX10: Int,
    val hrvRmssdX10: Int,
    val hrvPnn50: Int,
    val hrvQuality: Int,
    val hrvFlags: Int,
    val vcellCv: Int,
    /** v2 ext fields — wire values verbatim; gate on extFlags VALID bits before showing. */
    val edaX100: Int? = null,
    val spo2X10: Int? = null,
    val perfusionX100: Int? = null,
    val extFlags: Int? = null,
)

/** True HRV series: one row per closed 10-minute window (FLAG_HRV_FRESH records or FE05 notifies). */
@Entity(
    tableName = "hrv_points",
    foreignKeys = [ForeignKey(entity = SessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId", "windowEndS"], unique = true)],
)
data class HrvPointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    /** Seconds since session start. */
    val windowEndS: Long,
    val meanIbi: Int,
    val sdnnX10: Int,
    val rmssdX10: Int,
    val pnn50: Int,
    val accepted: Int,
    val rejected: Int,
    val quality: Int,
    val flags: Int,
)

/** Derived from sweat_flag transitions (START → …→ NONE). */
@Entity(
    tableName = "sweat_events",
    foreignKeys = [ForeignKey(entity = SessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("sessionId")],
)
data class SweatEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val startS: Long,
    val endS: Long,
    val peakDahX100: Int,
)

enum class ActivityKind(val label: String) {
    UP("Up & about"),
    LIGHT_EXERCISE("Light exercise"),
    HEAVY_EXERCISE("Heavy exercise"),
    SLEEPING("Sleeping"),
    NIGHT_FLASH("Night flash"),
    NIGHT_SWEATS("Night sweats"),
    SESSION_START("Session started"),
    SESSION_END("Session ended"),
}

enum class EventSource { DEMO, USER, POD }

/** Timeline markers: demo mode changes, user tags, pod events. Shown on charts and in the log. */
@Entity(
    tableName = "activity_events",
    foreignKeys = [ForeignKey(entity = SessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("sessionId")],
)
data class ActivityEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val tS: Long,
    val kind: ActivityKind,
    val label: String,
    val source: EventSource,
)

/** The app's own slot inventory (spec §15.1 — the pod cannot list what it stores). */
@Entity(tableName = "pod_slots")
data class PodSlotEntity(
    @PrimaryKey val slot: Int,
    val sessionId: Long?,
    val lastSeenAt: Long,
)
