package com.aurora.msg.data.sync

import com.aurora.msg.data.db.EpochEntity
import com.aurora.msg.data.db.HrvPointEntity
import com.aurora.msg.data.db.SessionEntity
import com.aurora.msg.data.db.SessionSummaryEntity

/**
 * Server contract. The shipping app stores everything ON DEVICE and uses [NoOpSyncGateway].
 * When a backend exists, implement this interface (see SERVER_API.md) and swap it in AppGraph.
 * Nothing else in the app changes.
 */
interface SyncGateway {
    val isEnabled: Boolean

    /** Exchange credentials for a bearer token. */
    suspend fun signIn(email: String, password: String): Result<AuthToken>
    suspend fun register(email: String, password: String, displayName: String): Result<AuthToken>

    /** Idempotent upsert of a session (+ summary). Returns the server id. */
    suspend fun pushSession(token: AuthToken, session: SessionEntity, summary: SessionSummaryEntity?): Result<String>

    /** Epochs are pushed in chunks (≤ 500) so a night is ~2 requests. */
    suspend fun pushEpochs(token: AuthToken, serverSessionId: String, epochs: List<EpochEntity>): Result<Unit>
    suspend fun pushHrv(token: AuthToken, serverSessionId: String, points: List<HrvPointEntity>): Result<Unit>

    /** Sessions changed on the server since [sinceEpochMs] (multi-device restore). */
    suspend fun pullSessions(token: AuthToken, sinceEpochMs: Long): Result<List<RemoteSession>>
}

data class AuthToken(val accessToken: String, val expiresAtEpochMs: Long, val userId: String)

data class RemoteSession(
    val serverId: String,
    val startedAtEpochMs: Long,
    val endedAtEpochMs: Long?,
    val summary: SessionSummaryEntity?,
)

class NoOpSyncGateway : SyncGateway {
    override val isEnabled = false
    private val off = Result.failure<Nothing>(IllegalStateException("Sync is disabled: data stays on this device"))
    override suspend fun signIn(email: String, password: String): Result<AuthToken> = off
    override suspend fun register(email: String, password: String, displayName: String): Result<AuthToken> = off
    override suspend fun pushSession(token: AuthToken, session: SessionEntity, summary: SessionSummaryEntity?): Result<String> = off
    override suspend fun pushEpochs(token: AuthToken, serverSessionId: String, epochs: List<EpochEntity>): Result<Unit> = off
    override suspend fun pushHrv(token: AuthToken, serverSessionId: String, points: List<HrvPointEntity>): Result<Unit> = off
    override suspend fun pullSessions(token: AuthToken, sinceEpochMs: Long): Result<List<RemoteSession>> = off
}
