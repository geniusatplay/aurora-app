package com.aurora.msg.pod

import com.aurora.msg.domain.NightAnalytics
import com.aurora.msg.protocol.ExtFlags
import com.aurora.msg.protocol.SleepState
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** Demo activity modes — the chips on the Demo sheet. */
enum class DemoMode(val label: String, val emoji: String, val description: String) {
    UP("Up & about", "🚶", "Awake, resting heart rate, dry skin"),
    LIGHT_EXERCISE("Light exercise", "🧘", "Walking / yoga — moderate HR, mild warmth"),
    HEAVY_EXERCISE("Heavy exercise", "🏃", "Running — high HR, strong sweating"),
    SLEEPING("Sleeping", "😴", "Light/deep cycles, cooling skin, low motion"),
    NIGHT_FLASH("Night flash", "🔥", "Hot flash: sudden HR + skin-temp rise, then recovery"),
    NIGHT_SWEATS("Night sweats", "💧", "Hot flash with heavy sweating over ~10 minutes"),
}

/**
 * A small physiological model that eases each signal toward mode-specific targets with
 * organic noise so the live chart looks like a real person. Pure Kotlin.
 *
 * All temperatures °C, humidity %RH, motion = unitless activity counts per 30 s epoch.
 */
class DemoScenario(seed: Long = System.nanoTime()) {
    private val rnd = Random(seed)

    // ----- state (current values) -----
    var hr = 72f; private set
    var skinTemp = 33.4f; private set
    var skinRh = 30f; private set
    var ambTemp = 21.5f; private set
    var ambRh = 42f; private set
    var motion = 20f; private set
    var sleepState: SleepState = SleepState.WAKE; private set
    var sweating = false; private set
    var battPct = 92; private set

    // ----- extended sensors (brief §2) -----
    /** Skin conductance µS = tonic level + phasic flash response + noise. */
    var eda = 4f; private set
    /** Blood oxygen %, slow wander 95.5–98.5, motion-tied dips — deliberately NOT flash-correlated. */
    var spo2 = 97f; private set
    /** PPG perfusion index %, 1.0–3.5 stable, rises with vasodilation during a flash. */
    var perfusion = 2f; private set

    /** Per-person tonic EDA baseline, 2–6 µS. Drifts down through sleep. */
    private var tonicEda = 2.5f + rnd.nextFloat() * 3f
    /** Phasic amplitude for the CURRENT flash event, 3–8 µS, re-rolled on entry (brief §2). */
    private var phasicAmpUs = 0f
    private var basePerfusion = 1.2f + rnd.nextFloat() * 1.8f
    private var spo2Wander = 96.5f + rnd.nextFloat() * 1.5f

    var mode: DemoMode = DemoMode.UP
        private set

    /** Scales how much a flash/sweat event raises skin humidity and temperature (per-person variation). */
    var sweatGain = 1f

    private var modeElapsedS = 0f
    private var sleepCycleS = 0f
    private var flashPhaseS = 0f
    private var baselineSkin = 33.4f
    private var baselineHr = 62f
    private var battAccumS = 0f

    fun setMode(m: DemoMode) {
        if (m == mode) return
        mode = m
        modeElapsedS = 0f
        flashPhaseS = 0f
        if (m == DemoMode.SLEEPING) { sleepCycleS = 0f }
        // Each flash gets its own phasic EDA size: +3–8 µS over 60–90 s (brief §2).
        if (m == DemoMode.NIGHT_FLASH || m == DemoMode.NIGHT_SWEATS) phasicAmpUs = 3f + rnd.nextFloat() * 5f
    }

    private data class Target(
        val hr: Float, val hrJitter: Float,
        val skinTemp: Float, val skinRh: Float,
        val motionLo: Float, val motionHi: Float,
        val sweat: Boolean,
    )

    private fun target(): Target = when (mode) {
        DemoMode.UP -> Target(72f, 4f, 33.4f, 30f, 30f, 120f, false)
        DemoMode.LIGHT_EXERCISE -> Target(105f, 6f, 33.9f, 42f, 200f, 420f, false)
        DemoMode.HEAVY_EXERCISE -> Target(148f, 8f, 34.6f, 70f, 500f, 950f, true)
        DemoMode.SLEEPING -> {
            val deep = sleepState == SleepState.DEEP
            Target(if (deep) 54f else 59f, 2f, baselineSkin - 0.5f, 28f, 0f, if (deep) 6f else 18f, false)
        }
        DemoMode.NIGHT_FLASH -> {
            // Rise over ~90 s, plateau ~2 min, recover over ~6 min.
            val p = flashPhaseS
            val env = when {
                p < 90f -> p / 90f
                p < 210f -> 1f
                else -> exp(-(p - 210f) / 150f)
            }
            Target(58f + 26f * env, 3f, baselineSkin + (0.8f + 0.5f * sweatGain) * env, 30f + 22f * env * sweatGain, 20f + 60f * env, 40f + 100f * env, env > 0.45f)
        }
        DemoMode.NIGHT_SWEATS -> {
            // Longer, heavier: rise 2 min, sweat plateau ~9 min, slow recovery.
            val p = flashPhaseS
            val env = when {
                p < 120f -> p / 120f
                p < 660f -> 1f
                else -> exp(-(p - 660f) / 240f)
            }
            Target(62f + 30f * env, 4f, baselineSkin + (1.0f + 0.6f * sweatGain) * env, 30f + 38f * env * sweatGain, 40f + 90f * env, 70f + 160f * env, env > 0.35f)
        }
    }

    /** Advance the model by dt simulated seconds. */
    fun step(dtS: Float) {
        modeElapsedS += dtS
        if (mode == DemoMode.NIGHT_FLASH || mode == DemoMode.NIGHT_SWEATS) flashPhaseS += dtS

        // Sleep-stage cycling while sleeping: ~90-min cycles of light → deep → light, with brief wakes.
        if (mode == DemoMode.SLEEPING) {
            sleepCycleS += dtS
            val cycle = (sleepCycleS % 5400f)
            sleepState = when {
                modeElapsedS < 240f -> SleepState.WAKE       // falling asleep
                cycle < 1500f -> SleepState.LIGHT
                cycle < 3600f -> SleepState.DEEP
                cycle < 5100f -> SleepState.LIGHT
                cycle < 5250f -> if (rnd.nextFloat() < 0.6f) SleepState.WAKE else SleepState.LIGHT
                else -> SleepState.LIGHT
            }
        } else if (mode == DemoMode.NIGHT_FLASH || mode == DemoMode.NIGHT_SWEATS) {
            sleepState = if (flashPhaseS < 40f) SleepState.LIGHT else if (flashPhaseS < 600f) SleepState.WAKE else SleepState.LIGHT
        } else {
            sleepState = SleepState.WAKE
        }

        val t = target()
        // Time constants (s): HR fast, skin temp slow, RH medium.
        hr = ease(hr, t.hr + noise(t.hrJitter), dtS, 25f)
        skinTemp = ease(skinTemp, t.skinTemp + noise(0.05f), dtS, 120f)
        skinRh = ease(skinRh, t.skinRh + noise(1.2f), dtS, 60f)
        ambTemp = ease(ambTemp, 21.5f + noise(0.03f), dtS, 600f)
        ambRh = ease(ambRh, 42f + noise(0.5f), dtS, 600f)
        val motionTarget = t.motionLo + rnd.nextFloat() * (t.motionHi - t.motionLo)
        val burst = if (mode == DemoMode.SLEEPING && rnd.nextFloat() < 0.01f) 60f else 0f
        motion = ease(motion, motionTarget + burst, dtS, 15f)
        sweating = t.sweat

        stepExtended(dtS)

        battAccumS += dtS
        if (battAccumS > 1500f) { battAccumS = 0f; battPct = max(5, battPct - 1) }
    }

    /**
     * EDA / SpO2 / perfusion model, brief §2.
     *
     * The phasic EDA envelope rises fast (60–90 s from onset) while skin temperature both
     * chases a slower ramping target AND eases with a 120 s time constant — so the sweat
     * spike leads the skin-temp peak by the required 30–60 s without explicit scheduling.
     */
    private fun stepExtended(dtS: Float) {
        // Tonic level: per-person baseline, drifting slowly DOWN through sleep, raised by exercise.
        val tonicTarget = when (mode) {
            DemoMode.LIGHT_EXERCISE -> tonicEda + 1.5f                      // +1–2 µS
            DemoMode.HEAVY_EXERCISE -> tonicEda + 4.5f                      // +3–6 µS
            DemoMode.SLEEPING -> tonicEda * (1f - min(0.35f, modeElapsedS / 28800f)) // ~-35 % over 8 h
            else -> tonicEda
        }
        // Phasic envelope: fast attack, then flash decays over minutes / sweats stay elevated 5–10 min.
        val phasic = when (mode) {
            DemoMode.NIGHT_FLASH -> phasicAmpUs * when {
                flashPhaseS < 75f -> flashPhaseS / 75f
                flashPhaseS < 180f -> 1f
                else -> exp(-(flashPhaseS - 180f) / 120f)                   // gone in 1–5 min
            }
            DemoMode.NIGHT_SWEATS -> phasicAmpUs * when {
                flashPhaseS < 90f -> flashPhaseS / 90f
                flashPhaseS < 570f -> 1f                                    // elevated 5–10 min
                else -> exp(-(flashPhaseS - 570f) / 240f)
            }
            else -> 0f
        }
        // Smooth only the tonic component; the phasic envelope is already shaped, and easing it
        // again would blunt the sharp onset that makes the spike lead the temperature peak.
        tonicNow = ease(tonicNow, tonicTarget, dtS, 40f)
        eda = (tonicNow + phasic + noise(0.15f)).coerceAtLeast(0.05f)

        // SpO2: slow wander inside 95.5–98.5; brief dips to 93–94 tied to MOTION only. A
        // falling-O2-no-sweat night is the "not a flash" pattern, so flashes must not drag it.
        spo2Wander = (spo2Wander + noise(0.02f) * dtS).coerceIn(95.5f, 98.5f)
        val spo2Target = if (motion > 250f) 93f + rnd.nextFloat() else spo2Wander
        spo2 = ease(spo2, spo2Target + noise(0.1f), dtS, 45f).coerceIn(88f, 100f)

        // Perfusion: stable base; vasodilation raises it 1.5–2.5× aligned with the flash
        // envelope; heavy exercise raises it too.
        val flashFactor = 1f + 1.4f * (if (phasicAmpUs > 0f) phasic / phasicAmpUs else 0f)
        val exerciseFactor = if (mode == DemoMode.HEAVY_EXERCISE) 1.8f else 1f
        perfusion = ease(perfusion, basePerfusion * max(flashFactor, exerciseFactor) + noise(0.08f), dtS, 60f)
            .coerceIn(0.2f, 20f)
    }

    /** Smoothed tonic EDA (declared after [tonicEda] so the initializer sees its value). */
    private var tonicNow = tonicEda

    /** Skin-minus-ambient absolute humidity, ×100, computed exactly as the firmware does. */
    fun dahX100(): Int = NightAnalytics.dahX100(skinTemp, skinRh, ambTemp, ambRh)

    fun motionIndex(): Int = motion.toInt().coerceIn(0, 65535)

    // ----- extended-sensor wire values (FE06 / v2 records, brief §1) -----

    fun edaX100(): Int = (eda * 100f).toInt().coerceIn(0, 65535)
    fun spo2X10(): Int = (spo2 * 10f).toInt().coerceIn(0, 1000)
    fun perfusionX100(): Int = (perfusion * 100f).toInt().coerceIn(0, 65535)

    /**
     * ext_flags for the current tick. EDA is an electrical measurement and stays valid;
     * SpO2 and perfusion ride the optical path, which washes out under heavy movement —
     * exercising the UI's "shown only when VALID" rule now and then.
     */
    fun extFlags(): Int {
        var f = ExtFlags.EDA_VALID
        if (motion < 600f) f = f or ExtFlags.SPO2_VALID or ExtFlags.PI_VALID
        return f
    }

    /** Heart-rate quality: worse with motion. */
    fun hrQuality(): Int = (96f - min(60f, motion / 12f) + noise(3f)).toInt().coerceIn(20, 100)

    private fun ease(current: Float, target: Float, dtS: Float, tauS: Float): Float {
        val a = 1f - exp(-dtS / tauS)
        return current + (target - current) * a
    }

    private fun noise(amp: Float): Float = (rnd.nextFloat() * 2f - 1f) * amp

    /** Gaussian-ish jitter for HRV numbers. */
    fun gauss(mean: Float, sd: Float): Float {
        var s = 0f
        repeat(6) { s += rnd.nextFloat() }
        return mean + (s - 3f) * sd
    }

    fun nextFloat(): Float = rnd.nextFloat()
}
