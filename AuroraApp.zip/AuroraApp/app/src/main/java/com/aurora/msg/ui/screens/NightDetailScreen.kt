package com.aurora.msg.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.msg.data.db.ActivityEventEntity
import com.aurora.msg.R
import com.aurora.msg.data.db.ActivityKind
import com.aurora.msg.data.db.EventSource
import com.aurora.msg.data.db.ReplayState
import com.aurora.msg.data.repo.NightBundle
import com.aurora.msg.domain.NightAnalytics
import com.aurora.msg.domain.Ranges
import com.aurora.msg.pod.ReplayStatus
import com.aurora.msg.protocol.HrvFlags
import com.aurora.msg.protocol.HwConst
import com.aurora.msg.protocol.QualityBand
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.Fmt
import com.aurora.msg.ui.hasAmbientData
import com.aurora.msg.ui.isHardwareNight
import com.aurora.msg.ui.isHardwarePod
import com.aurora.msg.ui.nightLacksMotion
import com.aurora.msg.ui.nightLacksSleep
import com.aurora.msg.ui.charts.BloodFlowPanel
import com.aurora.msg.ui.charts.BundleBandColor
import com.aurora.msg.ui.charts.ChartLeftInset
import com.aurora.msg.ui.charts.ChartRightInset
import com.aurora.msg.ui.charts.ConductancePanel
import com.aurora.msg.ui.charts.DotPanel
import com.aurora.msg.ui.charts.ExtGuideBands
import com.aurora.msg.ui.charts.OxygenPanel
import com.aurora.msg.ui.charts.extGuides
import com.aurora.msg.ui.charts.DotPoint
import com.aurora.msg.ui.charts.HypnogramPanel
import com.aurora.msg.ui.charts.Legend
import com.aurora.msg.ui.charts.LinePanel
import com.aurora.msg.ui.charts.LineSeries
import com.aurora.msg.ui.charts.Marker
import com.aurora.msg.ui.charts.MarkerLegend
import com.aurora.msg.ui.charts.MotionPanel
import com.aurora.msg.ui.charts.ScrubBox
import com.aurora.msg.ui.charts.SleepRing
import com.aurora.msg.ui.charts.TimePoint
import com.aurora.msg.ui.charts.rememberReveal
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.BannerTone
import com.aurora.msg.ui.components.Disclaimer
import com.aurora.msg.ui.components.EmptyState
import com.aurora.msg.ui.components.HeroCard
import com.aurora.msg.ui.components.InfoBanner
import com.aurora.msg.ui.components.Pill
import com.aurora.msg.ui.components.SectionHeader
import com.aurora.msg.ui.components.StatTile
import com.aurora.msg.ui.components.WhiteLabeledValue
import com.aurora.msg.ui.theme.Aurora
import com.aurora.msg.ui.theme.AuroraThemeExtras
import kotlinx.coroutines.launch

fun ActivityKind.color(): Color = when (this) {
    ActivityKind.NIGHT_FLASH -> Aurora.Fuchsia
    ActivityKind.NIGHT_SWEATS -> Aurora.Magenta
    ActivityKind.HEAVY_EXERCISE -> Aurora.Plum
    ActivityKind.LIGHT_EXERCISE -> Aurora.SeriesAmbient
    ActivityKind.SLEEPING -> Aurora.SleepDeep
    ActivityKind.UP -> Aurora.SeriesMotion
    ActivityKind.SESSION_START, ActivityKind.SESSION_END -> Aurora.Ash
}

@Composable
fun ActivityKind.displayLabel(): String = stringResource(
    when (this) {
        ActivityKind.UP -> R.string.night_event_up
        ActivityKind.LIGHT_EXERCISE -> R.string.night_event_light_exercise
        ActivityKind.HEAVY_EXERCISE -> R.string.night_event_heavy_exercise
        ActivityKind.SLEEPING -> R.string.night_event_sleeping
        ActivityKind.NIGHT_FLASH -> R.string.night_event_night_flash
        ActivityKind.NIGHT_SWEATS -> R.string.night_event_night_sweats
        ActivityKind.SESSION_START -> R.string.night_event_session_start
        ActivityKind.SESSION_END -> R.string.night_event_session_end
    }
)

@Composable
private fun EventSource.displayLabel(): String = stringResource(
    when (this) {
        EventSource.DEMO -> R.string.night_source_demo
        EventSource.USER -> R.string.night_source_user
        EventSource.POD -> R.string.night_source_pod
    }
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NightDetailScreen(vm: AppViewModel, sessionId: Long, onBack: () -> Unit, onOpenPod: () -> Unit, onOpenVitalSheet: () -> Unit) {
    val nightFlow = remember(sessionId) { vm.night(sessionId) }
    val bundle by nightFlow.collectAsStateWithLifecycle(initialValue = null)
    val settings by vm.settings.collectAsStateWithLifecycle()
    val replay by vm.pod.replayStatus.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val active by vm.pod.activeSession.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val info by vm.pod.deviceInfo.collectAsStateWithLifecycle()
    val cards by vm.nightCards.collectAsStateWithLifecycle()
    var scrub by remember { mutableStateOf<Float?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val reveal = rememberReveal(bundle?.epochs?.size?.let { if (it > 0) sessionId else null })
    val show = settings.showRanges

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(bundle?.let { Fmt.nightLabel(it.session.startedAtEpochMs) } ?: stringResource(R.string.night_title_fallback), style = MaterialTheme.typography.titleLarge)
                        bundle?.let {
                            Text(
                                stringResource(R.string.night_time_range, Fmt.clock(it.session.startedAtEpochMs, settings), it.session.endedAtEpochMs?.let { e -> Fmt.clock(e, settings) } ?: stringResource(R.string.night_recording_lower)),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.night_cd_back)) } },
                actions = {
                    val exportSubject = stringResource(R.string.night_export_subject)
                    val shareChooser = stringResource(R.string.night_share_chooser)
                    IconButton(onClick = {
                        scope.launch {
                            val csv = vm.exportCsv(sessionId)
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"; putExtra(Intent.EXTRA_SUBJECT, exportSubject); putExtra(Intent.EXTRA_TEXT, csv)
                            }
                            // LocalContext may be the locale-overridden (non-Activity) context from AuroraRoot;
                            // starting an activity from it requires NEW_TASK or Android throws.
                            context.startActivity(Intent.createChooser(send, shareChooser).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }) { Icon(Icons.Rounded.Share, stringResource(R.string.night_cd_share_csv)) }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, stringResource(R.string.night_cd_delete_night)) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
    ) { inner ->
        val b = bundle
        if (b == null) {
            EmptyState(stringResource(R.string.common_loading), "", Modifier.padding(inner)); return@Scaffold
        }
        val start = b.session.startedAtEpochMs
        val xFormat: (Float) -> String = { t -> Fmt.clock(start + (t * 1000).toLong(), settings) }
        val epochs = b.epochs
        val isLive = active?.id == sessionId

        // Flash bundles (brief §3): their spans shade ALL panels at 0.10-alpha fuchsia (§6).
        val records = remember(epochs) { with(vm.sessions) { epochs.map { it.toRecord() } } }
        val bundles = remember(records) { NightAnalytics.detectBundles(records) }
        // Gate on the night's DATA (a hardware night stays one even in demo mode).
        val hwNight = isHardwareNight(records)
        val noSleep = nightLacksSleep(records, b.summary)
        val hwLog = hwNight || (b.session.source == com.aurora.msg.data.db.SessionSource.BLE && isHardwarePod(caps, info))
        // The real pod holds only its most recent session: offer the download on that night only.
        val latestBleNight = cards.firstOrNull { it.session.source == com.aurora.msg.data.db.SessionSource.BLE && it.session.endedAtEpochMs != null }?.session?.id
        val canDownload = !hwLog || latestBleNight == sessionId
        val baseline = epochs.filter { it.tS < 1800 }.map { it.skinTempX100 }.sorted().let { if (it.isEmpty()) null else it[it.size / 2] }
        val maxRise = baseline?.let { bl -> epochs.maxOfOrNull { it.skinTempX100 - bl } }?.let { it / 100f }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding() + 4.dp, bottom = inner.calculateBottomPadding() + 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item { NightHero(b, maxRise, settings, reveal, isLive, show, hw = hwNight, noSleep = noSleep) }

            // Nighttime Vital Sheet entry point (brief §4)
            if (epochs.isNotEmpty()) item {
                Button(onClick = onOpenVitalSheet, shape = CircleShape, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Text(stringResource(R.string.vs_open))
                }
            }

            // Replay / download status
            if (!isLive) item {
                ReplayCard(b, replay, conn.isConnected, hwLog = hwLog, canDownload = canDownload, onDownload = { slot -> vm.pod.downloadNight(sessionId, slot) }, onCancel = { vm.pod.cancelDownload() }, onOpenPod = onOpenPod)
            }

            if (epochs.isEmpty()) {
                item { AuroraCard { EmptyState(stringResource(R.string.night_no_detail_title), stringResource(if (isLive) R.string.night_no_detail_live else R.string.night_no_detail_offline)) } }
            } else item {
                NightChartsCard(b, records, bundles, settings, caps, reveal, scrub) { scrub = it }
            }

            if (b.sweat.isNotEmpty()) {
                item { NightSweatEventsHeader(b, hwNight) }
                item { NightSweatEventsCard(b, xFormat) }
            }

            if (b.events.isNotEmpty()) {
                item { SectionHeader(stringResource(R.string.night_event_log_title), stringResource(R.string.night_event_log_sub)) }
                items(b.events, key = { it.id }) { e -> EventRow(e, xFormat) }
            }

            item { DiagnosticsCard(b) }
            item { Disclaimer(Modifier.navigationBarsPadding()) }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.night_delete_title)) },
            text = { Text(stringResource(R.string.night_delete_text)) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deleteSession(sessionId); onBack() }) { Text(stringResource(R.string.common_delete), color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.common_keep)) } },
        )
    }
}

/**
 * A night's stacked charts (temperature, sweat/moisture, sleep, movement, HR, HRV, extended
 * sensors) with flash-bundle shading, markers and a shared scrub line. Gated on the night's DATA.
 */
@Composable
internal fun NightChartsCard(
    b: NightBundle,
    records: List<com.aurora.msg.protocol.LogRecord>,
    bundles: List<com.aurora.msg.domain.FlashBundle>,
    settings: com.aurora.msg.data.repo.AppSettings,
    caps: com.aurora.msg.protocol.PodCapabilities,
    reveal: Float,
    scrub: Float?,
    onScrub: (Float?) -> Unit,
) {
    val start = b.session.startedAtEpochMs
    val xFormat: (Float) -> String = { t -> Fmt.clock(start + (t * 1000).toLong(), settings) }
    val epochs = b.epochs
    val lenS = (b.summary?.sessionLenS ?: epochs.lastOrNull()?.tS?.plus(30) ?: 0L).coerceAtLeast(600L)
    val x0 = 0f; val x1 = lenS.toFloat()
    val show = settings.showRanges
    val bands = b.sweat.map { it.startS.toFloat() to it.endS.toFloat() }
    val bundleBands = bundles.map { it.startTs.toFloat() to it.endTs.toFloat() }
    val displayBands = if (bundleBands.isNotEmpty()) bundleBands else bands
    val hasEda = records.any { it.validEdaX100 != null }
    val hasPi = records.any { it.validPerfusionX100 != null }
    val hasSpo2 = records.any { it.validSpo2X10 != null }
    val hasExt = hasEda || hasPi || hasSpo2
    val hwNight = isHardwareNight(records)
    val showAmbient = hasAmbientData(records)
    val noSleep = nightLacksSleep(records, b.summary)
    val noMotion = nightLacksMotion(records, b.summary)
    val hrvRelative = hwNight || caps.hrvRelativeOnly
    val markers = b.events.filter { it.kind != ActivityKind.SESSION_START && it.kind != ActivityKind.SESSION_END }
        .map { Marker(it.tS.toFloat(), it.kind.color(), it.kind.displayLabel()) }

    AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
        SectionHeader(stringResource(R.string.night_charts_title), stringResource(R.string.night_charts_sub), Modifier.padding(start = 12.dp))
        ScrubBox(x0 = x0, x1 = x1, leftInset = ChartLeftInset, rightInset = ChartRightInset, scrub = scrub, onScrub = onScrub) {
            Column {
                val skinLabel = stringResource(R.string.night_series_skin)
                val roomLabel = stringResource(R.string.night_series_room)
                val sweatLabel = stringResource(R.string.night_series_sweat)
                val hrLabel = stringResource(R.string.night_series_hr)
                val rmssdLabel = stringResource(R.string.night_series_rmssd)
                val lowConfidence = stringResource(R.string.night_low_confidence)
                // Room series only when the records carry a real room reading (not the hardware sentinel).
                PanelTitle(stringResource(if (showAmbient) R.string.night_panel_temp else R.string.vs_row_skin), settings.tempLabel())
                if (showAmbient) Legend(listOf(skinLabel to Aurora.SeriesSkin, roomLabel to Aurora.SeriesAmbient), Modifier.padding(start = 12.dp, bottom = 4.dp))
                LinePanel(
                    series = listOfNotNull(
                        LineSeries(skinLabel, epochs.map { TimePoint(it.tS.toFloat(), settings.toDisplayTemp(it.skinTempX100 / 100f)) }, Aurora.SeriesSkin),
                        if (showAmbient) LineSeries(roomLabel, epochs.filter { com.aurora.msg.protocol.HwAdapter.hasAmbient(it.ambTempX100) }.map { TimePoint(it.tS.toFloat(), settings.toDisplayTemp(it.ambTempX100 / 100f)) }, Aurora.SeriesAmbient) else null,
                    ),
                    x0 = x0, x1 = x1, height = 160.dp, bands = displayBands, bandColor = BundleBandColor, markers = markers, scrub = scrub, unit = settings.tempLabel(), xFormat = xFormat, reveal = reveal,
                    guides = guidesFor(Ranges.skinTemp, show) { settings.toDisplayTemp(it) },
                )
                // Hardware nights: dah is the rise of skin absolute humidity over the glove's own
                // baseline (no room sensor), so it can dip below zero and the room-based guides don't apply.
                PanelTitle(stringResource(if (hwNight) R.string.hw_night_moisture_title else R.string.night_panel_sweat), stringResource(if (hwNight) R.string.hw_night_moisture_sub else R.string.night_panel_sweat_sub))
                LinePanel(
                    series = listOf(LineSeries(sweatLabel, epochs.map { TimePoint(it.tS.toFloat(), it.dahX100 / 100f) }, Aurora.SeriesSweat, area = true)),
                    x0 = x0, x1 = x1, height = 140.dp, decimals = if (hwNight) 2 else 1, yMin = if (hwNight) null else 0f, bands = displayBands, bandColor = BundleBandColor, markers = markers, scrub = scrub, unit = " g/m³", xFormat = xFormat, reveal = reveal,
                    guides = if (hwNight) null else guidesFor(Ranges.sweat, show),
                )
                // No sleep staging / no accelerometer → no hypnogram, no movement panel (not an empty chart).
                if (!noSleep) {
                    PanelTitle(stringResource(R.string.night_panel_sleep), stringResource(R.string.night_panel_sleep_sub))
                    HypnogramPanel(epochs.map { it.tS.toFloat() to SleepState.fromCode(it.sleepState) }, x0, x1, height = 96.dp, bands = displayBands, scrub = scrub, xFormat = xFormat, reveal = reveal)
                }
                if (!noMotion) {
                    PanelTitle(stringResource(R.string.night_panel_movement), stringResource(R.string.night_panel_movement_sub))
                    MotionPanel(epochs.map { TimePoint(it.tS.toFloat(), it.motionIndex.toFloat()) }, x0, x1, height = 90.dp, bands = displayBands, scrub = scrub, xFormat = xFormat, reveal = reveal, guides = guidesFor(Ranges.movement, show))
                }
                PanelTitle(stringResource(R.string.night_panel_hr), stringResource(if (hwNight) R.string.hw_night_hr_sub else R.string.night_panel_hr_sub))
                DotPanel(
                    hrLabel, epochs.filter { it.hrBpm > 0 && QualityBand.of(it.hrQuality) != QualityBand.HIDE }
                        .map { DotPoint(it.tS.toFloat(), it.hrBpm.toFloat(), QualityBand.of(it.hrQuality) == QualityBand.NORMAL, lowConfidence) },
                    Aurora.SeriesHeart, x0, x1, height = 120.dp, unit = " bpm", bands = displayBands, scrub = scrub, xFormat = xFormat, reveal = reveal, guides = guidesFor(Ranges.sleepHeartRate, show),
                )
                PanelTitle(stringResource(R.string.night_panel_rmssd), stringResource(R.string.night_panel_rmssd_sub))
                if (hrvRelative) {
                    // Quantisation-limited HRV (20 ms at 50 Hz): relative trend only, no reference guides.
                    Text(stringResource(R.string.hw_hrv_relative_note), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp, end = 4.dp, bottom = 2.dp))
                }
                DotPanel(
                    rmssdLabel, b.hrv.map { DotPoint(it.windowEndS.toFloat(), it.rmssdX10 / 10f, HrvFlags.has(it.flags, HrvFlags.VALID), HrvFlags.shortReason(it.flags)) },
                    Aurora.SeriesHrv, x0, x1, height = 120.dp, showXAxis = !hasExt, unit = " ms", connect = true, bands = displayBands, scrub = scrub, xFormat = xFormat, reveal = reveal, guides = if (hrvRelative) null else guidesFor(Ranges.rmssd, show),
                )
                // Extended-sensor panels (brief §6) — skipped silently when the night has no ext data.
                if (hasEda) {
                    PanelTitle(stringResource(R.string.ext_conductance), stringResource(R.string.ext_panel_conductance_sub))
                    ConductancePanel(
                        stringResource(R.string.ext_series_conductance),
                        records.mapNotNull { r -> r.edaUs?.let { TimePoint(r.tS.toFloat(), it) } },
                        x0, x1, showXAxis = !hasPi && !hasSpo2, bands = displayBands, scrub = scrub, xFormat = xFormat, reveal = reveal,
                        guides = extGuides(show, ExtGuideBands.CONDUCTANCE_LOW_MAX, ExtGuideBands.CONDUCTANCE_HIGH_MIN),
                    )
                }
                if (hasPi) {
                    PanelTitle(stringResource(R.string.ext_bloodflow), stringResource(R.string.ext_panel_bloodflow_sub))
                    BloodFlowPanel(
                        stringResource(R.string.ext_series_bloodflow),
                        records.mapNotNull { r -> r.perfusionPct?.let { TimePoint(r.tS.toFloat(), it) } },
                        x0, x1, showXAxis = !hasSpo2, bands = displayBands, scrub = scrub, xFormat = xFormat, reveal = reveal,
                        guides = extGuides(show, ExtGuideBands.BLOODFLOW_LOW_MAX, ExtGuideBands.BLOODFLOW_HIGH_MIN),
                    )
                }
                if (hasSpo2) {
                    PanelTitle(stringResource(R.string.ext_oxygen), stringResource(R.string.ext_panel_oxygen_sub))
                    OxygenPanel(
                        stringResource(R.string.ext_series_oxygen),
                        records.mapNotNull { r -> r.spo2Pct?.let { TimePoint(r.tS.toFloat(), it) } },
                        x0, x1, showXAxis = true, bands = displayBands, scrub = scrub, xFormat = xFormat, reveal = reveal,
                        guides = extGuides(show && !hwNight, ExtGuideBands.OXYGEN_LOW_MAX, ExtGuideBands.OXYGEN_HIGH_MIN, higherIsBetter = true),
                    )
                }
            }
        }
        MarkerLegend(markers, Modifier.padding(start = 12.dp, top = 6.dp))
    }
}

@Composable
internal fun NightSweatEventsHeader(b: NightBundle, hwNight: Boolean) {
    SectionHeader(stringResource(R.string.night_sweat_events_title), stringResource(R.string.night_sweat_events_sub, b.sweat.size, Fmt.durationShort(b.sweat.maxOf { it.endS - it.startS })) + (if (hwNight) " · " + stringResource(R.string.hw_provisional) else ""))
}

/** The night's sweat events, numbered, with time range, duration and peak. */
@Composable
internal fun NightSweatEventsCard(b: NightBundle, xFormat: (Float) -> String) {
    AuroraCard(padding = PaddingValues(8.dp)) {
        b.sweat.forEachIndexed { i, e ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Pill("${i + 1}", AuroraThemeExtras.pillBg)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.night_sweat_row_range, xFormat(e.startS.toFloat()), xFormat(e.endS.toFloat())), style = MaterialTheme.typography.titleSmall)
                    Text(stringResource(R.string.night_sweat_row_detail, Fmt.durationShort(e.endS - e.startS), Fmt.dah(e.peakDahX100 / 100f)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun PanelTitle(title: String, sub: String) {
    Row(Modifier.padding(start = 12.dp, top = 10.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.width(8.dp))
        Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun NightHero(b: NightBundle, maxRise: Float?, settings: com.aurora.msg.data.repo.AppSettings, reveal: Float, isLive: Boolean, show: Boolean, hw: Boolean = false, noSleep: Boolean = false) {
    val s = b.summary
    val sweatCount = s?.sweatEvents ?: b.sweat.size
    val peak = (s?.peakDahX100 ?: b.epochs.maxOfOrNull { it.dahX100 } ?: 0) / 100f
    HeroCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Pill(stringResource(if (isLive) R.string.common_recording else R.string.night_summary_pill), Color.White.copy(alpha = 0.22f), Color.White)
            Spacer(Modifier.weight(1f))
            if (b.session.source == com.aurora.msg.data.db.SessionSource.DEMO) Pill(stringResource(R.string.night_demo_pill), Color.White.copy(alpha = 0.22f), Color.White)
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${(sweatCount * reveal).toInt()}", style = MaterialTheme.typography.displayLarge, color = Color.White)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.padding(bottom = 10.dp)) {
                Text(pluralStringResource(R.plurals.night_sweat_event_count, sweatCount, sweatCount), style = MaterialTheme.typography.titleMedium, color = Color.White)
                // The real pod's flush count is a placeholder detector (PROTOCOL §9).
                if (hw) { Spacer(Modifier.height(4.dp)); Pill(stringResource(R.string.hw_provisional), Color.White.copy(alpha = 0.22f), Color.White) }
            }
            Spacer(Modifier.weight(1f))
            if (noSleep) {
                // No sleep staging for this night: time in bed only, no ring.
                Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(bottom = 10.dp)) {
                    Text(Fmt.duration(s?.sessionLenS ?: 0L), style = MaterialTheme.typography.titleLarge, color = Color.White)
                    Text(stringResource(R.string.night_in_bed), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.85f))
                }
            } else SleepRing(s?.pctWake ?: 0, s?.pctLight ?: 0, s?.pctDeep ?: 0, size = 92.dp, centerTop = Fmt.duration(s?.sessionLenS ?: 0L), centerBottom = stringResource(R.string.night_in_bed), reveal = reveal)
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            WhiteLabeledValue(stringResource(R.string.night_peak_sweat), stringResource(R.string.night_gm3_value, Fmt.dah(peak)))
            WhiteLabeledValue(stringResource(R.string.night_skin_rise), maxRise?.let { stringResource(R.string.night_up_to, Fmt.delta(it, settings)) + (if (show) " · " + stringResource(when (Ranges.skinRise.levelOf(it)) { com.aurora.msg.domain.Level.LOW -> R.string.level_low; com.aurora.msg.domain.Level.MEDIUM -> R.string.level_medium; com.aurora.msg.domain.Level.HIGH -> R.string.level_high }).lowercase() else "") } ?: "—")
            WhiteLabeledValue(stringResource(R.string.night_heart), s?.takeIf { it.hrMin > 0 && it.hrMax > 0 }?.let { stringResource(R.string.night_hr_range, it.hrMin, it.hrMax) } ?: "—")
        }
    }
}

@Composable
private fun ReplayCard(b: NightBundle, replay: ReplayStatus, connected: Boolean, hwLog: Boolean = false, canDownload: Boolean = true, onDownload: (Int) -> Unit, onCancel: () -> Unit, onOpenPod: () -> Unit) {
    val slot = b.session.slot
    val state = b.session.replayState
    val mine = (replay as? ReplayStatus.Downloading)?.slot == slot || (replay as? ReplayStatus.WaitingForHeader)?.slot == slot
    AuroraCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Download, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when {
                        state == ReplayState.COMPLETE -> stringResource(R.string.night_replay_complete)
                        state == ReplayState.PARTIAL -> stringResource(R.string.night_replay_partial)
                        b.epochs.isNotEmpty() -> stringResource(R.string.night_replay_live_data)
                        else -> stringResource(R.string.night_replay_not_downloaded)
                    }, style = MaterialTheme.typography.titleSmall,
                )
                Text(
                    when {
                        slot == null -> stringResource(R.string.night_replay_no_slot)
                        // The real pod keeps ONE RAM log, not 14 slots.
                        hwLog && state == ReplayState.COMPLETE -> stringResource(R.string.hw_night_replay_records, b.epochs.size) + if (b.session.crcFailures > 0) stringResource(R.string.night_replay_dropped_crc, b.session.crcFailures) else ""
                        hwLog -> stringResource(R.string.hw_night_replay_stored)
                        state == ReplayState.COMPLETE -> stringResource(R.string.night_replay_slot_records, slot, b.epochs.size) + if (b.session.crcFailures > 0) stringResource(R.string.night_replay_dropped_crc, b.session.crcFailures) else ""
                        else -> stringResource(R.string.night_replay_stored_in_slot, slot)
                    }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (slot != null && state != ReplayState.COMPLETE && !mine && canDownload) {
                if (connected) Button(onClick = { onDownload(slot) }, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary), enabled = !replay.isActive) { Text(stringResource(R.string.common_download)) }
                else OutlinedButton(onClick = onOpenPod, shape = CircleShape) { Text(stringResource(R.string.common_connect)) }
            }
        }
        if (mine) {
            Spacer(Modifier.height(10.dp))
            when (replay) {
                is ReplayStatus.WaitingForHeader -> { LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary, trackColor = AuroraThemeExtras.track); Text(stringResource(R.string.night_replay_waiting), style = MaterialTheme.typography.bodySmall) }
                is ReplayStatus.Downloading -> {
                    LinearProgressIndicator(progress = { replay.percent / 100f }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary, trackColor = AuroraThemeExtras.track)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.night_replay_progress, replay.percent, replay.framesReceived, replay.expectedFrames), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = onCancel) { Text(stringResource(R.string.common_cancel)) }
                    }
                    Text(stringResource(R.string.night_replay_lock_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> Unit
            }
        }
        (replay as? ReplayStatus.Failed)?.takeIf { it.slot == slot }?.let {
            Spacer(Modifier.height(8.dp)); InfoBanner(stringResource(it.messageRes, *it.args.toTypedArray()), tone = BannerTone.Error)
        }
        (replay as? ReplayStatus.Done)?.takeIf { it.slot == slot }?.let {
            Spacer(Modifier.height(8.dp)); InfoBanner(stringResource(R.string.night_done_records, it.records) + (if (it.crcFailures > 0) stringResource(R.string.night_done_crc, it.crcFailures) else "") + (if (!it.complete) stringResource(R.string.night_done_incomplete) else "."), tone = if (it.complete) BannerTone.Success else BannerTone.Warning)
        }
    }
}

@Composable
private fun EventRow(e: ActivityEventEntity, xFormat: (Float) -> String) {
    AuroraCard(padding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(e.kind.color(), CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(xFormat(e.tS.toFloat()), style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(64.dp))
            Text(e.kind.displayLabel(), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(e.source.displayLabel(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DiagnosticsCard(b: NightBundle) {
    var open by remember { mutableStateOf(false) }
    AuroraCard(onClick = { open = !open }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.night_diagnostics), style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            Text(stringResource(if (open) R.string.common_hide else R.string.common_show), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
        if (open) {
            Spacer(Modifier.height(10.dp))
            val last = b.epochs.lastOrNull(); val first = b.epochs.firstOrNull()
            val volts = last?.vcellCv?.takeIf { it > 0 }?.let { 2.50f + it / 100f }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // 0xFF = unknown (no cell fitted on the real pod) → a dash, not "255 %".
                val battKnown = first != null && last != null && first.battPct != HwConst.BATT_UNKNOWN && last.battPct != HwConst.BATT_UNKNOWN
                StatTile(stringResource(R.string.night_diag_battery), if (battKnown) "${first?.battPct ?: 0}→${last?.battPct ?: 0}" else if (first == null) "0→0" else "—", if (battKnown || first == null) "%" else "", Modifier.weight(1f), accent = Aurora.Good)
                StatTile(stringResource(R.string.night_diag_cell), volts?.let { "%.2f".format(it) } ?: "—", if (volts != null) "V" else "", Modifier.weight(1f), accent = Aurora.Good)
                StatTile(stringResource(R.string.night_diag_records), "${b.epochs.size}", modifier = Modifier.weight(1f), accent = Aurora.Ash, note = if (b.session.crcFailures > 0) stringResource(R.string.night_diag_crc_drops, b.session.crcFailures) else stringResource(R.string.night_diag_crc_ok))
            }
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.night_diag_summary, b.session.source.name.lowercase(), b.session.slot?.toString() ?: "—", b.session.replayState.name.lowercase(), b.hrv.size, b.hrv.count { HrvFlags.has(it.flags, HrvFlags.VALID) }), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
