package com.aurora.msg.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

class Converters {
    @TypeConverter fun sourceToString(v: SessionSource): String = v.name
    @TypeConverter fun stringToSource(v: String): SessionSource = SessionSource.valueOf(v)
    @TypeConverter fun replayToString(v: ReplayState): String = v.name
    @TypeConverter fun stringToReplay(v: String): ReplayState = ReplayState.valueOf(v)
    @TypeConverter fun kindToString(v: ActivityKind): String = v.name
    @TypeConverter fun stringToKind(v: String): ActivityKind = ActivityKind.valueOf(v)
    @TypeConverter fun evSourceToString(v: EventSource): String = v.name
    @TypeConverter fun stringToEvSource(v: String): EventSource = EventSource.valueOf(v)
}

@Database(
    entities = [
        UserEntity::class,
        SessionEntity::class,
        SessionSummaryEntity::class,
        EpochEntity::class,
        HrvPointEntity::class,
        SweatEventEntity::class,
        ActivityEventEntity::class,
        PodSlotEntity::class,
    ],
    version = 2,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AuroraDatabase : RoomDatabase() {
    abstract fun users(): UserDao
    abstract fun sessions(): SessionDao
    abstract fun summaries(): SummaryDao
    abstract fun epochs(): EpochDao
    abstract fun hrv(): HrvDao
    abstract fun sweatEvents(): SweatEventDao
    abstract fun activityEvents(): ActivityEventDao
    abstract fun podSlots(): PodSlotDao

    companion object {
        /**
         * v1 → v2: the four nullable ext-sensor columns (brief §7). ADD COLUMN keeps every
         * existing night — recorded data must NEVER be destroyed by an app update.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE epochs ADD COLUMN edaX100 INTEGER DEFAULT NULL")
                db.execSQL("ALTER TABLE epochs ADD COLUMN spo2X10 INTEGER DEFAULT NULL")
                db.execSQL("ALTER TABLE epochs ADD COLUMN perfusionX100 INTEGER DEFAULT NULL")
                db.execSQL("ALTER TABLE epochs ADD COLUMN extFlags INTEGER DEFAULT NULL")
            }
        }

        fun build(context: Context): AuroraDatabase =
            Room.databaseBuilder(context.applicationContext, AuroraDatabase::class.java, "aurora.db")
                .addMigrations(MIGRATION_1_2)
                .build()
    }
}
