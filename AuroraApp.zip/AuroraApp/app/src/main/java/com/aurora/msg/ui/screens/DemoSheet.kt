package com.aurora.msg.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.msg.R
import com.aurora.msg.pod.DemoMode
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.components.BannerTone
import com.aurora.msg.ui.components.InfoBanner
import com.aurora.msg.ui.components.Pill
import com.aurora.msg.ui.theme.Aurora

/**
 * The Demo control sheet. Modes feed the simulated pod with human-like parameters; the
 * live chart shows them and each change is logged as an activity marker on the night.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DemoSheet(vm: AppViewModel, onDismiss: () -> Unit) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val settings by vm.settings.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val active by vm.pod.activeSession.collectAsStateWithLifecycle()
    val mode by vm.demo.mode.collectAsStateWithLifecycle()
    val speed by vm.demo.speed.collectAsStateWithLifecycle()
    val busy by vm.demo.busy.collectAsStateWithLifecycle()
    val vitals by vm.pod.latestVitals.collectAsStateWithLifecycle()
    val cards by vm.nightCards.collectAsStateWithLifecycle()
    val recording = active != null && settings.demoMode

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.common_demo), style = MaterialTheme.typography.headlineSmall)
                    Text(stringResource(R.string.demo_intro), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (recording) Pill(stringResource(R.string.common_recording), MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.height(14.dp))

            if (!settings.demoMode) {
                InfoBanner(stringResource(R.string.demo_swap_banner), tone = BannerTone.Info)
                Spacer(Modifier.height(12.dp))
            }

            // Activity modes
            Text(stringResource(R.string.demo_activity), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.height(250.dp)) {
                items(DemoMode.entries) { m ->
                    val selected = m == mode && settings.demoMode
                    Column(
                        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium)
                            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainer)
                            .border(BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline), MaterialTheme.shapes.medium)
                            .clickable {
                                if (recording) vm.demoMode(m) else vm.demoStart(m)
                            }
                            .padding(12.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(m.emoji, style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.width(8.dp))
                            Text(m.title(), style = MaterialTheme.typography.titleSmall, color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(m.blurb(), style = MaterialTheme.typography.bodySmall, color = if (selected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                }
            }
            Text(
                if (recording) stringResource(R.string.demo_tap_switch) else stringResource(R.string.demo_tap_start),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp),
            )

            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.demo_speed), style = MaterialTheme.typography.titleSmall, modifier = Modifier.width(60.dp))
                listOf(1, 10, 30, 60).forEach { s ->
                    FilterChip(
                        selected = speed == s, onClick = { vm.demoSpeed(s) }, label = { Text("${s}×") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.inverseSurface, selectedLabelColor = MaterialTheme.colorScheme.inverseOnSurface),
                        modifier = Modifier.padding(end = 6.dp),
                    )
                }
            }
            Text(stringResource(R.string.demo_speed_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            vitals?.takeIf { settings.demoMode && conn.isConnected }?.let { v ->
                Spacer(Modifier.height(12.dp))
                val hrText = if (v.hasHr) stringResource(R.string.demo_now_hr, v.hrBpm) else stringResource(R.string.demo_now_hr_between)
                val sleepText = when (v.sleepState) {
                    SleepState.WAKE -> stringResource(R.string.demo_sleep_awake)
                    SleepState.LIGHT -> stringResource(R.string.demo_sleep_light)
                    SleepState.DEEP -> stringResource(R.string.demo_sleep_deep)
                    SleepState.UNKNOWN -> stringResource(R.string.demo_sleep_unknown)
                }
                Text(
                    stringResource(R.string.demo_now_line, hrText, "%.1f".format(v.skinTempC), "%.0f".format(v.skinRh), v.motionIndex, sleepText) +
                        (if (v.sweatFlag.code > 0) stringResource(R.string.demo_now_sweating) else ""),
                    style = MaterialTheme.typography.labelMedium, color = Aurora.Plum,
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (recording) {
                    Button(onClick = { vm.demoStop() }, shape = CircleShape, modifier = Modifier.weight(1f).height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.inverseSurface, contentColor = MaterialTheme.colorScheme.inverseOnSurface)) { Text(stringResource(R.string.demo_stop)) }
                } else {
                    Button(onClick = { vm.demoStart(DemoMode.SLEEPING) }, shape = CircleShape, modifier = Modifier.weight(1f).height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) { Text(stringResource(R.string.demo_start_night)) }
                }
                OutlinedButton(onClick = { vm.demoSeed() }, enabled = busy == null, shape = CircleShape, modifier = Modifier.weight(1f).height(46.dp)) {
                    if (busy != null) { CircularProgressIndicator(Modifier.width(16.dp).height(16.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.demo_working)) }
                    else Text(if (cards.isEmpty()) stringResource(R.string.demo_add_nights) else stringResource(R.string.demo_add_more_nights))
                }
            }
            busy?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)) }
            if (settings.demoMode) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.demoDisable(); onDismiss() }, shape = CircleShape, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.demo_leave)) }
            }
        }
    }
}

/** Localized label for a demo activity mode (the enum's [DemoMode.label] is English-only). */
@Composable
fun DemoMode.title(): String = when (this) {
    DemoMode.UP -> stringResource(R.string.demo_mode_up)
    DemoMode.LIGHT_EXERCISE -> stringResource(R.string.demo_mode_light_exercise)
    DemoMode.HEAVY_EXERCISE -> stringResource(R.string.demo_mode_heavy_exercise)
    DemoMode.SLEEPING -> stringResource(R.string.demo_mode_sleeping)
    DemoMode.NIGHT_FLASH -> stringResource(R.string.demo_mode_night_flash)
    DemoMode.NIGHT_SWEATS -> stringResource(R.string.demo_mode_night_sweats)
}

/** Localized description for a demo activity mode (the enum's [DemoMode.description] is English-only). */
@Composable
fun DemoMode.blurb(): String = when (this) {
    DemoMode.UP -> stringResource(R.string.demo_mode_up_desc)
    DemoMode.LIGHT_EXERCISE -> stringResource(R.string.demo_mode_light_exercise_desc)
    DemoMode.HEAVY_EXERCISE -> stringResource(R.string.demo_mode_heavy_exercise_desc)
    DemoMode.SLEEPING -> stringResource(R.string.demo_mode_sleeping_desc)
    DemoMode.NIGHT_FLASH -> stringResource(R.string.demo_mode_night_flash_desc)
    DemoMode.NIGHT_SWEATS -> stringResource(R.string.demo_mode_night_sweats_desc)
}
