package com.aurora.msg.pod

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.aurora.msg.R

/**
 * Keeps the process alive (and shows a small notification) while a night is downloading,
 * so the replay survives the screen locking (spec §9 "design consequence").
 * The actual transfer runs in PodConnectionManager; this service is only a lifetime anchor.
 */
class ReplayService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.app_notif_channel_name), NotificationManager.IMPORTANCE_LOW).apply {
                    description = getString(R.string.app_notif_channel_desc)
                }
            )
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.app_notif_title))
            .setContentText(getString(R.string.app_notif_text))
            .setOngoing(true)
            .setProgress(0, 0, true)
            .build()
    }

    companion object {
        const val CHANNEL = "aurora_replay"
        const val NOTIFICATION_ID = 1101
    }
}
