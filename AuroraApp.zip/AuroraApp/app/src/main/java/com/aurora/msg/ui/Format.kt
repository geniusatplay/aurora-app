package com.aurora.msg.ui

import com.aurora.msg.data.repo.AppSettings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Locale-aware patterns used by [Fmt]. English defaults so formatting works before the UI
 * has loaded resources; AuroraRoot refreshes them from `R.string.app_fmt_*` when the language changes.
 * Placeholders are `%1$d` (numbers) or `%1$s` (the formatted date in [nightOf]).
 */
data class FmtStrings(
    val hoursMinutes: String = "%1\$dh %2\$dm",
    val minutes: String = "%1\$dm",
    val min: String = "%1\$d min",
    val sec: String = "%1\$d s",
    val justNow: String = "just now",
    val minAgo: String = "%1\$d min ago",
    val hAgo: String = "%1\$d h ago",
    val dAgo: String = "%1\$d d ago",
    val nightOf: String = "Night of %1\$s",
)

object Fmt {
    @Volatile var strings: FmtStrings = FmtStrings()

    fun duration(seconds: Long): String {
        val h = seconds / 3600; val m = (seconds % 3600) / 60
        return if (h > 0) strings.hoursMinutes.format(h, m) else strings.minutes.format(m)
    }

    fun durationShort(seconds: Long): String {
        val m = seconds / 60; val s = seconds % 60
        return if (m > 0) strings.min.format(m) else strings.sec.format(s)
    }

    fun clock(epochMs: Long, settings: AppSettings): String =
        SimpleDateFormat(if (settings.use24h) "HH:mm" else "h:mm a", Locale.getDefault()).format(Date(epochMs))

    fun dayShort(epochMs: Long): String = SimpleDateFormat("EEE d", Locale.getDefault()).format(Date(epochMs))
    fun dayNum(epochMs: Long): String = SimpleDateFormat("d", Locale.getDefault()).format(Date(epochMs))
    fun dateLong(epochMs: Long): String = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(epochMs))
    fun dateMedium(epochMs: Long): String = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(epochMs))

    /** "Night of Mon 12 Aug" based on bedtime. */
    fun nightLabel(startedAtMs: Long): String = strings.nightOf.format(dateMedium(startedAtMs))

    fun temp(c: Float, s: AppSettings): String = "%.1f".format(s.toDisplayTemp(c)) + s.tempLabel()
    fun delta(dc: Float, s: AppSettings): String = (if (dc >= 0) "+" else "") + "%.1f".format(s.toDisplayDelta(dc)) + s.tempLabel()
    fun dah(gm3: Float): String = "%.1f".format(gm3)
    fun pct(v: Float): String = "%.0f%%".format(v)

    fun relative(ms: Long, now: Long = System.currentTimeMillis()): String {
        val d = (now - ms) / 1000
        return when {
            d < 60 -> strings.justNow
            d < 3600 -> strings.minAgo.format(d / 60)
            d < 86400 -> strings.hAgo.format(d / 3600)
            else -> strings.dAgo.format(d / 86400)
        }
    }
}
