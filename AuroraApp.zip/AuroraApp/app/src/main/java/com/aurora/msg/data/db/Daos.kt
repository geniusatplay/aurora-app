package com.aurora.msg.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE email = :email COLLATE NOCASE LIMIT 1")
    suspend fun byEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun byId(id: Long): UserEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(user: UserEntity): Long

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int
}

/** Session row + its summary, for lists. */
data class SessionWithSummary(
    val session: SessionEntity,
    val summary: SessionSummaryEntity?,
)

@Dao
interface SessionDao {
    @Insert
    suspend fun insert(session: SessionEntity): Long

    @Update
    suspend fun update(session: SessionEntity)

    @Query("SELECT * FROM sessions WHERE id = :id")
    suspend fun byId(id: Long): SessionEntity?

    @Query("SELECT * FROM sessions WHERE id = :id")
    fun observe(id: Long): Flow<SessionEntity?>

    @Query("SELECT * FROM sessions WHERE userId = :userId AND endedAtEpochMs IS NULL ORDER BY startedAtEpochMs DESC LIMIT 1")
    suspend fun openSession(userId: Long): SessionEntity?

    @Query("SELECT * FROM sessions WHERE userId = :userId ORDER BY startedAtEpochMs DESC")
    fun observeAll(userId: Long): Flow<List<SessionEntity>>

    @Query("SELECT * FROM sessions WHERE userId = :userId AND endedAtEpochMs IS NOT NULL ORDER BY startedAtEpochMs DESC LIMIT 1")
    fun observeLatestCompleted(userId: Long): Flow<SessionEntity?>

    @Query("SELECT * FROM sessions WHERE userId = :userId AND startedAtEpochMs >= :sinceMs ORDER BY startedAtEpochMs ASC")
    fun observeSince(userId: Long, sinceMs: Long): Flow<List<SessionEntity>>

    @Query("DELETE FROM sessions WHERE userId = :userId")
    suspend fun deleteAllForUser(userId: Long)

    @Query("DELETE FROM sessions WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM sessions WHERE userId = :userId")
    suspend fun count(userId: Long): Int
}

@Dao
interface SummaryDao {
    @Upsert
    suspend fun upsert(summary: SessionSummaryEntity)

    @Query("SELECT * FROM session_summary WHERE sessionId = :sessionId")
    suspend fun bySession(sessionId: Long): SessionSummaryEntity?

    @Query("SELECT * FROM session_summary WHERE sessionId = :sessionId")
    fun observe(sessionId: Long): Flow<SessionSummaryEntity?>

    @Query("SELECT * FROM session_summary WHERE sessionId IN (:ids)")
    fun observeFor(ids: List<Long>): Flow<List<SessionSummaryEntity>>
}

@Dao
interface EpochDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(epochs: List<EpochEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(epoch: EpochEntity)

    @Query("SELECT * FROM epochs WHERE sessionId = :sessionId ORDER BY tS ASC")
    fun observe(sessionId: Long): Flow<List<EpochEntity>>

    @Query("SELECT * FROM epochs WHERE sessionId = :sessionId ORDER BY tS ASC")
    suspend fun forSession(sessionId: Long): List<EpochEntity>

    @Query("DELETE FROM epochs WHERE sessionId = :sessionId")
    suspend fun deleteForSession(sessionId: Long)

    @Query("SELECT COUNT(*) FROM epochs WHERE sessionId = :sessionId")
    suspend fun count(sessionId: Long): Int
}

@Dao
interface HrvDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(points: List<HrvPointEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(point: HrvPointEntity)

    @Query("SELECT * FROM hrv_points WHERE sessionId = :sessionId ORDER BY windowEndS ASC")
    fun observe(sessionId: Long): Flow<List<HrvPointEntity>>

    @Query("SELECT * FROM hrv_points WHERE sessionId = :sessionId ORDER BY windowEndS ASC")
    suspend fun forSession(sessionId: Long): List<HrvPointEntity>

    @Query("DELETE FROM hrv_points WHERE sessionId = :sessionId")
    suspend fun deleteForSession(sessionId: Long)
}

@Dao
interface SweatEventDao {
    @Insert
    suspend fun insertAll(events: List<SweatEventEntity>)

    @Query("SELECT * FROM sweat_events WHERE sessionId = :sessionId ORDER BY startS ASC")
    fun observe(sessionId: Long): Flow<List<SweatEventEntity>>

    @Query("DELETE FROM sweat_events WHERE sessionId = :sessionId")
    suspend fun deleteForSession(sessionId: Long)

    @Transaction
    suspend fun replaceForSession(sessionId: Long, events: List<SweatEventEntity>) {
        deleteForSession(sessionId)
        if (events.isNotEmpty()) insertAll(events)
    }
}

@Dao
interface ActivityEventDao {
    @Insert
    suspend fun insert(event: ActivityEventEntity): Long

    @Insert
    suspend fun insertAll(events: List<ActivityEventEntity>)

    @Query("SELECT * FROM activity_events WHERE sessionId = :sessionId ORDER BY tS ASC")
    fun observe(sessionId: Long): Flow<List<ActivityEventEntity>>

    @Query("SELECT * FROM activity_events WHERE sessionId = :sessionId ORDER BY tS ASC")
    suspend fun forSession(sessionId: Long): List<ActivityEventEntity>
}

@Dao
interface PodSlotDao {
    @Upsert
    suspend fun upsert(slot: PodSlotEntity)

    @Query("SELECT * FROM pod_slots ORDER BY slot ASC")
    fun observeAll(): Flow<List<PodSlotEntity>>

    @Query("SELECT * FROM pod_slots ORDER BY slot ASC")
    suspend fun all(): List<PodSlotEntity>

    @Query("DELETE FROM pod_slots")
    suspend fun clear()
}
