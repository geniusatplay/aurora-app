package com.aurora.msg.ui.charts

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurora.msg.R
import com.aurora.msg.ui.theme.Aurora
import com.aurora.msg.ui.theme.LocalChartColors

/*
 * Stacked panels for the extended-sensor channels (brief §6): sweat conductance (µS),
 * blood flow (perfusion index %), blood oxygen (%). Single series each, shared x-domain
 * with the existing panels, no dual axes. Bundle spans are drawn as 0.10-alpha fuchsia
 * background shading via the existing sweat-band mechanism (LinePanel `bands`).
 * Channel colours come from LocalChartColors so light/dark variants apply; they NEVER
 * vary with the Vital Sheet scheme.
 */

/** Bundle shading colour — 0.10 opacity fuchsia across ALL panels (brief §6). */
val BundleBandColor get() = Aurora.Fuchsia.copy(alpha = 0.10f)

/**
 * UI-owned Low/Medium/High reference bands for the new channels (shown behind the existing
 * showRanges setting). Guides only — not medical limits, mirroring domain/Ranges.kt style.
 */
object ExtGuideBands {
    const val CONDUCTANCE_LOW_MAX = 2f   // µS
    const val CONDUCTANCE_HIGH_MIN = 8f
    const val BLOODFLOW_LOW_MAX = 1f     // PI %
    const val BLOODFLOW_HIGH_MIN = 4f
    const val OXYGEN_LOW_MAX = 94f       // % SpO2 — higher is the reassuring side
    const val OXYGEN_HIGH_MIN = 97f
}

/** Guides for an extended channel, or null when range guides are off. */
@Composable
fun extGuides(show: Boolean, lowMax: Float, highMin: Float, higherIsBetter: Boolean = false): Guides? =
    if (!show) null else Guides(
        lowMax, highMin,
        stringResource(R.string.level_low), stringResource(R.string.level_medium), stringResource(R.string.level_high),
        higherIsBetter,
    )

/** Sweat conductance panel — µS, 1 decimal, teal, area fill like the sweat-moisture panel. */
@Composable
fun ConductancePanel(
    name: String,
    points: List<TimePoint>,
    x0: Float, x1: Float,
    height: Dp = 140.dp,
    showXAxis: Boolean = false,
    bands: List<Pair<Float, Float>> = emptyList(),
    scrub: Float? = null,
    xFormat: (Float) -> String = ::fmtHm,
    reveal: Float = 1f,
    guides: Guides? = null,
) {
    LinePanel(
        series = listOf(LineSeries(name, points, LocalChartColors.current.conductance, area = true)),
        x0 = x0, x1 = x1, height = height, showXAxis = showXAxis, decimals = 1, unit = " µS", yMin = 0f,
        bands = bands, bandColor = BundleBandColor, scrub = scrub, xFormat = xFormat, reveal = reveal, guides = guides,
    )
}

/** Blood flow (perfusion index) panel — %, 1 decimal, orange. */
@Composable
fun BloodFlowPanel(
    name: String,
    points: List<TimePoint>,
    x0: Float, x1: Float,
    height: Dp = 120.dp,
    showXAxis: Boolean = false,
    bands: List<Pair<Float, Float>> = emptyList(),
    scrub: Float? = null,
    xFormat: (Float) -> String = ::fmtHm,
    reveal: Float = 1f,
    guides: Guides? = null,
) {
    LinePanel(
        series = listOf(LineSeries(name, points, LocalChartColors.current.bloodFlow)),
        x0 = x0, x1 = x1, height = height, showXAxis = showXAxis, decimals = 1, unit = "%", yMin = 0f,
        bands = bands, bandColor = BundleBandColor, scrub = scrub, xFormat = xFormat, reveal = reveal, guides = guides,
    )
}

/** Blood oxygen panel — %, 1 decimal, violet. */
@Composable
fun OxygenPanel(
    name: String,
    points: List<TimePoint>,
    x0: Float, x1: Float,
    height: Dp = 120.dp,
    showXAxis: Boolean = false,
    bands: List<Pair<Float, Float>> = emptyList(),
    scrub: Float? = null,
    xFormat: (Float) -> String = ::fmtHm,
    reveal: Float = 1f,
    guides: Guides? = null,
) {
    LinePanel(
        series = listOf(LineSeries(name, points, LocalChartColors.current.oxygen)),
        x0 = x0, x1 = x1, height = height, showXAxis = showXAxis, decimals = 1, unit = "%",
        bands = bands, bandColor = BundleBandColor, scrub = scrub, xFormat = xFormat, reveal = reveal, guides = guides,
    )
}

/**
 * The night as one horizontal band (Vital Sheet header, brief §4.2): quiet = neutral track,
 * each flash bundle a rounded fuchsia block (width = duration), wake-ups as thin ticks.
 */
@Composable
fun BundleTimelineStrip(
    bundles: List<Pair<Float, Float>>,
    wakes: List<Float>,
    x0: Float, x1: Float,
    modifier: Modifier = Modifier,
    height: Dp = 36.dp,
) {
    val cc = LocalChartColors.current
    val track = MaterialTheme.colorScheme.surfaceVariant
    Canvas(modifier.fillMaxWidth().height(height)) {
        val bandH = size.height * 0.52f
        val top = (size.height - bandH) / 2f
        val span = (x1 - x0).coerceAtLeast(1f)
        fun px(t: Float) = ((t - x0) / span).coerceIn(0f, 1f) * size.width
        drawRoundRect(track, Offset(0f, top), Size(size.width, bandH), CornerRadius(bandH / 2))
        bundles.forEach { (a, b) ->
            val xA = px(a); val xB = px(b)
            drawRoundRect(Aurora.Fuchsia, Offset(xA, top), Size((xB - xA).coerceAtLeast(3.dp.toPx()), bandH), CornerRadius(bandH / 2))
        }
        wakes.forEach { t ->
            val x = px(t)
            drawLine(cc.axisText, Offset(x, top - 4.dp.toPx()), Offset(x, top), strokeWidth = 1.5f.dp.toPx())
        }
    }
}
