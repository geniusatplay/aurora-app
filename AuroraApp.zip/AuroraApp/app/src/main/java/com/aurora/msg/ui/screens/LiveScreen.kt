package com.aurora.msg.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.msg.R
import com.aurora.msg.domain.NightAnalytics
import com.aurora.msg.domain.RangeGuide
import com.aurora.msg.domain.Ranges
import com.aurora.msg.protocol.Cadence
import com.aurora.msg.protocol.HrvFlags
import com.aurora.msg.protocol.HwAdapter
import com.aurora.msg.protocol.QualityBand
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.protocol.SweatFlag
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.Fmt
import com.aurora.msg.ui.charts.Guides
import com.aurora.msg.ui.charts.Legend
import com.aurora.msg.ui.charts.LinePanel
import com.aurora.msg.ui.charts.LineSeries
import com.aurora.msg.ui.charts.Sparkline
import com.aurora.msg.ui.charts.TimePoint
import com.aurora.msg.ui.charts.fmtHm
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.BannerTone
import com.aurora.msg.ui.components.EmptyState
import com.aurora.msg.ui.components.InfoBanner
import com.aurora.msg.ui.components.LevelBadge
import com.aurora.msg.ui.components.Pill
import com.aurora.msg.ui.components.SectionHeader
import com.aurora.msg.ui.components.StatTile
import com.aurora.msg.ui.theme.Aurora
import com.aurora.msg.ui.theme.AuroraThemeExtras
import com.aurora.msg.ui.theme.LocalChartColors

/** Builds chart guides from a range, converting to display units where needed. */
@Composable
fun guidesFor(range: RangeGuide, show: Boolean, convert: (Float) -> Float = { it }): Guides? =
    if (!show) null else Guides(
        convert(range.lowMax), convert(range.highMin),
        stringResource(R.string.level_low), stringResource(R.string.level_medium), stringResource(R.string.level_high),
        range.higherIsBetter,
    )

@Composable
fun LiveScreen(vm: AppViewModel, inner: PaddingValues, onOpenPod: () -> Unit, onDemo: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val v by vm.pod.latestVitals.collectAsStateWithLifecycle()
    val window by vm.pod.liveWindow.collectAsStateWithLifecycle()
    val hrv by vm.pod.latestHrv.collectAsStateWithLifecycle()
    val lastHr by vm.pod.lastHr.collectAsStateWithLifecycle()
    val active by vm.pod.activeSession.collectAsStateWithLifecycle()
    val synced by vm.pod.timeSynced.collectAsStateWithLifecycle()
    val hasExt by vm.pod.hasExtendedSensors.collectAsStateWithLifecycle()
    val ext by vm.pod.latestExt.collectAsStateWithLifecycle()
    val extWindow by vm.pod.extWindow.collectAsStateWithLifecycle()
    // What this pod can measure: demo = full paper spec (UI unchanged); real glove = HARDWARE_V1.
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val battery by vm.pod.batteryPct.collectAsStateWithLifecycle()
    val show = settings.showRanges

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding(), bottom = inner.calculateBottomPadding() + 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Column(Modifier.statusBarsPadding().padding(top = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.live_title), style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.width(10.dp))
                if (conn.isConnected) Pill(if (active != null) stringResource(R.string.common_recording) else stringResource(R.string.common_connected), if (active != null) MaterialTheme.colorScheme.primary else AuroraThemeExtras.pillBg, if (active != null) MaterialTheme.colorScheme.onPrimary else Color.Unspecified)
            }
            Text(stringResource(R.string.live_subtitle), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (!conn.isConnected || v == null) {
            AuroraCard {
                EmptyState(stringResource(R.string.live_not_connected_title), stringResource(R.string.live_not_connected_body)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onOpenPod, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) { Text(stringResource(R.string.common_connect)) }
                        OutlinedButton(onClick = onDemo, shape = CircleShape) { Text(stringResource(R.string.common_demo)) }
                    }
                }
            }
            return@Column
        }
        val vit = v!!
        val asleep = vit.sleepState == SleepState.LIGHT || vit.sleepState == SleepState.DEEP
        // Room climate only when the pod has a room sensor AND this packet carries a reading
        // (the real glove sends the NO_AMBIENT sentinel).
        val showRoom = caps.roomClimate && HwAdapter.hasAmbient(vit.ambTempX100)

        if (vit.sensorFault) InfoBanner(stringResource(R.string.live_banner_sensor_fault), tone = BannerTone.Error, icon = Icons.Rounded.ErrorOutline)
        if (!synced) InfoBanner(stringResource(R.string.live_banner_syncing_clock), tone = BannerTone.Info)
        if (!vit.podDetected) InfoBanner(stringResource(R.string.live_banner_not_on_skin), tone = BannerTone.Warning)
        if (show) InfoBanner(stringResource(R.string.live_banner_guides), tone = BannerTone.Info)

        // ----- Skin moisture (absolute humidity) — the real glove's key sweat signal
        if (caps.directAbsHumidity) {
            AuroraCard {
                Text(stringResource(R.string.hw_live_moisture_title), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.hw_live_moisture_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                val ah = vit.absHumX100
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(ah?.let { "%.2f".format(it / 100f) } ?: "—", style = MaterialTheme.typography.displayMedium)
                    if (ah != null) {
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.common_gm3), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
                    }
                }
                vit.dahDirectX100?.let { d ->
                    Text(stringResource(R.string.hw_live_moisture_vs_baseline, "%+.2f".format(d / 100f)), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (vit.sweatFlag != SweatFlag.NONE) {
                    Spacer(Modifier.height(8.dp))
                    Pill(stringResource(R.string.hw_live_possible_flush), Aurora.SeriesSweat, MaterialTheme.colorScheme.onPrimary)
                }
            }
            // SpO2 — an uncalibrated ratio estimate, trend only; hidden below quality 40 (PROTOCOL §3)
            if (caps.spo2Estimate) {
                val cc = LocalChartColors.current
                val spo2 = ext?.spo2Pct
                AuroraCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile(
                            stringResource(R.string.hw_live_spo2_title),
                            spo2?.let { "%.0f".format(it) } ?: "—",
                            if (spo2 != null) "%" else "",
                            Modifier.weight(1f), accent = cc.oxygen,
                            note = stringResource(if (spo2 != null) R.string.hw_live_spo2_note else R.string.hw_live_spo2_low_quality),
                        )
                    }
                }
            }
        }

        // ----- Heart rate — never "0 bpm", never stale
        AuroraCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Favorite, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.live_heart_rate), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                if (vit.ppgActive) Pill(stringResource(R.string.live_pill_measuring), AuroraThemeExtras.pillBg)
            }
            Spacer(Modifier.height(8.dp))
            when {
                vit.ppgActive && vit.hasHr -> {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("${vit.hrBpm}", style = MaterialTheme.typography.displayMedium)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.common_bpm), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
                        Spacer(Modifier.width(12.dp))
                        if (show && asleep) LevelBadge(Ranges.sleepHeartRate.levelOf(vit.hrBpm.toFloat()), modifier = Modifier.padding(bottom = 10.dp))
                        if (QualityBand.of(vit.hrQuality) == QualityBand.LOW_CONFIDENCE) { Spacer(Modifier.width(6.dp)); Pill(stringResource(R.string.live_pill_low_confidence), AuroraThemeExtras.track, modifier = Modifier.padding(bottom = 10.dp)) }
                    }
                    if (settings.demoMode) {
                        Text(stringResource(R.string.live_hr_streaming), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else if (caps.continuousPpg) {
                        // The real glove's optical sensor runs all the time: no burst countdown.
                        Text(stringResource(R.string.hw_live_hr_continuous), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        val inBurst = (vit.tS % Cadence.HRV_PERIOD_S).toInt()
                        LinearProgressIndicator(progress = { inBurst / Cadence.PPG_BURST_S.toFloat() }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary, trackColor = AuroraThemeExtras.track)
                        Text(stringResource(R.string.live_optical_burst, inBurst, Cadence.PPG_BURST_S), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                vit.ppgActive -> {
                    Text(stringResource(R.string.live_measuring), style = MaterialTheme.typography.headlineMedium)
                    Text(stringResource(R.string.live_measuring_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                caps.continuousPpg -> {
                    // Continuous PPG with no skin contact: a dash, never a zero or a countdown.
                    Text("—", style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(stringResource(R.string.hw_live_hr_no_finger), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> {
                    val m = (vit.secondsToNextPpg + 59) / 60
                    val last = lastHr
                    if (last != null) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("${last.bpm}", style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.common_bpm), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
                            Spacer(Modifier.width(12.dp))
                            if (show && asleep) LevelBadge(Ranges.sleepHeartRate.levelOf(last.bpm.toFloat()), modifier = Modifier.padding(bottom = 10.dp))
                        }
                        val ageMin = ((vit.tS - last.tS) / 60).toInt()
                        Text(if (ageMin < 1) stringResource(R.string.live_last_reading_just_now) else stringResource(R.string.live_last_reading_ago, ageMin), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(if (m <= 1) stringResource(R.string.live_next_reading_minute) else stringResource(R.string.live_next_reading_min, m), style = if (last != null) MaterialTheme.typography.titleSmall else MaterialTheme.typography.headlineSmall)
                    Text(stringResource(R.string.live_next_reading_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // ----- Heart-rate variability (two clearly named numbers)
        hrv?.let { h ->
            AuroraCard {
                Text(stringResource(R.string.live_hrv_title), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(if (caps.hrvRelativeOnly) R.string.hw_live_hrv_body else R.string.live_hrv_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (caps.hrvRelativeOnly) {
                    Spacer(Modifier.height(4.dp))
                    Text(stringResource(R.string.hw_hrv_relative_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (h.isValid) {
                        StatTile(
                            stringResource(R.string.live_hrv_rmssd), "%.0f".format(h.rmssdMs), stringResource(R.string.common_ms), Modifier.weight(1f), accent = Aurora.SeriesHrv,
                            note = stringResource(R.string.live_hrv_rmssd_note), level = if (show && !caps.hrvRelativeOnly) Ranges.rmssd.levelOf(h.rmssdMs) else null, higherIsBetter = true,
                        )
                        StatTile(stringResource(R.string.live_hrv_sdnn), "%.0f".format(h.sdnnMs), stringResource(R.string.common_ms), Modifier.weight(1f), accent = Aurora.SeriesHrv, note = stringResource(R.string.live_hrv_sdnn_note))
                    } else {
                        val reason = stringResource(
                            when {
                                HrvFlags.has(h.flags, HrvFlags.MOTION) -> R.string.live_hrv_reason_movement
                                HrvFlags.has(h.flags, HrvFlags.LOW_PERF) -> R.string.live_hrv_reason_weak_pulse
                                HrvFlags.has(h.flags, HrvFlags.LOW_BEATS) -> R.string.live_hrv_reason_few_beats
                                HrvFlags.has(h.flags, HrvFlags.SAMPLE_LOSS) -> R.string.live_hrv_reason_sample_loss
                                else -> R.string.live_hrv_reason_low_quality
                            }
                        )
                        StatTile(stringResource(R.string.live_hrv_variability), "—", modifier = Modifier.weight(1f), accent = Aurora.SeriesHrv, note = stringResource(R.string.live_hrv_not_enough, reason))
                    }
                }
            }
        }

        // ----- Skin & room (skin only on a pod without a room sensor)
        if (!showRoom) {
            AuroraCard {
                Text(stringResource(R.string.hw_live_skin_title), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(stringResource(R.string.live_skin_temp), Fmt.temp(vit.skinTempC, settings), modifier = Modifier.weight(1f), accent = Aurora.SeriesSkin, level = if (show) Ranges.skinTemp.levelOf(vit.skinTempC) else null)
                    StatTile(stringResource(R.string.live_skin_humidity), "%.0f".format(vit.skinRh), "%", Modifier.weight(1f), accent = Aurora.SeriesSkin, level = if (show) Ranges.skinRh.levelOf(vit.skinRh) else null)
                }
            }
        } else AuroraCard {
            Text(stringResource(R.string.live_skin_room), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(stringResource(R.string.live_skin_temp), Fmt.temp(vit.skinTempC, settings), modifier = Modifier.weight(1f), accent = Aurora.SeriesSkin, level = if (show) Ranges.skinTemp.levelOf(vit.skinTempC) else null)
                StatTile(stringResource(R.string.live_room_temp), Fmt.temp(vit.ambTempC, settings), modifier = Modifier.weight(1f), accent = Aurora.SeriesAmbient, level = if (show) Ranges.roomTemp.levelOf(vit.ambTempC) else null)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(stringResource(R.string.live_skin_humidity), "%.0f".format(vit.skinRh), "%", Modifier.weight(1f), accent = Aurora.SeriesSkin, level = if (show) Ranges.skinRh.levelOf(vit.skinRh) else null)
                StatTile(stringResource(R.string.live_room_humidity), "%.0f".format(vit.ambRh), "%", Modifier.weight(1f), accent = Aurora.SeriesAmbient, level = if (show) Ranges.roomRh.levelOf(vit.ambRh) else null)
            }
        }

        // ----- Sweat moisture (the pod's special measurement) — skin-vs-room Magnus math,
        //       so only for pods with a room sensor; the real glove has its own card above.
        if (!caps.directAbsHumidity && showRoom) {
            val dah = NightAnalytics.dahX100(vit.skinTempC, vit.skinRh, vit.ambTempC, vit.ambRh) / 100f
            AuroraCard {
                Text(stringResource(R.string.live_sweat_title), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.live_sweat_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(stringResource(R.string.live_sweat_now), Fmt.dah(dah), stringResource(R.string.common_gm3), Modifier.weight(1f), accent = Aurora.SeriesSweat, level = if (show) Ranges.sweat.levelOf(dah) else null)
                    StatTile(stringResource(R.string.live_sweat_event), stringResource(when (vit.sweatFlag.code) { 2 -> R.string.live_sweat_started; 1 -> R.string.live_sweat_ongoing; else -> R.string.live_sweat_none }), modifier = Modifier.weight(1f), accent = Aurora.SeriesSweat)
                }
            }
        }

        // ----- Skin conductance — only when this pod exposes the extended sensors (FE06)
        if (hasExt) {
            val cc = LocalChartColors.current
            AuroraCard {
                Text(stringResource(R.string.ext_live_conductance), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.ext_live_conductance_sub), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                val edaNow = ext?.edaUs
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        stringResource(R.string.ext_conductance),
                        edaNow?.let { "%.1f".format(it) } ?: "—",
                        if (edaNow != null) stringResource(R.string.ext_us) else "",
                        Modifier.weight(1f), accent = cc.conductance,
                        level = if (show && edaNow != null) {
                            if (edaNow < com.aurora.msg.ui.charts.ExtGuideBands.CONDUCTANCE_LOW_MAX) com.aurora.msg.domain.Level.LOW
                            else if (edaNow > com.aurora.msg.ui.charts.ExtGuideBands.CONDUCTANCE_HIGH_MIN) com.aurora.msg.domain.Level.HIGH
                            else com.aurora.msg.domain.Level.MEDIUM
                        } else null,
                    )
                }
                val trail = extWindow.mapNotNull { it.edaUs }
                if (trail.size > 2) {
                    Spacer(Modifier.height(10.dp))
                    Sparkline(trail, cc.conductance, Modifier.fillMaxWidth().height(48.dp))
                }
            }
        }

        // ----- Rolling charts (last 15 min)
        if (window.size > 2) {
            val x0 = window.first().tS.toFloat(); val x1 = window.last().tS.toFloat().coerceAtLeast(x0 + 60f)
            val fmt: (Float) -> String = { fmtHm(it) }
            val skinLabel = stringResource(R.string.live_series_skin)
            val roomLabel = stringResource(R.string.live_series_room)
            val hrPoints = window.filter { it.hasHr }.map { TimePoint(it.tS.toFloat(), it.hrBpm.toFloat()) }
            if (hrPoints.size > 1) AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.live_chart_hr), stringResource(R.string.live_chart_hr_sub), Modifier.padding(start = 12.dp))
                LinePanel(
                    series = listOf(LineSeries(stringResource(R.string.live_heart_rate), hrPoints, Aurora.SeriesHeart)),
                    x0 = x0, x1 = x1, height = 140.dp, showXAxis = true, decimals = 0, unit = " " + stringResource(R.string.common_bpm), xFormat = fmt,
                    guides = if (asleep) guidesFor(Ranges.sleepHeartRate, show) else null,
                )
            }
            if (!showRoom) AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.vs_row_skin), stringResource(R.string.live_chart_last_min, ((x1 - x0) / 60).toInt().coerceAtLeast(1)), Modifier.padding(start = 12.dp))
                LinePanel(
                    series = listOf(LineSeries(skinLabel, window.map { TimePoint(it.tS.toFloat(), settings.toDisplayTemp(it.skinTempC)) }, Aurora.SeriesSkin)),
                    x0 = x0, x1 = x1, height = 150.dp, showXAxis = true, unit = settings.tempLabel(), xFormat = fmt,
                    guides = guidesFor(Ranges.skinTemp, show) { settings.toDisplayTemp(it) },
                )
            } else AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.live_chart_skin_vs_room), stringResource(R.string.live_chart_last_min, ((x1 - x0) / 60).toInt().coerceAtLeast(1)), Modifier.padding(start = 12.dp))
                Legend(listOf(skinLabel to Aurora.SeriesSkin, roomLabel to Aurora.SeriesAmbient), Modifier.padding(start = 12.dp, bottom = 6.dp))
                LinePanel(
                    series = listOf(
                        LineSeries(skinLabel, window.map { TimePoint(it.tS.toFloat(), settings.toDisplayTemp(it.skinTempC)) }, Aurora.SeriesSkin),
                        LineSeries(roomLabel, window.map { TimePoint(it.tS.toFloat(), settings.toDisplayTemp(it.ambTempC)) }, Aurora.SeriesAmbient),
                    ),
                    x0 = x0, x1 = x1, height = 150.dp, showXAxis = true, unit = settings.tempLabel(), xFormat = fmt,
                    guides = guidesFor(Ranges.skinTemp, show) { settings.toDisplayTemp(it) },
                )
            }
            val ahPoints = if (caps.directAbsHumidity) window.mapNotNull { w -> w.absHumX100?.let { TimePoint(w.tS.toFloat(), it / 100f) } } else emptyList()
            if (caps.directAbsHumidity) {
                if (ahPoints.size > 1) AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                    SectionHeader(stringResource(R.string.hw_live_moisture_title), stringResource(R.string.hw_live_chart_moisture_sub), Modifier.padding(start = 12.dp))
                    LinePanel(
                        series = listOf(LineSeries(stringResource(R.string.hw_series_moisture), ahPoints, Aurora.SeriesSweat, area = true)),
                        x0 = x0, x1 = x1, height = 140.dp, showXAxis = true, decimals = 2, unit = " g/m³", xFormat = fmt,
                    )
                }
            } else if (showRoom) AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.live_sweat_title), stringResource(R.string.live_chart_sweat_subtitle), Modifier.padding(start = 12.dp))
                LinePanel(
                    series = listOf(LineSeries(stringResource(R.string.live_series_sweat), window.map { TimePoint(it.tS.toFloat(), NightAnalytics.dahX100(it.skinTempC, it.skinRh, it.ambTempC, it.ambRh) / 100f) }, Aurora.SeriesSweat, area = true)),
                    x0 = x0, x1 = x1, height = 140.dp, showXAxis = true, yMin = 0f, unit = " g/m³", xFormat = fmt, guides = guidesFor(Ranges.sweat, show),
                )
            }
            if (caps.movement) AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.live_chart_movement), stringResource(R.string.live_chart_movement_subtitle), Modifier.padding(start = 12.dp))
                LinePanel(
                    series = listOf(LineSeries(stringResource(R.string.live_chart_movement), window.map { TimePoint(it.tS.toFloat(), it.motionIndex.toFloat()) }, Aurora.SeriesMotion, area = true)),
                    x0 = x0, x1 = x1, height = 110.dp, showXAxis = true, yMin = 0f, decimals = 0, xFormat = fmt, guides = guidesFor(Ranges.movement, show),
                )
            }
        }

        // ----- Sleep level (its own card) — only when the pod stages sleep (needs an IMU)
        if (caps.sleepStaging) AuroraCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Bedtime, null, tint = Aurora.SleepDeep)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.live_sleep_level), style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(
                    when (vit.sleepState) {
                        SleepState.WAKE -> R.string.live_sleep_awake
                        SleepState.LIGHT -> R.string.live_sleep_light
                        SleepState.DEEP -> R.string.live_sleep_deep
                        SleepState.UNKNOWN -> R.string.live_sleep_unknown
                    }
                ),
                style = MaterialTheme.typography.headlineMedium)
            Text(
                stringResource(
                    when (vit.sleepState) {
                        SleepState.WAKE -> R.string.live_sleep_desc_awake
                        SleepState.LIGHT -> R.string.live_sleep_desc_light
                        SleepState.DEEP -> R.string.live_sleep_desc_deep
                        SleepState.UNKNOWN -> R.string.live_sleep_desc_unknown
                    }
                ) + " " + stringResource(R.string.live_sleep_lag_note),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // ----- Battery (its own card). Unknown (no cell fitted) → no gauge at all, just the text.
        if (!caps.battery && battery == null) AuroraCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.BatteryFull, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.live_battery_title), style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.hw_battery_unknown), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else AuroraCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (vit.charging) Icons.Rounded.BatteryChargingFull else Icons.Rounded.BatteryFull, null, tint = if (vit.lowBatt) Aurora.Bad else Aurora.Good)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.live_battery_title), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                Text(stringResource(R.string.live_battery_pct, vit.battPct), style = MaterialTheme.typography.headlineMedium, color = if (vit.lowBatt) Aurora.Bad else MaterialTheme.colorScheme.onSurface)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { vit.battPct / 100f }, modifier = Modifier.fillMaxWidth(), color = if (vit.lowBatt) Aurora.Bad else Aurora.Good, trackColor = AuroraThemeExtras.track)
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(
                    when {
                        vit.charging -> R.string.live_battery_charging
                        vit.lowBatt -> R.string.live_battery_low
                        else -> R.string.live_battery_normal
                    }
                ),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (active != null) InfoBanner(stringResource(R.string.live_banner_recording), tone = BannerTone.Success)
    }
}
