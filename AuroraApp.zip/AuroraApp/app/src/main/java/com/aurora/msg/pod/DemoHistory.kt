package com.aurora.msg.pod

import com.aurora.msg.protocol.Cadence
import com.aurora.msg.protocol.LogRecord
import com.aurora.msg.protocol.PodFlags
import com.aurora.msg.protocol.HrvFlags
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.protocol.SweatFlag
import com.aurora.msg.domain.NightAnalytics
import kotlin.math.roundToInt
import kotlin.random.Random

/** One generated night, ready to store. */
data class GeneratedNight(
    val startedAtEpochMs: Long,
    val records: List<LogRecord>,
    val events: List<Pair<Long, DemoMode>>,
)

/**
 * Generates whole nights of realistic records by scripting the same DemoScenario model:
 * fall asleep → cycles → 2–7 flashes/sweats scattered through the night → wake.
 */
object DemoHistory {

    fun generateNight(startedAtEpochMs: Long, seed: Long, intensity: Float = 0.5f): GeneratedNight {
        val rnd = Random(seed)
        val scenario = DemoScenario(seed).apply { sweatGain = 0.7f + rnd.nextFloat() * 0.6f + intensity * 0.3f }
        val lengthS = (6.4f + rnd.nextFloat() * 1.9f).let { (it * 3600).toInt() }   // 6.4–8.3 h
        // 0–7 events per night (brief §2): the wide random factor makes genuinely quiet
        // (zero-event) nights happen at low intensity, and bad 6–7 event nights at high.
        val nEvents = (intensity * 7f * (rnd.nextFloat() * 1.35f)).roundToInt().coerceIn(0, 7)

        // Schedule events at least 40 min apart, mostly in the second half of the night.
        val eventStarts = ArrayList<Int>()
        var attempts = 0
        while (eventStarts.size < nEvents && attempts < 200) {
            attempts++
            val t = ((1800 + rnd.nextFloat() * (lengthS - 3600)).toInt() / Cadence.EPOCH_S) * Cadence.EPOCH_S
            if (eventStarts.all { kotlin.math.abs(it - t) > 2400 }) eventStarts.add(t)
        }
        eventStarts.sort()
        val eventKinds = eventStarts.map { if (rnd.nextFloat() < 0.45f) DemoMode.NIGHT_SWEATS else DemoMode.NIGHT_FLASH }

        val records = ArrayList<LogRecord>(lengthS / Cadence.EPOCH_S)
        val events = ArrayList<Pair<Long, DemoMode>>()
        scenario.setMode(DemoMode.UP)
        var sweatWasOn = false
        var lastHrvT = -1L
        var hrvFresh = false
        var hrv: Triple<Int, Int, Int>? = null // ibi, sdnnX10, rmssdX10
        var hrvFlags = 0
        var hrvQ = 0
        var mode = DemoMode.UP
        var modeEndsAt = 0

        // Warm-up: model settles for 5 min before "session start".
        repeat(60) { scenario.step(5f) }
        scenario.setMode(DemoMode.SLEEPING)
        mode = DemoMode.SLEEPING
        events.add(0L to DemoMode.SLEEPING)

        var t = 0
        while (t < lengthS) {
            // Enter / leave events
            val idx = eventStarts.indexOf(t)
            if (idx >= 0) {
                mode = eventKinds[idx]
                scenario.setMode(mode)
                modeEndsAt = t + if (mode == DemoMode.NIGHT_SWEATS) 900 + rnd.nextInt(300) else 420 + rnd.nextInt(180)
                events.add(t.toLong() to mode)
            } else if (mode != DemoMode.SLEEPING && t >= modeEndsAt) {
                mode = DemoMode.SLEEPING
                scenario.setMode(mode)
                events.add(t.toLong() to DemoMode.SLEEPING)
            }

            repeat(Cadence.EPOCH_S / 5) { scenario.step(5f) }
            t += Cadence.EPOCH_S

            val cycle = t % Cadence.HRV_PERIOD_S
            val ppg = cycle < Cadence.PPG_BURST_S
            if (cycle >= Cadence.PPG_BURST_S && (t / Cadence.HRV_PERIOD_S).toLong() != lastHrvT) {
                lastHrvT = (t / Cadence.HRV_PERIOD_S).toLong()
                val motionHigh = scenario.motionIndex() > 150
                val rmssd = scenario.gauss(if (scenario.sleepState == SleepState.DEEP) 52f else 40f, 7f).coerceIn(8f, 120f)
                val sdnn = (rmssd * 1.15f + scenario.gauss(0f, 4f)).coerceIn(8f, 140f)
                hrv = Triple((60_000f / scenario.hr).roundToInt(), (sdnn * 10).roundToInt(), (rmssd * 10).roundToInt())
                hrvFlags = if (motionHigh) HrvFlags.MOTION else if (rnd.nextFloat() < 0.05f) HrvFlags.LOW_PERF else HrvFlags.VALID
                hrvQ = if (HrvFlags.has(hrvFlags, HrvFlags.VALID)) 75 + rnd.nextInt(24) else 25 + rnd.nextInt(30)
                hrvFresh = true
            }

            val on = scenario.sweating
            val sf = when { on && !sweatWasOn -> SweatFlag.START; on -> SweatFlag.ONGOING; else -> SweatFlag.NONE }
            sweatWasOn = on

            var flags = PodFlags.POD_DETECTED or PodFlags.LOGGING or PodFlags.TIME_SYNCED
            if (ppg) flags = flags or PodFlags.PPG_ACTIVE
            if (hrvFresh) { flags = flags or PodFlags.HRV_FRESH; hrvFresh = false }

            records.add(
                LogRecord(
                    tS = t.toLong(),
                    hrBpm = if (ppg) scenario.hr.roundToInt() else 0,
                    hrQuality = if (ppg) scenario.hrQuality() else 0,
                    skinTempX100 = (scenario.skinTemp * 100).roundToInt(),
                    skinRhX100 = (scenario.skinRh * 100).roundToInt(),
                    ambTempX100 = (scenario.ambTemp * 100).roundToInt(),
                    ambRhX100 = (scenario.ambRh * 100).roundToInt(),
                    motionIndex = scenario.motionIndex(),
                    sleepState = scenario.sleepState,
                    sweatFlag = sf,
                    battPct = scenario.battPct,
                    flags = flags,
                    dahX100 = scenario.dahX100(),
                    hrvMeanIbiMs = hrv?.first ?: 0,
                    hrvSdnnMsX10 = hrv?.second ?: 0,
                    hrvRmssdMsX10 = hrv?.third ?: 0,
                    hrvPnn50Pct = hrv?.let { (it.third / 22).coerceIn(0, 100) } ?: 0,
                    hrvQuality = hrvQ,
                    hrvFlags = hrvFlags,
                    vcellCv = ((3.3f + 0.9f * scenario.battPct / 100f - 2.5f) * 100).roundToInt().coerceIn(1, 255),
                    // Seeded history is v2 (brief §2): every generated night carries EDA/SpO2/PI.
                    edaX100 = scenario.edaX100(),
                    spo2X10 = scenario.spo2X10(),
                    perfusionX100 = scenario.perfusionX100(),
                    extFlags = scenario.extFlags(),
                )
            )
        }
        events.add(lengthS.toLong() to DemoMode.UP)
        return GeneratedNight(startedAtEpochMs, records, events)
    }

    /** 14 nights ending last night, bedtime ~22:30–23:45 local, with a gentle downward trend in intensity. */
    fun generateHistory(nowEpochMs: Long, nights: Int = 14, seed: Long = 42L): List<GeneratedNight> {
        val rnd = Random(seed)
        val dayMs = 86_400_000L
        val zone = java.util.TimeZone.getDefault()
        val cal = java.util.Calendar.getInstance(zone).apply { timeInMillis = nowEpochMs }
        // Last night = yesterday 23:00 local
        cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        cal.set(java.util.Calendar.HOUR_OF_DAY, 23); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0)
        val lastBed = cal.timeInMillis
        return (0 until nights).map { i ->
            val bed = lastBed - (nights - 1 - i) * dayMs + (rnd.nextInt(-30, 45) * 60_000L)
            val intensity = (0.75f - 0.35f * i / nights + rnd.nextFloat() * 0.3f).coerceIn(0.15f, 1f)
            generateNight(bed, seed + i * 7919L, intensity)
        }
    }

    /** Convenience for tests / previews. */
    fun summaryOf(night: GeneratedNight) = NightAnalytics.summarize(night.records)
}
