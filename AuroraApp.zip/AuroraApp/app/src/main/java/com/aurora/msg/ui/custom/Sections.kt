package com.aurora.msg.ui.custom

import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DateRange
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FiberManualRecord
import androidx.compose.material.icons.rounded.Grain
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Hotel
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.MonitorHeart
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.Opacity
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.msg.R
import com.aurora.msg.data.repo.AppSettings
import com.aurora.msg.data.repo.CustomPagesModel
import com.aurora.msg.data.repo.NightBundle
import com.aurora.msg.domain.NightAnalytics
import com.aurora.msg.domain.Ranges
import com.aurora.msg.pod.CheckText
import com.aurora.msg.pod.DurationArg
import com.aurora.msg.pod.HardwareCheckRunner
import com.aurora.msg.pod.HardwareCheckStep
import com.aurora.msg.pod.LinkRecorder
import com.aurora.msg.pod.LinkStats
import com.aurora.msg.pod.RawPacket
import com.aurora.msg.pod.RawPacketKind
import com.aurora.msg.protocol.HwAdapter
import com.aurora.msg.protocol.LiveVitals
import com.aurora.msg.protocol.QualityBand
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.protocol.SweatFlag
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.Fmt
import com.aurora.msg.ui.charts.Sparkline
import com.aurora.msg.ui.charts.rememberReveal
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.BannerTone
import com.aurora.msg.ui.components.InfoBanner
import com.aurora.msg.ui.components.Pill
import com.aurora.msg.ui.components.SectionHeader
import com.aurora.msg.ui.components.StatTile
import com.aurora.msg.ui.isHardwareNight
import com.aurora.msg.ui.isHardwarePod
import com.aurora.msg.ui.screens.DemoControlsContent
import com.aurora.msg.ui.screens.LastNightHero
import com.aurora.msg.ui.screens.LiveCharts
import com.aurora.msg.ui.screens.LiveConductanceCard
import com.aurora.msg.ui.screens.LiveHeartRateCard
import com.aurora.msg.ui.screens.LiveHrvCard
import com.aurora.msg.ui.screens.LiveMoistureCard
import com.aurora.msg.ui.screens.LiveSpo2Card
import com.aurora.msg.ui.screens.LiveSweatCard
import com.aurora.msg.ui.screens.MorningCard
import com.aurora.msg.ui.screens.NightChartsCard
import com.aurora.msg.ui.screens.NightRow
import com.aurora.msg.ui.screens.NightSweatEventsCard
import com.aurora.msg.ui.screens.NightSweatEventsHeader
import com.aurora.msg.ui.screens.PodConnectionCard
import com.aurora.msg.ui.screens.PodDeviceCard
import com.aurora.msg.ui.screens.PodHwLogCard
import com.aurora.msg.ui.screens.PodMaintenanceCard
import com.aurora.msg.ui.screens.PodNoNightsCard
import com.aurora.msg.ui.screens.PodReplayProgressCard
import com.aurora.msg.ui.screens.PodSecurityNote
import com.aurora.msg.ui.screens.PodSlotRow
import com.aurora.msg.ui.screens.PodTonightCard
import com.aurora.msg.ui.screens.TrendFlashesCard
import com.aurora.msg.ui.screens.TrendRangeChips
import com.aurora.msg.ui.screens.TrendRestingHrCard
import com.aurora.msg.ui.screens.TrendSeries
import com.aurora.msg.ui.screens.TrendSleepCard
import com.aurora.msg.ui.screens.TrendTilesBottom
import com.aurora.msg.ui.screens.TrendTilesTop
import com.aurora.msg.ui.screens.TrendTimeInBedCard
import com.aurora.msg.ui.screens.VitalSheetPreview
import com.aurora.msg.ui.screens.rememberPodScanAction
import com.aurora.msg.ui.theme.Aurora
import com.aurora.msg.ui.theme.AuroraThemeExtras
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * Custom pages — the section catalogue (stable IDs shared with the iPhone and web apps,
 * CUSTOM_PAGES_BRIEF.md) and [SectionContent], which renders each section with the SAME live
 * data and look as the screen it comes from by reusing that screen's composables
 * (LiveHeartRateCard, NightChartsCard, TrendFlashesCard, PodConnectionCard, …).
 *
 * Every catalogue section has Android data. When there is nothing to show yet (no pod
 * connected, no finished night, fewer than two nights for a trend) the section renders a short
 * explanatory card instead — never fake data.
 */

// ====================================================================== catalogue

enum class SectionCategory(@StringRes val titleRes: Int) {
    LIVE(R.string.cp_cat_live),
    NIGHTS(R.string.cp_cat_nights),
    TRENDS(R.string.cp_cat_trends),
    POD(R.string.cp_cat_pod),
    DIAGNOSTICS(R.string.cp_cat_diagnostics),
}

data class SectionDef(
    val id: String,
    val category: SectionCategory,
    @StringRes val nameRes: Int,
    @StringRes val descRes: Int,
    val icon: ImageVector,
)

object SectionCatalog {
    private fun def(id: String, c: SectionCategory, name: Int, desc: Int, icon: ImageVector) = SectionDef(id, c, name, desc, icon)

    /** Library order = brief order (same as [CustomPagesModel.KNOWN_SECTION_IDS]). */
    val all: List<SectionDef> = listOf(
        def("live_hr", SectionCategory.LIVE, R.string.cp_sec_live_hr, R.string.cp_sec_live_hr_desc, Icons.Rounded.Favorite),
        def("live_moisture", SectionCategory.LIVE, R.string.cp_sec_live_moisture, R.string.cp_sec_live_moisture_desc, Icons.Rounded.WaterDrop),
        def("live_skin_temp", SectionCategory.LIVE, R.string.cp_sec_live_skin_temp, R.string.cp_sec_live_skin_temp_desc, Icons.Rounded.Thermostat),
        def("live_skin_rh", SectionCategory.LIVE, R.string.cp_sec_live_skin_rh, R.string.cp_sec_live_skin_rh_desc, Icons.Rounded.Opacity),
        def("live_spo2", SectionCategory.LIVE, R.string.cp_sec_live_spo2, R.string.cp_sec_live_spo2_desc, Icons.Rounded.Air),
        def("live_quality", SectionCategory.LIVE, R.string.cp_sec_live_quality, R.string.cp_sec_live_quality_desc, Icons.Rounded.Speed),
        def("live_status", SectionCategory.LIVE, R.string.cp_sec_live_status, R.string.cp_sec_live_status_desc, Icons.Rounded.CheckCircle),
        def("live_chart", SectionCategory.LIVE, R.string.cp_sec_live_chart, R.string.cp_sec_live_chart_desc, Icons.Rounded.Insights),
        def("live_hrv", SectionCategory.LIVE, R.string.cp_sec_live_hrv, R.string.cp_sec_live_hrv_desc, Icons.Rounded.Waves),
        def("live_conductance", SectionCategory.LIVE, R.string.cp_sec_live_conductance, R.string.cp_sec_live_conductance_desc, Icons.Rounded.Bolt),
        def("session_controls", SectionCategory.LIVE, R.string.cp_sec_session_controls, R.string.cp_sec_session_controls_desc, Icons.Rounded.FiberManualRecord),
        def("last_night", SectionCategory.NIGHTS, R.string.cp_sec_last_night, R.string.cp_sec_last_night_desc, Icons.Rounded.Bedtime),
        def("morning_card", SectionCategory.NIGHTS, R.string.cp_sec_morning_card, R.string.cp_sec_morning_card_desc, Icons.Rounded.WbSunny),
        def("night_timeline", SectionCategory.NIGHTS, R.string.cp_sec_night_timeline, R.string.cp_sec_night_timeline_desc, Icons.Rounded.Timeline),
        def("vital_sheet", SectionCategory.NIGHTS, R.string.cp_sec_vital_sheet, R.string.cp_sec_vital_sheet_desc, Icons.Rounded.Description),
        def("recent_nights", SectionCategory.NIGHTS, R.string.cp_sec_recent_nights, R.string.cp_sec_recent_nights_desc, Icons.Rounded.DateRange),
        def("sweat_events", SectionCategory.NIGHTS, R.string.cp_sec_sweat_events, R.string.cp_sec_sweat_events_desc, Icons.Rounded.Grain),
        def("trends_overview", SectionCategory.TRENDS, R.string.cp_sec_trends_overview, R.string.cp_sec_trends_overview_desc, Icons.Rounded.GridView),
        def("trends_flashes", SectionCategory.TRENDS, R.string.cp_sec_trends_flashes, R.string.cp_sec_trends_flashes_desc, Icons.Rounded.BarChart),
        def("trends_hr", SectionCategory.TRENDS, R.string.cp_sec_trends_hr, R.string.cp_sec_trends_hr_desc, Icons.Rounded.MonitorHeart),
        def("trends_time_in_bed", SectionCategory.TRENDS, R.string.cp_sec_trends_time_in_bed, R.string.cp_sec_trends_time_in_bed_desc, Icons.Rounded.Hotel),
        def("trends_sleep", SectionCategory.TRENDS, R.string.cp_sec_trends_sleep, R.string.cp_sec_trends_sleep_desc, Icons.Rounded.NightsStay),
        def("pod_connection", SectionCategory.POD, R.string.cp_sec_pod_connection, R.string.cp_sec_pod_connection_desc, Icons.Rounded.Bluetooth),
        def("pod_info", SectionCategory.POD, R.string.cp_sec_pod_info, R.string.cp_sec_pod_info_desc, Icons.Rounded.Info),
        def("pod_log", SectionCategory.POD, R.string.cp_sec_pod_log, R.string.cp_sec_pod_log_desc, Icons.Rounded.Download),
        def("pod_controls", SectionCategory.POD, R.string.cp_sec_pod_controls, R.string.cp_sec_pod_controls_desc, Icons.Rounded.Tune),
        def("demo_controls", SectionCategory.POD, R.string.cp_sec_demo_controls, R.string.cp_sec_demo_controls_desc, Icons.Rounded.PlayArrow),
        def("link_health", SectionCategory.DIAGNOSTICS, R.string.cp_sec_link_health, R.string.cp_sec_link_health_desc, Icons.Rounded.NetworkCheck),
        def("packet_inspector", SectionCategory.DIAGNOSTICS, R.string.cp_sec_packet_inspector, R.string.cp_sec_packet_inspector_desc, Icons.Rounded.Code),
        def("hardware_check", SectionCategory.DIAGNOSTICS, R.string.cp_sec_hardware_check, R.string.cp_sec_hardware_check_desc, Icons.Rounded.Verified),
    )

    private val byId: Map<String, SectionDef> = all.associateBy { it.id }

    /** null for IDs this build does not know (kept in storage, skipped when rendering). */
    fun find(id: String): SectionDef? = byId[id]

    fun inCategory(category: SectionCategory): List<SectionDef> = all.filter { it.category == category }
}

/** What a section may ask its host to do (open a night, the Vital Sheet, the Pod tab, the demo). */
class SectionActions(
    val openNight: (Long) -> Unit,
    val openVitalSheet: (Long) -> Unit,
    val openPod: () -> Unit,
    val openDemo: () -> Unit,
)

// ====================================================================== SectionContent

/** Renders one catalogue section with real data; unknown IDs render nothing. */
@Composable
fun SectionContent(id: String, vm: AppViewModel, actions: SectionActions) {
    val def = SectionCatalog.find(id) ?: return
    when (def.category) {
        SectionCategory.LIVE -> LiveSection(def, vm, actions)
        SectionCategory.NIGHTS -> NightSection(def, vm, actions)
        SectionCategory.TRENDS -> TrendSection(def, vm, actions)
        SectionCategory.POD -> PodSection(def, vm, actions)
        SectionCategory.DIAGNOSTICS -> DiagnosticsSection(def, vm)
    }
}

// ====================================================================== shared pieces

/** Section title + one honest sentence (+ optional action) when there is nothing to show. */
@Composable
internal fun SectionPlaceholderCard(def: SectionDef, message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    AuroraCard {
        SectionTitleRow(def)
        Spacer(Modifier.height(6.dp))
        Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onAction, shape = CircleShape) { Text(actionLabel) }
        }
    }
}

/** Icon + section name (+ optional pill) for the cards this file builds itself. */
@Composable
private fun SectionTitleRow(def: SectionDef, trailing: String? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(def.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(stringResource(def.nameRes), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        if (trailing != null) Pill(trailing, AuroraThemeExtras.pillBg)
    }
}

// ====================================================================== Live

@Composable
private fun LiveSection(def: SectionDef, vm: AppViewModel, actions: SectionActions) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val v by vm.pod.latestVitals.collectAsStateWithLifecycle()
    if (def.id == "session_controls") {
        // Start / stop works (and explains itself) without live vitals.
        val active by vm.pod.activeSession.collectAsStateWithLifecycle()
        PodTonightCard(vm, settings, conn, active)
        return
    }
    val vit = v
    if (!conn.isConnected || vit == null) {
        SectionPlaceholderCard(def, stringResource(R.string.cp_live_not_connected), stringResource(R.string.common_connect), actions.openPod)
        return
    }
    val window by vm.pod.liveWindow.collectAsStateWithLifecycle()
    val hrv by vm.pod.latestHrv.collectAsStateWithLifecycle()
    val lastHr by vm.pod.lastHr.collectAsStateWithLifecycle()
    val synced by vm.pod.timeSynced.collectAsStateWithLifecycle()
    val hasExt by vm.pod.hasExtendedSensors.collectAsStateWithLifecycle()
    val ext by vm.pod.latestExt.collectAsStateWithLifecycle()
    val extWindow by vm.pod.extWindow.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val show = settings.showRanges
    val asleep = vit.sleepState == SleepState.LIGHT || vit.sleepState == SleepState.DEEP
    val showRoom = caps.roomClimate && HwAdapter.hasAmbient(vit.ambTempX100)

    when (def.id) {
        "live_hr" -> LiveHeartRateCard(vit, lastHr, caps, show, asleep, settings.demoMode)
        "live_moisture" -> when {
            caps.directAbsHumidity -> LiveMoistureCard(vit)
            // Demo / paper-spec pods: sweat moisture from skin vs room (same card as Live).
            showRoom -> LiveSweatCard(vit, show)
            else -> SectionPlaceholderCard(def, stringResource(R.string.cp_no_moisture))
        }
        "live_skin_temp" -> LiveTrailCard(
            def, Fmt.temp(vit.skinTempC, settings), "", Aurora.SeriesSkin,
            level = if (show) Ranges.skinTemp.levelOf(vit.skinTempC) else null,
            trail = window.map { settings.toDisplayTemp(it.skinTempC) },
        )
        "live_skin_rh" -> LiveTrailCard(
            def, "%.0f".format(vit.skinRh), "%", Aurora.SeriesSkin,
            level = if (show) Ranges.skinRh.levelOf(vit.skinRh) else null,
            trail = window.map { it.skinRh },
        )
        "live_spo2" -> if (caps.spo2Estimate) LiveSpo2Card(ext?.spo2Pct) else SectionPlaceholderCard(def, stringResource(R.string.cp_no_spo2))
        "live_quality" -> LiveTrailCard(
            def, "${vit.hrQuality}", stringResource(R.string.cp_of_100), MaterialTheme.colorScheme.primary,
            note = stringResource(
                when (QualityBand.of(vit.hrQuality)) {
                    QualityBand.HIDE -> R.string.cp_quality_too_low
                    QualityBand.LOW_CONFIDENCE -> R.string.cp_quality_low
                    QualityBand.NORMAL -> R.string.cp_quality_good
                }
            ),
            trail = window.map { it.hrQuality.toFloat() },
        )
        "live_status" -> LiveStatusCard(def, vit, synced, hardware = caps.directAbsHumidity)
        "live_chart" -> if (window.size > 2) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) { LiveCharts(window, settings, caps, show, asleep, showRoom) }
        } else SectionPlaceholderCard(def, stringResource(R.string.cp_chart_collecting))
        "live_hrv" -> hrv?.let { LiveHrvCard(it, caps, show) } ?: SectionPlaceholderCard(def, stringResource(R.string.cp_hrv_waiting))
        "live_conductance" -> if (hasExt) LiveConductanceCard(ext, extWindow, show) else SectionPlaceholderCard(def, stringResource(R.string.cp_no_conductance))
        else -> Unit
    }
}

/** A value now (+ level / note) and its recent trace — skin temperature, skin humidity, quality. */
@Composable
private fun LiveTrailCard(
    def: SectionDef, value: String, unit: String, accent: androidx.compose.ui.graphics.Color,
    level: com.aurora.msg.domain.Level? = null, note: String? = null, trail: List<Float>,
) {
    AuroraCard {
        SectionTitleRow(def)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(stringResource(R.string.cp_now), value, unit, Modifier.weight(1f), accent = accent, note = note, level = level)
        }
        if (trail.size > 2) {
            Spacer(Modifier.height(10.dp))
            Sparkline(trail, accent, Modifier.fillMaxWidth().height(48.dp))
        }
    }
}

/** Pod flags as on/off chips: finger, HR lock, session, clock, flush/sweat, low battery. */
@Composable
private fun LiveStatusCard(def: SectionDef, vit: LiveVitals, synced: Boolean, hardware: Boolean) {
    val chips = listOf(
        stringResource(R.string.cp_status_finger) to vit.ppgActive,
        stringResource(R.string.cp_status_hr_lock) to vit.hasHr,
        stringResource(R.string.cp_status_session) to vit.logging,
        stringResource(R.string.cp_status_clock) to synced,
        stringResource(if (hardware) R.string.cp_status_flush else R.string.cp_status_sweat) to (vit.sweatFlag != SweatFlag.NONE),
        stringResource(R.string.cp_status_low_batt) to vit.lowBatt,
    )
    val on = stringResource(R.string.cp_on)
    val off = stringResource(R.string.cp_off)
    AuroraCard {
        SectionTitleRow(def)
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            chips.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pair.forEach { (text, active) -> StatusChip(text, active, if (active) on else off, Modifier.weight(1f)) }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun StatusChip(text: String, on: Boolean, stateLabel: String, modifier: Modifier = Modifier) {
    val fg = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    val bg = if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceContainer
    Row(
        modifier.clip(RoundedCornerShape(12.dp)).background(bg).padding(horizontal = 10.dp, vertical = 8.dp)
            .clearAndSetSemantics { contentDescription = "$text, $stateLabel" },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (on) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null, tint = fg, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, color = fg, maxLines = 2)
    }
}

// ====================================================================== Nights

@Composable
private fun NightSection(def: SectionDef, vm: AppViewModel, actions: SectionActions) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    if (def.id == "recent_nights") {
        val cards by vm.nightCards.collectAsStateWithLifecycle()
        if (cards.isEmpty()) {
            SectionPlaceholderCard(def, stringResource(R.string.cp_no_nights), stringResource(R.string.home_try_demo), actions.openDemo)
        } else Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SectionHeader(stringResource(R.string.home_recent_nights), stringResource(R.string.home_recent_nights_sub))
            cards.take(6).forEach { c -> NightRow(c, settings, actions.openNight) }
        }
        return
    }
    val latest by vm.latestNight.collectAsStateWithLifecycle()
    val night = latest
    if (night == null) {
        SectionPlaceholderCard(def, stringResource(R.string.cp_no_night_yet), stringResource(R.string.home_try_demo), actions.openDemo)
        return
    }
    when (def.id) {
        "last_night" -> LastNightHero(night, rememberReveal(night.session.id), actions.openNight, actions.openVitalSheet)
        "morning_card" -> MorningCard(night, settings, rememberReveal(night.session.id), settings.showRanges)
        "night_timeline" -> NightTimelineSection(def, vm, night, settings, actions)
        "vital_sheet" -> VitalSheetPreview(vm, night, onOpen = { actions.openVitalSheet(night.session.id) }) {
            SectionPlaceholderCard(def, stringResource(R.string.vs_no_data_body))
        }
        "sweat_events" -> if (night.sweat.isEmpty()) {
            SectionPlaceholderCard(def, stringResource(R.string.cp_no_sweat_events))
        } else {
            val start = night.session.startedAtEpochMs
            val xFormat: (Float) -> String = { t -> Fmt.clock(start + (t * 1000).toLong(), settings) }
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                NightSweatEventsHeader(night, isHardwareNight(night.epochs))
                NightSweatEventsCard(night, xFormat)
            }
        }
        else -> Unit
    }
}

/** The latest night's stacked charts with flash-bundle shading (NightDetail's chart card). */
@Composable
private fun NightTimelineSection(def: SectionDef, vm: AppViewModel, night: NightBundle, settings: AppSettings, actions: SectionActions) {
    if (night.epochs.isEmpty()) {
        SectionPlaceholderCard(def, stringResource(R.string.night_no_detail_offline))
        return
    }
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val records = remember(night.epochs) { with(vm.sessions) { night.epochs.map { it.toRecord() } } }
    val bundles = remember(records) { NightAnalytics.detectBundles(records) }
    var scrub by remember(night.session.id) { mutableStateOf<Float?>(null) }
    val reveal = rememberReveal(night.session.id)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { actions.openNight(night.session.id) }.padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(Fmt.nightLabel(night.session.startedAtEpochMs), style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            Text(stringResource(R.string.cp_open_night), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.primary)
        }
        NightChartsCard(night, records, bundles, settings, caps, reveal, scrub) { scrub = it }
    }
}

// ====================================================================== Trends

/** Trend sections share ONE remembered range (chosen in "Trend tiles"), like the iPhone app. */
@Composable
private fun TrendSection(def: SectionDef, vm: AppViewModel, actions: SectionActions) {
    val cards by vm.nightCards.collectAsStateWithLifecycle()
    val rangeDays by vm.customTrendsRangeDays.collectAsStateWithLifecycle()
    val series = TrendSeries(cards, rangeDays)
    val reveal = rememberReveal(rangeDays to series.inRange.size)
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (def.id == "trends_overview") TrendRangeChips(rangeDays) { vm.setCustomTrendsRangeDays(it) }
        if (series.inRange.size < 2) {
            SectionPlaceholderCard(def, stringResource(R.string.trends_empty_body), stringResource(R.string.trends_open_demo), actions.openDemo)
        } else when (def.id) {
            "trends_overview" -> { TrendTilesTop(series); TrendTilesBottom(series) }
            "trends_flashes" -> TrendFlashesCard(series, reveal)
            "trends_hr" -> TrendRestingHrCard(series, reveal)
            "trends_time_in_bed" -> TrendTimeInBedCard(series, reveal)
            // Hidden automatically when no night in range has sleep staging (real glove).
            "trends_sleep" -> if (series.anySleep) TrendSleepCard(series, reveal) else SectionPlaceholderCard(def, stringResource(R.string.cp_trends_no_sleep))
            else -> Unit
        }
    }
}

// ====================================================================== Pod

@Composable
private fun PodSection(def: SectionDef, vm: AppViewModel, actions: SectionActions) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val info by vm.pod.deviceInfo.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    // Same rule as the Pod screen: the real glove, never while in demo mode.
    val hwPod = !settings.demoMode && isHardwarePod(caps, info)
    when (def.id) {
        "pod_connection" -> {
            val scan by vm.pod.scanResults.collectAsStateWithLifecycle()
            val synced by vm.pod.timeSynced.collectAsStateWithLifecycle()
            val scanAction = rememberPodScanAction(vm, settings.demoMode)
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                if (hwPod) PodSecurityNote()
                PodConnectionCard(vm, conn, scan, synced, scanAction)
            }
        }
        "pod_info" -> if (conn.isConnected) {
            val battery by vm.pod.batteryPct.collectAsStateWithLifecycle()
            PodDeviceCard(info, battery, hwPod)
        } else SectionPlaceholderCard(def, stringResource(R.string.cp_pod_info_not_connected), stringResource(R.string.common_connect), actions.openPod)
        "pod_log" -> {
            val replay by vm.pod.replayStatus.collectAsStateWithLifecycle()
            val active by vm.pod.activeSession.collectAsStateWithLifecycle()
            val cards by vm.nightCards.collectAsStateWithLifecycle()
            val slotsFlow = remember { vm.sessions.observeSlots() }
            val slots by slotsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                if (replay.isActive) PodReplayProgressCard(vm, replay, hwPod)
                if (hwPod) {
                    PodHwLogCard(vm, cards, conn, active, replay)
                } else if (slots.isEmpty()) {
                    PodNoNightsCard()
                } else {
                    slots.forEach { s -> PodSlotRow(vm, s, cards, conn, replay, actions.openNight) }
                }
            }
        }
        "pod_controls" -> Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            PodMaintenanceCard(vm, hwPod, conn.isConnected)
            if (hwPod) PodLogIntervalCard(vm)
        }
        "demo_controls" -> AuroraCard { DemoControlsContent(vm, onLeave = {}) }
        else -> Unit
    }
}

/** Real glove only: the pod's log interval (opcode 0x06, PROTOCOL §6). The pod does not confirm it. */
@Composable
private fun PodLogIntervalCard(vm: AppViewModel) {
    var seconds by remember { mutableIntStateOf(HardwareCheckRunner.DEFAULT_LOG_INTERVAL_S) }
    var sentSeconds by remember { mutableStateOf<Int?>(null) }
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val canSet = conn.isConnected && caps == com.aurora.msg.protocol.PodCapabilities.HARDWARE_V1 && !vm.pod.isDemo
    AuroraCard {
        Text(stringResource(R.string.cp_log_interval_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.cp_log_interval_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 10, 30, 60, 120, 240).forEach { s ->
                FilterChip(
                    selected = seconds == s, onClick = { seconds = s }, label = { Text(stringResource(R.string.cp_seconds, s)) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primary, selectedLabelColor = MaterialTheme.colorScheme.onPrimary),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { val s = seconds; vm.setLogInterval(s) { ok -> if (ok) sentSeconds = s } },
            enabled = canSet, shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        ) { Text(stringResource(R.string.cp_log_interval_set)) }
        sentSeconds?.let {
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.cp_log_interval_sent, it), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ====================================================================== Diagnostics

@Composable
private fun DiagnosticsSection(def: SectionDef, vm: AppViewModel) {
    when (def.id) {
        "link_health" -> LinkHealthCard(def, vm)
        "packet_inspector" -> PacketInspectorCard(def, vm)
        "hardware_check" -> HardwareCheckCard(def, vm)
        else -> Unit
    }
}

/** Packets, CRC failures, dropped notifications (sequence gaps) and the FE01 rate. */
@Composable
private fun LinkHealthCard(def: SectionDef, vm: AppViewModel) {
    val st by vm.pod.linkStats.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val isDemo = settings.demoMode
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { delay(1_000); now = System.currentTimeMillis() }
    }
    AuroraCard {
        SectionTitleRow(def, trailing = if (isDemo) stringResource(R.string.common_demo) else null)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(if (isDemo) R.string.cp_link_demo_note else R.string.cp_link_hw_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(stringResource(R.string.cp_link_packets), "${st.packets}", modifier = Modifier.weight(1f), accent = MaterialTheme.colorScheme.primary)
            val rate = st.rateHz
            StatTile(stringResource(R.string.cp_link_rate), rate?.let { "%.2f".format(it) } ?: "—", if (rate != null) stringResource(R.string.cp_hz) else "", Modifier.weight(1f), accent = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(stringResource(R.string.cp_link_crc), "${st.crcFailures}", modifier = Modifier.weight(1f), accent = if (st.crcFailures > 0) Aurora.Bad else Aurora.Good)
            StatTile(stringResource(R.string.cp_link_gaps), "${st.seqGaps}", modifier = Modifier.weight(1f), accent = if (st.seqGaps > 0) Aurora.Bad else Aurora.Good)
        }
        Spacer(Modifier.height(8.dp))
        Text(lastPacketText(st, conn.isConnected, now), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun lastPacketText(st: LinkStats, connected: Boolean, now: Long): String {
    if (!connected) {
        return stringResource(if (st.packets > 0 || st.crcFailures > 0) R.string.cp_link_disconnected_last else R.string.cp_link_not_connected)
    }
    val last = st.lastPacketAtMs ?: return stringResource(R.string.cp_link_no_packets)
    val ago = ((now - last) / 1000).toInt().coerceAtLeast(0)
    return if (ago > 4) stringResource(R.string.cp_link_stalled, ago) else stringResource(R.string.cp_link_last_packet, ago)
}

/** The last ~50 raw packets, newest first; Pause freezes the list so it can be read. */
@Composable
private fun PacketInspectorCard(def: SectionDef, vm: AppViewModel) {
    val live by vm.pod.rawPackets.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var paused by remember { mutableStateOf(false) }
    var frozen by remember { mutableStateOf<List<RawPacket>>(emptyList()) }
    val list = (if (paused) frozen else live).asReversed()
    AuroraCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f)) { SectionTitleRow(def) }
            OutlinedButton(onClick = { if (!paused) frozen = live; paused = !paused }, shape = CircleShape) {
                Text(stringResource(if (paused) R.string.cp_pi_resume else R.string.cp_pi_pause))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.cp_pi_body, LinkRecorder.RING_CAPACITY), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        if (list.isEmpty()) {
            Text(stringResource(R.string.cp_pi_empty), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Column(Modifier.fillMaxWidth().heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                list.forEach { p -> PacketRow(p, settings) }
            }
        }
    }
}

@Composable
private fun PacketRow(p: RawPacket, settings: AppSettings) {
    val decoded = describePacket(p.decoded, settings)
    val okLabel = stringResource(if (p.ok) R.string.cp_pi_ok else R.string.cp_pi_bad)
    val time = remember(p.timeMs, settings.use24h) {
        SimpleDateFormat(if (settings.use24h) "HH:mm:ss" else "h:mm:ss a", Locale.getDefault()).format(Date(p.timeMs))
    }
    Column(Modifier.fillMaxWidth().clearAndSetSemantics { contentDescription = "${p.characteristic}, $okLabel, $decoded" }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(time, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(6.dp))
            Text(p.characteristic, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
            Icon(if (p.ok) Icons.Rounded.CheckCircle else Icons.Rounded.Cancel, null, tint = if (p.ok) Aurora.Good else Aurora.Bad, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text(decoded, style = MaterialTheme.typography.labelMedium, maxLines = 2)
        }
        Text(p.hex, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
    }
}

@Composable
private fun describePacket(kind: RawPacketKind, settings: AppSettings): String = when (kind) {
    is RawPacketKind.Vitals -> {
        val parts = ArrayList<String>()
        kind.seq?.let { parts.add(stringResource(R.string.cp_pi_seq, it)) }
        parts.add(kind.hrBpm?.let { stringResource(R.string.cp_pi_hr, "%.1f".format(it)) } ?: stringResource(R.string.cp_pi_hr_none))
        kind.absHumX100?.let { parts.add(stringResource(R.string.cp_pi_ah, "%.2f".format(it / 100f))) }
        kind.skinTempX100?.let { parts.add(stringResource(R.string.cp_pi_skin, Fmt.temp(it / 100f, settings))) }
        parts.joinToString(" · ")
    }
    is RawPacketKind.Hrv -> stringResource(R.string.cp_pi_hrv, "%.1f".format(kind.rmssdX10 / 10f), kind.beats)
    is RawPacketKind.Summary -> stringResource(R.string.cp_pi_summary, Fmt.durationShort(kind.durationS))
    is RawPacketKind.Replay -> stringResource(R.string.cp_pi_replay, kind.seq)
    is RawPacketKind.Invalid -> stringResource(R.string.cp_pi_invalid, kind.reason)
}

/** One-button hardware check ([HardwareCheckRunner], owned by the manager). */
@Composable
private fun HardwareCheckCard(def: SectionDef, vm: AppViewModel) {
    val check = vm.pod.hardwareCheck
    val phase by check.phase.collectAsStateWithLifecycle()
    val steps by check.steps.collectAsStateWithLifecycle()
    val refusal by check.refusal.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val active by vm.pod.activeSession.collectAsStateWithLifecycle()
    val replay by vm.pod.replayStatus.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val running = phase is HardwareCheckRunner.Phase.Running
    // Explain up front why it would refuse (same rules as HardwareCheckRunner.refusalReason()).
    val why: CheckText? = when {
        running -> null
        !conn.isConnected -> CheckText(R.string.hc_refuse_not_connected)
        active != null -> CheckText(R.string.hc_refuse_recording)
        replay.isActive -> CheckText(R.string.hc_refuse_downloading)
        else -> null
    }
    val hardwareLink = conn.isConnected && caps == com.aurora.msg.protocol.PodCapabilities.HARDWARE_V1 && !vm.pod.isDemo
    AuroraCard {
        SectionTitleRow(def)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.hc_body, HardwareCheckRunner.STREAM_SECONDS), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.hc_test_night_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (hardwareLink && !running) {
            // The pod keeps ONE session's log: the test session replaces it.
            Spacer(Modifier.height(8.dp))
            InfoBanner(stringResource(R.string.hc_log_warning), tone = BannerTone.Warning)
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { vm.runHardwareCheck() },
            enabled = !running && why == null,
            shape = CircleShape, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        ) {
            if (running) {
                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                Spacer(Modifier.width(8.dp))
            }
            Text(stringResource(if (running) R.string.hc_running else R.string.hc_run))
        }
        (why ?: refusal)?.let { reason ->
            Spacer(Modifier.height(8.dp))
            InfoBanner(resolve(reason), tone = if (active != null) BannerTone.Warning else BannerTone.Info)
        }
        (phase as? HardwareCheckRunner.Phase.Running)?.let {
            Spacer(Modifier.height(10.dp))
            Text(resolve(it.status), style = MaterialTheme.typography.labelLarge)
        }
        if (steps.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            steps.forEach { step -> CheckStepRow(step) }
        }
        (phase as? HardwareCheckRunner.Phase.Finished)?.let { f ->
            Spacer(Modifier.height(10.dp))
            InfoBanner(
                checkSummaryText(f.passed, f.failed, f.skipped),
                tone = if (f.failed > 0) BannerTone.Error else if (f.passed > 0) BannerTone.Success else BannerTone.Warning,
            )
        }
    }
}

@Composable
private fun CheckStepRow(step: HardwareCheckStep) {
    val (icon, color, label) = when (step.status) {
        HardwareCheckStep.Status.PASS -> Triple(Icons.Rounded.CheckCircle, Aurora.Good, R.string.hc_pass)
        HardwareCheckStep.Status.FAIL -> Triple(Icons.Rounded.Cancel, Aurora.Bad, R.string.hc_fail)
        HardwareCheckStep.Status.SKIPPED -> Triple(Icons.Rounded.RemoveCircleOutline, MaterialTheme.colorScheme.onSurfaceVariant, R.string.hc_skipped)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(resolve(step.title), style = MaterialTheme.typography.titleSmall)
            step.detail?.let { Text(resolve(it), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Spacer(Modifier.width(8.dp))
        Text(stringResource(label), style = MaterialTheme.typography.labelMedium, color = color)
    }
}

/** Resolves a hardware-check line: raw text, or a string resource with its (duration-aware) args. */
@Composable
private fun resolve(t: CheckText): String {
    t.raw?.let { return it }
    if (t.args.isEmpty()) return stringResource(t.res)
    val args = t.args.map { a -> if (a is DurationArg) Fmt.durationShort(a.seconds) else a }
    return stringResource(t.res, *args.toTypedArray())
}

@Composable
private fun checkSummaryText(passed: Int, failed: Int, skipped: Int): String {
    var t = when {
        failed > 0 -> stringResource(if (failed == 1) R.string.hc_summary_failed_one else R.string.hc_summary_failed_other, failed) + " " +
            stringResource(if (passed == 1) R.string.hc_summary_passed_one else R.string.hc_summary_passed_other, passed)
        passed > 0 -> stringResource(if (passed == 1) R.string.hc_summary_all_passed_one else R.string.hc_summary_all_passed_other, passed)
        else -> stringResource(R.string.hc_summary_nothing_ran)
    }
    if (skipped > 0) t += " " + stringResource(if (skipped == 1) R.string.hc_summary_skipped_one else R.string.hc_summary_skipped_other, skipped)
    return t
}
