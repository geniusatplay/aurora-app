package com.aurora.msg.ui.charts

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/* ------------------------------------------------------------------ shared scales */

/** Shared x-domain in seconds and a y-domain, mapped into a plot rect. */
class PlotScale(val plot: Rect, val x0: Float, val x1: Float, val y0: Float, val y1: Float) {
    fun x(v: Float): Float = plot.left + (v - x0) / max(1e-6f, (x1 - x0)) * plot.width
    fun y(v: Float): Float = plot.bottom - (v - y0) / max(1e-6f, (y1 - y0)) * plot.height
    fun xInv(px: Float): Float = x0 + ((px - plot.left) / max(1e-6f, plot.width)).coerceIn(0f, 1f) * (x1 - x0)
}

/** "Nice" tick step for a numeric range. */
fun niceStep(range: Float, targetTicks: Int = 4): Float {
    if (range <= 0f) return 1f
    val raw = range / targetTicks
    val mag = Math.pow(10.0, floor(Math.log10(raw.toDouble()))).toFloat()
    val n = raw / mag
    val step = when {
        n < 1.5f -> 1f
        n < 3f -> 2f
        n < 7f -> 5f
        else -> 10f
    }
    return step * mag
}

fun niceBounds(lo: Float, hi: Float, targetTicks: Int = 4, padFrac: Float = 0.08f): Pair<Float, Float> {
    if (hi - lo < 1e-4f) return Pair(lo - 1f, hi + 1f)
    val pad = (hi - lo) * padFrac
    val step = niceStep(hi - lo + 2 * pad, targetTicks)
    return Pair(floor((lo - pad) / step) * step, ceil((hi + pad) / step) * step)
}

fun fmtNum(v: Float, decimals: Int): String = "%.${decimals}f".format(v)

/** Hours:minutes label for seconds since start. */
fun fmtHm(seconds: Float): String {
    val s = seconds.toInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 3600, (s % 3600) / 60)
}

/* ------------------------------------------------------------------ drawing helpers */

/** Catmull-Rom → cubic Bézier smooth path through points. */
fun smoothPath(points: List<Offset>, tension: Float = 0.5f): Path {
    val p = Path()
    if (points.isEmpty()) return p
    p.moveTo(points[0].x, points[0].y)
    if (points.size == 1) return p
    for (i in 0 until points.size - 1) {
        val p0 = points[max(0, i - 1)]
        val p1 = points[i]
        val p2 = points[i + 1]
        val p3 = points[min(points.size - 1, i + 2)]
        val c1 = Offset(p1.x + (p2.x - p0.x) * tension / 3f, p1.y + (p2.y - p0.y) * tension / 3f)
        val c2 = Offset(p2.x - (p3.x - p1.x) * tension / 3f, p2.y - (p3.y - p1.y) * tension / 3f)
        p.cubicTo(c1.x, c1.y, c2.x, c2.y, p2.x, p2.y)
    }
    return p
}

fun DrawScope.drawGrid(scale: PlotScale, gridColor: Color, yStep: Float) {
    var v = scale.y0
    while (v <= scale.y1 + 1e-3f) {
        val y = scale.y(v)
        drawLine(gridColor, Offset(scale.plot.left, y), Offset(scale.plot.right, y), strokeWidth = 1.dp.toPx())
        v += yStep
    }
}

fun DrawScope.drawYLabels(scale: PlotScale, tm: TextMeasurer, style: TextStyle, yStep: Float, format: (Float) -> String) {
    var v = scale.y0
    while (v <= scale.y1 + 1e-3f) {
        val label = format(v)
        val size = tm.measure(label, style).size
        val y = scale.y(v) - size.height / 2f
        drawText(tm, label, Offset(scale.plot.left - size.width - 6.dp.toPx(), y.coerceIn(0f, this.size.height - size.height)), style)
        v += yStep
    }
}

fun DrawScope.drawXLabels(scale: PlotScale, tm: TextMeasurer, style: TextStyle, stepS: Float, format: (Float) -> String) {
    var v = ceil(scale.x0 / stepS) * stepS
    while (v <= scale.x1 + 1e-3f) {
        val label = format(v)
        val size = tm.measure(label, style).size
        val x = (scale.x(v) - size.width / 2f).coerceIn(0f, this.size.width - size.width)
        drawText(tm, label, Offset(x, scale.plot.bottom + 6.dp.toPx()), style)
        drawLine(style.color.copy(alpha = 0.35f), Offset(scale.x(v), scale.plot.bottom), Offset(scale.x(v), scale.plot.bottom + 3.dp.toPx()), 1.dp.toPx())
        v += stepS
    }
}

/**
 * Low / Medium / High reference zones: three faint horizontal tints separated by dashed
 * lines, labelled at the right edge. `guide` values are in the chart's y units.
 */
fun DrawScope.drawRangeGuides(
    scale: PlotScale, tm: TextMeasurer, lowMax: Float, highMin: Float,
    lowLabel: String, midLabel: String, highLabel: String,
    lowColor: Color, midColor: Color, highColor: Color, textColor: Color,
) {
    val yLow = scale.y(lowMax).coerceIn(scale.plot.top, scale.plot.bottom)
    val yHigh = scale.y(highMin).coerceIn(scale.plot.top, scale.plot.bottom)
    // zones
    drawRect(highColor.copy(alpha = 0.10f), Offset(scale.plot.left, scale.plot.top), Size(scale.plot.width, (yHigh - scale.plot.top).coerceAtLeast(0f)))
    drawRect(midColor.copy(alpha = 0.07f), Offset(scale.plot.left, yHigh), Size(scale.plot.width, (yLow - yHigh).coerceAtLeast(0f)))
    drawRect(lowColor.copy(alpha = 0.10f), Offset(scale.plot.left, yLow), Size(scale.plot.width, (scale.plot.bottom - yLow).coerceAtLeast(0f)))
    val dash = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx()))
    listOf(yLow, yHigh).forEach { y ->
        if (y > scale.plot.top + 1f && y < scale.plot.bottom - 1f)
            drawLine(textColor.copy(alpha = 0.45f), Offset(scale.plot.left, y), Offset(scale.plot.right, y), strokeWidth = 1.dp.toPx(), pathEffect = dash)
    }
    val style = TextStyle(color = textColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    fun label(text: String, top: Float, bottom: Float) {
        if (bottom - top < 12.dp.toPx()) return
        val m = tm.measure(text, style)
        drawText(tm, text, Offset(scale.plot.right - m.size.width - 4.dp.toPx(), top + 3.dp.toPx()), style)
    }
    label(highLabel, scale.plot.top, yHigh)
    label(midLabel, yHigh, yLow)
    label(lowLabel, yLow, scale.plot.bottom)
}

/** Shaded vertical bands (sweat events). */
fun DrawScope.drawBands(scale: PlotScale, bands: List<Pair<Float, Float>>, color: Color) {
    for ((a, b) in bands) {
        val x0 = scale.x(a).coerceIn(scale.plot.left, scale.plot.right)
        val x1 = scale.x(b).coerceIn(scale.plot.left, scale.plot.right)
        if (x1 - x0 < 1f) continue
        drawRoundRect(color, Offset(x0, scale.plot.top), Size(x1 - x0, scale.plot.height), CornerRadius(3.dp.toPx()))
    }
}

/** Vertical marker pins with a short label (activity events). */
fun DrawScope.drawMarkers(scale: PlotScale, markers: List<Pair<Float, Color>>, dashColor: Color) {
    for ((t, c) in markers) {
        val x = scale.x(t)
        if (x < scale.plot.left || x > scale.plot.right) continue
        drawLine(c.copy(alpha = 0.55f), Offset(x, scale.plot.top), Offset(x, scale.plot.bottom), strokeWidth = 1.5f.dp.toPx())
        drawCircle(c, radius = 3.5f.dp.toPx(), center = Offset(x, scale.plot.top + 4.dp.toPx()))
        drawCircle(dashColor, radius = 1.5f.dp.toPx(), center = Offset(x, scale.plot.top + 4.dp.toPx()))
    }
}

fun DrawScope.drawCrosshair(scale: PlotScale, xSeconds: Float?, color: Color) {
    val t = xSeconds ?: return
    val x = scale.x(t)
    if (x < scale.plot.left || x > scale.plot.right) return
    drawLine(color, Offset(x, scale.plot.top), Offset(x, scale.plot.bottom), strokeWidth = 1.dp.toPx())
}

/** Tooltip chip anchored to a point, kept inside the canvas. */
fun DrawScope.drawTooltip(tm: TextMeasurer, text: String, anchor: Offset, bg: Color, fg: Color) {
    val style = TextStyle(color = fg, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    val m = tm.measure(text, style)
    val padX = 8.dp.toPx(); val padY = 5.dp.toPx()
    val w = m.size.width + padX * 2; val h = m.size.height + padY * 2
    var x = anchor.x + 10.dp.toPx()
    if (x + w > size.width) x = anchor.x - w - 10.dp.toPx()
    val y = (anchor.y - h - 6.dp.toPx()).coerceIn(0f, size.height - h)
    drawRoundRect(bg, Offset(x, y), Size(w, h), CornerRadius(8.dp.toPx()))
    drawText(tm, text, Offset(x + padX, y + padY), style)
}

/* ------------------------------------------------------------------ interaction */

/**
 * Wraps a chart stack; tracks a scrub position in seconds shared by all child panels.
 * Tap or drag anywhere on the chart to scrub; tap again on the same spot to clear.
 */
@Composable
fun ScrubBox(
    modifier: Modifier = Modifier,
    x0: Float, x1: Float, leftInset: Dp, rightInset: Dp,
    scrub: Float?, onScrub: (Float?) -> Unit,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .fillMaxWidth()
            .pointerInput(x0, x1) {
                val l = leftInset.toPx(); val r = rightInset.toPx()
                fun toSeconds(px: Float): Float {
                    val w = size.width - l - r
                    return x0 + ((px - l) / max(1f, w)).coerceIn(0f, 1f) * (x1 - x0)
                }
                detectDragGestures(
                    onDragStart = { onScrub(toSeconds(it.x)) },
                    onDrag = { change, _ -> change.consume(); onScrub(toSeconds(change.position.x)) },
                )
            }
            .pointerInput(x0, x1, scrub) {
                val l = leftInset.toPx(); val r = rightInset.toPx()
                detectTapGestures { pos ->
                    val w = size.width - l - r
                    val s = x0 + ((pos.x - l) / max(1f, w)).coerceIn(0f, 1f) * (x1 - x0)
                    if (scrub != null && abs(scrub - s) < (x1 - x0) * 0.01f) onScrub(null) else onScrub(s)
                }
            }
    ) { content() }
}

/** Progress 0→1 that animates in once per key. */
@Composable
fun rememberReveal(key: Any?): Float {
    val anim = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { anim.snapTo(0f); anim.animateTo(1f, tween(700)) }
    return anim.value
}

/* ------------------------------------------------------------------ chart chrome */

val ChartLeftInset = 44.dp
val ChartRightInset = 12.dp
val ChartTopInset = 8.dp
val ChartBottomInset = 22.dp

@Composable
fun axisStyle(color: Color) = remember(color) { TextStyle(color = color, fontSize = 10.sp) }

/** Panel skeleton so all panels align; caller draws inside using the given scale. */
@Composable
fun ChartPanel(
    height: Dp,
    x0: Float, x1: Float, y0: Float, y1: Float,
    showXAxis: Boolean,
    gridColor: Color, axisText: Color,
    yStep: Float, yFormat: (Float) -> String,
    xStepS: Float, xFormat: (Float) -> String,
    draw: DrawScope.(PlotScale, TextMeasurer) -> Unit,
) {
    val tm = rememberTextMeasurer()
    val style = axisStyle(axisText)
    Canvas(Modifier.fillMaxWidth().height(height)) {
        val plot = Rect(
            left = ChartLeftInset.toPx(), top = ChartTopInset.toPx(),
            right = size.width - ChartRightInset.toPx(),
            bottom = size.height - (if (showXAxis) ChartBottomInset.toPx() else 6.dp.toPx()),
        )
        val scale = PlotScale(plot, x0, x1, y0, y1)
        drawGrid(scale, gridColor, yStep)
        drawYLabels(scale, tm, style, yStep, yFormat)
        if (showXAxis) drawXLabels(scale, tm, style, xStepS, xFormat)
        draw(scale, tm)
    }
}

/** Standard stroke for line series (2 dp, round). */
fun DrawScope.seriesStroke(): Stroke = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)

fun areaBrush(color: Color, top: Float, bottom: Float): Brush =
    Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), color.copy(alpha = 0.02f)), startY = top, endY = bottom)
