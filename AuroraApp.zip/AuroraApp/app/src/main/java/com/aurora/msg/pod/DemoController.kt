package com.aurora.msg.pod

import com.aurora.msg.data.db.ActivityKind
import com.aurora.msg.data.repo.SessionRepository
import com.aurora.msg.data.repo.SettingsRepository
import com.aurora.msg.protocol.Cadence
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * The "Demo" button's brain. Switches the manager to the simulated pod, connects, starts a
 * session and lets the user pick activity modes; can also seed 14 nights of history.
 */
class DemoController(
    private val pod: PodConnectionManager,
    private val repo: SessionRepository,
    private val settings: SettingsRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _busy = MutableStateFlow<String?>(null)
    /** Non-null while a long demo action runs (e.g. "Generating 14 nights…"). */
    val busy: StateFlow<String?> = _busy.asStateFlow()

    val mode: StateFlow<DemoMode> get() = pod.demo.mode
    val speed: StateFlow<Int> get() = pod.demo.speed

    /** Enter demo mode: simulated pod, connected, ready. */
    fun enable() = scope.launch {
        settings.setDemoMode(true)
        pod.useDemo(true)
        pod.connect(DemoPodSource.DEMO_ADDRESS)
    }

    fun disable() = scope.launch {
        settings.setDemoMode(false)
        pod.useDemo(false)
    }

    /** Start a demo night: connect if needed, then START (goes through the real command path). */
    fun startDemoNight(initialMode: DemoMode = DemoMode.SLEEPING) = scope.launch {
        if (!pod.isDemo) { settings.setDemoMode(true); pod.useDemo(true) }
        if (!pod.connectionState.value.isConnected) {
            pod.connect(DemoPodSource.DEMO_ADDRESS)
            pod.connectionState.first { it.isConnected }
        }
        pod.demo.setMode(initialMode)
        pod.startSession()
    }

    fun setMode(mode: DemoMode) = pod.demo.setMode(mode)
    fun setSpeed(speed: Int) = pod.demo.setSpeed(speed)

    /** Stop → FE02 → morning card, exactly like the real pod. */
    fun stopDemoNight() = scope.launch { pod.stopSession() }

    /** Seed 14 realistic nights so Trends and the home hero have something to show. */
    fun seedHistory(nights: Int = Cadence.NIGHT_SLOTS) = scope.launch {
        val uid = settings.settings.first().userId ?: return@launch
        _busy.value = "Generating $nights nights…"
        try {
            val history = DemoHistory.generateHistory(System.currentTimeMillis(), nights)
            history.forEachIndexed { i, night ->
                _busy.value = "Generating night ${i + 1} of $nights…"
                val events = night.events.map { (t, m) -> t to m.toKind() }
                repo.insertGeneratedNight(uid, night.startedAtEpochMs, night.records, events, slot = i % Cadence.NIGHT_SLOTS)
                pod.demo.installSlot(i % Cadence.NIGHT_SLOTS, night.records)
            }
        } finally {
            _busy.value = null
        }
    }

    private fun DemoMode.toKind() = when (this) {
        DemoMode.UP -> ActivityKind.UP
        DemoMode.LIGHT_EXERCISE -> ActivityKind.LIGHT_EXERCISE
        DemoMode.HEAVY_EXERCISE -> ActivityKind.HEAVY_EXERCISE
        DemoMode.SLEEPING -> ActivityKind.SLEEPING
        DemoMode.NIGHT_FLASH -> ActivityKind.NIGHT_FLASH
        DemoMode.NIGHT_SWEATS -> ActivityKind.NIGHT_SWEATS
    }
}
