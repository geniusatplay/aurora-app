package com.aurora.msg.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Control commands written to FE03 (spec §6).
 * Fire-and-forget: there is NO ack. Confirm each by observing FE01 / FE02.
 */
sealed class PodCommand(val opcode: Int) {
    abstract fun encode(): ByteArray

    /** 0x01 — ignored unless idle. Confirm via FLAG_LOGGING. */
    data object StartSession : PodCommand(0x01) {
        override fun encode() = byteArrayOf(0x01)
    }

    /** 0x02 — ignored unless running. Triggers FE02. */
    data object StopSession : PodCommand(0x02) {
        override fun encode() = byteArrayOf(0x02)
    }

    /** 0x03 — SEND FIRST, ALWAYS (spec §8.1). */
    data class TimeSync(val unixSeconds: Long) : PodCommand(0x03) {
        override fun encode(): ByteArray =
            ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN)
                .put(0x03).putInt(unixSeconds.toInt()).array()
    }

    /** 0x04 — buzz; motor is DNP on the standard build so this may do nothing. */
    data class HapticTest(val millis: Int? = null) : PodCommand(0x04) {
        override fun encode(): ByteArray =
            if (millis == null) byteArrayOf(0x04)
            else ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN)
                .put(0x04).putShort(millis.toShort()).array()
    }

    /** 0x05 — MAX17048 QuickStart. Only after a battery swap. */
    data object FuelGaugeRelearn : PodCommand(0x05) {
        override fun encode() = byteArrayOf(0x05)
    }

    /** 0x06 — replay slot 0..13 on FE04. */
    data class ReplaySlot(val slot: Int) : PodCommand(0x06) {
        init { require(slot in 0 until Cadence.NIGHT_SLOTS) { "slot must be 0..13" } }
        override fun encode() = byteArrayOf(0x06, slot.toByte())
    }

    /** 0x07 */
    data object AbortReplay : PodCommand(0x07) {
        override fun encode() = byteArrayOf(0x07)
    }

    /** 0x08 A5 5A — DESTRUCTIVE. UI must put this behind a typed confirmation. */
    data object FormatFlash : PodCommand(0x08) {
        override fun encode() = byteArrayOf(0x08, 0xA5.toByte(), 0x5A)
    }

    /** 0x09 — force an FE02 notify now. */
    data object PushSummary : PodCommand(0x09) {
        override fun encode() = byteArrayOf(0x09)
    }
}
