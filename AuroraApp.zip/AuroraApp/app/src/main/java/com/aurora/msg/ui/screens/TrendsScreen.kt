package com.aurora.msg.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.msg.R
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.Fmt
import com.aurora.msg.ui.summaryHasSleep
import com.aurora.msg.ui.charts.BarDatum
import com.aurora.msg.ui.charts.Legend
import com.aurora.msg.ui.charts.StackDatum
import com.aurora.msg.ui.charts.StackedBars
import com.aurora.msg.ui.charts.TrendBars
import com.aurora.msg.ui.charts.rememberReveal
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.EmptyState
import com.aurora.msg.ui.components.SectionHeader
import com.aurora.msg.ui.components.StatTile
import com.aurora.msg.ui.theme.Aurora

@Composable
fun TrendsScreen(vm: AppViewModel, inner: PaddingValues, onOpenNight: (Long) -> Unit, onDemo: () -> Unit) {
    val cards by vm.nightCards.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var rangeDays by remember { mutableIntStateOf(14) }
    val since = System.currentTimeMillis() - rangeDays * 86_400_000L
    val inRange = cards.filter { it.session.startedAtEpochMs >= since && it.summary != null }.sortedBy { it.session.startedAtEpochMs }
    val reveal = rememberReveal(rangeDays to inRange.size)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding(), bottom = inner.calculateBottomPadding() + 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Column(Modifier.statusBarsPadding().padding(top = 8.dp)) {
                Text(stringResource(R.string.trends_title), style = MaterialTheme.typography.headlineMedium)
                Text(stringResource(R.string.trends_subtitle), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(7, 14, 30, 90).forEach { d ->
                    FilterChip(
                        selected = rangeDays == d, onClick = { rangeDays = d }, label = { Text(stringResource(R.string.trends_days, d)) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primary, selectedLabelColor = MaterialTheme.colorScheme.onPrimary),
                    )
                }
            }
        }

        if (inRange.size < 2) {
            item {
                AuroraCard {
                    EmptyState(stringResource(R.string.trends_empty_title), stringResource(R.string.trends_empty_body)) {
                        OutlinedButton(onClick = onDemo, shape = CircleShape) { Text(stringResource(R.string.trends_open_demo)) }
                    }
                }
            }
            return@LazyColumn
        }

        val labels = inRange.map { Fmt.dayNum(it.session.startedAtEpochMs) }
        val sweat = inRange.map { it.summary!!.sweatEvents.toFloat() }
        val peak = inRange.map { it.summary!!.peakDahX100 / 100f }
        val sleepLen = inRange.map { it.summary!!.sessionLenS / 3600f }
        val restHr = inRange.map { it.summary!!.hrMin.toFloat() }
        // 0 bpm = no heart-rate reading that night: leave it out of the average (never "0").
        val restHrKnown = restHr.filter { it > 0f }
        // Nights from the real glove carry no sleep split (no IMU): skip the chart if none has one.
        val anySleep = inRange.any { summaryHasSleep(it.summary) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(stringResource(R.string.trends_avg_events), "%.1f".format(sweat.average()), modifier = Modifier.weight(1f), accent = Aurora.Fuchsia, note = trendNoteText(trendNote(sweat, lowerIsBetter = true)))
                StatTile(stringResource(R.string.trends_avg_peak_sweat), "%.1f".format(peak.average()), stringResource(R.string.common_gm3), Modifier.weight(1f), accent = Aurora.Rose, note = trendNoteText(trendNote(peak, lowerIsBetter = true)))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(stringResource(R.string.trends_avg_time_in_bed), Fmt.duration((sleepLen.average() * 3600).toLong()), modifier = Modifier.weight(1f), accent = Aurora.SleepDeep)
                StatTile(stringResource(R.string.trends_resting_hr), if (restHrKnown.isEmpty()) "—" else "%.0f".format(restHrKnown.average()), if (restHrKnown.isEmpty()) "" else stringResource(R.string.common_bpm), Modifier.weight(1f), accent = Aurora.Ink, note = trendNoteText(trendNote(restHrKnown, lowerIsBetter = true)))
            }
        }

        item {
            AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.trends_sweat_events_title), stringResource(R.string.trends_sweat_events_sub), Modifier.padding(start = 12.dp))
                TrendBars(inRange.mapIndexed { i, _ -> BarDatum(labels[i], sweat[i], highlight = i == inRange.lastIndex) }, Aurora.Fuchsia, reveal = reveal)
            }
        }
        item {
            AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.trends_peak_sweat_title), stringResource(R.string.trends_peak_sweat_sub), Modifier.padding(start = 12.dp))
                TrendBars(inRange.mapIndexed { i, _ -> BarDatum(labels[i], peak[i], highlight = i == inRange.lastIndex) }, Aurora.Rose, decimals = 1, unit = " g/m³", reveal = reveal)
            }
        }
        if (anySleep) item {
            AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.trends_sleep_comp_title), stringResource(R.string.trends_sleep_comp_sub), Modifier.padding(start = 12.dp))
                Legend(listOf(stringResource(R.string.trends_deep) to Aurora.SleepDeep, stringResource(R.string.trends_light) to Aurora.SleepLight, stringResource(R.string.trends_awake) to Aurora.SleepWake), Modifier.padding(start = 12.dp, bottom = 6.dp))
                StackedBars(
                    inRange.mapIndexed { i, c -> val sm = c.summary!!; StackDatum(labels[i], listOf(sm.pctDeep.toFloat(), sm.pctLight.toFloat(), sm.pctWake.toFloat()), highlight = i == inRange.lastIndex) },
                    listOf(Aurora.SleepDeep, Aurora.SleepLight, Aurora.SleepWake), reveal = reveal,
                    partLabels = listOf(stringResource(R.string.trends_deep), stringResource(R.string.trends_light), stringResource(R.string.trends_awake)),
                )
            }
        }
        item {
            AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.trends_resting_hr_title), stringResource(R.string.trends_resting_hr_sub), Modifier.padding(start = 12.dp))
                // Nights with no heart-rate reading get no bar (never a "0 bpm" bar).
                TrendBars(inRange.indices.filter { restHr[it] > 0f }.map { i -> BarDatum(labels[i], restHr[i], highlight = i == inRange.lastIndex) }, Aurora.Ink, unit = " bpm", reveal = reveal)
            }
        }
        item {
            AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(stringResource(R.string.trends_time_in_bed_title), stringResource(R.string.trends_time_in_bed_sub), Modifier.padding(start = 12.dp))
                TrendBars(inRange.mapIndexed { i, _ -> BarDatum(labels[i], sleepLen[i], highlight = i == inRange.lastIndex) }, Aurora.SleepDeep, decimals = 1, unit = " h", reveal = reveal)
            }
        }

        item { SectionHeader(stringResource(R.string.trends_nights_in_range), pluralStringResource(R.plurals.trends_nights_count, inRange.size, inRange.size)) }
        items(inRange.reversed(), key = { it.session.id }) { c -> NightRow(c, settings, onOpenNight) }
        item {
            Text(
                stringResource(R.string.trends_footer),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp),
            )
        }
    }
}

/** Result of comparing the last third of the range with the first third. */
private sealed class Trend {
    object None : Trend()
    object Steady : Trend()
    data class Down(val pct: Int) : Trend()
    data class Up(val pct: Int) : Trend()
}

@Composable
private fun trendNoteText(t: Trend): String? = when (t) {
    Trend.None -> null
    Trend.Steady -> stringResource(R.string.trends_note_steady)
    is Trend.Down -> stringResource(R.string.trends_note_down, t.pct)
    is Trend.Up -> stringResource(R.string.trends_note_up, t.pct)
}

/** Compare the last third of the range with the first third. */
private fun trendNote(values: List<Float>, lowerIsBetter: Boolean): Trend {
    if (values.size < 4) return Trend.None
    val n = values.size / 3
    val first = values.take(n).average(); val last = values.takeLast(n).average()
    if (first == 0.0) return Trend.None
    val change = (last - first) / first * 100
    if (kotlin.math.abs(change) < 8) return Trend.Steady
    val pct = kotlin.math.abs(change).toInt()
    return if (change < 0) Trend.Down(pct) else Trend.Up(pct)
}
