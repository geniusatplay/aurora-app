package com.aurora.msg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothDisabled
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.msg.R
import com.aurora.msg.data.repo.NightBundle
import com.aurora.msg.data.repo.NightCard
import com.aurora.msg.domain.Ranges
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.Fmt
import com.aurora.msg.ui.isHardwareNight
import com.aurora.msg.ui.isHardwarePod
import com.aurora.msg.ui.nightLacksSleep
import com.aurora.msg.ui.charts.SleepRing
import com.aurora.msg.ui.charts.Sparkline
import com.aurora.msg.ui.charts.rememberReveal
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.BannerTone
import com.aurora.msg.ui.components.EmptyState
import com.aurora.msg.ui.components.HeroCard
import com.aurora.msg.ui.components.InfoBanner
import com.aurora.msg.ui.components.Pill
import com.aurora.msg.ui.components.SectionHeader
import com.aurora.msg.ui.components.StatTile
import com.aurora.msg.ui.components.WhiteLabeledValue
import com.aurora.msg.ui.theme.Aurora

@Composable
fun HomeScreen(
    vm: AppViewModel,
    inner: PaddingValues,
    onOpenNight: (Long) -> Unit,
    onOpenPod: () -> Unit,
    onOpenLive: () -> Unit,
    onDemo: () -> Unit,
    onOpenVitalSheet: (Long) -> Unit,
) {
    val user by vm.user.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val latest by vm.latestNight.collectAsStateWithLifecycle()
    val cards by vm.nightCards.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val battery by vm.pod.batteryPct.collectAsStateWithLifecycle()
    val active by vm.pod.activeSession.collectAsStateWithLifecycle()
    val vitals by vm.pod.latestVitals.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val info by vm.pod.deviceInfo.collectAsStateWithLifecycle()
    val slotsFlow = remember { vm.sessions.observeSlots() }
    val slots by slotsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val reveal = rememberReveal(latest?.session?.id)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding(), bottom = inner.calculateBottomPadding() + 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Column(Modifier.statusBarsPadding().padding(top = 8.dp)) {
                val name = user?.displayName?.substringBefore(' ') ?: stringResource(R.string.home_greeting_fallback_name)
                val greetingRes = when (dayPart()) {
                    DayPart.NIGHT -> R.string.home_greeting_night
                    DayPart.MORNING -> R.string.home_greeting_morning
                    DayPart.AFTERNOON -> R.string.home_greeting_afternoon
                    DayPart.EVENING -> R.string.home_greeting_evening
                }
                Text(stringResource(greetingRes, name), style = MaterialTheme.typography.headlineMedium)
                Text(Fmt.dateLong(System.currentTimeMillis()), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Recording now
        if (active != null) item {
            AuroraCard(onClick = onOpenLive) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pill(stringResource(R.string.common_recording), MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(10.dp))
                    Text(stringResource(R.string.home_since, Fmt.clock(active!!.startedAtEpochMs, settings)), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (conn.isConnected) stringResource(R.string.home_live_streaming) else stringResource(R.string.home_phone_disconnected),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                vitals?.let { v ->
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile(stringResource(R.string.home_tile_skin), Fmt.temp(v.skinTempC, settings), modifier = Modifier.weight(1f), accent = Aurora.SeriesSkin)
                        StatTile(stringResource(R.string.home_tile_heart), if (v.hasHr) "${v.hrBpm}" else "—", if (v.hasHr) stringResource(R.string.common_bpm) else "", modifier = Modifier.weight(1f), accent = Aurora.Ink)
                        if (caps.sleepStaging) {
                            StatTile(stringResource(R.string.home_tile_sleep), stringResource(when (v.sleepState) { com.aurora.msg.protocol.SleepState.WAKE -> R.string.app_sleep_awake; com.aurora.msg.protocol.SleepState.LIGHT -> R.string.app_sleep_light; com.aurora.msg.protocol.SleepState.DEEP -> R.string.app_sleep_deep; com.aurora.msg.protocol.SleepState.UNKNOWN -> R.string.app_sleep_unknown }), modifier = Modifier.weight(1f), accent = Aurora.SleepDeep)
                        } else if (caps.directAbsHumidity) {
                            // No sleep staging on the real glove: show its key signal instead.
                            val ah = v.absHumX100
                            StatTile(stringResource(R.string.hw_home_tile_moisture), ah?.let { "%.2f".format(it / 100f) } ?: "—", if (ah != null) stringResource(R.string.common_gm3) else "", modifier = Modifier.weight(1f), accent = Aurora.SeriesSweat)
                        }
                    }
                }
            }
        }

        if (latest == null) {
            item {
                AuroraCard {
                    EmptyState(
                        title = stringResource(R.string.home_empty_title),
                        body = stringResource(R.string.home_empty_body),
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = onOpenPod, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) { Text(stringResource(R.string.home_connect_pod)) }
                            OutlinedButton(onClick = onDemo, shape = CircleShape) { Text(stringResource(R.string.home_try_demo)) }
                        }
                    }
                }
            }
        } else {
            val night = latest!!
            item { LastNightHero(night, reveal, onOpenNight, onOpenVitalSheet) }
            item { MorningCard(night, settings, reveal, settings.showRanges) }
            if (cards.size >= 2) item { WeekStrip(cards, reveal) }
        }

        item {
            PodStrip(conn.isConnected, battery, slots.size, settings.demoMode, onOpenPod, hwPod = !settings.demoMode && isHardwarePod(caps, info))
        }

        if (cards.size > 1) {
            item { SectionHeader(stringResource(R.string.home_recent_nights), stringResource(R.string.home_recent_nights_sub)) }
            items(cards.take(6), key = { it.session.id }) { c -> NightRow(c, settings, onOpenNight) }
        }
    }
}

private enum class DayPart { NIGHT, MORNING, AFTERNOON, EVENING }

private fun dayPart(): DayPart {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when { h < 5 -> DayPart.NIGHT; h < 12 -> DayPart.MORNING; h < 17 -> DayPart.AFTERNOON; else -> DayPart.EVENING }
}

@Composable
internal fun LastNightHero(night: NightBundle, reveal: Float, onOpen: (Long) -> Unit, onOpenVitalSheet: (Long) -> Unit) {
    val s = night.summary
    // Recorded on the real glove (no room sensor in its records): pod flush count is provisional.
    val hw = isHardwareNight(night.epochs)
    HeroCard(onClick = { onOpen(night.session.id) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.home_last_night), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.85f), fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(Fmt.dateMedium(night.session.startedAtEpochMs), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.85f))
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            val eventCount = s?.sweatEvents ?: night.sweat.size
            Text("${(eventCount * reveal).toInt()}", style = MaterialTheme.typography.displayLarge, color = Color.White)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.padding(bottom = 10.dp)) {
                Text(pluralStringResource(R.plurals.home_hero_line1, eventCount), style = MaterialTheme.typography.titleMedium, color = Color.White)
                Text(pluralStringResource(R.plurals.home_hero_line2, eventCount), style = MaterialTheme.typography.titleMedium, color = Color.White)
            }
            if (hw) {
                Spacer(Modifier.width(10.dp))
                Pill(stringResource(R.string.hw_provisional), Color.White.copy(alpha = 0.22f), Color.White, modifier = Modifier.padding(bottom = 14.dp))
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            WhiteLabeledValue(stringResource(R.string.home_peak_sweat), "${Fmt.dah((s?.peakDahX100 ?: 0) / 100f)} ${stringResource(R.string.common_gm3)}")
            // No sleep staging on the real glove: time in bed, not "asleep".
            WhiteLabeledValue(stringResource(if (hw) R.string.hw_time_in_bed else R.string.home_asleep), Fmt.duration(s?.sessionLenS ?: 0L))
            // The pod's FE02 carries no longest-event field: derive it from the stored sweat spans.
            val longest = if (hw) night.sweat.maxOfOrNull { it.endS - it.startS } else (s?.longestSweatS ?: 0).toLong()
            WhiteLabeledValue(stringResource(R.string.home_longest_event), longest?.let { Fmt.durationShort(it) } ?: "—")
        }
        Spacer(Modifier.height(12.dp))
        Text(stringResource(if (hw) R.string.hw_home_peak_note else R.string.home_peak_sweat_note), style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
        Spacer(Modifier.height(12.dp))
        // Nighttime Vital Sheet entry point (brief §4)
        Button(
            onClick = { onOpenVitalSheet(night.session.id) }, shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.22f), contentColor = Color.White),
        ) { Text(stringResource(R.string.vs_open)) }
    }
}

@Composable
internal fun MorningCard(night: NightBundle, settings: com.aurora.msg.data.repo.AppSettings, reveal: Float, showRanges: Boolean) {
    val s = night.summary
    AuroraCard {
        Text(stringResource(R.string.home_morning_card), style = MaterialTheme.typography.titleMedium)
        Text(stringResource(R.string.home_morning_card_sub), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        if (nightLacksSleep(night.epochs, s)) {
            // No sleep staging for this night (real glove has no IMU): no ring, no % split.
            InBedValue(Fmt.duration(s?.sessionLenS ?: 0L), stringResource(R.string.home_in_bed))
        } else Row(verticalAlignment = Alignment.CenterVertically) {
            SleepRing(s?.pctWake ?: 0, s?.pctLight ?: 0, s?.pctDeep ?: 0, centerTop = Fmt.duration(s?.sessionLenS ?: 0L), centerBottom = stringResource(R.string.home_in_bed), reveal = reveal)
            Spacer(Modifier.width(18.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RingLegend(Aurora.SleepDeep, stringResource(R.string.home_deep), "${s?.pctDeep ?: 0}%")
                RingLegend(Aurora.SleepLight, stringResource(R.string.home_light), "${s?.pctLight ?: 0}%")
                RingLegend(Aurora.SleepWake, stringResource(R.string.home_awake), "${s?.pctWake ?: 0}%")
            }
        }
        Spacer(Modifier.height(14.dp))
        // 0 bpm is the internal "no reading" — render a dash, never a zero.
        val hrMin = s?.hrMin ?: 0; val hrMean = s?.hrMean ?: 0; val hrMax = s?.hrMax ?: 0
        val bpm = stringResource(R.string.common_bpm)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(stringResource(R.string.home_resting_hr), if (hrMin > 0) "$hrMin" else "—", if (hrMin > 0) bpm else "", Modifier.weight(1f), accent = Aurora.Ink, note = stringResource(R.string.home_resting_hr_note), level = if (showRanges && hrMin > 0) Ranges.sleepHeartRate.levelOf(hrMin.toFloat()) else null)
            StatTile(stringResource(R.string.home_average_hr), if (hrMean > 0) "$hrMean" else "—", if (hrMean > 0) bpm else "", Modifier.weight(1f), accent = Aurora.Ink)
            StatTile(stringResource(R.string.home_peak_hr), if (hrMax > 0) "$hrMax" else "—", if (hrMax > 0) bpm else "", Modifier.weight(1f), accent = Aurora.Fuchsia)
        }
    }
}

/** Duration + "in bed" in place of the sleep ring when the night has no sleep staging. */
@Composable
private fun InBedValue(value: String, label: String) {
    Row(verticalAlignment = Alignment.Bottom) {
        Text(value, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
    }
}

@Composable
private fun RingLegend(color: Color, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.width(52.dp))
        Text(value, style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
private fun WeekStrip(cards: List<NightCard>, reveal: Float) {
    val recent = cards.take(7).reversed()
    val values = recent.map { (it.summary?.sweatEvents ?: 0).toFloat() }
    AuroraCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(pluralStringResource(R.plurals.home_last_n_nights, recent.size, recent.size), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.home_events_per_night), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(stringResource(R.string.home_avg, "%.1f".format(values.average())), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(10.dp))
        Sparkline(values, Aurora.Fuchsia, Modifier.fillMaxWidth().height(56.dp), reveal)
    }
}

@Composable
private fun PodStrip(connected: Boolean, battery: Int?, nightsStored: Int, demo: Boolean, onOpenPod: () -> Unit, hwPod: Boolean = false) {
    AuroraCard(onClick = onOpenPod, padding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (connected) Icons.Rounded.Bluetooth else Icons.Rounded.BluetoothDisabled, null, tint = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (connected) (if (demo) stringResource(R.string.home_demo_pod_connected) else stringResource(R.string.home_pod_connected)) else stringResource(R.string.home_pod_not_connected), style = MaterialTheme.typography.titleSmall)
                // The real glove keeps ONE log in RAM — no 14-slot inventory.
                Text(if (hwPod) stringResource(R.string.hw_home_pod_log) else stringResource(R.string.home_nights_stored, nightsStored, 14), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (battery != null) {
                Icon(Icons.Rounded.BatteryFull, null, tint = if (battery <= 15) Aurora.Bad else Aurora.Good, modifier = Modifier.width(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("$battery%", style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.width(6.dp))
            Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (nightsStored >= 12 && !hwPod) {
            Spacer(Modifier.height(10.dp))
            InfoBanner(stringResource(R.string.home_pod_nearly_full), tone = BannerTone.Warning, icon = Icons.Rounded.Warning)
        }
    }
}

@Composable
fun NightRow(c: NightCard, settings: com.aurora.msg.data.repo.AppSettings, onOpen: (Long) -> Unit) {
    AuroraCard(onClick = { onOpen(c.session.id) }, padding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(Fmt.nightLabel(c.session.startedAtEpochMs), style = MaterialTheme.typography.titleSmall)
                Text(
                    "${Fmt.clock(c.session.startedAtEpochMs, settings)} → ${c.session.endedAtEpochMs?.let { Fmt.clock(it, settings) } ?: "…"}  ·  ${Fmt.duration(c.summary?.sessionLenS ?: 0L)}",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${c.summary?.sweatEvents ?: 0}", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                Text(stringResource(R.string.home_sweat_events_label), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(6.dp))
            Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
