package com.aurora.msg.ui

import com.aurora.msg.data.db.EpochEntity
import com.aurora.msg.data.db.SessionSummaryEntity
import com.aurora.msg.protocol.DeviceInfo
import com.aurora.msg.protocol.HwAdapter
import com.aurora.msg.protocol.LogRecord
import com.aurora.msg.protocol.PodCapabilities
import com.aurora.msg.protocol.SleepState

/*
 * Data-presence gates for the real Aurora Pod (hardware protocol v1, PROTOCOL §3/§4/§9).
 *
 * Stored nights are gated on their DATA, never only on the current pod: a night recorded
 * on the real glove stays a hardware night even while the app is in demo mode.
 * The real glove has no room sensor, so every record it produces carries the
 * HwAdapter.NO_AMBIENT_TEMP_X100 sentinel — that is what identifies a hardware night.
 */

/** A night whose records have no ambient (room) sensor reading is a hardware night. */
fun isHardwareNight(records: List<LogRecord>): Boolean =
    records.isNotEmpty() && records.none { HwAdapter.hasAmbient(it.ambTempX100) }

@JvmName("isHardwareNightEpochs")
fun isHardwareNight(epochs: List<EpochEntity>): Boolean =
    epochs.isNotEmpty() && epochs.none { HwAdapter.hasAmbient(it.ambTempX100) }

/** At least one record carries a real room temperature/humidity reading. */
fun hasAmbientData(records: List<LogRecord>): Boolean = records.any { HwAdapter.hasAmbient(it.ambTempX100) }

@JvmName("hasAmbientDataEpochs")
fun hasAmbientData(epochs: List<EpochEntity>): Boolean = epochs.any { HwAdapter.hasAmbient(it.ambTempX100) }

private fun SessionSummaryEntity.hasSleepSplit(): Boolean = pctWake + pctLight + pctDeep > 0

/**
 * True when the night has no sleep staging to show (no hypnogram, no sleep ring, no
 * % deep/light/awake): every record is UNKNOWN AND the night is either a hardware night
 * or a finished night whose summary carries no split. A demo night that is still being
 * recorded (UNKNOWN for its first minutes, no summary yet) keeps its charts as before.
 */
fun nightLacksSleep(records: List<LogRecord>, summary: SessionSummaryEntity?): Boolean {
    val allUnknown = records.all { it.sleepState == SleepState.UNKNOWN }
    return allUnknown && (isHardwareNight(records) || (summary != null && !summary.hasSleepSplit()))
}

@JvmName("nightLacksSleepEpochs")
fun nightLacksSleep(epochs: List<EpochEntity>, summary: SessionSummaryEntity?): Boolean {
    val allUnknown = epochs.all { SleepState.fromCode(it.sleepState) == SleepState.UNKNOWN }
    return allUnknown && (isHardwareNight(epochs) || (summary != null && !summary.hasSleepSplit()))
}

/** No sleep staging AND no movement at all (no accelerometer) → hide movement panels too. */
fun nightLacksMotion(records: List<LogRecord>, summary: SessionSummaryEntity?): Boolean =
    nightLacksSleep(records, summary) && records.all { it.motionIndex == 0 }

@JvmName("nightLacksMotionEpochs")
fun nightLacksMotion(epochs: List<EpochEntity>, summary: SessionSummaryEntity?): Boolean =
    nightLacksSleep(epochs, summary) && epochs.all { it.motionIndex == 0 }

/** Summary-only check (Trends, night lists): a split exists to draw. */
fun summaryHasSleep(summary: SessionSummaryEntity?): Boolean = summary?.hasSleepSplit() == true

/** The connected / last-seen pod speaks hardware protocol v1 (the real glove). */
fun isHardwarePod(caps: PodCapabilities, info: DeviceInfo?): Boolean =
    caps == PodCapabilities.HARDWARE_V1 || info?.hardwareRevision?.contains("protocol v1") == true
