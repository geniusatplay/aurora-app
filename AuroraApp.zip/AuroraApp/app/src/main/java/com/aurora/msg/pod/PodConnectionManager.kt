package com.aurora.msg.pod

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.annotation.StringRes
import com.aurora.msg.R
import com.aurora.msg.data.db.ActivityKind
import com.aurora.msg.data.db.EventSource
import com.aurora.msg.data.db.SessionEntity
import com.aurora.msg.data.db.SessionSource
import com.aurora.msg.data.repo.SessionRepository
import com.aurora.msg.domain.NightAnalytics
import com.aurora.msg.protocol.Cadence
import com.aurora.msg.protocol.ExtFlags
import com.aurora.msg.protocol.ExtendedVitals
import com.aurora.msg.protocol.HrvSummary
import com.aurora.msg.protocol.LiveVitals
import com.aurora.msg.protocol.LogRecord
import com.aurora.msg.protocol.PodCommand
import com.aurora.msg.protocol.PodFlags
import com.aurora.msg.protocol.ReplayAssembler
import com.aurora.msg.protocol.SessionSummary
import com.aurora.msg.protocol.SweatFlag
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.roundToInt

/** Progress of a night download (spec §9 — needs a real percentage and a visible cancel). */
sealed class ReplayStatus {
    data object Idle : ReplayStatus()
    data class WaitingForHeader(val slot: Int) : ReplayStatus()
    data class Downloading(val slot: Int, val percent: Int, val framesReceived: Int, val expectedFrames: Int) : ReplayStatus()
    data class Done(val slot: Int, val records: Int, val crcFailures: Int, val complete: Boolean) : ReplayStatus()
    data class Failed(val slot: Int, @StringRes val messageRes: Int, val args: List<Any> = emptyList()) : ReplayStatus()
    val isActive: Boolean get() = this is WaitingForHeader || this is Downloading
}

/** One-shot UI messages (snackbars). */
data class PodMessage(@StringRes val textRes: Int, val args: List<Any> = emptyList(), val isError: Boolean = false)

/**
 * Orchestrates whichever [PodSource] is active (BLE or demo) and applies the spec's rules:
 *  - CMD_TIME_SYNC first after every connection, confirmed via FLAG_TIME_SYNCED, retried
 *  - commands confirmed by observing their effect, with timeout + retry (spec §15.2)
 *  - wall-clock session start stored by the app (spec §8.2)
 *  - provisional epochs synthesised from live vitals so charts grow while connected;
 *    replaced by authoritative replay data when downloaded
 */
class PodConnectionManager(
    private val context: Context,
    private val repo: SessionRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val ble = BlePodSource(context, scope)
    val demo = DemoPodSource(scope)

    private val _source = MutableStateFlow<PodSource>(ble)
    val source: StateFlow<PodSource> = _source.asStateFlow()
    val isDemo: Boolean get() = _source.value.isDemo

    @OptIn(ExperimentalCoroutinesApi::class)
    val connectionState: StateFlow<ConnectionState> = _source.flatMapLatest { it.connectionState }
        .stateIn(scope, SharingStarted.Eagerly, ConnectionState.Disconnected)
    @OptIn(ExperimentalCoroutinesApi::class)
    val scanResults: StateFlow<List<ScannedPod>> = _source.flatMapLatest { it.scanResults }
        .stateIn(scope, SharingStarted.Eagerly, emptyList())
    @OptIn(ExperimentalCoroutinesApi::class)
    val deviceInfo = _source.flatMapLatest { it.deviceInfo }.stateIn(scope, SharingStarted.Eagerly, null)
    @OptIn(ExperimentalCoroutinesApi::class)
    val batteryPct = _source.flatMapLatest { it.batteryPct }.stateIn(scope, SharingStarted.Eagerly, null)

    private val _latestVitals = MutableStateFlow<LiveVitals?>(null)
    val latestVitals: StateFlow<LiveVitals?> = _latestVitals.asStateFlow()

    /** Rolling window of the last ~15 minutes of 1 Hz vitals for the live chart. */
    private val _liveWindow = MutableStateFlow<List<LiveVitals>>(emptyList())
    val liveWindow: StateFlow<List<LiveVitals>> = _liveWindow.asStateFlow()

    /** Whether the active pod exposes FE06 — drives the live conductance tile vs "not in this pod". */
    @OptIn(ExperimentalCoroutinesApi::class)
    val hasExtendedSensors: StateFlow<Boolean> = _source.flatMapLatest { it.hasExtendedSensors }
        .stateIn(scope, SharingStarted.Eagerly, false)

    /** What the active pod can measure (demo: everything; real glove: HARDWARE_V1). */
    @OptIn(ExperimentalCoroutinesApi::class)
    val capabilities: StateFlow<com.aurora.msg.protocol.PodCapabilities> = _source.flatMapLatest { it.capabilities }
        .stateIn(scope, SharingStarted.Eagerly, com.aurora.msg.protocol.PodCapabilities.NONE)

    /** Link diagnostics of the active source (custom pages: link_health / packet_inspector). */
    @OptIn(ExperimentalCoroutinesApi::class)
    val linkStats: StateFlow<LinkStats> = _source.flatMapLatest { it.linkStats }
        .stateIn(scope, SharingStarted.Eagerly, LinkStats())
    @OptIn(ExperimentalCoroutinesApi::class)
    val rawPackets: StateFlow<List<RawPacket>> = _source.flatMapLatest { it.rawPackets }
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    private val _latestExt = MutableStateFlow<ExtendedVitals?>(null)
    val latestExt: StateFlow<ExtendedVitals?> = _latestExt.asStateFlow()

    /** Rolling window of FE06 samples, same span as [liveWindow], for the live sparkline. */
    private val _extWindow = MutableStateFlow<List<ExtendedVitals>>(emptyList())
    val extWindow: StateFlow<List<ExtendedVitals>> = _extWindow.asStateFlow()

    /** Most recent valid heart-rate reading and the pod time (t_s) it was taken. */
    data class HrReading(val bpm: Int, val quality: Int, val tS: Long)
    private val _lastHr = MutableStateFlow<HrReading?>(null)
    val lastHr: StateFlow<HrReading?> = _lastHr.asStateFlow()

    private val _latestHrv = MutableStateFlow<HrvSummary?>(null)
    val latestHrv: StateFlow<HrvSummary?> = _latestHrv.asStateFlow()

    private val _timeSynced = MutableStateFlow(false)
    val timeSynced: StateFlow<Boolean> = _timeSynced.asStateFlow()

    private val _activeSession = MutableStateFlow<SessionEntity?>(null)
    val activeSession: StateFlow<SessionEntity?> = _activeSession.asStateFlow()

    private val _replay = MutableStateFlow<ReplayStatus>(ReplayStatus.Idle)
    val replayStatus: StateFlow<ReplayStatus> = _replay.asStateFlow()

    private val _messages = MutableSharedFlow<PodMessage>(extraBufferCapacity = 8)
    val messages: SharedFlow<PodMessage> = _messages.asSharedFlow()

    /** Emitted when a morning card (FE02) arrives for a session, so the UI can navigate to it. */
    private val _morningCard = MutableSharedFlow<Long>(extraBufferCapacity = 2)
    val morningCard: SharedFlow<Long> = _morningCard.asSharedFlow()

    private var userId: Long? = null
    private var collectors: Job? = null
    private var replayJob: Job? = null

    private val epochAgg = EpochAggregator()

    /** Set while the hardware check runs: its test session gets no morning-card navigation. */
    @Volatile private var testRunActive = false
    /** FE02 summaries arriving before this time are dropped (a discarded test session's STOP). */
    @Volatile private var discardSummariesUntil = 0L

    /** One-button hardware check (custom-page `hardware_check` section). */
    val hardwareCheck = HardwareCheckRunner(this, repo, scope)

    init { attachCollectors() }

    // ------------------------------------------------------------------ mode & user

    fun setUser(id: Long?) {
        userId = id
        scope.launch {
            _activeSession.value = id?.let { repo.openSession(it) }
        }
    }

    fun useDemo(enabled: Boolean) {
        if (isDemo == enabled) return
        _source.value.disconnect()
        _source.value = if (enabled) demo else ble
        _timeSynced.value = false
        _latestVitals.value = null
        _lastHr.value = null
        _latestHrv.value = null
        _liveWindow.value = emptyList()
        _latestExt.value = null
        _extWindow.value = emptyList()
        attachCollectors()
    }

    // ------------------------------------------------------------------ connection

    fun startScan() = _source.value.startScan()
    fun stopScan() = _source.value.stopScan()
    fun connect(address: String? = null) = _source.value.connect(address)
    fun disconnect() = _source.value.disconnect()

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun attachCollectors() {
        collectors?.cancel()
        val src = _source.value
        collectors = scope.launch {
            launch { src.connectionState.collectLatest { onConnectionState(it) } }
            launch { src.vitals.collect { onVitals(it) } }
            launch { src.extVitals.collect { onExtVitals(it) } }
            launch { src.hrv.collect { onHrv(it) } }
            launch { src.summary.collect { onSummary(it) } }
            if (src is DemoPodSource) launch { src.modeEvents.collect { (t, m) -> onDemoMode(t, m) } }
        }
    }

    private suspend fun onConnectionState(state: ConnectionState) {
        when (state) {
            is ConnectionState.Connected -> {
                _timeSynced.value = false
                syncTime()
                deviceInfo.value?.let { if (it.firmwareMismatch) toast(R.string.app_msg_firmware_mismatch, listOf(it.softwareRevision, "1.0.0"), true) }
            }
            is ConnectionState.Disconnected, is ConnectionState.Error -> {
                _timeSynced.value = false
                // A reconnect must never stitch pre- and post-gap samples into one epoch
                // (or gap-fill the whole disconnected span with one sample).
                epochAgg.reset()
                val current = _replay.value
                if (current.isActive) {
                    val slot = when (current) {
                        is ReplayStatus.Downloading -> current.slot
                        is ReplayStatus.WaitingForHeader -> current.slot
                        else -> 0
                    }
                    replayJob?.cancel()
                    _replay.value = ReplayStatus.Failed(slot, R.string.app_msg_replay_connection_dropped)
                    stopReplayService()
                }
                if (state is ConnectionState.Error) toast(state.messageRes, listOfNotNull(state.arg), true)
            }
            else -> Unit
        }
    }

    /** Spec §8.1 — FIRST thing after every connection. Confirmed via FLAG_TIME_SYNCED, 3 attempts. */
    private suspend fun syncTime() {
        repeat(3) { attempt ->
            _source.value.write(PodCommand.TimeSync(System.currentTimeMillis() / 1000))
            val ok = withTimeoutOrNull(2500) { _source.value.vitals.filter { it.timeSynced }.first() } != null
            if (ok) { _timeSynced.value = true; return }
            if (attempt == 2) toast(R.string.app_msg_clock_sync_failed, error = true)
        }
    }

    // ------------------------------------------------------------------ session lifecycle

    /** Bedtime: START, confirm FLAG_LOGGING, store wall-clock start (spec §12). */
    suspend fun startSession(): Boolean {
        val uid = userId ?: run { toast(R.string.app_msg_sign_in_first, error = true); return false }
        if (!connectionState.value.isConnected) { toast(R.string.app_msg_connect_first, error = true); return false }
        if (_activeSession.value != null) { toast(R.string.app_msg_already_recording); return true }
        if (!_timeSynced.value) syncTime()
        repeat(3) {
            _source.value.write(PodCommand.StartSession)
            val ok = withTimeoutOrNull(4000) { _source.value.vitals.filter { it.logging }.first() } != null
            if (ok) {
                val session = repo.startSession(uid, if (isDemo) SessionSource.DEMO else SessionSource.BLE)
                _activeSession.value = session
                epochAgg.reset()
                toast(R.string.app_msg_recording_started)
                return true
            }
        }
        toast(R.string.app_msg_recording_not_started, error = true)
        return false
    }

    /** Morning: STOP, receive FE02 → morning card (spec §12). */
    suspend fun stopSession(): Boolean {
        if (!connectionState.value.isConnected) { toast(R.string.app_msg_connect_first, error = true); return false }
        repeat(3) { attempt ->
            // Subscribe BEFORE writing: the demo pod emits FE02 synchronously inside write().
            val waiter = scope.async(start = CoroutineStart.UNDISPATCHED) { _source.value.summary.first() }
            _source.value.write(if (attempt == 0) PodCommand.StopSession else PodCommand.PushSummary)
            val summary = withTimeoutOrNull(4000) { waiter.await() }
            if (summary == null) waiter.cancel()
            if (summary != null) return true // onSummary() handles persistence
        }
        // Fall back to a direct read of FE02
        _source.value.readSummary()?.let { onSummary(it); return true }
        toast(R.string.app_msg_no_summary, error = true)
        return false
    }

    private suspend fun onSummary(summary: SessionSummary) {
        if (System.currentTimeMillis() < discardSummariesUntil) return
        val session = _activeSession.value ?: userId?.let { repo.openSession(it) }
        if (session == null) {
            toast(R.string.app_msg_summary_without_session, listOf(summary.slot))
            return
        }
        epochAgg.flush(session.id)
        // Real glove: if the pod was reset mid-night its FE02 duration restarts from 0 —
        // never let that shrink a night the phone watched for hours.
        val fixed = if (_source.value.isDemo) summary else summary.copy(
            sessionLenS = maxOf(summary.sessionLenS, (System.currentTimeMillis() - session.startedAtEpochMs) / 1000))
        repo.endSession(session, fixed)
        _activeSession.value = null
        if (!testRunActive) _morningCard.tryEmit(session.id)
    }

    // ------------------------------------------------------------------ live data

    private suspend fun onVitals(v: LiveVitals) {
        _latestVitals.value = v
        if (v.hasHr) _lastHr.value = HrReading(v.hrBpm, v.hrQuality, v.tS)
        // Pod time restarts at 0 when a session starts: begin a fresh rolling window.
        val prev = _liveWindow.value
        // Also restart on a big forward jump (hardware: session stop switches tS back to raw uptime).
        val window = if (prev.isNotEmpty() && (v.tS < prev.last().tS || v.tS - prev.last().tS > 120)) emptyList() else prev
        _liveWindow.value = (if (window.size >= LIVE_WINDOW) window.drop(window.size - LIVE_WINDOW + 1) else window) + v
        val session = _activeSession.value ?: return
        if (!v.logging) return
        epochAgg.push(v, _latestHrv.value)?.let { records ->
            records.forEach { repo.appendProvisionalEpoch(session.id, it) }
        }
        if (v.sensorFault) sensorFaultOnce()
    }

    private suspend fun onExtVitals(v: ExtendedVitals) {
        _latestExt.value = v
        // Same restart rule as the FE01 window: pod time resets at session start.
        val prev = _extWindow.value
        val window = if (prev.isNotEmpty() && v.tS < prev.last().tS) emptyList() else prev
        _extWindow.value = (if (window.size >= LIVE_WINDOW) window.drop(window.size - LIVE_WINDOW + 1) else window) + v
        // The epoch aggregator averages the valid samples into the provisional record (brief §7).
        // Gate on logging like onVitals does: push() — the only place ext samples are drained —
        // runs only while logging, so collecting here without that gate would grow the buffer
        // 1/s forever when an orphaned open session meets a connected, non-logging pod.
        if (_activeSession.value != null && _latestVitals.value?.logging == true) epochAgg.pushExt(v)
    }

    private var sensorFaultToasted = false
    private suspend fun sensorFaultOnce() {
        if (!sensorFaultToasted) { sensorFaultToasted = true; toast(R.string.app_msg_sensor_fault, error = true) }
    }

    private suspend fun onHrv(h: HrvSummary) {
        _latestHrv.value = h
        val session = _activeSession.value ?: return
        // Same gate as epochs: while the pod is not logging (reset pod, unknown time base)
        // its HRV timestamps are not session-relative and would overwrite real points.
        if (_latestVitals.value?.logging != true) return
        val windowEndS = if (h.isWallClock) (h.windowEndTimeS - session.startedAtEpochMs / 1000).coerceAtLeast(0) else h.windowEndTimeS
        repo.appendHrv(session.id, h, windowEndS)
        epochAgg.markHrvFresh()
    }

    private suspend fun onDemoMode(tS: Long, mode: DemoMode) {
        val session = _activeSession.value ?: return
        val kind = when (mode) {
            DemoMode.UP -> ActivityKind.UP
            DemoMode.LIGHT_EXERCISE -> ActivityKind.LIGHT_EXERCISE
            DemoMode.HEAVY_EXERCISE -> ActivityKind.HEAVY_EXERCISE
            DemoMode.SLEEPING -> ActivityKind.SLEEPING
            DemoMode.NIGHT_FLASH -> ActivityKind.NIGHT_FLASH
            DemoMode.NIGHT_SWEATS -> ActivityKind.NIGHT_SWEATS
        }
        repo.addActivityEvent(session.id, tS, kind, EventSource.DEMO)
    }

    // ------------------------------------------------------------------ replay (night download)

    fun downloadNight(sessionId: Long, slot: Int) {
        if (_replay.value.isActive) return
        replayJob?.cancel()
        replayJob = scope.launch { runReplay(sessionId, slot) }
    }

    fun cancelDownload() {
        replayJob?.cancel(); replayJob = null
        scope.launch { _source.value.write(PodCommand.AbortReplay) }
        _replay.value = ReplayStatus.Idle
        stopReplayService()
    }

    private suspend fun runReplay(sessionId: Long, slot: Int) {
        if (!connectionState.value.isConnected) { _replay.value = ReplayStatus.Failed(slot, R.string.app_msg_connect_first); return }
        startReplayService()
        val asm = ReplayAssembler()
        _replay.value = ReplayStatus.WaitingForHeader(slot)
        val src = _source.value
        var finished: ReplayAssembler.Result? = null
        var error: String? = null
        // UNDISPATCHED: the subscription must exist before ReplaySlot is written (demo emits immediately).
        val collector = scope.launch(start = CoroutineStart.UNDISPATCHED) {
            src.replayFrames.collect { frame ->
                when (val ev = asm.feed(frame)) {
                    is ReplayAssembler.Event.HeaderReceived ->
                        _replay.value = ReplayStatus.Downloading(slot, 0, 0, ev.header.expectedFrames)
                    is ReplayAssembler.Event.Data ->
                        _replay.value = ReplayStatus.Downloading(slot, ev.progress.percent, ev.progress.framesReceived, ev.progress.expectedFrames)
                    is ReplayAssembler.Event.Finished -> { finished = ev.result; cancel() }
                    is ReplayAssembler.Event.Error -> { error = ev.message; cancel() }
                }
            }
        }
        src.write(PodCommand.ReplaySlot(slot))
        // Header must arrive within ~2 s or the slot is empty (spec §9 step 3). The real pod
        // streams + converts its whole log before the first internal frame, so it gets longer.
        val gotHeader = withTimeoutOrNull(src.replayHeaderTimeoutMs) {
            kotlinx.coroutines.flow.merge(
                replayStatus.filter { it is ReplayStatus.Downloading }.map { true },
                src.replayEmpty.map { false },   // real pod: nothing stored for this session
            ).first()
        } == true
        if (!gotHeader) {
            collector.cancel()
            src.write(PodCommand.AbortReplay)
            _replay.value = ReplayStatus.Failed(slot, R.string.app_msg_replay_slot_empty, listOf(slot))
            stopReplayService(); return
        }
        // Whole night: allow up to 5 minutes (slow connection intervals, spec §9).
        withTimeoutOrNull(5 * 60_000L) { collector.join() }
        collector.cancel()
        val result = finished
        when {
            error != null -> _replay.value = ReplayStatus.Failed(slot, R.string.app_msg_raw, listOf(error!!))
            result == null -> { src.write(PodCommand.AbortReplay); _replay.value = ReplayStatus.Failed(slot, R.string.app_msg_replay_timeout) }
            result.unsupportedFormat -> _replay.value = ReplayStatus.Failed(slot, R.string.app_msg_replay_old_firmware, listOf(result.header.recordSize))
            result.records.isEmpty() -> _replay.value = ReplayStatus.Failed(slot, R.string.app_msg_replay_slot_empty, listOf(slot))
            else -> {
                // Real pod: fold in link-level losses the re-encoded internal stream can't show.
                val diag = src.takeReplayDiagnostics()
                val complete = result.complete && (diag?.first ?: 0) == 0
                val crc = result.crcFailures + (diag?.second ?: 0)
                repo.storeReplay(sessionId, result.records, crc, complete)
                _replay.value = ReplayStatus.Done(slot, result.records.size, crc, complete)
                if (result.crcFailures > 0) toast(R.string.app_msg_crc_dropped, listOf(result.crcFailures))
            }
        }
        stopReplayService()
    }

    private fun startReplayService() {
        runCatching {
            val i = Intent(context, ReplayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i) else context.startService(i)
        }
    }

    private fun stopReplayService() {
        runCatching { context.stopService(Intent(context, ReplayService::class.java)) }
    }

    // ------------------------------------------------------------------ hardware check support

    /** The real glove (hardware protocol v1) is the connected source. */
    val isHardwareLink: Boolean
        get() = !isDemo && connectionState.value.isConnected &&
            capabilities.value == com.aurora.msg.protocol.PodCapabilities.HARDWARE_V1

    /** Marks a hardware-check test session (suppresses its morning-card navigation). */
    fun setTestRun(active: Boolean) { testRunActive = active }

    /**
     * Pod log interval in seconds (1…240). Only the real glove has one; false when the active
     * source cannot take it (demo, not connected, out of range) or the write failed.
     */
    suspend fun setLogInterval(seconds: Int): Boolean {
        if (!isHardwareLink) return false
        return ble.setLogPeriod(seconds)
    }

    /**
     * Removes the hardware check's test night. If it is somehow still the active session, the
     * pod is stopped and the resulting FE02 discarded, so no morning card / orphan night appears.
     */
    suspend fun discardTestSession(sessionId: Long) {
        if (_activeSession.value?.id == sessionId) {
            _activeSession.value = null
            epochAgg.reset()
            discardSummariesUntil = System.currentTimeMillis() + 10_000L
            if (connectionState.value.isConnected) _source.value.write(PodCommand.StopSession)
        }
        repo.deleteSession(sessionId)
    }

    // ------------------------------------------------------------------ misc commands

    suspend fun hapticTest() { _source.value.write(PodCommand.HapticTest(250)); toast(R.string.app_msg_buzz_sent) }
    suspend fun fuelGaugeRelearn() { _source.value.write(PodCommand.FuelGaugeRelearn); toast(R.string.app_msg_fuel_gauge_sent) }
    suspend fun formatFlash() { _source.value.write(PodCommand.FormatFlash); toast(R.string.app_msg_storage_erased) }

    private suspend fun toast(@StringRes textRes: Int, args: List<Any> = emptyList(), error: Boolean = false) { _messages.emit(PodMessage(textRes, args, error)) }

    /**
     * Aggregates 1 Hz vitals into 30 s provisional records (one per epoch boundary crossed).
     * dah is computed by the app from the same physics the firmware uses; HR = best-quality
     * reading in the epoch; sweat flag START if any START seen, else ONGOING if any, else NONE.
     */
    private class EpochAggregator {
        private var epochIndex = -1L
        private val samples = ArrayList<LiveVitals>()
        /** FE06 samples ride their own flow; matched to epochs by t_s (same tick as FE01). */
        private val extSamples = ArrayList<ExtendedVitals>()
        private var hrvFresh = false

        fun reset() { epochIndex = -1; samples.clear(); extSamples.clear(); hrvFresh = false }
        fun markHrvFresh() { hrvFresh = true }
        fun pushExt(v: ExtendedVitals) { extSamples.add(v) }

        fun push(v: LiveVitals, hrv: HrvSummary?): List<LogRecord>? {
            val idx = v.tS / Cadence.EPOCH_S
            if (epochIndex == -1L) { epochIndex = idx; samples.add(v); return null }
            if (idx == epochIndex) { samples.add(v); return null }
            // Backwards or a long jump = a new time base (reconnect, re-pinned session start):
            // start over instead of fabricating epochs from one sample. Short skips (≤ 5
            // epochs) are the demo's fast-forward and are still filled.
            if (idx < epochIndex || idx - epochIndex > 5) { reset(); epochIndex = idx; samples.add(v); return null }
            // One or more boundaries crossed (demo speed > 30× can skip epochs): close the current one,
            // and fill any skipped epochs with the latest sample.
            val out = ArrayList<LogRecord>()
            out.add(build(epochIndex, samples, hrv))
            var e = epochIndex + 1
            while (e < idx) { out.add(build(e, listOf(v), hrv)); e++ }
            epochIndex = idx
            samples.clear(); samples.add(v)
            // Ext samples for closed epochs were consumed by build(); drop them.
            extSamples.removeAll { it.tS < idx * Cadence.EPOCH_S }
            return out
        }

        fun flush(sessionId: Long) { /* the final partial epoch is discarded, matching firmware behaviour */ samples.clear(); extSamples.clear() }

        private fun build(epoch: Long, s: List<LiveVitals>, hrv: HrvSummary?): LogRecord {
            val last = s.last()
            val hrBest = s.filter { it.hrBpm > 0 }.maxByOrNull { it.hrQuality }
            val sweat = when {
                s.any { it.sweatFlag == SweatFlag.START } -> SweatFlag.START
                s.any { it.sweatFlag == SweatFlag.ONGOING } -> SweatFlag.ONGOING
                else -> SweatFlag.NONE
            }
            val skinT = s.map { it.skinTempX100 }.average().roundToInt()
            val skinRh = s.map { it.skinRhX100 }.average().roundToInt()
            // The real glove has no room sensor: keep its "absent" sentinel instead of
            // averaging it into a fake temperature.
            val noAmbient = s.any { !com.aurora.msg.protocol.HwAdapter.hasAmbient(it.ambTempX100) }
            val ambT = if (noAmbient) com.aurora.msg.protocol.HwAdapter.NO_AMBIENT_TEMP_X100 else s.map { it.ambTempX100 }.average().roundToInt()
            val ambRh = if (noAmbient) com.aurora.msg.protocol.HwAdapter.NO_AMBIENT_RH_X100 else s.map { it.ambRhX100 }.average().roundToInt()
            // Hardware pods report absolute humidity directly: use its rise over baseline.
            val direct = s.mapNotNull { it.dahDirectX100 }
            val fresh = hrvFresh; hrvFresh = false
            // Ext channels (brief §7): average the VALID samples of this epoch; a channel with
            // no valid sample stays null. No FE06 at all (a 1.0.0 pod) → a v1-shaped record.
            val ext = extSamples.filter { it.tS / Cadence.EPOCH_S == epoch }
            val eda = ext.filter { it.edaValid }.map { it.edaX100 }
            val spo2 = ext.filter { it.spo2Valid }.map { it.spo2X10 }
            val pi = ext.filter { it.perfusionValid }.map { it.perfusionX100 }
            val extFlags = if (ext.isEmpty()) null else
                (if (eda.isEmpty()) 0 else ExtFlags.EDA_VALID) or
                    (if (spo2.isEmpty()) 0 else ExtFlags.SPO2_VALID) or
                    (if (pi.isEmpty()) 0 else ExtFlags.PI_VALID)
            return LogRecord(
                tS = epoch * Cadence.EPOCH_S,
                hrBpm = hrBest?.hrBpm ?: 0, hrQuality = hrBest?.hrQuality ?: 0,
                skinTempX100 = skinT, skinRhX100 = skinRh, ambTempX100 = ambT, ambRhX100 = ambRh,
                motionIndex = s.maxOf { it.motionIndex },
                sleepState = last.sleepState, sweatFlag = sweat, battPct = last.battPct,
                flags = last.flags or (if (fresh) PodFlags.HRV_FRESH else 0),
                dahX100 = if (direct.isNotEmpty()) direct.average().roundToInt().coerceAtLeast(0) // u16 on the wire
                    else NightAnalytics.dahX100(skinT / 100f, skinRh / 100f, ambT / 100f, ambRh / 100f),
                hrvMeanIbiMs = hrv?.meanIbiMs ?: 0, hrvSdnnMsX10 = hrv?.sdnnMsX10 ?: 0, hrvRmssdMsX10 = hrv?.rmssdMsX10 ?: 0,
                hrvPnn50Pct = hrv?.pnn50Pct ?: 0, hrvQuality = hrv?.quality ?: 0, hrvFlags = hrv?.flags ?: 0,
                vcellCv = 0,
                edaX100 = if (eda.isEmpty()) null else eda.average().roundToInt(),
                spo2X10 = if (spo2.isEmpty()) null else spo2.average().roundToInt(),
                perfusionX100 = if (pi.isEmpty()) null else pi.average().roundToInt(),
                extFlags = extFlags,
            )
        }
    }

    companion object { private const val LIVE_WINDOW = 900 }
}
