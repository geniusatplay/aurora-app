package com.aurora.msg.ui.custom

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.msg.R

/**
 * "Add section" — the section library: a searchable, scrollable list grouped by category
 * (Live, Nights, Trends, Pod, Diagnostics). Each row shows the section's name, a one-line
 * description and "+ Add"; tapping the row adds it to the end of the page. Sections already
 * on this page show "Added" (one copy per page; the same section may be on several pages).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SectionLibrarySheet(
    pageNumber: Int,
    onPage: Set<String>,
    onAdd: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    var query by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    val q = query.trim()
    // Match against the localized name / description / category and the stable ID.
    val groups = SectionCategory.entries.map { cat ->
        val catTitle = context.getString(cat.titleRes)
        val catHit = q.isNotEmpty() && catTitle.contains(q, ignoreCase = true)
        cat to SectionCatalog.inCategory(cat).filter { d ->
            q.isEmpty() || catHit ||
                context.getString(d.nameRes).contains(q, ignoreCase = true) ||
                context.getString(d.descRes).contains(q, ignoreCase = true) ||
                d.id.contains(q, ignoreCase = true)
        }
    }.filter { it.second.isNotEmpty() }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.cp_library_title, pageNumber), style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.weight(1f).semantics { heading() },
                )
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.cp_done), fontWeight = FontWeight.SemiBold) }
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text(stringResource(R.string.cp_library_search)) },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Clear, stringResource(R.string.common_cancel)) }
                },
                shape = CircleShape,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            )
            LazyColumn(
                Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (groups.isEmpty()) item {
                    Text(
                        stringResource(R.string.cp_library_no_match), style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp),
                    )
                }
                groups.forEach { (cat, defs) ->
                    item(key = "cat_" + cat.name) {
                        Text(
                            stringResource(cat.titleRes), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 4.dp, top = 12.dp, bottom = 2.dp).semantics { heading() },
                        )
                    }
                    items(defs, key = { it.id }) { d -> LibraryRow(d, added = d.id in onPage) { onAdd(d.id) } }
                }
            }
        }
    }
}

@Composable
private fun LibraryRow(def: SectionDef, added: Boolean, onAdd: () -> Unit) {
    val name = stringResource(def.nameRes)
    val desc = stringResource(def.descRes)
    val addedLabel = stringResource(R.string.cp_added)
    val addHint = stringResource(R.string.cp_add_hint)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .clickable(enabled = !added, onClickLabel = addHint, role = Role.Button, onClick = onAdd)
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .clearAndSetSemantics {
                contentDescription = "$name, $desc"
                if (added) stateDescription = addedLabel
            },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(def.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.titleSmall)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        if (added) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(addedLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            Text(
                stringResource(R.string.cp_add), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.primary).padding(horizontal = 10.dp, vertical = 5.dp),
            )
        }
    }
}
