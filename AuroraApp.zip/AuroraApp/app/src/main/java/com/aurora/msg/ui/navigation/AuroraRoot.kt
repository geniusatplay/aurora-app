package com.aurora.msg.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MonitorHeart
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.aurora.msg.ui.theme.AuroraTheme
import java.util.Locale
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.annotation.StringRes
import com.aurora.msg.R
import com.aurora.msg.ui.Fmt
import com.aurora.msg.ui.FmtStrings
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.screens.DemoSheet
import com.aurora.msg.ui.screens.HomeScreen
import com.aurora.msg.ui.screens.LiveScreen
import com.aurora.msg.ui.screens.NightDetailScreen
import com.aurora.msg.ui.screens.PodScreen
import com.aurora.msg.ui.screens.SettingsScreen
import com.aurora.msg.ui.screens.SignInScreen
import com.aurora.msg.ui.screens.TrendsScreen
import com.aurora.msg.ui.screens.VitalSheetScreen
import com.aurora.msg.ui.theme.Aurora

object Routes {
    const val SIGN_IN = "signin"
    const val HOME = "home"
    const val LIVE = "live"
    const val TRENDS = "trends"
    const val POD = "pod"
    const val SETTINGS = "settings"
    const val NIGHT = "night/{sessionId}"
    fun night(id: Long) = "night/$id"
    const val VITAL_SHEET = "vitalSheet/{sessionId}"
    fun vitalSheet(id: Long) = "vitalSheet/$id"
}

private data class Tab(val route: String, @StringRes val labelRes: Int, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.HOME, R.string.app_tab_home, Icons.Rounded.Home),
    Tab(Routes.LIVE, R.string.app_tab_live, Icons.Rounded.MonitorHeart),
    Tab(Routes.TRENDS, R.string.app_tab_trends, Icons.Rounded.Timeline),
    Tab(Routes.POD, R.string.app_tab_pod, Icons.Rounded.Bluetooth),
    Tab(Routes.SETTINGS, R.string.app_tab_settings, Icons.Rounded.Settings),
)

/**
 * Root: applies the chosen theme and language, then hosts navigation.
 * Language is switched in-app by providing a locale-overridden Context/Configuration to the
 * whole tree, so `stringResource()` everywhere resolves in the selected language without an
 * activity restart.
 */
@Composable
fun AuroraRoot(vm: AppViewModel = viewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val baseContext = LocalContext.current
    val baseConfig = LocalConfiguration.current
    val tag = settings.language.tag
    // Remember the phone's own locale so switching back to "Use phone setting" restores Fmt/SimpleDateFormat.
    val systemLocale = remember { Locale.getDefault() }
    val localized = remember(tag, baseConfig) {
        if (tag.isEmpty()) { Locale.setDefault(systemLocale); null } else {
            val locale = Locale.forLanguageTag(tag)
            Locale.setDefault(locale)
            val cfg = Configuration(baseConfig).apply { setLocale(locale) }
            cfg to baseContext.createConfigurationContext(cfg)
        }
    }
    AuroraTheme(mode = settings.themeMode) {
        if (localized == null) {
            AuroraNavigation(vm)
        } else {
            CompositionLocalProvider(LocalContext provides localized.second, LocalConfiguration provides localized.first) {
                AuroraNavigation(vm)
            }
        }
    }
}

@Composable
private fun AuroraNavigation(vm: AppViewModel) {
    val nav = rememberNavController()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val loaded by vm.settingsLoaded.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var demoOpen by remember { mutableStateOf(false) }
    val backStack by nav.currentBackStackEntryAsState()
    val currentDest = backStack?.destination
    val signedIn = settings.userId != null
    val onTab = tabs.any { t -> currentDest?.hierarchy?.any { it.route == t.route } == true }
    val activeSession by vm.pod.activeSession.collectAsStateWithLifecycle()

    val context = LocalContext.current
    // Pod messages → snackbar
    LaunchedEffect(context) { vm.pod.messages.collect { snackbar.showSnackbar(context.getString(it.textRes, *it.args.toTypedArray())) } }
    // Locale-aware patterns for the plain-function formatter (Fmt) — refreshed when the language changes.
    // Assigned during composition (not in an effect) so the screens composed below in the same pass
    // already see the new patterns; `context` is the locale-overridden one provided by AuroraRoot.
    Fmt.strings = remember(settings.language, context) {
        FmtStrings(
            hoursMinutes = context.getString(R.string.app_fmt_hours_minutes),
            minutes = context.getString(R.string.app_fmt_minutes),
            min = context.getString(R.string.app_fmt_min),
            sec = context.getString(R.string.app_fmt_sec),
            justNow = context.getString(R.string.app_fmt_just_now),
            minAgo = context.getString(R.string.app_fmt_min_ago),
            hAgo = context.getString(R.string.app_fmt_h_ago),
            dAgo = context.getString(R.string.app_fmt_d_ago),
            nightOf = context.getString(R.string.app_fmt_night_of),
        )
    }
    // Morning card arrives → open the night
    LaunchedEffect(Unit) {
        vm.pod.morningCard.collect { id ->
            nav.navigate(Routes.night(id)) { launchSingleTop = true }
        }
    }
    // Sign-in / sign-out routing
    LaunchedEffect(signedIn, loaded) {
        if (!loaded) return@LaunchedEffect
        if (!signedIn && currentDest?.route != Routes.SIGN_IN) {
            nav.navigate(Routes.SIGN_IN) { popUpTo(0) { inclusive = true } }
        } else if (signedIn && currentDest?.route == Routes.SIGN_IN) {
            nav.navigate(Routes.HOME) { popUpTo(0) { inclusive = true } }
        }
    }

    if (!loaded) {
        Box(Modifier.fillMaxSize().background(Aurora.Blossom), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = MaterialTheme.colorScheme.primary) }
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            AnimatedVisibility(visible = signedIn && onTab, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                Column {
                    DemoBar(recording = activeSession != null, isDemo = settings.demoMode) { demoOpen = true }
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp, windowInsets = NavigationBarDefaults.windowInsets) {
                        tabs.forEach { tab ->
                            val selected = currentDest?.hierarchy?.any { it.route == tab.route } == true
                            val label = stringResource(tab.labelRes)
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    nav.navigate(tab.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true; restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, label) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimary, selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                ),
                            )
                        }
                    }
                }
            }
        },
    ) { inner ->
        NavHost(
            navController = nav,
            startDestination = if (signedIn) Routes.HOME else Routes.SIGN_IN,
            modifier = Modifier.fillMaxSize(),
        ) {
            composable(Routes.SIGN_IN) { SignInScreen(vm) }
            composable(Routes.HOME) { HomeScreen(vm, inner, onOpenNight = { nav.navigate(Routes.night(it)) }, onOpenPod = { nav.navigate(Routes.POD) }, onOpenLive = { nav.navigate(Routes.LIVE) }, onDemo = { demoOpen = true }, onOpenVitalSheet = { nav.navigate(Routes.vitalSheet(it)) }) }
            composable(Routes.LIVE) { LiveScreen(vm, inner, onOpenPod = { nav.navigate(Routes.POD) }, onDemo = { demoOpen = true }) }
            composable(Routes.TRENDS) { TrendsScreen(vm, inner, onOpenNight = { nav.navigate(Routes.night(it)) }, onDemo = { demoOpen = true }) }
            composable(Routes.POD) { PodScreen(vm, inner, onOpenNight = { nav.navigate(Routes.night(it)) }) }
            composable(Routes.SETTINGS) { SettingsScreen(vm, inner) }
            composable(Routes.NIGHT, arguments = listOf(navArgument("sessionId") { type = NavType.LongType })) { entry ->
                val id = entry.arguments?.getLong("sessionId") ?: 0L
                NightDetailScreen(vm, id, onBack = { nav.popBackStack() }, onOpenPod = { nav.navigate(Routes.POD) }, onOpenVitalSheet = { nav.navigate(Routes.vitalSheet(id)) })
            }
            composable(Routes.VITAL_SHEET, arguments = listOf(navArgument("sessionId") { type = NavType.LongType })) { entry ->
                val id = entry.arguments?.getLong("sessionId") ?: 0L
                VitalSheetScreen(vm, id, onBack = { nav.popBackStack() })
            }
        }
    }

    if (demoOpen) DemoSheet(vm, onDismiss = { demoOpen = false })
}

/** The always-visible Demo button at the bottom of every main tab. */
@Composable
private fun DemoBar(recording: Boolean, isDemo: Boolean, onClick: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = onClick,
                modifier = Modifier.fillMaxWidth().height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (isDemo) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.inverseSurface, contentColor = if (isDemo) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.inverseOnSurface),
                shape = CircleShape,
            ) {
                Icon(if (recording) Icons.Rounded.Bedtime else Icons.Rounded.PlayArrow, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(if (recording && isDemo) R.string.app_demo_recording else if (isDemo) R.string.app_demo_mode else R.string.common_demo))
                if (recording) {
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.size(8.dp).background(Aurora.Petal, CircleShape))
                }
            }
        }
    }
}
