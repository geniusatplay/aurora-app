package com.aurora.msg.protocol

/** Spec §7 — enums and flag bits. */

enum class SleepState(val code: Int, val label: String) {
    WAKE(0, "Awake"),
    LIGHT(1, "Light"),
    DEEP(2, "Deep"),
    UNKNOWN(3, "Unknown");

    companion object {
        fun fromCode(code: Int): SleepState = entries.firstOrNull { it.code == code } ?: UNKNOWN
    }
}

enum class SweatFlag(val code: Int) {
    NONE(0),
    ONGOING(1),
    START(2);

    companion object {
        fun fromCode(code: Int): SweatFlag = entries.firstOrNull { it.code == code } ?: NONE
    }
}

/** flags bitfield (uint8) — FE01 and every log record. */
object PodFlags {
    const val PPG_ACTIVE = 0x01
    const val POD_DETECTED = 0x02
    const val CHARGING = 0x04
    const val LOW_BATT = 0x08
    const val SENSOR_FAULT = 0x10
    const val LOGGING = 0x20
    const val TIME_SYNCED = 0x40
    const val HRV_FRESH = 0x80 // log records only

    fun has(flags: Int, bit: Int): Boolean = (flags and bit) != 0
}

/**
 * ext_flags bitfield (uint8) — FE06 and every v2 log record (brief §1).
 * A field is shown ONLY when its VALID bit is set; the raw value is meaningless otherwise.
 */
object ExtFlags {
    const val EDA_VALID = 0x01
    const val SPO2_VALID = 0x02
    const val PI_VALID = 0x04

    fun has(flags: Int, bit: Int): Boolean = (flags and bit) != 0
}

/** hrv_flags bitfield (uint8) — FE05 and every log record. */
object HrvFlags {
    const val VALID = 0x01
    const val LOW_BEATS = 0x02
    const val MOTION = 0x04
    const val LOW_PERF = 0x08
    const val BUF_FULL = 0x10
    const val WALL_CLOCK = 0x20
    const val SAMPLE_LOSS = 0x40

    fun has(flags: Int, bit: Int): Boolean = (flags and bit) != 0

    /** Human explanations for why an HRV window was rejected (spec §4). */
    fun reasons(flags: Int): List<String> = buildList {
        if (has(flags, LOW_BEATS)) add("Too few clean beats — keep the glove still")
        if (has(flags, MOTION)) add("Movement during the window")
        if (has(flags, LOW_PERF)) add("Weak pulse signal — reposition the pod")
        if (has(flags, SAMPLE_LOSS)) add("Sensor dropped samples")
        if (has(flags, BUF_FULL)) add("Interval buffer filled")
    }

    fun shortReason(flags: Int): String = when {
        has(flags, MOTION) -> "movement"
        has(flags, LOW_PERF) -> "weak pulse"
        has(flags, LOW_BEATS) -> "few beats"
        has(flags, SAMPLE_LOSS) -> "sample loss"
        else -> "low quality"
    }
}

/** Quality banding (spec §7). Provisional until confirmed against real data. */
enum class QualityBand { HIDE, LOW_CONFIDENCE, NORMAL;
    companion object {
        fun of(quality: Int): QualityBand = when {
            quality < 40 -> HIDE
            quality < 70 -> LOW_CONFIDENCE
            else -> NORMAL
        }
    }
}

/** Measurement cadence constants (spec §5). */
object Cadence {
    const val EPOCH_S = 30
    const val HRV_PERIOD_S = 600
    const val PPG_BURST_S = 120
    const val BATTERY_UPDATE_S = 60
    const val NIGHT_SLOTS = 14
}
