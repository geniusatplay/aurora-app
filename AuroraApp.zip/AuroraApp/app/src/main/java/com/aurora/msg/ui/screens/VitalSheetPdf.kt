package com.aurora.msg.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import com.aurora.msg.data.repo.SheetScheme
import com.aurora.msg.ui.theme.Aurora
import java.io.File
import java.io.FileOutputStream

/*
 * One-page PDF of the Nighttime Vital Sheet (brief §4): the SAME row model the screen
 * renders ([VitalSheetUi], strings already resolved/localised), drawn in the ACTIVE
 * scheme's look (§5). android.graphics.pdf.PdfDocument on a plain Canvas; shared via
 * ACTION_SEND + FileProvider (authority "<applicationId>.fileprovider", manifest).
 * The PDF always uses the LIGHT channel colours — it is a printed page.
 */

private const val PAGE_W = 595   // A4 @ 72 dpi
private const val PAGE_H = 842
private const val MARGIN = 40f

private val INK = 0xFF17111A.toInt()
private val GRAY = 0xFF5A4F5C.toInt()
private val RULE = 0xFFD9C3CE.toInt()
private val CARD_BG = 0xFFF7F2F5.toInt()
private val TRACK = 0xFFEFE6EB.toInt()

/** Data colours never vary by scheme; the PDF pins them to the light variants for print. */
private fun pdfAccent(id: SheetRowId): Int = when (id) {
    SheetRowId.HR -> Aurora.SeriesHeart.toArgb()
    SheetRowId.HRV -> Aurora.SeriesHrv.toArgb()
    SheetRowId.SKIN -> Aurora.SeriesSkin.toArgb()
    SheetRowId.SWEAT -> Aurora.SeriesConductance.toArgb()
    SheetRowId.BLOODFLOW -> Aurora.SeriesBloodFlow.toArgb()
    SheetRowId.OXYGEN -> Aurora.SeriesOxygen.toArgb()
    SheetRowId.MOVEMENT -> Aurora.SeriesMotion.toArgb()
    SheetRowId.CLIMATE -> Aurora.SeriesAmbient.toArgb()
}

private fun tp(sizePt: Float, color: Int, bold: Boolean = false): TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
    textSize = sizePt
    this.color = color
    typeface = if (bold) Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) else Typeface.SANS_SERIF
}

/** Draws wrapped text at (x, y); returns the height used. */
private fun drawWrapped(canvas: Canvas, text: String, paint: TextPaint, x: Float, y: Float, width: Float, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): Float {
    val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt().coerceAtLeast(1))
        .setAlignment(align).setLineSpacing(0f, 1.05f).build()
    canvas.save()
    canvas.translate(x, y)
    layout.draw(canvas)
    canvas.restore()
    return layout.height.toFloat()
}

private fun drawTimeline(canvas: Canvas, ui: VitalSheetUi, x: Float, y: Float, w: Float, h: Float) {
    val band = Paint(Paint.ANTI_ALIAS_FLAG)
    band.color = TRACK
    canvas.drawRoundRect(RectF(x, y, x + w, y + h), h / 2, h / 2, band)
    val span = ui.lengthS.coerceAtLeast(1f)
    band.color = Aurora.Fuchsia.toArgb()
    ui.bundles.forEach { (a, b) ->
        val xa = x + (a / span).coerceIn(0f, 1f) * w
        val xb = x + (b / span).coerceIn(0f, 1f) * w
        canvas.drawRoundRect(RectF(xa, y, maxOf(xb, xa + 2.5f), y + h), h / 2, h / 2, band)
    }
    band.color = GRAY
    band.strokeWidth = 1f
    ui.wakes.forEach { t ->
        val xt = x + (t / span).coerceIn(0f, 1f) * w
        canvas.drawLine(xt, y - 4f, xt, y, band)
    }
}

/** Header shared by the three scheme looks; returns the y after it. */
private fun drawHeader(canvas: Canvas, ui: VitalSheetUi): Float {
    var y = MARGIN
    val w = PAGE_W - 2 * MARGIN
    y += drawWrapped(canvas, ui.title.uppercase(), tp(8.5f, GRAY, bold = true), MARGIN, y, w) + 4f
    y += drawWrapped(canvas, ui.nightLabel, tp(19f, INK, bold = true), MARGIN, y, w) + 6f
    y += drawWrapped(canvas, "${ui.bundleCount} ${ui.bundleCountLabel} · ${ui.scoreLabel}", tp(11f, Aurora.Magenta.toArgb(), bold = true), MARGIN, y, w) + 4f
    ui.flagChips.forEach { y += drawWrapped(canvas, "• $it", tp(8.5f, GRAY), MARGIN, y, w) + 2f }
    y += 8f
    drawTimeline(canvas, ui, MARGIN, y, w, 12f)
    y += 12f + 14f
    return y
}

/** Footer pinned to the bottom of the page. */
private fun drawFooter(canvas: Canvas, ui: VitalSheetUi) {
    val w = PAGE_W - 2 * MARGIN
    val paint = tp(7.5f, GRAY)
    val footerLayout = StaticLayout.Builder.obtain(ui.footer, 0, ui.footer.length, paint, w.toInt()).setLineSpacing(0f, 1.05f).build()
    val discLayout = StaticLayout.Builder.obtain(ui.disclaimer, 0, ui.disclaimer.length, paint, w.toInt()).setLineSpacing(0f, 1.05f).build()
    var y = PAGE_H - MARGIN - footerLayout.height - discLayout.height - 6f
    y += drawWrapped(canvas, ui.footer, paint, MARGIN, y, w) + 6f
    drawWrapped(canvas, ui.disclaimer, paint, MARGIN, y, w)
}

/* ------------------------------------------------------------------ scheme looks */

/** Scheme 1 — Aurora cards: rounded cards, 4 pt colour rail, two value columns. */
private fun drawScheme1(canvas: Canvas, ui: VitalSheetUi, yStart: Float) {
    var y = yStart
    val w = PAGE_W - 2 * MARGIN
    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    ui.rows.forEach { row ->
        val verdictPaint = tp(8f, GRAY)
        val verdictLayout = StaticLayout.Builder.obtain(row.verdict, 0, row.verdict.length, verdictPaint, (w - 24f).toInt()).setLineSpacing(0f, 1.05f).build()
        val cardH = 44f + verdictLayout.height
        fill.color = CARD_BG
        canvas.drawRoundRect(RectF(MARGIN, y, MARGIN + w, y + cardH), 8f, 8f, fill)
        fill.color = pdfAccent(row.id)
        canvas.drawRoundRect(RectF(MARGIN, y, MARGIN + 4f, y + cardH), 2f, 2f, fill)
        val xText = MARGIN + 12f
        drawWrapped(canvas, row.title, tp(10f, INK, bold = true), xText, y + 7f, w - 24f)
        val colW = (w - 24f) / 2f
        drawWrapped(canvas, ui.quietCol, tp(7.5f, GRAY), xText, y + 21f, colW)
        drawWrapped(canvas, row.quiet, tp(11f, INK, bold = true), xText, y + 30f, colW)
        drawWrapped(canvas, ui.eventCol, tp(7.5f, GRAY), xText + colW, y + 21f, colW)
        drawWrapped(canvas, row.event, tp(11f, INK, bold = true), xText + colW, y + 30f, colW)
        drawWrapped(canvas, row.verdict, verdictPaint, xText, y + 44f - 2f, w - 24f)
        y += cardH + 7f
    }
}

/** Scheme 2 — Clinic sheet: ruled flowsheet, dense rows, one accent for event values. */
private fun drawScheme2(canvas: Canvas, ui: VitalSheetUi, yStart: Float) {
    var y = yStart
    val w = PAGE_W - 2 * MARGIN
    val rule = Paint().apply { color = RULE; strokeWidth = 0.75f }
    val fuchsia = Aurora.Fuchsia.toArgb()
    val colQuietX = MARGIN + w - 190f
    val colEventX = MARGIN + w - 90f
    // small-caps column headers
    drawWrapped(canvas, ui.quietCol.uppercase(), tp(7.5f, GRAY, bold = true), colQuietX, y, 90f, Layout.Alignment.ALIGN_OPPOSITE)
    drawWrapped(canvas, ui.eventCol.uppercase(), tp(7.5f, fuchsia, bold = true), colEventX, y, 90f, Layout.Alignment.ALIGN_OPPOSITE)
    y += 13f
    canvas.drawLine(MARGIN, y, MARGIN + w, y, Paint().apply { color = INK; strokeWidth = 1.2f })
    y += 4f
    ui.rows.forEach { row ->
        val verdictPaint = tp(7.5f, GRAY)
        val titleW = w - 200f
        val verdictLayout = StaticLayout.Builder.obtain(row.verdict, 0, row.verdict.length, verdictPaint, titleW.toInt()).setLineSpacing(0f, 1.05f).build()
        val rowH = maxOf(26f, 13f + verdictLayout.height + 5f)
        drawWrapped(canvas, row.title, tp(9.5f, INK, bold = true), MARGIN, y + 3f, titleW)
        drawWrapped(canvas, row.verdict, verdictPaint, MARGIN, y + 15f, titleW)
        drawWrapped(canvas, row.quiet, tp(10f, INK), colQuietX, y + 5f, 90f, Layout.Alignment.ALIGN_OPPOSITE)
        val eventText = row.event + (row.delta?.let { "  $it" } ?: "")
        drawWrapped(canvas, eventText, tp(10f, fuchsia, bold = true), colEventX, y + 5f, 90f, Layout.Alignment.ALIGN_OPPOSITE)
        y += rowH
        canvas.drawLine(MARGIN, y, MARGIN + w, y, rule)
        y += 3f
    }
}

/** Scheme 3 — Timeline focus: a taller timeline, then a 2-per-row grid of big stat tiles. */
private fun drawScheme3(canvas: Canvas, ui: VitalSheetUi, yStart: Float) {
    var y = yStart
    val w = PAGE_W - 2 * MARGIN
    // A second, taller timeline band is this scheme's lead visual.
    drawTimeline(canvas, ui, MARGIN, y, w, 22f)
    y += 22f + 16f
    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    val tileW = (w - 10f) / 2f
    var col = 0
    var rowTop = y
    var rowMaxH = 0f
    ui.rows.forEach { row ->
        val x = MARGIN + col * (tileW + 10f)
        val verdictPaint = tp(7.5f, GRAY)
        val innerW = tileW - 20f
        val verdictLayout = StaticLayout.Builder.obtain(row.verdict, 0, row.verdict.length, verdictPaint, innerW.toInt()).setLineSpacing(0f, 1.05f).build()
        val tileH = 58f + verdictLayout.height
        fill.color = CARD_BG
        canvas.drawRoundRect(RectF(x, rowTop, x + tileW, rowTop + tileH), 10f, 10f, fill)
        fill.color = pdfAccent(row.id)
        canvas.drawCircle(x + 14f, rowTop + 13f, 3.5f, fill)
        drawWrapped(canvas, row.title, tp(8.5f, GRAY, bold = true), x + 22f, rowTop + 8f, innerW - 12f)
        val big = if (row.event != "—") row.event else row.quiet
        drawWrapped(canvas, big, tp(15f, INK, bold = true), x + 10f, rowTop + 24f, innerW)
        drawWrapped(canvas, "${ui.quietCol}: ${row.quiet}", tp(7.5f, GRAY), x + 10f, rowTop + 44f, innerW)
        drawWrapped(canvas, row.verdict, verdictPaint, x + 10f, rowTop + 55f, innerW)
        rowMaxH = maxOf(rowMaxH, tileH)
        col++
        if (col == 2) { col = 0; rowTop += rowMaxH + 8f; rowMaxH = 0f }
    }
}

/* ------------------------------------------------------------------ entry point */

/**
 * Renders the sheet as a one-page PDF in the active scheme's look and opens the share
 * sheet. Mirrors the CSV export flow on NightDetail, including the NEW_TASK fix:
 * LocalContext may be the locale-overridden (non-Activity) context from AuroraRoot;
 * starting an activity from it requires NEW_TASK or Android throws.
 */
fun shareVitalSheetPdf(
    context: Context,
    ui: VitalSheetUi,
    scheme: SheetScheme,
    sessionId: Long,
    subject: String,
    chooserTitle: String,
) {
    val doc = PdfDocument()
    val page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, 1).create())
    val canvas = page.canvas
    canvas.drawColor(android.graphics.Color.WHITE)
    val yAfterHeader = drawHeader(canvas, ui)
    when (scheme) {
        SheetScheme.SCHEME1 -> drawScheme1(canvas, ui, yAfterHeader)
        SheetScheme.SCHEME2 -> drawScheme2(canvas, ui, yAfterHeader)
        SheetScheme.SCHEME3 -> drawScheme3(canvas, ui, yAfterHeader)
    }
    drawFooter(canvas, ui)
    doc.finishPage(page)

    val dir = File(context.cacheDir, "exports").apply { mkdirs() }
    val file = File(dir, "aurora_vital_sheet_$sessionId.pdf")
    FileOutputStream(file).use { doc.writeTo(it) }
    doc.close()

    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(
        Intent.createChooser(send, chooserTitle)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    )
}
