package com.aurora.msg.pod

import androidx.annotation.StringRes

import com.aurora.msg.protocol.DeviceInfo
import com.aurora.msg.protocol.ExtendedVitals
import com.aurora.msg.protocol.HrvSummary
import com.aurora.msg.protocol.LiveVitals
import com.aurora.msg.protocol.PodCapabilities
import com.aurora.msg.protocol.PodCommand
import com.aurora.msg.protocol.SessionSummary
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

sealed class ConnectionState {
    data object Off : ConnectionState()            // Bluetooth off / unsupported
    data object Disconnected : ConnectionState()
    data object Scanning : ConnectionState()
    data class Connecting(val name: String) : ConnectionState()
    data class Connected(val name: String, val address: String) : ConnectionState()
    data class Error(@StringRes val messageRes: Int, val arg: Any? = null) : ConnectionState()

    val isConnected: Boolean get() = this is Connected
}

data class ScannedPod(val name: String, val address: String, val rssi: Int)

/**
 * One abstraction for "a pod". The BLE implementation and the demo simulator both
 * emit the SAME packet types, so every screen, parser and database path is exercised
 * identically in demo mode.
 */
interface PodSource {
    val connectionState: StateFlow<ConnectionState>
    val scanResults: StateFlow<List<ScannedPod>>
    val deviceInfo: StateFlow<DeviceInfo?>
    val batteryPct: StateFlow<Int?>

    /** FE01 — 1 Hz while connected. */
    val vitals: SharedFlow<LiveVitals>
    /** FE06 — 1 Hz, only from pods with extended sensors (brief §1). Silent otherwise. */
    val extVitals: SharedFlow<ExtendedVitals>
    /** True once FE06 is known to exist: always for demo, after discovery for BLE. */
    val hasExtendedSensors: StateFlow<Boolean>
    /**
     * What this pod can actually measure. Screens hide cards/panels for absent channels
     * instead of drawing empty charts. Demo = full paper spec; real glove = [PodCapabilities.HARDWARE_V1].
     */
    val capabilities: StateFlow<PodCapabilities>
    /**
     * How long the manager waits for the first internal replay frame. The demo answers
     * instantly; the real pod streams its whole RAM log first and the BLE layer converts
     * it, so the first frame can take tens of seconds.
     */
    val replayHeaderTimeoutMs: Long get() = 2_500L

    /** Fires when a requested replay turned out to hold nothing for this session (real pod). */
    val replayEmpty: SharedFlow<Unit> get() = kotlinx.coroutines.flow.MutableSharedFlow()

    /**
     * Link-level problems of the LAST replay that the internal re-encoded stream cannot show
     * (real pod: dropped FE04 notifications, record CRC failures): (missing, crcFailures).
     * Taken once by the manager when the replay finishes.
     */
    fun takeReplayDiagnostics(): Pair<Int, Int>? = null
    /** FE05 — every 10 min. */
    val hrv: SharedFlow<HrvSummary>
    /** FE02 — on stop / on demand. */
    val summary: SharedFlow<SessionSummary>
    /** FE04 — raw 20-byte replay frames. */
    val replayFrames: SharedFlow<ByteArray>

    /**
     * Link-level counters for the Diagnostics sections (packets, CRC failures, sequence gaps,
     * FE01 rate). Reset on every new connection. Real pod: counted per notification; demo:
     * its own simple counts.
     */
    val linkStats: StateFlow<LinkStats> get() = NO_LINK_STATS
    /** Ring buffer of the most recent raw packets (newest last, [LinkRecorder.RING_CAPACITY]). */
    val rawPackets: StateFlow<List<RawPacket>> get() = NO_RAW_PACKETS

    fun startScan()
    fun stopScan()
    fun connect(address: String?)
    fun disconnect()

    /** Fire-and-forget write to FE03. */
    suspend fun write(command: PodCommand): Boolean

    /** Direct reads (READ props on FE02 / FE05). */
    suspend fun readSummary(): SessionSummary?
    suspend fun readHrv(): HrvSummary?

    val isDemo: Boolean
}
