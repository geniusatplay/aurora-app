package com.aurora.msg

import android.app.Application
import com.aurora.msg.di.AppGraph
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AuroraApp : Application() {
    lateinit var graph: AppGraph
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
        appScope.launch {
            graph.auth.seedDemoAccount()
            val s = graph.settings.settings.first()
            graph.pod.setUser(s.userId)
            if (s.demoMode) graph.pod.useDemo(true)
        }
    }

    companion object {
        fun graph(context: android.content.Context): AppGraph = (context.applicationContext as AuroraApp).graph
    }
}
