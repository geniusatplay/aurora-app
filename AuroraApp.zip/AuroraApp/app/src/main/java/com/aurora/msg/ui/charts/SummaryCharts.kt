package com.aurora.msg.ui.charts

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.msg.ui.theme.Aurora
import com.aurora.msg.ui.theme.LocalChartColors

/** Three-segment ring: wake / light / deep, with a centre label. */
@Composable
fun SleepRing(pctWake: Int, pctLight: Int, pctDeep: Int, size: Dp = 120.dp, centerTop: String, centerBottom: String, reveal: Float = 1f) {
    val cc = LocalChartColors.current
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val stroke = 12.dp.toPx()
            val r = (this.size.minDimension - stroke) / 2
            val rect = Rect(center - Offset(r, r), Size(2 * r, 2 * r))
            drawArc(cc.grid, 0f, 360f, false, rect.topLeft, rect.size, style = Stroke(stroke))
            var start = -90f
            val gap = 3f
            listOf(pctDeep to Aurora.SleepDeep, pctLight to Aurora.SleepLight, pctWake to Aurora.SleepWake).forEach { (pct, color) ->
                val sweep = 360f * pct / 100f * reveal
                if (sweep > gap) drawArc(color, start + gap / 2, sweep - gap, false, rect.topLeft, rect.size, style = Stroke(stroke, cap = StrokeCap.Butt))
                start += 360f * pct / 100f * reveal
            }
        }
        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(centerTop, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
            Text(centerBottom, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

data class BarDatum(val label: String, val value: Float, val highlight: Boolean = false)

/** Bars with 4 dp rounded data-ends anchored at the baseline; tap a bar for its value. */
@Composable
fun TrendBars(
    data: List<BarDatum>,
    color: Color,
    height: Dp = 150.dp,
    decimals: Int = 0,
    unit: String = "",
    reveal: Float = 1f,
) {
    val cc = LocalChartColors.current
    val tm = rememberTextMeasurer()
    var selected by remember(data) { mutableStateOf<Int?>(null) }
    val maxV = (data.maxOfOrNull { it.value } ?: 1f).coerceAtLeast(1f)
    val (_, top) = niceBounds(0f, maxV, targetTicks = 3, padFrac = 0.05f)
    val yStep = niceStep(top, 3)
    val axisText = axisStyle(cc.axisText)
    Canvas(
        Modifier.fillMaxWidth().height(height).pointerInput(data) {
            detectTapGestures { pos ->
                val l = ChartLeftInset.toPx(); val w = size.width - l - ChartRightInset.toPx()
                val i = ((pos.x - l) / w * data.size).toInt()
                selected = if (i in data.indices) (if (selected == i) null else i) else null
            }
        }
    ) {
        val plot = Rect(ChartLeftInset.toPx(), ChartTopInset.toPx(), size.width - ChartRightInset.toPx(), size.height - ChartBottomInset.toPx())
        val scale = PlotScale(plot, 0f, data.size.toFloat(), 0f, top)
        drawGrid(scale, cc.grid, yStep)
        drawYLabels(scale, tm, axisText, yStep) { fmtNum(it, if (yStep < 1f) 1 else 0) }
        val slot = plot.width / data.size.coerceAtLeast(1)
        val bw = (slot * 0.62f).coerceAtMost(28.dp.toPx())
        data.forEachIndexed { i, d ->
            val x = plot.left + slot * i + (slot - bw) / 2
            val y = scale.y(d.value * reveal)
            val c = if (d.highlight || selected == i) color else color.copy(alpha = 0.55f)
            drawRoundRect(c, Offset(x, y), Size(bw, (plot.bottom - y).coerceAtLeast(0f)), CornerRadius(4.dp.toPx()))
            // baseline anchor (square bottom)
            if (plot.bottom - y > 4.dp.toPx()) drawRect(c, Offset(x, plot.bottom - 4.dp.toPx()), Size(bw, 4.dp.toPx()))
            val labelEvery = if (data.size > 10) 2 else 1
            if (i % labelEvery == 0 || i == data.lastIndex) {
                val m = tm.measure(d.label, axisText)
                drawText(tm, d.label, Offset(x + bw / 2 - m.size.width / 2, plot.bottom + 6.dp.toPx()), axisText)
            }
        }
        selected?.let { i ->
            val d = data[i]
            val x = plot.left + slot * i + slot / 2
            drawTooltip(tm, "${d.label}: ${fmtNum(d.value, decimals)}$unit", Offset(x, scale.y(d.value)), cc.tooltipBg, cc.tooltipText)
        }
    }
}

data class StackDatum(val label: String, val parts: List<Float>, val highlight: Boolean = false)

/** Stacked bars (sleep composition), 2 dp surface gap between segments. */
@Composable
fun StackedBars(
    data: List<StackDatum>,
    colors: List<Color>,
    height: Dp = 150.dp,
    reveal: Float = 1f,
    partLabels: List<String> = listOf("deep", "light", "awake"),
) {
    val cc = LocalChartColors.current
    val tm = rememberTextMeasurer()
    var selected by remember(data) { mutableStateOf<Int?>(null) }
    val axisText = axisStyle(cc.axisText)
    Canvas(
        Modifier.fillMaxWidth().height(height).pointerInput(data) {
            detectTapGestures { pos ->
                val l = ChartLeftInset.toPx(); val w = size.width - l - ChartRightInset.toPx()
                val i = ((pos.x - l) / w * data.size).toInt()
                selected = if (i in data.indices) (if (selected == i) null else i) else null
            }
        }
    ) {
        val plot = Rect(ChartLeftInset.toPx(), ChartTopInset.toPx(), size.width - ChartRightInset.toPx(), size.height - ChartBottomInset.toPx())
        val scale = PlotScale(plot, 0f, data.size.toFloat(), 0f, 100f)
        drawGrid(scale, cc.grid, 25f)
        drawYLabels(scale, tm, axisText, 25f) { "${it.toInt()}%" }
        val slot = plot.width / data.size.coerceAtLeast(1)
        val bw = (slot * 0.62f).coerceAtMost(28.dp.toPx())
        val gap = 2.dp.toPx()
        data.forEachIndexed { i, d ->
            val x = plot.left + slot * i + (slot - bw) / 2
            var acc = 0f
            val total = d.parts.sum().coerceAtLeast(1f)
            d.parts.forEachIndexed { k, part ->
                val pct = part / total * 100f * reveal
                val y0 = scale.y(acc); val y1 = scale.y(acc + pct)
                val h = (y0 - y1 - gap).coerceAtLeast(0f)
                val c = colors.getOrElse(k) { Aurora.Petal }.let { if (d.highlight || selected == i) it else it.copy(alpha = 0.7f) }
                if (h > 0f) drawRoundRect(c, Offset(x, y1 + gap / 2), Size(bw, h), CornerRadius(3.dp.toPx()))
                acc += pct
            }
            val labelEvery = if (data.size > 10) 2 else 1
            if (i % labelEvery == 0 || i == data.lastIndex) {
                val m = tm.measure(d.label, axisText)
                drawText(tm, d.label, Offset(x + bw / 2 - m.size.width / 2, plot.bottom + 6.dp.toPx()), axisText)
            }
        }
        selected?.let { i ->
            val d = data[i]
            val x = plot.left + slot * i + slot / 2
            val total = d.parts.sum().coerceAtLeast(1f)
            val txt = d.label + ": " + d.parts.mapIndexed { k, p -> "${partLabels.getOrElse(k) { "" }} ${(p / total * 100).toInt()}%" }.joinToString(" · ")
            drawTooltip(tm, txt, Offset(x, plot.top + 10.dp.toPx()), cc.tooltipBg, cc.tooltipText)
        }
    }
}

/** Tiny line for cards. */
@Composable
fun Sparkline(values: List<Float>, color: Color, modifier: Modifier = Modifier, reveal: Float = 1f) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val lo = values.min(); val hi = values.max()
        val pts = values.mapIndexed { i, v ->
            Offset(i.toFloat() / (values.size - 1) * size.width, size.height - (v - lo) / (hi - lo).coerceAtLeast(1e-3f) * (size.height - 6.dp.toPx()) - 3.dp.toPx())
        }
        val path = smoothPath(pts)
        clipRect(right = size.width * reveal) {
            drawPath(path, color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        }
        pts.lastOrNull()?.let { drawCircle(color, 3.dp.toPx(), it) }
    }
}
