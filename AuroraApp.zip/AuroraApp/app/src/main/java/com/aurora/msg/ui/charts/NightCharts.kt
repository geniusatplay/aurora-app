package com.aurora.msg.ui.charts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurora.msg.R
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.ui.theme.Aurora
import com.aurora.msg.ui.theme.LocalChartColors
import kotlin.math.abs

data class TimePoint(val t: Float, val v: Float)
data class LineSeries(val name: String, val points: List<TimePoint>, val color: Color, val area: Boolean = false)

/** Low / Medium / High reference zones for a panel, in the panel's display units. */
data class Guides(val lowMax: Float, val highMin: Float, val lowLabel: String, val midLabel: String, val highLabel: String, val higherIsBetter: Boolean = false)

internal fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGuides(g: Guides?, scale: PlotScale, tm: androidx.compose.ui.text.TextMeasurer, textColor: Color) {
    if (g == null) return
    val calm = Aurora.SeriesAmbient; val alert = Aurora.Bad; val mid = Color(0xFF9A8F9C)
    drawRangeGuides(
        scale, tm, g.lowMax, g.highMin, g.lowLabel, g.midLabel, g.highLabel,
        lowColor = if (g.higherIsBetter) alert else calm, midColor = mid, highColor = if (g.higherIsBetter) calm else alert, textColor = textColor,
    )
}

/** Time-x markers with a colour (activity events). */
data class Marker(val t: Float, val color: Color, val label: String)

private fun nearest(points: List<TimePoint>, t: Float): TimePoint? {
    if (points.isEmpty()) return null
    var lo = 0; var hi = points.size - 1
    while (lo < hi) { val mid = (lo + hi) / 2; if (points[mid].t < t) lo = mid + 1 else hi = mid }
    val a = points[lo]; val b = points.getOrNull(lo - 1)
    return if (b != null && abs(b.t - t) < abs(a.t - t)) b else a
}

@Composable
fun Legend(items: List<Pair<String, Color>>, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        items.forEach { (name, color) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(color, CircleShape))
                Spacer(Modifier.width(5.dp))
                Text(name, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/**
 * Multi-line panel on the shared time axis. One y-axis only (dataviz rule: never dual-axis).
 * Optional shaded bands (sweat events) and markers (activity events). Scrub shows a tooltip.
 */
@Composable
fun LinePanel(
    series: List<LineSeries>,
    x0: Float, x1: Float,
    height: Dp = 150.dp,
    showXAxis: Boolean = false,
    decimals: Int = 1,
    unit: String = "",
    yMin: Float? = null,
    yMax: Float? = null,
    bands: List<Pair<Float, Float>> = emptyList(),
    bandColor: Color = Aurora.Fuchsia.copy(alpha = 0.14f),
    markers: List<Marker> = emptyList(),
    scrub: Float? = null,
    xFormat: (Float) -> String = ::fmtHm,
    reveal: Float = 1f,
    guides: Guides? = null,
) {
    val cc = LocalChartColors.current
    val all = series.flatMap { it.points }
    val lo = minOf(yMin ?: (all.minOfOrNull { it.v } ?: 0f), guides?.lowMax ?: Float.MAX_VALUE)
    val hi = maxOf(yMax ?: (all.maxOfOrNull { it.v } ?: 1f), guides?.highMin ?: -Float.MAX_VALUE)
    val (b0, b1) = niceBounds(lo, hi)
    val yStep = niceStep(b1 - b0)
    val xStep = if (x1 - x0 > 5 * 3600) 3600f else if (x1 - x0 > 3600) 1800f else 600f
    ChartPanel(
        height = height, x0 = x0, x1 = x1, y0 = b0, y1 = b1, showXAxis = showXAxis,
        gridColor = cc.grid, axisText = cc.axisText, yStep = yStep, yFormat = { fmtNum(it, if (yStep < 1f) 1 else 0) },
        xStepS = xStep, xFormat = xFormat,
    ) { scale, tm ->
        drawGuides(guides, scale, tm, cc.axisText)
        drawBands(scale, bands, bandColor)
        clipRect(scale.plot.left, scale.plot.top, scale.plot.left + scale.plot.width * reveal, scale.plot.bottom) {
            series.forEach { s ->
                if (s.points.isEmpty()) return@forEach
                val pts = s.points.map { Offset(scale.x(it.t), scale.y(it.v)) }
                val path = smoothPath(pts)
                if (s.area) {
                    val area = Path().apply {
                        addPath(path)
                        lineTo(pts.last().x, scale.plot.bottom); lineTo(pts.first().x, scale.plot.bottom); close()
                    }
                    drawPath(area, areaBrush(s.color, scale.plot.top, scale.plot.bottom))
                }
                drawPath(path, s.color, style = seriesStroke())
            }
        }
        drawMarkers(scale, markers.map { it.t to it.color }, cc.plotSurface)
        drawCrosshair(scale, scrub, cc.axisText.copy(alpha = 0.7f))
        if (scrub != null) {
            val lines = series.mapNotNull { s -> nearest(s.points, scrub)?.let { p -> Triple(s, p, Offset(scale.x(p.t), scale.y(p.v))) } }
            lines.forEach { (s, _, o) ->
                drawCircle(cc.plotSurface, 5.dp.toPx(), o)
                drawCircle(s.color, 3.5f.dp.toPx(), o)
            }
            val text = lines.joinToString("  ·  ") { (s, p, _) -> "${s.name} ${fmtNum(p.v, decimals)}$unit" }
            lines.firstOrNull()?.let { drawTooltip(tm, "${xFormat(scrub)}  $text", it.third, cc.tooltipBg, cc.tooltipText) }
        }
    }
}

/** Sleep hypnogram: stepped Wake/Light/Deep rail, ordinal single-hue ramp. */
@Composable
fun HypnogramPanel(
    states: List<Pair<Float, SleepState>>,
    x0: Float, x1: Float,
    height: Dp = 96.dp,
    showXAxis: Boolean = false,
    bands: List<Pair<Float, Float>> = emptyList(),
    bandColor: Color = Aurora.Fuchsia.copy(alpha = 0.10f),
    scrub: Float? = null,
    xFormat: (Float) -> String = ::fmtHm,
    reveal: Float = 1f,
) {
    val cc = LocalChartColors.current
    // Resolved at composable level; used inside the (non-composable) draw lambda below.
    val awakeLabel = stringResource(R.string.app_sleep_awake)
    val lightLabel = stringResource(R.string.app_sleep_light)
    val deepLabel = stringResource(R.string.app_sleep_deep)
    val unknownLabel = stringResource(R.string.app_sleep_unknown)
    fun label(s: SleepState) = when (s) { SleepState.WAKE -> awakeLabel; SleepState.LIGHT -> lightLabel; SleepState.DEEP -> deepLabel; SleepState.UNKNOWN -> unknownLabel }
    val xStep = if (x1 - x0 > 5 * 3600) 3600f else if (x1 - x0 > 3600) 1800f else 600f
    fun level(s: SleepState) = when (s) { SleepState.WAKE -> 2f; SleepState.LIGHT -> 1f; SleepState.DEEP -> 0f; SleepState.UNKNOWN -> -1f }
    fun color(s: SleepState) = when (s) { SleepState.WAKE -> Aurora.SleepWake; SleepState.LIGHT -> Aurora.SleepLight; SleepState.DEEP -> Aurora.SleepDeep; SleepState.UNKNOWN -> Aurora.SleepUnknown }
    ChartPanel(
        height = height, x0 = x0, x1 = x1, y0 = 0f, y1 = 2f, showXAxis = showXAxis,
        gridColor = Color.Transparent, axisText = cc.axisText, yStep = 1f,
        yFormat = { when (it.toInt()) { 2 -> awakeLabel; 1 -> lightLabel; else -> deepLabel } },
        xStepS = xStep, xFormat = xFormat,
    ) { scale, tm ->
        drawBands(scale, bands, bandColor)
        val rail = 10.dp.toPx()
        clipRect(scale.plot.left, scale.plot.top, scale.plot.left + scale.plot.width * reveal, scale.plot.bottom) {
            for (i in states.indices) {
                val (t, s) = states[i]
                val tNext = states.getOrNull(i + 1)?.first ?: (t + 30f)
                if (s == SleepState.UNKNOWN) continue
                val xA = scale.x(t); val xB = scale.x(tNext)
                val y = scale.y(level(s))
                drawRoundRect(color(s), Offset(xA, y - rail / 2), Size((xB - xA).coerceAtLeast(1.5f), rail), CornerRadius(rail / 2))
                // connector to next level
                states.getOrNull(i + 1)?.let { (_, n) ->
                    if (n != SleepState.UNKNOWN && n != s) {
                        val y2 = scale.y(level(n))
                        drawLine(Aurora.SleepLight.copy(alpha = 0.5f), Offset(xB, y), Offset(xB, y2), 1.5f.dp.toPx())
                    }
                }
            }
        }
        drawCrosshair(scale, scrub, cc.axisText.copy(alpha = 0.7f))
        if (scrub != null) {
            val idx = states.indexOfLast { it.first <= scrub }.coerceAtLeast(0)
            states.getOrNull(idx)?.let { (_, s) ->
                drawTooltip(tm, "${xFormat(scrub)}  ${label(s)}", Offset(scale.x(scrub), scale.y(level(s).coerceAtLeast(0f))), cc.tooltipBg, cc.tooltipText)
            }
        }
    }
}

/** Movement as thin rounded bars (one per epoch). */
@Composable
fun MotionPanel(
    points: List<TimePoint>,
    x0: Float, x1: Float,
    height: Dp = 90.dp,
    showXAxis: Boolean = false,
    bands: List<Pair<Float, Float>> = emptyList(),
    bandColor: Color = Aurora.Fuchsia.copy(alpha = 0.10f),
    scrub: Float? = null,
    xFormat: (Float) -> String = ::fmtHm,
    reveal: Float = 1f,
    guides: Guides? = null,
) {
    val cc = LocalChartColors.current
    val movementLabel = stringResource(R.string.app_movement)
    val hi = maxOf((points.maxOfOrNull { it.v } ?: 100f).coerceAtLeast(50f), guides?.highMin?.times(1.1f) ?: 0f)
    val (b0, b1) = niceBounds(0f, hi, padFrac = 0.02f)
    val xStep = if (x1 - x0 > 5 * 3600) 3600f else if (x1 - x0 > 3600) 1800f else 600f
    ChartPanel(
        height = height, x0 = x0, x1 = x1, y0 = 0f, y1 = b1, showXAxis = showXAxis,
        gridColor = cc.grid, axisText = cc.axisText, yStep = niceStep(b1 - b0, 2), yFormat = { fmtNum(it, 0) },
        xStepS = xStep, xFormat = xFormat,
    ) { scale, tm ->
        drawGuides(guides, scale, tm, cc.axisText)
        drawBands(scale, bands, bandColor)
        val w = (scale.plot.width / ((x1 - x0) / 30f)).coerceAtLeast(1.5f)
        clipRect(scale.plot.left, scale.plot.top, scale.plot.left + scale.plot.width * reveal, scale.plot.bottom) {
            points.forEach { p ->
                val x = scale.x(p.t); val y = scale.y(p.v)
                drawRoundRect(Aurora.SeriesMotion, Offset(x - w / 2, y), Size(w, scale.plot.bottom - y), CornerRadius(w / 2))
            }
        }
        drawCrosshair(scale, scrub, cc.axisText.copy(alpha = 0.7f))
        if (scrub != null) nearest(points, scrub)?.let { p ->
            drawTooltip(tm, "${xFormat(scrub)}  $movementLabel ${p.v.toInt()}", Offset(scale.x(p.t), scale.y(p.v)), cc.tooltipBg, cc.tooltipText)
        }
    }
}

data class DotPoint(val t: Float, val v: Float, val valid: Boolean, val note: String = "")

/** Dots for sparse series: heart rate (quality-banded) and HRV (valid = filled, invalid = hollow). */
@Composable
fun DotPanel(
    name: String,
    points: List<DotPoint>,
    color: Color,
    x0: Float, x1: Float,
    height: Dp = 120.dp,
    showXAxis: Boolean = false,
    unit: String = "",
    decimals: Int = 0,
    connect: Boolean = false,
    bands: List<Pair<Float, Float>> = emptyList(),
    bandColor: Color = Aurora.Fuchsia.copy(alpha = 0.10f),
    scrub: Float? = null,
    xFormat: (Float) -> String = ::fmtHm,
    reveal: Float = 1f,
    guides: Guides? = null,
) {
    val cc = LocalChartColors.current
    val noSignalLabel = stringResource(R.string.app_not_enough_signal)
    val vals = points.map { it.v }
    val (b0, b1) = niceBounds(minOf(vals.minOrNull() ?: 0f, guides?.lowMax ?: Float.MAX_VALUE), maxOf(vals.maxOrNull() ?: 1f, guides?.highMin ?: -Float.MAX_VALUE))
    val xStep = if (x1 - x0 > 5 * 3600) 3600f else if (x1 - x0 > 3600) 1800f else 600f
    ChartPanel(
        height = height, x0 = x0, x1 = x1, y0 = b0, y1 = b1, showXAxis = showXAxis,
        gridColor = cc.grid, axisText = cc.axisText, yStep = niceStep(b1 - b0), yFormat = { fmtNum(it, 0) },
        xStepS = xStep, xFormat = xFormat,
    ) { scale, tm ->
        drawGuides(guides, scale, tm, cc.axisText)
        drawBands(scale, bands, bandColor)
        clipRect(scale.plot.left, scale.plot.top, scale.plot.left + scale.plot.width * reveal, scale.plot.bottom) {
            if (connect) {
                val valid = points.filter { it.valid }.map { Offset(scale.x(it.t), scale.y(it.v)) }
                if (valid.size > 1) drawPath(smoothPath(valid, 0.35f), color.copy(alpha = 0.5f), style = Stroke(1.5f.dp.toPx()))
            }
            points.forEach { p ->
                val o = Offset(scale.x(p.t), scale.y(p.v))
                if (p.valid) {
                    drawCircle(cc.plotSurface, 5.dp.toPx(), o)
                    drawCircle(color, 3.5f.dp.toPx(), o)
                } else {
                    drawCircle(cc.plotSurface, 5.dp.toPx(), o)
                    drawCircle(color.copy(alpha = 0.7f), 3.5f.dp.toPx(), o, style = Stroke(1.5f.dp.toPx()))
                }
            }
        }
        drawCrosshair(scale, scrub, cc.axisText.copy(alpha = 0.7f))
        if (scrub != null && points.isNotEmpty()) {
            val p = points.minByOrNull { abs(it.t - scrub) }!!
            val txt = if (p.valid) "$name ${fmtNum(p.v, decimals)}$unit" else "$name — ${p.note.ifBlank { noSignalLabel }}"
            drawTooltip(tm, "${xFormat(p.t)}  $txt", Offset(scale.x(p.t), scale.y(p.v)), cc.tooltipBg, cc.tooltipText)
        }
    }
}

/** Small strip that names event markers under a chart stack. */
@Composable
fun MarkerLegend(markers: List<Marker>, modifier: Modifier = Modifier) {
    val distinct = markers.distinctBy { it.label }
    if (distinct.isEmpty()) return
    Legend(distinct.map { it.label to it.color }, modifier.padding(top = 4.dp))
}
