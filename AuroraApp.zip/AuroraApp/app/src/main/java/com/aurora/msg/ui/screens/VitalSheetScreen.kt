package com.aurora.msg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import com.aurora.msg.R
import com.aurora.msg.data.repo.AppSettings
import com.aurora.msg.data.repo.NightBundle
import com.aurora.msg.data.repo.SheetScheme
import com.aurora.msg.domain.FlashBundle
import com.aurora.msg.domain.Level
import com.aurora.msg.domain.NightAnalytics
import com.aurora.msg.domain.NightComparison
import com.aurora.msg.domain.NightFlags
import com.aurora.msg.domain.NightScore
import com.aurora.msg.domain.Ranges
import com.aurora.msg.domain.VitalComparison
import com.aurora.msg.protocol.LogRecord
import com.aurora.msg.protocol.QualityBand
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.Fmt
import com.aurora.msg.ui.isHardwareNight
import com.aurora.msg.ui.nightLacksMotion
import com.aurora.msg.ui.nightLacksSleep
import com.aurora.msg.ui.charts.BundleBandColor
import com.aurora.msg.ui.charts.BundleTimelineStrip
import com.aurora.msg.ui.charts.DotPanel
import com.aurora.msg.ui.charts.DotPoint
import com.aurora.msg.ui.charts.ExtGuideBands
import com.aurora.msg.ui.charts.HypnogramPanel
import com.aurora.msg.ui.charts.LinePanel
import com.aurora.msg.ui.charts.LineSeries
import com.aurora.msg.ui.charts.TimePoint
import com.aurora.msg.ui.charts.rememberReveal
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.Disclaimer
import com.aurora.msg.ui.components.EmptyState
import com.aurora.msg.ui.components.HeroCard
import com.aurora.msg.ui.components.LevelBadge
import com.aurora.msg.ui.components.Pill
import com.aurora.msg.ui.components.SectionHeader
import com.aurora.msg.ui.theme.Aurora
import com.aurora.msg.ui.theme.LocalChartColors
import kotlin.math.roundToInt

/* ====================================================================== row model
 * ONE row model shared by the three schemes AND the PDF (brief §5): all strings are
 * resolved here, data colours follow the channel and never the scheme. */

enum class SheetRowId { HR, HRV, SKIN, SWEAT, BLOODFLOW, OXYGEN, MOVEMENT, CLIMATE }

data class SheetRowUi(
    val id: SheetRowId,
    val title: String,
    /** Formatted "Quiet sleep" column value (median over non-bundle epochs). */
    val quiet: String,
    /** Formatted "Flash events" column value (median over bundle epochs, peak in parens). */
    val event: String,
    /** Plain-language verdict line for the row. */
    val verdict: String,
    /** Channel colour — identical in every scheme. */
    val accent: Color,
    val level: Level? = null,
    val higherIsBetter: Boolean = false,
    /** Optional "▲ +12" style delta badge (Scheme 2 / PDF flowsheet look). */
    val delta: String? = null,
)

data class VitalSheetUi(
    val title: String,
    val nightLabel: String,
    val bundleCount: Int,
    val bundleCountLabel: String,
    val scoreLabel: String,
    val score: NightScore,
    val flagChips: List<String>,
    /** Bundle spans in pod-relative seconds (timeline strip + PDF). */
    val bundles: List<Pair<Float, Float>>,
    /** Wake-up times in pod-relative seconds (timeline ticks). */
    val wakes: List<Float>,
    val lengthS: Float,
    val quietCol: String,
    val eventCol: String,
    val timelineTitle: String,
    val timelineSub: String,
    val rows: List<SheetRowUi>,
    val footer: String,
    val disclaimer: String,
    /** False when the night has no sleep staging (real glove, no IMU): no hypnogram. */
    val hasSleep: Boolean = true,
    /** Recorded on the real glove (records carry no room sensor): dah is "above baseline". */
    val hwNight: Boolean = false,
)

/* ============================ CORE ADAPTER — keep tiny ============================
 * Maps NightAnalytics.quietVsEvent()'s comparison structure into the row model's
 * numbers. If the core's NightComparison / VitalComparison shape drifts, reconcile
 * HERE ONLY — each mapping is a one-line fix. */
data class RowNumbers(val quiet: Float?, val event: Float?, val peak: Float?)

private fun VitalComparison.toRow(): RowNumbers = RowNumbers(quietMedian, eventMedian, eventPeak)

/* ====================================================================== screen */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VitalSheetScreen(vm: AppViewModel, sessionId: Long, onBack: () -> Unit) {
    val nightFlow = remember(sessionId) { vm.night(sessionId) }
    val bundle by nightFlow.collectAsStateWithLifecycle(initialValue = null)
    val settings by vm.settings.collectAsStateWithLifecycle()
    val cards by vm.nightCards.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val reveal = rememberReveal(bundle?.epochs?.size?.let { if (it > 0) sessionId else null })

    // "Compare her to herself": mean valid RMSSD over her other recent nights (up to 14).
    var baselineRmssdX10 by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(cards, sessionId) {
        val means = cards.filter { it.session.id != sessionId }.take(14).mapNotNull { c ->
            val recs = with(vm.sessions) { vm.sessions.epochsFor(c.session.id).map { it.toRecord() } }
            NightAnalytics.meanValidRmssdX10(recs)
        }
        baselineRmssdX10 = if (means.isEmpty()) null else means.average().roundToInt()
    }

    val b = bundle
    val records = remember(b?.epochs) { b?.let { n -> with(vm.sessions) { n.epochs.map { it.toRecord() } } } ?: emptyList() }
    val bundles = remember(records) { NightAnalytics.detectBundles(records) }
    val score = remember(bundles) { NightAnalytics.nightScore(bundles) }
    val flags = remember(records) { NightAnalytics.nightFlags(records) }
    val cmp = remember(records, bundles) { NightAnalytics.quietVsEvent(records, bundles) }
    val ui: VitalSheetUi? = if (b == null || records.isEmpty()) null
    else buildVitalSheetUi(b, records, bundles, score, flags, cmp, baselineRmssdX10, settings, caps.hrvRelativeOnly)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.vs_title), style = MaterialTheme.typography.titleLarge)
                        b?.let { Text(Fmt.nightLabel(it.session.startedAtEpochMs), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.night_cd_back)) } },
                actions = {
                    val subject = stringResource(R.string.vs_export_subject)
                    val chooser = stringResource(R.string.vs_share_chooser)
                    val scope = rememberCoroutineScope()
                    if (ui != null) {
                        IconButton(onClick = {
                            // PDF render + disk write off the main thread (StrictMode
                            // DiskWriteViolation / dropped frames otherwise); the share
                            // intent itself is fine to fire from a background thread.
                            scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                shareVitalSheetPdf(context, ui, settings.sheetScheme, sessionId, subject, chooser)
                            }
                        }) {
                            Icon(Icons.Rounded.Share, stringResource(R.string.vs_cd_share_pdf))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
    ) { inner ->
        if (ui == null) {
            EmptyState(stringResource(R.string.vs_no_data_title), stringResource(R.string.vs_no_data_body), Modifier.padding(inner))
            return@Scaffold
        }
        when (settings.sheetScheme) {
            SheetScheme.SCHEME1 -> Scheme1Sheet(ui, inner, reveal)
            SheetScheme.SCHEME2 -> Scheme2Sheet(ui, inner)
            SheetScheme.SCHEME3 -> Scheme3Sheet(ui, records, settings, inner, reveal)
        }
    }
}

/**
 * Compact Vital Sheet for a custom page (`vital_sheet` section): hero, bundle timeline and the
 * Scheme-1 rows for [b], plus "Open full sheet". Same row model and data as the full screen.
 * [placeholder] renders when the night has no epochs to compare.
 */
@Composable
internal fun VitalSheetPreview(vm: AppViewModel, b: NightBundle, onOpen: () -> Unit, placeholder: @Composable () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val cards by vm.nightCards.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    val sessionId = b.session.id
    val reveal = rememberReveal(if (b.epochs.isNotEmpty()) sessionId else null)

    // "Compare her to herself": mean valid RMSSD over her other recent nights (up to 14).
    var baselineRmssdX10 by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(cards, sessionId) {
        val means = cards.filter { it.session.id != sessionId }.take(14).mapNotNull { c ->
            val recs = with(vm.sessions) { vm.sessions.epochsFor(c.session.id).map { it.toRecord() } }
            NightAnalytics.meanValidRmssdX10(recs)
        }
        baselineRmssdX10 = if (means.isEmpty()) null else means.average().roundToInt()
    }

    val records = remember(b.epochs) { with(vm.sessions) { b.epochs.map { it.toRecord() } } }
    val bundles = remember(records) { NightAnalytics.detectBundles(records) }
    val score = remember(bundles) { NightAnalytics.nightScore(bundles) }
    val flags = remember(records) { NightAnalytics.nightFlags(records) }
    val cmp = remember(records, bundles) { NightAnalytics.quietVsEvent(records, bundles) }
    if (records.isEmpty()) {
        placeholder()
    } else {
        val ui = buildVitalSheetUi(b, records, bundles, score, flags, cmp, baselineRmssdX10, settings, caps.hrvRelativeOnly)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SheetHero(ui, reveal)
            AuroraCard {
                SectionHeader(ui.timelineTitle, ui.timelineSub)
                BundleTimelineStrip(ui.bundles, ui.wakes, 0f, ui.lengthS)
            }
            ui.rows.forEach { row -> Scheme1Row(row, ui.quietCol, ui.eventCol) }
            Button(onClick = onOpen, shape = CircleShape, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                Text(stringResource(R.string.cp_vs_open_full))
            }
        }
    }
}

/* ====================================================================== row building */

private fun levelFor(v: Float, lowMax: Float, highMin: Float): Level =
    if (v < lowMax) Level.LOW else if (v > highMin) Level.HIGH else Level.MEDIUM

/** Wake-up onsets (transition into WAKE), pod-relative seconds. Being awake at
 *  bedtime is the starting state, not a wake-up — seed prevWake from epoch 0. */
private fun wakeTimes(records: List<LogRecord>): List<Long> {
    val out = ArrayList<Long>()
    var prevWake = records.firstOrNull()?.sleepState == SleepState.WAKE
    for ((i, r) in records.withIndex()) {
        val w = r.sleepState == SleepState.WAKE
        if (w && !prevWake && i > 0) out.add(r.tS)
        prevWake = w
    }
    return out
}

@Composable
private fun buildVitalSheetUi(
    b: NightBundle,
    records: List<LogRecord>,
    bundles: List<FlashBundle>,
    score: NightScore,
    flags: NightFlags,
    cmp: NightComparison,
    baselineRmssdX10: Int?,
    settings: AppSettings,
    liveHrvRelativeOnly: Boolean = false,
): VitalSheetUi {
    val cc = LocalChartColors.current
    val show = settings.showRanges
    // Gate on the night's DATA: a hardware night stays one even when the app is in demo mode.
    val hw = isHardwareNight(records)
    val noSleep = nightLacksSleep(records, b.summary)
    val noMotion = nightLacksMotion(records, b.summary)
    val hrvRelative = hw || liveHrvRelativeOnly
    val bpm = stringResource(R.string.common_bpm)
    val ms = stringResource(R.string.common_ms)
    val gm3 = stringResource(R.string.common_gm3)
    val us = stringResource(R.string.ext_us)
    val dash = "—"
    val noEvents = stringResource(R.string.vs_no_events)

    val rows = ArrayList<SheetRowUi>()

    // ---- Heart rate
    val hr = cmp.hrBpm.toRow()
    if (!(hr.quiet == null && hr.event == null)) {
        val d = if (hr.quiet != null && hr.event != null) (hr.event - hr.quiet).roundToInt() else null
        val verdict = when {
            flags.allNightHighHr -> stringResource(R.string.vs_hr_verdict_high)
            d != null && d >= 5 -> stringResource(R.string.vs_hr_verdict_up, d)
            d != null -> stringResource(R.string.vs_hr_verdict_flat)
            else -> noEvents
        }
        rows.add(SheetRowUi(
            SheetRowId.HR, stringResource(R.string.vs_row_hr),
            hr.quiet?.let { "${it.roundToInt()} $bpm" } ?: dash,
            hr.event?.let { e -> "${e.roundToInt()} $bpm" + (hr.peak?.let { p -> " " + stringResource(R.string.vs_peak_paren, "${p.roundToInt()}") } ?: "") } ?: dash,
            verdict, cc.heart,
            level = if (show && hr.quiet != null) Ranges.sleepHeartRate.levelOf(hr.quiet) else null,
            delta = d?.let { (if (it >= 0) "▲ +" else "▼ ") + it },
        ))
    }

    // ---- Heart-rate variability — Δ vs HER 14-night average, not a chart norm.
    val rmssd = cmp.rmssdMs.toRow()
    val nightMeanX10 = NightAnalytics.meanValidRmssdX10(records)
    if (!(rmssd.quiet == null && rmssd.event == null) || nightMeanX10 != null) {
        val verdict = when {
            nightMeanX10 != null && baselineRmssdX10 != null ->
                stringResource(R.string.vs_hrv_vs_avg, "%+.0f".format((nightMeanX10 - baselineRmssdX10) / 10f), "%.0f".format(baselineRmssdX10 / 10f))
            nightMeanX10 != null -> stringResource(R.string.vs_hrv_no_avg)
            else -> stringResource(R.string.vs_hrv_no_data)
        } + (if (hrvRelative) " · " + stringResource(R.string.hw_hrv_relative_note) else "")
        rows.add(SheetRowUi(
            SheetRowId.HRV, stringResource(R.string.vs_row_hrv),
            rmssd.quiet?.let { "%.0f $ms".format(it) } ?: dash,
            rmssd.event?.let { "%.0f $ms".format(it) } ?: dash,
            verdict, Aurora.SeriesHrv,
            // Quantisation-limited HRV reads high: no Low/Medium/High badge against adult norms.
            level = if (show && rmssd.quiet != null && !hrvRelative) Ranges.rmssd.levelOf(rmssd.quiet) else null,
            higherIsBetter = true,
        ))
    }

    // ---- Skin temperature
    val skin = cmp.skinTempC.toRow()
    if (!(skin.quiet == null && skin.event == null)) {
        val dC = if (skin.quiet != null && skin.event != null) skin.event - skin.quiet else null
        val verdict = if (dC != null) {
            stringResource(R.string.vs_skin_delta_events, Fmt.delta(dC, settings)) +
                (if (dC < 2f) " " + stringResource(R.string.vs_skin_not_fever) else "")
        } else noEvents
        rows.add(SheetRowUi(
            SheetRowId.SKIN, stringResource(R.string.vs_row_skin),
            skin.quiet?.let { Fmt.temp(it, settings) } ?: dash,
            skin.event?.let { e -> Fmt.temp(e, settings) + (skin.peak?.let { p -> " " + stringResource(R.string.vs_peak_paren, Fmt.temp(p, settings)) } ?: "") } ?: dash,
            verdict, Aurora.SeriesSkin,
            level = if (show && dC != null) Ranges.skinRise.levelOf(dC) else null,
            delta = dC?.let { (if (it >= 0) "▲ " else "▼ ") + Fmt.delta(it, settings) },
        ))
    }

    // ---- Sweat: v2 conductance, v1 fallback to sweat moisture (ΔAH)
    val eda = cmp.edaUs.toRow()
    if (!(eda.quiet == null && eda.event == null)) {
        rows.add(SheetRowUi(
            SheetRowId.SWEAT, stringResource(R.string.ext_conductance),
            eda.quiet?.let { "%.1f $us".format(it) } ?: dash,
            eda.event?.let { e -> "%.1f $us".format(e) + (eda.peak?.let { p -> " " + stringResource(R.string.vs_peak_paren, "%.1f $us".format(p)) } ?: "") } ?: dash,
            // Raw elevated-EDA spans, NOT the confirmed-bundle count: the sweat row reports
            // all sweat activity; the hero reports how many were confirmed by temp+HR.
            NightAnalytics.sweatSpikeCount(records).let { pluralStringResource(R.plurals.vs_sweat_spikes, it, it) },
            cc.conductance,
            level = if (show && eda.quiet != null) levelFor(eda.quiet, ExtGuideBands.CONDUCTANCE_LOW_MAX, ExtGuideBands.CONDUCTANCE_HIGH_MIN) else null,
        ))
    } else {
        val dah = cmp.dahGm3.toRow()
        if (!(dah.quiet == null && dah.event == null)) {
            // Hardware nights: skin absolute humidity above the glove's own baseline (no room
            // sensor), smaller numbers → 2 decimals, no room-based guide, events provisional.
            val f = if (hw) "%.2f $gm3" else "%.1f $gm3"
            rows.add(SheetRowUi(
                SheetRowId.SWEAT, stringResource(if (hw) R.string.hw_vs_row_moisture else R.string.vs_row_sweat_moisture),
                dah.quiet?.let { f.format(it) } ?: dash,
                dah.event?.let { e -> f.format(e) + (dah.peak?.let { p -> " " + stringResource(R.string.vs_peak_paren, f.format(p)) } ?: "") } ?: dash,
                pluralStringResource(R.plurals.vs_sweat_spikes, b.sweat.size, b.sweat.size) + " · " + stringResource(R.string.vs_sweat_fallback_note) +
                    (if (hw) " · " + stringResource(R.string.hw_provisional) else ""),
                Aurora.SeriesSweat,
                level = if (show && dah.quiet != null && !hw) Ranges.sweat.levelOf(dah.quiet) else null,
            ))
        }
    }

    // ---- Blood flow (perfusion index) — skipped when the sensor is absent (no fallback)
    val pi = cmp.perfusionPct.toRow()
    if (!(pi.quiet == null && pi.event == null)) {
        val verdict = if (pi.quiet != null && pi.event != null && pi.event >= pi.quiet * 1.3f)
            stringResource(R.string.vs_bloodflow_rise) else stringResource(R.string.vs_bloodflow_steady)
        rows.add(SheetRowUi(
            SheetRowId.BLOODFLOW, stringResource(R.string.ext_bloodflow),
            pi.quiet?.let { "%.1f%%".format(it) } ?: dash,
            pi.event?.let { e -> "%.1f%%".format(e) + (pi.peak?.let { p -> " " + stringResource(R.string.vs_peak_paren, "%.1f%%".format(p)) } ?: "") } ?: dash,
            verdict, cc.bloodFlow,
            level = if (show && pi.quiet != null) levelFor(pi.quiet, ExtGuideBands.BLOODFLOW_LOW_MAX, ExtGuideBands.BLOODFLOW_HIGH_MIN) else null,
        ))
    }

    // ---- Oxygen — explicit "sensor not in this pod" state when absent (brief §4)
    val spo2 = cmp.spo2Pct.toRow()
    if (spo2.quiet == null && spo2.event == null) {
        // The real glove HAS the optical sensor; no value means every sample was below quality 40.
        rows.add(SheetRowUi(SheetRowId.OXYGEN, stringResource(R.string.ext_oxygen), dash, dash, stringResource(if (hw) R.string.hw_live_spo2_low_quality else R.string.ext_not_present), cc.oxygen))
    } else {
        val minSpo2 = records.mapNotNull { it.spo2Pct }.minOrNull()
        val verdict = if (spo2.quiet != null && minSpo2 != null && minSpo2 <= spo2.quiet - 3f)
            stringResource(R.string.vs_oxygen_dips) else stringResource(R.string.vs_oxygen_steady)
        rows.add(SheetRowUi(
            SheetRowId.OXYGEN, stringResource(R.string.ext_oxygen),
            spo2.quiet?.let { "%.1f%%".format(it) } ?: dash,
            spo2.event?.let { "%.1f%%".format(it) } ?: dash,
            verdict, cc.oxygen,
            // No Low/Medium/High for an uncalibrated estimate from the real glove.
            level = if (show && !hw && spo2.quiet != null) levelFor(spo2.quiet, ExtGuideBands.OXYGEN_LOW_MAX, ExtGuideBands.OXYGEN_HIGH_MIN) else null,
            higherIsBetter = true,
        ))
    }

    // ---- Movement & wake-ups
    val wakes = wakeTimes(records)
    val motion = cmp.motion.toRow()
    // No accelerometer and no sleep staging (real glove) → skip the row rather than show zeros.
    if (!noMotion) rows.add(SheetRowUi(
        SheetRowId.MOVEMENT, stringResource(R.string.vs_row_movement),
        motion.quiet?.let { "%.0f".format(it) } ?: dash,
        motion.event?.let { "%.0f".format(it) } ?: dash,
        stringResource(R.string.vs_wake_verdict, wakes.size, bundles.count { it.hadWake }),
        Aurora.SeriesMotion,
        level = if (show && motion.quiet != null) Ranges.movement.levelOf(motion.quiet) else null,
    ))

    // ---- Room climate
    val ambT = cmp.ambTempC.toRow()
    val ambRh = cmp.ambRhPct.toRow()
    // Skipped when the records carry no room sensor (quietVsEvent returns null for the sentinel).
    if (!(ambT.quiet == null && ambT.event == null)) rows.add(SheetRowUi(
        SheetRowId.CLIMATE, stringResource(R.string.vs_row_climate),
        if (ambT.quiet != null && ambRh.quiet != null) stringResource(R.string.vs_climate_fmt, Fmt.temp(ambT.quiet, settings), "%.0f".format(ambRh.quiet)) else dash,
        if (ambT.event != null && ambRh.event != null) stringResource(R.string.vs_climate_fmt, Fmt.temp(ambT.event, settings), "%.0f".format(ambRh.event)) else dash,
        if (flags.warmRoom) stringResource(R.string.vs_flag_warm_room) else stringResource(R.string.vs_climate_ok),
        Aurora.SeriesAmbient,
        level = if (show && ambT.quiet != null) Ranges.roomTemp.levelOf(ambT.quiet) else null,
    ))

    val flagChips = ArrayList<String>()
    if (flags.notFlashPattern) flagChips.add(stringResource(R.string.vs_flag_not_flash))
    if (flags.warmRoom) flagChips.add(stringResource(R.string.vs_flag_warm_room))
    if (flags.allNightHighHr) flagChips.add(stringResource(R.string.vs_flag_hr_stayed_high))
    if (hw) flagChips.add(stringResource(R.string.hw_vs_flag_provisional))

    val lenS = (b.summary?.sessionLenS ?: records.lastOrNull()?.tS?.plus(30) ?: 0L).coerceAtLeast(600L)

    return VitalSheetUi(
        title = stringResource(R.string.vs_title),
        nightLabel = Fmt.nightLabel(b.session.startedAtEpochMs),
        bundleCount = bundles.size,
        bundleCountLabel = pluralStringResource(R.plurals.vs_bundle_count, bundles.size),
        scoreLabel = stringResource(
            when (score) {
                NightScore.QUIET -> R.string.vs_score_quiet
                NightScore.MILD -> R.string.vs_score_mild
                NightScore.MEANINGFUL -> R.string.vs_score_meaningful
            }
        ),
        score = score,
        flagChips = flagChips,
        bundles = bundles.map { it.startTs.toFloat() to it.endTs.toFloat() },
        wakes = wakes.map { it.toFloat() },
        lengthS = lenS.toFloat(),
        quietCol = stringResource(R.string.vs_quiet_col),
        eventCol = stringResource(R.string.vs_event_col),
        timelineTitle = stringResource(R.string.vs_timeline_title),
        timelineSub = stringResource(R.string.vs_timeline_sub),
        rows = rows,
        footer = stringResource(R.string.vs_footer),
        disclaimer = stringResource(R.string.wellness_disclaimer),
        hasSleep = !noSleep,
        hwNight = hw,
    )
}

/* ====================================================================== shared pieces */

@Composable
private fun SheetHero(ui: VitalSheetUi, reveal: Float) {
    HeroCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Pill(ui.title.uppercase(), Color.White.copy(alpha = 0.22f), Color.White)
            Spacer(Modifier.weight(1f))
            Text(ui.nightLabel, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.85f))
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${(ui.bundleCount * reveal).toInt()}", style = MaterialTheme.typography.displayLarge, color = Color.White)
            Spacer(Modifier.width(10.dp))
            Text(ui.bundleCountLabel, style = MaterialTheme.typography.titleMedium, color = Color.White, modifier = Modifier.padding(bottom = 10.dp))
        }
        Spacer(Modifier.height(8.dp))
        Pill(ui.scoreLabel, Color.White.copy(alpha = 0.22f), Color.White)
        ui.flagChips.forEach { chip ->
            Spacer(Modifier.height(6.dp))
            Pill(chip, Color.White.copy(alpha = 0.16f), Color.White)
        }
    }
}

@Composable
private fun SheetFooter(ui: VitalSheetUi) {
    Column {
        Text(ui.footer, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp))
        Spacer(Modifier.height(8.dp))
        Disclaimer(Modifier.navigationBarsPadding())
    }
}

/* ====================================================================== Scheme 1 — Aurora cards */

@Composable
private fun Scheme1Sheet(ui: VitalSheetUi, inner: PaddingValues, reveal: Float) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding() + 4.dp, bottom = inner.calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { SheetHero(ui, reveal) }
        item {
            AuroraCard {
                SectionHeader(ui.timelineTitle, ui.timelineSub)
                BundleTimelineStrip(ui.bundles, ui.wakes, 0f, ui.lengthS)
            }
        }
        ui.rows.forEach { row ->
            item { Scheme1Row(row, ui.quietCol, ui.eventCol) }
        }
        item { SheetFooter(ui) }
    }
}

@Composable
private fun Scheme1Row(row: SheetRowUi, quietCol: String, eventCol: String) {
    AuroraCard(padding = PaddingValues(0.dp)) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(row.accent))
            Column(Modifier.weight(1f).padding(horizontal = 14.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(row.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    if (row.level != null) LevelBadge(row.level, row.higherIsBetter)
                }
                Spacer(Modifier.height(8.dp))
                Row {
                    Column(Modifier.weight(1f)) {
                        Text(quietCol, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(row.quiet, style = MaterialTheme.typography.titleMedium)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(eventCol, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(row.event, style = MaterialTheme.typography.titleMedium)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(row.verdict, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/* ====================================================================== Scheme 2 — Clinic sheet */

@Composable
private fun Scheme2Sheet(ui: VitalSheetUi, inner: PaddingValues) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding() + 4.dp, bottom = inner.calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            AuroraCard {
                // Printed header: near-monochrome ink, ONE accent (fuchsia) for event values.
                Text(ui.title.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(ui.nightLabel, style = MaterialTheme.typography.titleLarge)
                Text("${ui.bundleCount} ${ui.bundleCountLabel} · ${ui.scoreLabel}", style = MaterialTheme.typography.bodyMedium)
                ui.flagChips.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                Spacer(Modifier.height(10.dp))
                BundleTimelineStrip(ui.bundles, ui.wakes, 0f, ui.lengthS, height = 24.dp)
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.weight(1f))
                    Text(ui.quietCol.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End, modifier = Modifier.width(96.dp))
                    Spacer(Modifier.width(16.dp))
                    Text(ui.eventCol.uppercase(), style = MaterialTheme.typography.labelSmall, color = Aurora.Fuchsia, textAlign = TextAlign.End, modifier = Modifier.width(120.dp))
                }
                ui.rows.forEach { row ->
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(row.title, style = MaterialTheme.typography.bodyMedium)
                                if (row.level != null) { Spacer(Modifier.width(6.dp)); LevelBadge(row.level, row.higherIsBetter) }
                            }
                            Text(row.verdict, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(row.quiet, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.End, modifier = Modifier.width(96.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.width(120.dp), horizontalAlignment = Alignment.End) {
                            Text(row.event, style = MaterialTheme.typography.titleSmall, color = Aurora.Fuchsia)
                            row.delta?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Aurora.Fuchsia) }
                        }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            }
        }
        item { SheetFooter(ui) }
    }
}

/* ====================================================================== Scheme 3 — Timeline focus */

@Composable
private fun Scheme3Sheet(ui: VitalSheetUi, records: List<LogRecord>, settings: AppSettings, inner: PaddingValues, reveal: Float) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding() + 4.dp, bottom = inner.calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { SheetHero(ui, reveal) }
        item {
            val cc = LocalChartColors.current
            AuroraCard(padding = PaddingValues(start = 6.dp, end = 12.dp, top = 16.dp, bottom = 12.dp)) {
                SectionHeader(ui.timelineTitle, ui.timelineSub, Modifier.padding(start = 12.dp))
                val x0 = 0f; val x1 = ui.lengthS
                val hrLabel = stringResource(R.string.vs_row_hr)
                val skinLabel = stringResource(R.string.vs_row_skin)
                val lowConfidence = stringResource(R.string.night_low_confidence)
                DotPanel(
                    hrLabel,
                    records.filter { it.hrBpm > 0 && QualityBand.of(it.hrQuality) != QualityBand.HIDE }
                        .map { DotPoint(it.tS.toFloat(), it.hrBpm.toFloat(), QualityBand.of(it.hrQuality) == QualityBand.NORMAL, lowConfidence) },
                    cc.heart, x0, x1, height = 84.dp, connect = true, bands = ui.bundles, reveal = reveal,
                )
                LinePanel(
                    series = listOf(LineSeries(skinLabel, records.map { TimePoint(it.tS.toFloat(), settings.toDisplayTemp(it.skinTempC)) }, Aurora.SeriesSkin)),
                    x0 = x0, x1 = x1, height = 84.dp, bands = ui.bundles, bandColor = BundleBandColor, unit = settings.tempLabel(), reveal = reveal,
                )
                val edaPoints = records.mapNotNull { r -> r.edaUs?.let { TimePoint(r.tS.toFloat(), it) } }
                if (edaPoints.isNotEmpty()) {
                    LinePanel(
                        series = listOf(LineSeries(stringResource(R.string.ext_conductance), edaPoints, cc.conductance, area = true)),
                        x0 = x0, x1 = x1, height = 84.dp, yMin = 0f, bands = ui.bundles, bandColor = BundleBandColor, unit = " " + stringResource(R.string.ext_us), reveal = reveal,
                    )
                } else {
                    LinePanel(
                        series = listOf(LineSeries(stringResource(if (ui.hwNight) R.string.hw_vs_row_moisture else R.string.vs_row_sweat_moisture), records.map { TimePoint(it.tS.toFloat(), it.dah) }, Aurora.SeriesSweat, area = true)),
                        x0 = x0, x1 = x1, height = 84.dp, showXAxis = !ui.hasSleep, decimals = if (ui.hwNight) 2 else 1, yMin = if (ui.hwNight) null else 0f, bands = ui.bundles, bandColor = BundleBandColor, unit = " g/m³", reveal = reveal,
                    )
                }
                if (ui.hasSleep) HypnogramPanel(
                    records.map { it.tS.toFloat() to it.sleepState },
                    x0, x1, height = 72.dp, showXAxis = true, bands = ui.bundles, reveal = reveal,
                )
            }
        }
        ui.rows.chunked(2).forEach { pair ->
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { row -> Scheme3Tile(row, ui.quietCol, Modifier.weight(1f)) }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        item { SheetFooter(ui) }
    }
}

@Composable
private fun Scheme3Tile(row: SheetRowUi, quietCol: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(row.accent, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(row.title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                if (row.level != null) LevelBadge(row.level, row.higherIsBetter)
            }
            Spacer(Modifier.height(6.dp))
            Text(if (row.event != "—") row.event else row.quiet, style = MaterialTheme.typography.headlineSmall)
            Text("$quietCol: ${row.quiet}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(row.verdict, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
