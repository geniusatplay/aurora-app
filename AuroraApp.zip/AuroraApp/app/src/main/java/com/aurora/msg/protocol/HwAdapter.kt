package com.aurora.msg.protocol

import kotlin.math.roundToInt

/**
 * Translates the real pod's hardware protocol v1 ([HwProtocol]) into the app's internal
 * model, so everything above the BLE layer — PodConnectionManager, the database, charts,
 * the Vital Sheet — keeps working unchanged. Pure Kotlin, no Android: unit-tested offline
 * and ported line-for-line to Swift (HwAdapter.swift).
 *
 * The hard parts, and why:
 *  - TIME: the pod reports uptime since boot; the app's model is seconds since session
 *    start. The session base is the uptime at which SESSION_ACTIVE rose, or — if we
 *    connected mid-session — uptime minus FE02's running duration.
 *  - SWEAT: the pod measures absolute humidity at the skin directly and has no room
 *    sensor, so dah = rise above a slow baseline (the same idea as the pod's own FLUSH
 *    flag), and FLUSH edges become the internal START/ONGOING sweat flag.
 *  - HONESTY (PROTOCOL §3): HR only when HR_LOCKED (never a zero); SpO2 only as an
 *    uncalibrated estimate at quality ≥ 40; battery 0xFF → unknown; HRV < 5 beats ignored.
 *  - REPLAY: the pod streams one RAM log (480 records, one per log interval, oldest
 *    first, each with its own CRC). We keep the current session's rows, map them onto the
 *    app's 30 s epoch grid, and re-encode them as the internal replay stream so the
 *    existing ReplayAssembler / storeReplay path is reused.
 */
class HwAdapter(private val nowEpochS: () -> Long = { System.currentTimeMillis() / 1000 }) {

    data class VitalsOut(
        val vitals: LiveVitals,
        /** SpO2 estimate carried on the ext channel (edaValid/piValid never set by hardware). */
        val ext: ExtendedVitals,
        /** null = unknown (no cell fitted). */
        val batteryPct: Int?,
        val raw: HwVitals,
    )

    data class ReplayResult(
        val records: List<LogRecord>,
        val framesReceived: Int,
        val crcFailures: Int,
        /** Sequence numbers never received below the highest one seen. */
        val missing: Int,
        /** Pod rows that fell inside the session window (before 30 s-grid mapping). */
        val sessionRows: Int,
    )

    // ------------------------------------------------------------------ live state
    var lastVitals: HwVitals? = null; private set
    var lastSession: HwSession? = null; private set
    /** phone epoch − pod uptime, refreshed on every vitals packet. */
    var epochOffsetS: Long? = null; private set
    private var sessionBase: Long? = null
    private var wasActive = false
    private var wasFlush = false
    private var baselineAbsHum: Double? = null
    private var lastSkinTempX100 = 0

    // per-session trackers for the FE02 translation
    private var peakDah = 0
    private var hrSum = 0L; private var hrN = 0; private var hrMin = 0; private var hrMax = 0

    /** Session running on the pod but its start is not yet known (FE02 read outstanding). */
    val needsSessionPin: Boolean @Synchronized get() = wasActive && sessionBase == null

    /** Call on every new connection. The pod keeps running; we just forget our view. */
    @Synchronized fun reset() {
        lastVitals = null; lastSession = null; epochOffsetS = null; sessionBase = null; wasActive = false; wasFlush = false
        baselineAbsHum = null
    }

    private fun sessionRel(uptime: Long): Long {
        val base = sessionBase ?: return uptime
        return (uptime - base).coerceAtLeast(0)
    }

    @Synchronized fun onVitals(bytes: ByteArray): VitalsOut {
        val v = HwVitals.parse(bytes)
        epochOffsetS = nowEpochS() - v.uptimeS

        // --- session time base
        if (v.sessionActive && !wasActive) {
            if (lastVitals != null) {
                // Rising edge seen live: a new session starts now.
                sessionBase = v.uptimeS
                peakDah = 0; hrSum = 0; hrN = 0; hrMin = 0; hrMax = 0
                baselineAbsHum = null
            } else {
                // First packet of a connection that joined a RUNNING session: only FE02's
                // running duration can pin the true start. Without it the base stays unknown
                // and LOGGING is withheld (see mapFlags below) so nothing is stored at a wrong
                // time — BlePodSource re-reads FE02 while [needsSessionPin] is true.
                sessionBase = lastSession?.let { v.uptimeS - it.durationS }
            }
        }
        if (!v.sessionActive && wasActive) sessionBase = null
        wasActive = v.sessionActive

        // --- sweat: abs humidity rise over a slow baseline (~10 min time constant,
        //     frozen during a flush so the baseline doesn't chase the event)
        val ah = v.absHumX100.toDouble()
        val base = baselineAbsHum ?: ah
        baselineAbsHum = if (v.flushActive) base else base + (ah - base) / 600.0
        val dah = (ah - base).roundToInt()
        val sweat = when {
            v.flushActive && !wasFlush -> SweatFlag.START
            v.flushActive -> SweatFlag.ONGOING
            else -> SweatFlag.NONE
        }
        wasFlush = v.flushActive

        // --- heart rate: only when locked; 0 is the internal "no reading", never shown
        val hr = v.hrShowBpm?.roundToInt()?.coerceIn(1, 255) ?: 0
        if (v.sessionActive) {
            peakDah = maxOf(peakDah, dah)
            if (hr > 0) { hrSum += hr; hrN++; hrMin = if (hrMin == 0) hr else minOf(hrMin, hr); hrMax = maxOf(hrMax, hr) }
        }

        val skin = v.skinTempX100 ?: lastSkinTempX100
        if (v.skinTempX100 != null) lastSkinTempX100 = v.skinTempX100

        val tS = sessionRel(v.uptimeS)
        val vitals = LiveVitals(
            tS = tS,
            hrBpm = hr,
            hrQuality = v.quality,
            skinTempX100 = skin,
            skinRhX100 = v.skinRhX100,
            ambTempX100 = NO_AMBIENT_TEMP_X100,
            ambRhX100 = NO_AMBIENT_RH_X100,
            motionIndex = 0,                        // no accelerometer on this pod
            sleepState = SleepState.UNKNOWN,        // no sleep staging without an IMU
            sweatFlag = sweat,
            battPct = v.battPct ?: HwConst.BATT_UNKNOWN,
            flags = mapFlags(v.flags, tempMissing = v.skinTempX100 == null, timeBaseKnown = sessionBase != null),
            absHumX100 = v.absHumX100,
            dahDirectX100 = dah,
        )
        lastVitals = v
        return VitalsOut(vitals, extFor(tS, v.spo2Pct, v.quality), v.battPct, v)
    }

    @Synchronized fun onHrv(bytes: ByteArray): HrvSummary {
        val h = HwHrv.parse(bytes)
        return HrvSummary(
            windowEndTimeS = sessionRel(h.uptimeS),
            meanIbiMs = h.meanRrMs,
            sdnnMsX10 = h.sdnnX10,
            rmssdMsX10 = h.rmssdX10,
            pnn50Pct = 0,                            // not reported by the pod
            beatsAccepted = h.beats,
            beatsRejected = 0,
            quality = h.quality,
            flags = if (h.usable) HrvFlags.VALID else HrvFlags.LOW_BEATS,
        )
    }

    /** FE02 → internal summary. Also remembers the raw summary for replay windowing. */
    @Synchronized fun onSession(bytes: ByteArray): SessionSummary {
        val s = HwSession.parse(bytes)
        lastSession = s
        // While a session runs FE02 carries the RUNNING duration, which pins the true start
        // (matters when we connected mid-session and vitals arrived before this read).
        val lv = lastVitals
        if (lv != null && lv.sessionActive) {
            val pinned = lv.uptimeS - s.durationS
            val cur = sessionBase
            if (cur == null || kotlin.math.abs(cur - pinned) > 2) sessionBase = pinned
        }
        return SessionSummary(
            sessionLenS = s.durationS,
            epochsLogged = (s.durationS / Cadence.EPOCH_S).toInt().coerceAtMost(0xFFFF),
            sweatEvents = s.flushEvents,             // PROVISIONAL on the pod
            longestSweatS = 0,
            peakDahX100 = peakDah.coerceAtLeast(0),
            hrMeanBpm = if (hrN > 0) (hrSum / hrN).toInt() else 0,
            hrMinBpm = hrMin,
            hrMaxBpm = hrMax,
            pctWake = 0, pctLight = 0, pctDeep = 0,  // no sleep staging on this pod
            battPct = s.battPct ?: HwConst.BATT_UNKNOWN,
            slot = 0,                                // one RAM log, no night slots
        )
    }

    // ------------------------------------------------------------------ replay
    private val frames = HashMap<Int, HwRecord>()
    var replayCrcFailures = 0; private set
    val replayReceived: Int @Synchronized get() = frames.size

    @Synchronized fun beginReplay() { frames.clear(); replayCrcFailures = 0 }

    /** Returns false (and counts it) when the record's own CRC fails — the row is dropped. */
    @Synchronized fun onReplayFrame(bytes: ByteArray): Boolean = try {
        val r = HwRecord.parseFrame(bytes); frames[r.seq] = r; true
    } catch (e: HwPacketException) { replayCrcFailures++; false }

    /**
     * Keep the rows of the most recent session and map them onto the app's 30 s grid.
     * Window: [start, start + duration] in pod uptime, from FE02 start_epoch and the
     * phone↔uptime offset; if the clock was never set, the last contiguous run of rows
     * flagged SESSION_ACTIVE.
     */
    @Synchronized fun finishReplay(): ReplayResult {
        val rows = frames.values.sortedBy { it.seq }
        val maxSeq = rows.maxOfOrNull { it.seq } ?: -1
        val missing = (maxSeq + 1) - rows.size
        val s = lastSession
        val off = epochOffsetS
        val window: LongRange? = when {
            s?.startEpoch != null && off != null -> {
                val start = s.startEpoch - off
                (start - 2)..(start + s.durationS + HwConst.DEFAULT_LOG_PERIOD_S)
            }
            else -> null
        }
        val inSession: List<HwRecord> = if (window != null) {
            // Rows logged during the session carry SESSION_ACTIVE; the window separates this
            // session from earlier ones still in the ring.
            rows.filter { it.uptimeS in window && HwFlags.has(it.flags, HwFlags.SESSION_ACTIVE) }
        } else {
            val last = rows.indexOfLast { HwFlags.has(it.flags, HwFlags.SESSION_ACTIVE) }
            if (last < 0) emptyList() else {
                var first = last
                while (first > 0 && HwFlags.has(rows[first - 1].flags, HwFlags.SESSION_ACTIVE)) first--
                rows.subList(first, last + 1)
            }
        }
        val startUptime = window?.let { it.first + 2 } ?: inSession.firstOrNull()?.uptimeS ?: 0L
        return ReplayResult(toEpochGrid(inSession, startUptime), rows.size, replayCrcFailures, missing, inSession.size)
    }

    /** Sample-and-hold each pod row onto 30 s epochs until the next row (default 60 s log). */
    internal fun toEpochGrid(rows: List<HwRecord>, startUptime: Long): List<LogRecord> {
        val out = ArrayList<LogRecord>()
        var base: Double? = null
        var prevFlush = false
        var lastSkin = rows.firstOrNull { it.skinTempX100 != null }?.skinTempX100 ?: 0
        for ((i, r) in rows.withIndex()) {
            val rel = (r.uptimeS - startUptime).coerceAtLeast(0)
            val e0 = rel / Cadence.EPOCH_S * Cadence.EPOCH_S
            val nextE = rows.getOrNull(i + 1)?.let { (it.uptimeS - startUptime).coerceAtLeast(0) / Cadence.EPOCH_S * Cadence.EPOCH_S }
            val flush = HwFlags.has(r.flags, HwFlags.FLUSH_ACTIVE)
            val ah = r.absHumX100.toDouble()
            val b = base ?: ah
            // Baseline tau ≈ 10 min expressed in rows of this log's real spacing.
            val spacing = rows.getOrNull(i + 1)?.let { (it.uptimeS - r.uptimeS).coerceAtLeast(1) } ?: HwConst.DEFAULT_LOG_PERIOD_S.toLong()
            base = if (flush) b else b + (ah - b) * (spacing.toDouble() / 600.0).coerceAtMost(1.0)
            // Stored dah is a u16 on the wire (LogRecord / replay image): a dip below baseline
            // must clamp to 0, or it wraps to ~655 g/m³ — a huge fake spike.
            val dah = (ah - b).roundToInt().coerceAtLeast(0)
            val sweat = when { flush && !prevFlush -> SweatFlag.START; flush -> SweatFlag.ONGOING; else -> SweatFlag.NONE }
            prevFlush = flush
            if (r.skinTempX100 != null) lastSkin = r.skinTempX100
            val hr = if (HwFlags.has(r.flags, HwFlags.HR_LOCKED) && r.hrX10 != null) (r.hrX10 / 10f).roundToInt().coerceIn(1, 255) else 0
            val ext = extFor(0, r.spo2Pct, r.quality)
            var e = e0
            val until = if (nextE != null && nextE > e0) nextE else e0 + Cadence.EPOCH_S
            while (e < until) {
                if (out.lastOrNull()?.tS != e) out.add(LogRecord(
                    tS = e, hrBpm = hr, hrQuality = r.quality, skinTempX100 = lastSkin, skinRhX100 = r.skinRhX100,
                    ambTempX100 = NO_AMBIENT_TEMP_X100, ambRhX100 = NO_AMBIENT_RH_X100, motionIndex = 0,
                    sleepState = SleepState.UNKNOWN,
                    sweatFlag = if (e == e0) sweat else if (flush) SweatFlag.ONGOING else SweatFlag.NONE,
                    battPct = r.battPct ?: HwConst.BATT_UNKNOWN,
                    flags = mapFlags(r.flags, tempMissing = r.skinTempX100 == null),
                    dahX100 = dah, hrvMeanIbiMs = 0, hrvSdnnMsX10 = 0, hrvRmssdMsX10 = 0, hrvPnn50Pct = 0,
                    hrvQuality = 0, hrvFlags = 0, vcellCv = 0,
                    edaX100 = 0, spo2X10 = ext.spo2X10, perfusionX100 = 0, extFlags = ext.extFlags,
                ))
                e += Cadence.EPOCH_S
                if (e - e0 >= 240) break // never hold one row longer than the pod's max interval
            }
        }
        return out
    }

    /** Re-encode converted records as the internal replay stream the manager consumes. */
    fun internalFrames(records: List<LogRecord>, slot: Int = 0): List<ByteArray> {
        val image = java.io.ByteArrayOutputStream()
        records.forEach { image.write(it.encode()) }
        return ReplayAssembler.frames(slot, image.toByteArray(), records.size)
    }

    // ------------------------------------------------------------------ commands
    sealed class Plan {
        data class Write(val bytes: ByteArray, val label: String) : Plan()
        /** No opcode exists — read FE02 instead (READ property). */
        data object ReadSummary : Plan()
        /** Read FE02 for the window, then 0x04 and collect FE04. */
        data object Replay : Plan()
        data object Unsupported : Plan()
    }

    /** Internal (paper-spec) command → what to do on the real pod. Opcodes differ! */
    fun plan(cmd: PodCommand): Plan = when (cmd) {
        is PodCommand.TimeSync -> Plan.Write(HwOp.timeSync(cmd.unixSeconds), "time sync")
        PodCommand.StartSession -> Plan.Write(HwOp.simple(HwOp.SESSION_START), "start")
        PodCommand.StopSession -> Plan.Write(HwOp.simple(HwOp.SESSION_STOP), "stop")
        PodCommand.PushSummary -> Plan.ReadSummary
        is PodCommand.ReplaySlot -> Plan.Replay
        is PodCommand.HapticTest -> Plan.Write(HwOp.simple(HwOp.IDENTIFY), "identify (blink)") // no motor; blink instead
        PodCommand.FormatFlash -> Plan.Write(HwOp.simple(HwOp.LOG_ERASE), "erase log")
        PodCommand.FuelGaugeRelearn, PodCommand.AbortReplay -> Plan.Unsupported
    }

    private fun extFor(tS: Long, spo2: Int?, quality: Int): ExtendedVitals {
        val valid = spo2 != null && quality >= HwConst.SPO2_MIN_QUALITY
        return ExtendedVitals(tS, 0, (spo2 ?: 0) * 10, 0, if (valid) ExtFlags.SPO2_VALID else 0)
    }

    companion object {
        /** No room sensor on this pod: sentinels the UI/analytics must treat as "absent". */
        const val NO_AMBIENT_TEMP_X100 = -32768
        const val NO_AMBIENT_RH_X100 = 0

        fun hasAmbient(ambTempX100: Int) = ambTempX100 != NO_AMBIENT_TEMP_X100

        /** Hardware FE01 flags → internal PodFlags bits. */
        fun mapFlags(hw: Int, tempMissing: Boolean, timeBaseKnown: Boolean = true): Int {
            var f = PodFlags.POD_DETECTED
            if (HwFlags.has(hw, HwFlags.FINGER)) f = f or PodFlags.PPG_ACTIVE
            if (HwFlags.has(hw, HwFlags.SESSION_ACTIVE) && timeBaseKnown) f = f or PodFlags.LOGGING
            if (HwFlags.has(hw, HwFlags.TIME_VALID)) f = f or PodFlags.TIME_SYNCED
            if (HwFlags.has(hw, HwFlags.LOW_BATTERY)) f = f or PodFlags.LOW_BATT
            if (tempMissing) f = f or PodFlags.SENSOR_FAULT
            return f
        }
    }
}
