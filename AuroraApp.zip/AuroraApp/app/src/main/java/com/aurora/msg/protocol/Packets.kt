package com.aurora.msg.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Little-endian helpers. Every multi-byte field in every packet is LE (spec §2). */
internal fun ByteArray.le(): ByteBuffer = ByteBuffer.wrap(this).order(ByteOrder.LITTLE_ENDIAN)
internal fun ByteBuffer.u8(): Int = get().toInt() and 0xFF
internal fun ByteBuffer.u16(): Int = short.toInt() and 0xFFFF
internal fun ByteBuffer.s16(): Int = short.toInt()
internal fun ByteBuffer.u32(): Long = int.toLong() and 0xFFFFFFFFL

class PacketFormatException(message: String) : IllegalArgumentException(message)

/* ------------------------------------------------------------------------- */
/* FE01 — LIVE VITALS · 20 bytes · 1 Hz (spec §3)                              */
/* ------------------------------------------------------------------------- */
data class LiveVitals(
    val tS: Long,
    val hrBpm: Int,
    val hrQuality: Int,
    val skinTempX100: Int,
    val skinRhX100: Int,
    val ambTempX100: Int,
    val ambRhX100: Int,
    val motionIndex: Int,
    val sleepState: SleepState,
    val sweatFlag: SweatFlag,
    val battPct: Int,
    val flags: Int,
    /**
     * Hardware protocol v1 only (null from the demo / paper-spec path): absolute humidity
     * at the skin straight from the pod, g/m³ ×100 — the glove's key sweat signal.
     */
    val absHumX100: Int? = null,
    /**
     * Hardware only: rise of [absHumX100] above its slow baseline, g/m³ ×100, computed by
     * [HwAdapter]. When present the epoch aggregator uses it as dah instead of the
     * skin-vs-room Magnus formula (the real pod has no room sensor).
     */
    val dahDirectX100: Int? = null,
) {
    val skinTempC: Float get() = skinTempX100 / 100f
    val ambTempC: Float get() = ambTempX100 / 100f
    val skinRh: Float get() = skinRhX100 / 100f
    val ambRh: Float get() = ambRhX100 / 100f
    val ppgActive: Boolean get() = PodFlags.has(flags, PodFlags.PPG_ACTIVE)
    val logging: Boolean get() = PodFlags.has(flags, PodFlags.LOGGING)
    val timeSynced: Boolean get() = PodFlags.has(flags, PodFlags.TIME_SYNCED)
    val sensorFault: Boolean get() = PodFlags.has(flags, PodFlags.SENSOR_FAULT)
    val podDetected: Boolean get() = PodFlags.has(flags, PodFlags.POD_DETECTED)
    val charging: Boolean get() = PodFlags.has(flags, PodFlags.CHARGING)
    val lowBatt: Boolean get() = PodFlags.has(flags, PodFlags.LOW_BATT)

    /** Valid HR reading this second? (0 means no reading — never show "0 bpm".) */
    val hasHr: Boolean get() = hrBpm > 0 && QualityBand.of(hrQuality) != QualityBand.HIDE

    /** Seconds until the next PPG burst starts, from the 600 s cadence. */
    val secondsToNextPpg: Int get() {
        val inCycle = (tS % Cadence.HRV_PERIOD_S).toInt()
        return if (inCycle < Cadence.PPG_BURST_S) 0 else Cadence.HRV_PERIOD_S - inCycle
    }

    fun encode(): ByteArray {
        val b = ByteBuffer.allocate(SIZE).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(tS.toInt())
        b.put(hrBpm.toByte()); b.put(hrQuality.toByte())
        b.putShort(skinTempX100.toShort()); b.putShort(skinRhX100.toShort())
        b.putShort(ambTempX100.toShort()); b.putShort(ambRhX100.toShort())
        b.putShort(motionIndex.toShort())
        b.put(sleepState.code.toByte()); b.put(sweatFlag.code.toByte())
        b.put(battPct.toByte()); b.put(flags.toByte())
        return b.array()
    }

    companion object {
        const val SIZE = 20
        fun parse(bytes: ByteArray): LiveVitals {
            if (bytes.size < SIZE) throw PacketFormatException("Live vitals packet ${bytes.size} B, expected $SIZE")
            val b = bytes.le()
            return LiveVitals(
                tS = b.u32(),
                hrBpm = b.u8(), hrQuality = b.u8(),
                skinTempX100 = b.s16(), skinRhX100 = b.u16(),
                ambTempX100 = b.s16(), ambRhX100 = b.u16(),
                motionIndex = b.u16(),
                sleepState = SleepState.fromCode(b.u8()),
                sweatFlag = SweatFlag.fromCode(b.u8()),
                battPct = b.u8(), flags = b.u8(),
            )
        }
    }
}

/* ------------------------------------------------------------------------- */
/* FE05 — HRV SUMMARY · 15 bytes · every 10 min (spec §4)                      */
/* ------------------------------------------------------------------------- */
data class HrvSummary(
    val windowEndTimeS: Long,
    val meanIbiMs: Int,
    val sdnnMsX10: Int,
    val rmssdMsX10: Int,
    val pnn50Pct: Int,
    val beatsAccepted: Int,
    val beatsRejected: Int,
    val quality: Int,
    val flags: Int,
) {
    /** THE ONE RULE: never display unless VALID. */
    val isValid: Boolean get() = HrvFlags.has(flags, HrvFlags.VALID)
    val isWallClock: Boolean get() = HrvFlags.has(flags, HrvFlags.WALL_CLOCK)
    val sdnnMs: Float get() = sdnnMsX10 / 10f
    val rmssdMs: Float get() = rmssdMsX10 / 10f
    val hrFromIbi: Int get() = if (meanIbiMs > 0) (60_000f / meanIbiMs).toInt() else 0

    fun encode(): ByteArray {
        val b = ByteBuffer.allocate(SIZE).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(windowEndTimeS.toInt())
        b.putShort(meanIbiMs.toShort()); b.putShort(sdnnMsX10.toShort()); b.putShort(rmssdMsX10.toShort())
        b.put(pnn50Pct.toByte()); b.put(beatsAccepted.toByte()); b.put(beatsRejected.toByte())
        b.put(quality.toByte()); b.put(flags.toByte())
        return b.array()
    }

    companion object {
        const val SIZE = 15
        fun parse(bytes: ByteArray): HrvSummary {
            if (bytes.size < SIZE) throw PacketFormatException("HRV packet ${bytes.size} B, expected $SIZE")
            val b = bytes.le()
            return HrvSummary(
                windowEndTimeS = b.u32(),
                meanIbiMs = b.u16(), sdnnMsX10 = b.u16(), rmssdMsX10 = b.u16(),
                pnn50Pct = b.u8(), beatsAccepted = b.u8(), beatsRejected = b.u8(),
                quality = b.u8(), flags = b.u8(),
            )
        }
    }
}

/* ------------------------------------------------------------------------- */
/* FE06 — EXTENDED VITALS · 20 bytes · 1 Hz (brief §1)                         */
/* ------------------------------------------------------------------------- */
/**
 * EDA / SpO2 / perfusion, same tick as the FE01 packet it accompanies.
 * Firmware 1.0.0 never sends this; the demo pod does, and a future firmware just works.
 */
data class ExtendedVitals(
    val tS: Long,
    /** Skin conductance, microsiemens ×100 (typ 100–2000; flash spike +200–1000). */
    val edaX100: Int,
    /** Blood oxygen % ×10 (e.g. 968 = 96.8 %). */
    val spo2X10: Int,
    /** PPG perfusion index % ×100 (blood flow; typ 50–400). */
    val perfusionX100: Int,
    val extFlags: Int,
) {
    val edaValid: Boolean get() = ExtFlags.has(extFlags, ExtFlags.EDA_VALID)
    val spo2Valid: Boolean get() = ExtFlags.has(extFlags, ExtFlags.SPO2_VALID)
    val perfusionValid: Boolean get() = ExtFlags.has(extFlags, ExtFlags.PI_VALID)

    /** Display values — null unless the VALID bit is set (brief §1: show ONLY when valid). */
    val edaUs: Float? get() = if (edaValid) edaX100 / 100f else null
    val spo2Pct: Float? get() = if (spo2Valid) spo2X10 / 10f else null
    val perfusionPct: Float? get() = if (perfusionValid) perfusionX100 / 100f else null

    fun encode(): ByteArray {
        val b = ByteBuffer.allocate(SIZE).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(tS.toInt())
        b.putShort(edaX100.toShort()); b.putShort(spo2X10.toShort()); b.putShort(perfusionX100.toShort())
        b.put(extFlags.toByte())
        // bytes 11–19 reserved, left zero by allocate()
        return b.array()
    }

    companion object {
        const val SIZE = 20

        /** Returns null on wrong length (brief §1) — unlike v1 parsers, which throw. */
        fun parse(bytes: ByteArray): ExtendedVitals? {
            if (bytes.size < SIZE) return null
            val b = bytes.le()
            return ExtendedVitals(
                tS = b.u32(),
                edaX100 = b.u16(), spo2X10 = b.u16(), perfusionX100 = b.u16(),
                extFlags = b.u8(),
            )
        }
    }
}

/* ------------------------------------------------------------------------- */
/* FE02 — SESSION SUMMARY · 20 bytes · on stop (spec §11)                      */
/* ------------------------------------------------------------------------- */
data class SessionSummary(
    val sessionLenS: Long,
    val epochsLogged: Int,
    val sweatEvents: Int,
    val longestSweatS: Int,
    val peakDahX100: Int,
    val hrMeanBpm: Int,
    val hrMinBpm: Int,
    val hrMaxBpm: Int,
    val pctWake: Int,
    val pctLight: Int,
    val pctDeep: Int,
    val battPct: Int,
    val slot: Int,
) {
    val peakDah: Float get() = peakDahX100 / 100f

    fun encode(): ByteArray {
        val b = ByteBuffer.allocate(SIZE).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(sessionLenS.toInt())
        b.putShort(epochsLogged.toShort()); b.putShort(sweatEvents.toShort())
        b.putShort(longestSweatS.toShort()); b.putShort(peakDahX100.toShort())
        b.put(hrMeanBpm.toByte()); b.put(hrMinBpm.toByte()); b.put(hrMaxBpm.toByte())
        b.put(pctWake.toByte()); b.put(pctLight.toByte()); b.put(pctDeep.toByte())
        b.put(battPct.toByte()); b.put(slot.toByte())
        return b.array()
    }

    companion object {
        const val SIZE = 20
        fun parse(bytes: ByteArray): SessionSummary {
            if (bytes.size < SIZE) throw PacketFormatException("Summary packet ${bytes.size} B, expected $SIZE")
            val b = bytes.le()
            return SessionSummary(
                sessionLenS = b.u32(),
                epochsLogged = b.u16(), sweatEvents = b.u16(),
                longestSweatS = b.u16(), peakDahX100 = b.u16(),
                hrMeanBpm = b.u8(), hrMinBpm = b.u8(), hrMaxBpm = b.u8(),
                pctWake = b.u8(), pctLight = b.u8(), pctDeep = b.u8(),
                battPct = b.u8(), slot = b.u8(),
            )
        }
    }
}

/* ------------------------------------------------------------------------- */
/* LOG RECORD · 34 bytes (v1) / 42 bytes (v2) · one per 30 s epoch             */
/* (spec §10; v2 extension brief §1)                                           */
/* ------------------------------------------------------------------------- */
data class LogRecord(
    val tS: Long,
    val hrBpm: Int,
    val hrQuality: Int,
    val skinTempX100: Int,
    val skinRhX100: Int,
    val ambTempX100: Int,
    val ambRhX100: Int,
    val motionIndex: Int,
    val sleepState: SleepState,
    val sweatFlag: SweatFlag,
    val battPct: Int,
    val flags: Int,
    /** Differential absolute humidity g/m³ ×100 — THE sweat number. */
    val dahX100: Int,
    val hrvMeanIbiMs: Int,
    val hrvSdnnMsX10: Int,
    val hrvRmssdMsX10: Int,
    val hrvPnn50Pct: Int,
    val hrvQuality: Int,
    val hrvFlags: Int,
    val vcellCv: Int,
    /**
     * v2 ext fields (brief §1): null on every v1 record. [extFlags] non-null marks a v2
     * record; the value fields hold the wire bytes verbatim — use the gated accessors
     * below for anything user-visible (a field counts only when its VALID bit is set).
     */
    val edaX100: Int? = null,
    val spo2X10: Int? = null,
    val perfusionX100: Int? = null,
    val extFlags: Int? = null,
) {
    val dah: Float get() = dahX100 / 100f
    val skinTempC: Float get() = skinTempX100 / 100f
    val ambTempC: Float get() = ambTempX100 / 100f
    val hrvFresh: Boolean get() = PodFlags.has(flags, PodFlags.HRV_FRESH)
    val hrvValid: Boolean get() = HrvFlags.has(hrvFlags, HrvFlags.VALID)
    val cellVolts: Float? get() = if (vcellCv == 0) null else 2.50f + vcellCv / 100f
    val hasHr: Boolean get() = hrBpm > 0 && QualityBand.of(hrQuality) != QualityBand.HIDE

    /** True for a v2 record (any record parsed from / destined for the 42-byte layout). */
    val hasExt: Boolean get() = extFlags != null

    /** Gated ext readings — non-null ONLY when the record is v2 AND the VALID bit is set. */
    val validEdaX100: Int? get() = if (extFlags != null && ExtFlags.has(extFlags, ExtFlags.EDA_VALID)) edaX100 else null
    val validSpo2X10: Int? get() = if (extFlags != null && ExtFlags.has(extFlags, ExtFlags.SPO2_VALID)) spo2X10 else null
    val validPerfusionX100: Int? get() = if (extFlags != null && ExtFlags.has(extFlags, ExtFlags.PI_VALID)) perfusionX100 else null

    /** Display conveniences over the gated readings. */
    val edaUs: Float? get() = validEdaX100?.let { it / 100f }
    val spo2Pct: Float? get() = validSpo2X10?.let { it / 10f }
    val perfusionPct: Float? get() = validPerfusionX100?.let { it / 100f }

    /**
     * Encode WITH a correct CRC — used by the demo simulator and tests.
     * Emits 34 B when the ext fields are absent (v1) and 42 B when present (v2, brief §1);
     * either way the CRC covers everything up to it and sits in the last two bytes.
     */
    fun encode(): ByteArray {
        val size = if (hasExt) SIZE_V2 else SIZE
        val b = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(tS.toInt())
        b.put(hrBpm.toByte()); b.put(hrQuality.toByte())
        b.putShort(skinTempX100.toShort()); b.putShort(skinRhX100.toShort())
        b.putShort(ambTempX100.toShort()); b.putShort(ambRhX100.toShort())
        b.putShort(motionIndex.toShort())
        b.put(sleepState.code.toByte()); b.put(sweatFlag.code.toByte())
        b.put(battPct.toByte()); b.put(flags.toByte())
        b.putShort(dahX100.toShort())
        b.putShort(hrvMeanIbiMs.toShort()); b.putShort(hrvSdnnMsX10.toShort()); b.putShort(hrvRmssdMsX10.toShort())
        b.put(hrvPnn50Pct.toByte()); b.put(hrvQuality.toByte()); b.put(hrvFlags.toByte())
        b.put(vcellCv.toByte())
        if (hasExt) {
            // v2 tail (brief §1): bytes 32–39, then CRC. Reserved byte 39 stays zero.
            b.putShort((edaX100 ?: 0).toShort())
            b.putShort((spo2X10 ?: 0).toShort())
            b.putShort((perfusionX100 ?: 0).toShort())
            b.put((extFlags ?: 0).toByte())
        }
        val arr = b.array()
        val crc = Crc16.ccittFalse(arr, 0, size - 2)
        arr[size - 2] = (crc and 0xFF).toByte()
        arr[size - 1] = ((crc shr 8) and 0xFF).toByte()
        return arr
    }

    companion object {
        const val SIZE = 34
        const val SIZE_V2 = 42
        const val CRC_COVERAGE = 32

        /**
         * Returns null when the CRC fails — such records must be DROPPED (spec §8.3) —
         * or when [size] is not a supported record size (34 = v1, 42 = v2; brief §1).
         * The CRC always covers the first size−2 bytes and sits in the last two.
         */
        fun parse(bytes: ByteArray, offset: Int = 0, size: Int = SIZE): LogRecord? {
            if (size != SIZE && size != SIZE_V2) return null
            if (bytes.size - offset < size) return null
            val stored = (bytes[offset + size - 2].toInt() and 0xFF) or ((bytes[offset + size - 1].toInt() and 0xFF) shl 8)
            val computed = Crc16.ccittFalse(bytes, offset, size - 2)
            if (stored != computed) return null
            val b = ByteBuffer.wrap(bytes, offset, size).order(ByteOrder.LITTLE_ENDIAN)
            return LogRecord(
                tS = b.u32(),
                hrBpm = b.u8(), hrQuality = b.u8(),
                skinTempX100 = b.s16(), skinRhX100 = b.u16(),
                ambTempX100 = b.s16(), ambRhX100 = b.u16(),
                motionIndex = b.u16(),
                sleepState = SleepState.fromCode(b.u8()),
                sweatFlag = SweatFlag.fromCode(b.u8()),
                battPct = b.u8(), flags = b.u8(),
                dahX100 = b.u16(),
                hrvMeanIbiMs = b.u16(), hrvSdnnMsX10 = b.u16(), hrvRmssdMsX10 = b.u16(),
                hrvPnn50Pct = b.u8(), hrvQuality = b.u8(), hrvFlags = b.u8(),
                vcellCv = b.u8(),
                // v2 tail — a v1 record parses exactly as before, ext fields stay null.
                edaX100 = if (size == SIZE_V2) b.u16() else null,
                spo2X10 = if (size == SIZE_V2) b.u16() else null,
                perfusionX100 = if (size == SIZE_V2) b.u16() else null,
                extFlags = if (size == SIZE_V2) b.u8() else null, // reserved byte 39 is skipped
            )
        }
    }
}

/* ------------------------------------------------------------------------- */
/* DEVICE INFORMATION (0x180A)                                                 */
/* ------------------------------------------------------------------------- */
data class DeviceInfo(
    val manufacturer: String = "",
    val model: String = "",
    val hardwareRevision: String = "",
    val softwareRevision: String = "",
) {
    val firmwareMismatch: Boolean
        get() = softwareRevision.isNotBlank() && softwareRevision != AuroraUuids.BUILT_AGAINST_FIRMWARE
}
