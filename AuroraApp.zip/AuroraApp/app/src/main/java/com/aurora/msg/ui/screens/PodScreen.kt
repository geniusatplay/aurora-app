package com.aurora.msg.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothSearching
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.msg.R
import com.aurora.msg.pod.ConnectionState
import com.aurora.msg.pod.ReplayStatus
import com.aurora.msg.protocol.AuroraUuids
import com.aurora.msg.ui.AppViewModel
import com.aurora.msg.ui.Fmt
import com.aurora.msg.ui.isHardwarePod
import com.aurora.msg.ui.components.AuroraCard
import com.aurora.msg.ui.components.BannerTone
import com.aurora.msg.ui.components.InfoBanner
import com.aurora.msg.ui.components.LabeledValue
import com.aurora.msg.ui.components.Pill
import com.aurora.msg.ui.components.SectionHeader
import com.aurora.msg.ui.theme.Aurora
import com.aurora.msg.ui.theme.AuroraThemeExtras

private fun blePermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val base = arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) base + Manifest.permission.POST_NOTIFICATIONS else base
    } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

@Composable
fun PodScreen(vm: AppViewModel, inner: PaddingValues, onOpenNight: (Long) -> Unit) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val conn by vm.pod.connectionState.collectAsStateWithLifecycle()
    val scan by vm.pod.scanResults.collectAsStateWithLifecycle()
    val info by vm.pod.deviceInfo.collectAsStateWithLifecycle()
    val battery by vm.pod.batteryPct.collectAsStateWithLifecycle()
    val synced by vm.pod.timeSynced.collectAsStateWithLifecycle()
    val active by vm.pod.activeSession.collectAsStateWithLifecycle()
    val replay by vm.pod.replayStatus.collectAsStateWithLifecycle()
    val slotsFlow = remember { vm.sessions.observeSlots() }
    val slots by slotsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val cards by vm.nightCards.collectAsStateWithLifecycle()
    val caps by vm.pod.capabilities.collectAsStateWithLifecycle()
    // The real glove (hardware protocol v1): one RAM log, no slots, LED instead of motor, no battery cell.
    val hwPod = !settings.demoMode && isHardwarePod(caps, info)
    var blinkSent by remember { mutableStateOf(false) }
    var showFormat by remember { mutableStateOf(false) }
    var formatText by remember { mutableStateOf("") }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        val ok = granted.filterKeys { it != Manifest.permission.POST_NOTIFICATIONS }.values.all { it }
        if (ok) vm.pod.startScan()
    }
    fun scanWithPermission() {
        if (settings.demoMode) { vm.pod.startScan(); return }
        val missing = blePermissions().filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) vm.pod.startScan() else launcher.launch(missing.toTypedArray())
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = inner.calculateTopPadding(), bottom = inner.calculateBottomPadding() + 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Column(Modifier.statusBarsPadding().padding(top = 8.dp)) {
                Text(stringResource(R.string.pod_title), style = MaterialTheme.typography.headlineMedium)
                Text(if (settings.demoMode) stringResource(R.string.pod_subtitle_demo) else if (hwPod) stringResource(R.string.hw_pod_subtitle) else stringResource(R.string.pod_subtitle_hw), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Honesty note (PROTOCOL §8): this build has no pairing / encryption.
        if (hwPod) item { InfoBanner(stringResource(R.string.hw_pod_security_note), tone = BannerTone.Warning, icon = Icons.Rounded.Warning) }

        // Connection card
        item {
            AuroraCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (conn is ConnectionState.Scanning) Icons.Rounded.BluetoothSearching else Icons.Rounded.Bluetooth, null, tint = if (conn.isConnected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            when (val c = conn) {
                                is ConnectionState.Connected -> stringResource(R.string.pod_conn_connected, c.name)
                                is ConnectionState.Connecting -> stringResource(R.string.pod_conn_connecting, c.name)
                                ConnectionState.Scanning -> stringResource(R.string.pod_conn_scanning)
                                ConnectionState.Off -> stringResource(R.string.pod_conn_off)
                                is ConnectionState.Error -> stringResource(R.string.pod_conn_error)
                                ConnectionState.Disconnected -> stringResource(R.string.pod_conn_disconnected)
                            }, style = MaterialTheme.typography.titleMedium,
                        )
                        (conn as? ConnectionState.Error)?.let { Text(if (it.arg != null) stringResource(it.messageRes, it.arg) else stringResource(it.messageRes), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                        if (conn.isConnected) Text(if (synced) stringResource(R.string.pod_clock_synced) else stringResource(R.string.pod_clock_syncing), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (conn is ConnectionState.Scanning || conn is ConnectionState.Connecting) CircularProgressIndicator(Modifier.width(22.dp).height(22.dp), color = MaterialTheme.colorScheme.primary, strokeWidth = 2.dp)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (conn.isConnected) {
                        OutlinedButton(onClick = { vm.pod.disconnect() }, shape = CircleShape, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.pod_disconnect)) }
                    } else {
                        Button(onClick = { scanWithPermission() }, shape = CircleShape, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary), enabled = conn !is ConnectionState.Scanning) { Text(stringResource(R.string.pod_find)) }
                    }
                }
                if (scan.isNotEmpty() && !conn.isConnected) {
                    Spacer(Modifier.height(10.dp))
                    scan.forEach { p ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.titleSmall)
                                Text(stringResource(R.string.pod_scan_detail, p.address, p.rssi), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Button(onClick = { vm.pod.connect(p.address) }, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.inverseSurface, contentColor = MaterialTheme.colorScheme.inverseOnSurface)) { Text(stringResource(R.string.common_connect)) }
                        }
                    }
                }
                if (conn is ConnectionState.Off) { Spacer(Modifier.height(8.dp)); InfoBanner(stringResource(R.string.pod_bt_off_hint), tone = BannerTone.Warning) }
            }
        }

        // Device information
        if (conn.isConnected) item {
            AuroraCard {
                Text(stringResource(R.string.pod_device), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    LabeledValue(stringResource(R.string.pod_model), info?.model?.ifBlank { "—" } ?: "—", Modifier.weight(1f))
                    LabeledValue(stringResource(R.string.pod_firmware), info?.softwareRevision?.ifBlank { "—" } ?: "—", Modifier.weight(1f))
                    LabeledValue(stringResource(R.string.pod_battery), battery?.let { "$it%" } ?: if (hwPod) stringResource(R.string.hw_battery_unknown) else "—", Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
                Text(info?.hardwareRevision ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (!hwPod && info?.firmwareMismatch == true) {
                    Spacer(Modifier.height(8.dp))
                    InfoBanner(stringResource(R.string.pod_fw_mismatch, info?.softwareRevision ?: "", AuroraUuids.BUILT_AGAINST_FIRMWARE), tone = BannerTone.Warning, icon = Icons.Rounded.Warning)
                }
            }
        }

        // Session control
        item {
            AuroraCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.pod_tonight), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    if (active != null) Pill(stringResource(R.string.common_recording), MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    if (active != null) stringResource(R.string.pod_recording_since, Fmt.clock(active!!.startedAtEpochMs, settings))
                    else stringResource(R.string.pod_not_recording_hint),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                if (active == null) {
                    Button(onClick = { vm.startSession() }, enabled = conn.isConnected, shape = CircleShape, modifier = Modifier.fillMaxWidth().height(48.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) { Text(stringResource(R.string.pod_start)) }
                } else {
                    Button(onClick = { vm.stopSession() }, enabled = conn.isConnected, shape = CircleShape, modifier = Modifier.fillMaxWidth().height(48.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.inverseSurface, contentColor = MaterialTheme.colorScheme.inverseOnSurface)) { Text(stringResource(R.string.pod_stop)) }
                    if (!conn.isConnected) { Spacer(Modifier.height(8.dp)); InfoBanner(stringResource(R.string.pod_reconnect_to_stop), tone = BannerTone.Info) }
                }
            }
        }

        // Replay status
        if (replay.isActive) item {
            AuroraCard {
                Text(stringResource(R.string.pod_downloading), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                when (val r = replay) {
                    is ReplayStatus.Downloading -> {
                        LinearProgressIndicator(progress = { r.percent / 100f }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary, trackColor = AuroraThemeExtras.track)
                        Text(if (hwPod) stringResource(R.string.hw_pod_download_progress, r.percent) else stringResource(R.string.pod_download_progress, r.percent, r.slot), style = MaterialTheme.typography.bodySmall)
                    }
                    is ReplayStatus.WaitingForHeader -> { LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary, trackColor = AuroraThemeExtras.track); Text(if (hwPod) stringResource(R.string.night_replay_waiting) else stringResource(R.string.pod_waiting_slot, r.slot), style = MaterialTheme.typography.bodySmall) }
                    else -> Unit
                }
                TextButton(onClick = { vm.pod.cancelDownload() }) { Text(stringResource(R.string.common_cancel)) }
            }
        }

        // Real glove: ONE log in RAM, no slots — a single download action into the latest night.
        if (hwPod) {
            item { SectionHeader(stringResource(R.string.hw_pod_log_title), stringResource(R.string.hw_pod_log_sub)) }
            item {
                val target = cards.firstOrNull { it.session.source == com.aurora.msg.data.db.SessionSource.BLE && it.session.endedAtEpochMs != null }
                AuroraCard {
                    Text(stringResource(R.string.hw_pod_log_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (target != null) stringResource(R.string.hw_pod_log_target, Fmt.nightLabel(target.session.startedAtEpochMs)) else stringResource(R.string.hw_pod_log_no_session),
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { target?.let { vm.pod.downloadNight(it.session.id, it.session.slot ?: 0) } },
                        // The pod only holds its most recent session; not while one is still running.
                        enabled = conn.isConnected && target != null && active == null && !replay.isActive,
                        shape = CircleShape, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    ) { Text(stringResource(R.string.hw_pod_log_download)) }
                    (replay as? ReplayStatus.Failed)?.let {
                        Spacer(Modifier.height(8.dp)); InfoBanner(stringResource(it.messageRes, *it.args.toTypedArray()), tone = BannerTone.Error)
                    }
                    (replay as? ReplayStatus.Done)?.let {
                        Spacer(Modifier.height(8.dp))
                        InfoBanner(
                            stringResource(R.string.night_done_records, it.records) + (if (it.crcFailures > 0) stringResource(R.string.night_done_crc, it.crcFailures) else "") + (if (!it.complete) stringResource(R.string.night_done_incomplete) else "."),
                            tone = if (it.complete) BannerTone.Success else BannerTone.Warning,
                        )
                    }
                }
            }
        }

        // Slot inventory (spec §15.1 — the app's own record)
        if (!hwPod) item { SectionHeader(stringResource(R.string.pod_nights_title), stringResource(R.string.pod_nights_sub, slots.size)) }
        if (!hwPod && slots.size >= 12) item { InfoBanner(stringResource(R.string.pod_nearly_full), tone = BannerTone.Warning, icon = Icons.Rounded.Warning) }
        if (!hwPod && slots.isEmpty()) item { AuroraCard { Text(stringResource(R.string.pod_no_nights), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        if (!hwPod) items(slots, key = { it.slot }) { s ->
            val card = cards.firstOrNull { it.session.id == s.sessionId }
            AuroraCard(onClick = { s.sessionId?.let(onOpenNight) }, padding = PaddingValues(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pill(stringResource(R.string.pod_slot, s.slot), AuroraThemeExtras.pillBg)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(card?.let { Fmt.nightLabel(it.session.startedAtEpochMs) } ?: stringResource(R.string.pod_unknown_night), style = MaterialTheme.typography.titleSmall)
                        Text(
                            when (card?.session?.replayState) {
                                com.aurora.msg.data.db.ReplayState.NONE -> stringResource(R.string.pod_download_none)
                                com.aurora.msg.data.db.ReplayState.PARTIAL -> stringResource(R.string.pod_download_partial)
                                com.aurora.msg.data.db.ReplayState.COMPLETE -> stringResource(R.string.pod_download_complete)
                                null -> ""
                            }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (card != null && card.session.replayState != com.aurora.msg.data.db.ReplayState.COMPLETE && conn.isConnected && !replay.isActive) {
                        TextButton(onClick = { vm.pod.downloadNight(card.session.id, s.slot) }) { Text(stringResource(R.string.common_download)) }
                    }
                }
            }
        }

        // Maintenance
        item { SectionHeader(stringResource(R.string.pod_maintenance)) }
        item {
            if (hwPod) AuroraCard {
                // No motor and no fuel gauge on the glove: Buzz → Blink LED (IDENTIFY), no re-learn.
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { vm.blinkLed(); blinkSent = true }, enabled = conn.isConnected, shape = CircleShape, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.hw_pod_blink)) }
                }
                Spacer(Modifier.height(8.dp))
                Text(stringResource(if (blinkSent) R.string.hw_pod_blink_sent else R.string.hw_pod_maintenance_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = { showFormat = true; formatText = "" }, enabled = conn.isConnected) { Text(stringResource(R.string.hw_pod_erase_log), color = MaterialTheme.colorScheme.error) }
            } else AuroraCard {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { vm.hapticTest() }, enabled = conn.isConnected, shape = CircleShape, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.pod_buzz_test)) }
                    OutlinedButton(onClick = { vm.fuelGaugeRelearn() }, enabled = conn.isConnected, shape = CircleShape, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.pod_batt_relearn)) }
                }
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.pod_maintenance_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = { showFormat = true; formatText = "" }, enabled = conn.isConnected) { Text(stringResource(R.string.pod_erase_all), color = MaterialTheme.colorScheme.error) }
            }
        }
    }

    if (showFormat) {
        AlertDialog(
            onDismissRequest = { showFormat = false },
            title = { Text(stringResource(if (hwPod) R.string.hw_pod_erase_title else R.string.pod_erase_title)) },
            text = {
                Column {
                    Text(stringResource(if (hwPod) R.string.hw_pod_erase_body else R.string.pod_erase_body))
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(formatText, { formatText = it }, singleLine = true, placeholder = { Text(stringResource(R.string.pod_erase_placeholder)) })
                }
            },
            confirmButton = { TextButton(enabled = formatText == "ERASE", onClick = { showFormat = false; vm.formatFlash() }) { Text(stringResource(R.string.pod_erase_confirm), color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { showFormat = false }) { Text(stringResource(R.string.common_cancel)) } },
        )
    }
}
