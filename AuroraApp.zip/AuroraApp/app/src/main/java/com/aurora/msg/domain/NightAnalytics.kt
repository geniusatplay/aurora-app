package com.aurora.msg.domain

import com.aurora.msg.protocol.Cadence
import com.aurora.msg.protocol.HrvFlags
import com.aurora.msg.protocol.HwAdapter
import com.aurora.msg.protocol.LogRecord
import com.aurora.msg.protocol.SessionSummary
import com.aurora.msg.protocol.SleepState
import com.aurora.msg.protocol.SweatFlag
import kotlin.math.exp
import kotlin.math.roundToInt

/*
 * ===========================================================================
 * Vital Sheet analytics — brief §3. Everything here is a PURE function over
 * verified log records; bundles are detected AFTER the data exists (detect-
 * and-log only, never prediction — patent US11804301B2).
 *
 * quietVsEvent() feeds the sheet's two data columns (§4): for each channel a
 * [VitalComparison] with the median over quiet (non-bundle) epochs, the median
 * over bundle epochs and the peak inside bundles — all in DISPLAY units (bpm,
 * ms, °C, µS, %, g/m³, counts) as nullable Floats. A value is null when the
 * channel has no usable epochs on that side: eda/spo2/perfusion when the pod
 * has no extended sensors (or no VALID samples), hr when no epoch had a
 * readable heart rate, rmssd when no VALID HRV window closed, event columns
 * when the night has no bundles. The UI skips a row when quietMedian AND
 * eventMedian are both null.
 * ===========================================================================
 */

/** A contiguous sweat event derived from sweat_flag transitions. */
data class SweatSpan(val startS: Long, val endS: Long, val peakDahX100: Int) {
    val durationS: Long get() = endS - startS
}

/**
 * One detected "bundle" (Mailyn's definition, brief §3): a sweat spike confirmed by
 * warmer skin AND a faster heart, ± a wake-up. Timestamps are pod-relative seconds.
 */
data class FlashBundle(
    val startTs: Long,
    val endTs: Long,
    /** Peak EDA rise over the pre-onset baseline, µS ×100. 0 when detected via v1 sweat flags. */
    val peakEdaDeltaX100: Int,
    /** Peak skin-temperature rise over baseline in the confirmation window, °C ×100. */
    val tempDeltaX100: Int,
    /** Peak heart-rate rise over baseline in the confirmation window, bpm. */
    val hrDelta: Int,
    /** A wake (sleep state or motion ≥ 40) inside [onset, end + 10 min]. */
    val hadWake: Boolean,
    /** Duration ≥ 20 min — the "night sweats" shape. */
    val longSoak: Boolean,
) {
    val durationS: Long get() = endTs - startTs
}

/** Whole-night classification from the bundle count (brief §3). Wording lives in strings. */
enum class NightScore { QUIET, MILD, MEANINGFUL }

/** Extra pattern flags, shown as info chips when true (brief §3). Never a diagnosis. */
data class NightFlags(
    /** HR rises with falling SpO2 and NO sweat — pattern not typical of hot flashes. */
    val notFlashPattern: Boolean,
    /** Bedroom above 26 °C or 60 %RH for most of the night. */
    val warmRoom: Boolean,
    /** HR baseline of the last third of the night ≥ first third + 10 bpm. */
    val allNightHighHr: Boolean,
)

/** Quiet-vs-event numbers for ONE channel, display units; see the header comment. */
data class VitalComparison(
    val quietMedian: Float?,
    val eventMedian: Float?,
    val eventPeak: Float?,
) {
    /** Nothing to show on either side → the sheet skips this row. */
    val isEmpty: Boolean get() = quietMedian == null && eventMedian == null
}

/** quietVsEvent() result: one [VitalComparison] per sheet row (§4 row order). */
data class NightComparison(
    val hrBpm: VitalComparison,
    val rmssdMs: VitalComparison,
    val skinTempC: VitalComparison,
    val edaUs: VitalComparison,
    val dahGm3: VitalComparison,
    val perfusionPct: VitalComparison,
    val spo2Pct: VitalComparison,
    val motion: VitalComparison,
    val ambTempC: VitalComparison,
    val ambRhPct: VitalComparison,
)

/**
 * Pure analytics over verified log records. Spec §15.3: FE02 only describes the most recent
 * session, so older nights' summaries must be recomputed by the app from replayed data.
 */
object NightAnalytics {

    /** Absolute humidity g/m³ from temperature °C and relative humidity %. (Magnus formula.) */
    fun absoluteHumidity(tempC: Float, rh: Float): Float {
        val svp = 6.112f * exp((17.67f * tempC) / (tempC + 243.5f)) // hPa
        return (svp * rh * 2.1674f) / (273.15f + tempC)
    }

    /** Differential absolute humidity (skin − ambient), clamped at zero, ×100 as the firmware stores it. */
    fun dahX100(skinTempC: Float, skinRh: Float, ambTempC: Float, ambRh: Float): Int {
        val d = absoluteHumidity(skinTempC, skinRh) - absoluteHumidity(ambTempC, ambRh)
        return (d.coerceAtLeast(0f) * 100f).roundToInt()
    }

    /**
     * Walk sweat_flag: START (2) opens an event; ONGOING (1) extends it; NONE (0) closes it.
     * An ONGOING without a START (e.g. connected mid-event) also opens one.
     */
    fun sweatSpans(records: List<LogRecord>): List<SweatSpan> {
        val spans = ArrayList<SweatSpan>()
        var start: Long? = null
        var peak = 0
        var lastT = 0L
        for (r in records) {
            lastT = r.tS
            when (r.sweatFlag) {
                SweatFlag.START -> {
                    start?.let { spans.add(SweatSpan(it, r.tS, peak)) }
                    start = r.tS; peak = r.dahX100
                }
                SweatFlag.ONGOING -> {
                    if (start == null) { start = r.tS; peak = 0 }
                    peak = maxOf(peak, r.dahX100)
                }
                SweatFlag.NONE -> {
                    start?.let { spans.add(SweatSpan(it, r.tS, peak)); start = null; peak = 0 }
                }
            }
        }
        start?.let { spans.add(SweatSpan(it, lastT + Cadence.EPOCH_S, peak)) }
        return spans
    }

    /** Recompute the FE02-equivalent summary from records, exactly as the firmware would. */
    fun summarize(records: List<LogRecord>, slot: Int = 0): SessionSummary {
        if (records.isEmpty()) return SessionSummary(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, slot)
        val lenS = records.last().tS + Cadence.EPOCH_S
        val spans = sweatSpans(records)
        val hrs = records.filter { it.hasHr }.map { it.hrBpm }
        val classified = records.filter { it.sleepState != SleepState.UNKNOWN }
        val n = classified.size.coerceAtLeast(1)
        val pctWake = (100 * classified.count { it.sleepState == SleepState.WAKE } / n)
        val pctDeep = (100 * classified.count { it.sleepState == SleepState.DEEP } / n)
        // No classified epoch at all (hardware pod: no IMU, no staging) → 0/0/0, never "100 % light".
        val pctLight = if (classified.isEmpty()) 0 else (100 - pctWake - pctDeep).coerceAtLeast(0)
        return SessionSummary(
            sessionLenS = lenS,
            epochsLogged = records.size,
            sweatEvents = spans.size,
            longestSweatS = (spans.maxOfOrNull { it.durationS } ?: 0L).toInt(),
            peakDahX100 = records.maxOf { it.dahX100 },
            hrMeanBpm = if (hrs.isEmpty()) 0 else hrs.average().roundToInt(),
            hrMinBpm = hrs.minOrNull() ?: 0,
            hrMaxBpm = hrs.maxOrNull() ?: 0,
            pctWake = pctWake, pctLight = pctLight, pctDeep = pctDeep,
            battPct = records.last().battPct,
            slot = slot,
        )
    }

    /** The true HRV series: only records flagged HRV_FRESH (spec §10). Never de-dup by value. */
    fun hrvSeries(records: List<LogRecord>): List<LogRecord> = records.filter { it.hrvFresh }

    /** Baseline skin temperature = median of the first 30 minutes of classified records. */
    fun skinBaselineX100(records: List<LogRecord>): Int? {
        val first = records.filter { it.tS < 1800 }.map { it.skinTempX100 }.sorted()
        if (first.isEmpty()) return null
        return first[first.size / 2]
    }

    /** Mean RMSSD of VALID windows, or null if none. */
    fun meanValidRmssdX10(records: List<LogRecord>): Int? {
        val v = hrvSeries(records).filter { HrvFlags.has(it.hrvFlags, HrvFlags.VALID) }.map { it.hrvRmssdMsX10 }
        return if (v.isEmpty()) null else v.average().roundToInt()
    }

    // ------------------------------------------------------------------ bundles (brief §3)

    /** Rolling baseline window: the previous 20 epochs = 10 min, clamped to what exists. */
    private const val BASELINE_EPOCHS = 20
    /** Sweat onset: EDA ≥ baseline + 1.5 µS. */
    private const val EDA_ONSET_DELTA_X100 = 150
    /** Confirmation: skin temp ≥ baseline + 0.3 °C … */
    private const val TEMP_CONFIRM_DELTA_X100 = 30
    /** … AND heart rate ≥ baseline + 8 bpm … */
    private const val HR_CONFIRM_DELTA = 8
    /** … within ±10 epochs (±5 min) of the onset. */
    private const val CONFIRM_WINDOW_EPOCHS = 10
    /** Bundles closer than 20 epochs (10 min) are one event that dipped briefly. */
    private const val MERGE_GAP_EPOCHS = 20
    /** Wake-ups are attributed to a bundle up to 20 epochs (10 min) after it ends. */
    private const val WAKE_TAIL_EPOCHS = 20
    private const val WAKE_MOTION_INDEX = 40
    private const val LONG_SOAK_S = 20L * 60
    /** notFlashPattern: SpO2 ≤ baseline − 3 % (×10 wire units). */
    private const val SPO2_DROP_X10 = 30
    private const val NOT_FLASH_WINDOW_EPOCHS = 10 // 5 min
    private const val NOT_FLASH_MIN_WINDOWS = 3

    /** Median of the ints, or null when empty (upper-middle, matching skinBaselineX100). */
    private fun medianOrNull(values: List<Int>): Int? {
        if (values.isEmpty()) return null
        val s = values.sorted()
        return s[s.size / 2]
    }

    private fun medianOrNull(values: List<Float>): Float? {
        if (values.isEmpty()) return null
        val s = values.sorted()
        return s[s.size / 2]
    }

    /**
     * Per-epoch rolling baseline: median of the VALID samples among the previous
     * [BASELINE_EPOCHS] epochs (never including the current one, so a spike cannot
     * raise its own baseline). Null when no valid sample precedes the epoch yet.
     */
    private fun rollingBaseline(values: IntArray, valid: BooleanArray): Array<Int?> =
        Array(values.size) { i ->
            val from = (i - BASELINE_EPOCHS).coerceAtLeast(0)
            medianOrNull((from until i).filter { valid[it] }.map { values[it] })
        }

    /** Per-epoch "sweat is elevated" mask: EDA rule for v2 nights, sweat_flag fallback for v1. */
    private fun sweatElevationMask(records: List<LogRecord>): BooleanArray {
        val n = records.size
        val eda = IntArray(n) { records[it].validEdaX100 ?: 0 }
        val edaValid = BooleanArray(n) { records[it].validEdaX100 != null }
        if (edaValid.any { it }) {
            val base = rollingBaseline(eda, edaValid)
            return BooleanArray(n) { i ->
                edaValid[i] && base[i] != null && eda[i] >= base[i]!! + EDA_ONSET_DELTA_X100
            }
        }
        // v1 fallback: reuse the existing sweat-span logic (spans are [startS, endS) ).
        val mask = BooleanArray(n)
        val spans = sweatSpans(records)
        records.forEachIndexed { i, r ->
            mask[i] = spans.any { r.tS >= it.startS && r.tS < it.endS }
        }
        return mask
    }

    /**
     * Raw sweat-spike count: contiguous elevated-sweat spans, BEFORE temp/HR
     * confirmation. The Vital Sheet's sweat row reports this (all sweat activity),
     * while the hero reports confirmed bundles — the two deliberately differ when a
     * spike had no temp/HR confirmation (blanket, humid room).
     */
    fun sweatSpikeCount(records: List<LogRecord>): Int {
        val elevated = sweatElevationMask(records)
        var count = 0
        var prev = false
        for (e in elevated) {
            if (e && !prev) count++
            prev = e
        }
        return count
    }

    /**
     * Detect flash/sweat bundles per brief §3. Input: one night of 30 s epochs, in time
     * order. A candidate is a contiguous elevated-sweat span (one onset per span); it
     * becomes a bundle only when skin temp AND heart rate confirm within ±5 min of the
     * onset — a sweat-only spike (blanket, humid room) must NOT count.
     */
    fun detectBundles(records: List<LogRecord>): List<FlashBundle> {
        val n = records.size
        if (n == 0) return emptyList()

        val hasEda = records.any { it.validEdaX100 != null }
        val eda = IntArray(n) { records[it].validEdaX100 ?: 0 }
        val edaValid = BooleanArray(n) { records[it].validEdaX100 != null }
        val edaBase = rollingBaseline(eda, edaValid)
        val temp = IntArray(n) { records[it].skinTempX100 }
        val tempBase = rollingBaseline(temp, BooleanArray(n) { true })
        val hr = IntArray(n) { records[it].hrBpm }
        val hrValid = BooleanArray(n) { records[it].hrBpm > 0 } // brief: epochs with hrBpm > 0 only
        val hrBase = rollingBaseline(hr, hrValid)

        // 1. Elevated-sweat spans as index ranges [first, last].
        val elevated = sweatElevationMask(records)
        val spans = ArrayList<IntRange>()
        var i = 0
        while (i < n) {
            if (elevated[i]) {
                var j = i
                while (j + 1 < n && elevated[j + 1]) j++
                spans.add(i..j)
                i = j + 1
            } else i++
        }

        // 2. Confirm each span at its onset; collect metrics.
        data class Candidate(var first: Int, var last: Int, var edaDelta: Int, var tempDelta: Int, var hrDelta: Int)
        val confirmed = ArrayList<Candidate>()
        for (span in spans) {
            val onset = span.first
            val tBase = tempBase[onset] ?: continue // epoch 0 has no history — nothing to confirm against
            val hBase = hrBase[onset] ?: continue
            val lo = (onset - CONFIRM_WINDOW_EPOCHS).coerceAtLeast(0)
            val hi = (onset + CONFIRM_WINDOW_EPOCHS).coerceAtMost(n - 1)
            val tempDelta = (lo..hi).maxOf { temp[it] - tBase }
            val hrDelta = (lo..hi).filter { hrValid[it] }.maxOfOrNull { hr[it] - hBase } ?: Int.MIN_VALUE
            if (tempDelta < TEMP_CONFIRM_DELTA_X100 || hrDelta < HR_CONFIRM_DELTA) continue
            val eBase = edaBase[onset]
            val edaDelta = if (hasEda && eBase != null) {
                span.filter { edaValid[it] }.maxOfOrNull { eda[it] - eBase } ?: 0
            } else 0 // v1: no conductance channel, delta is 0 by definition
            confirmed.add(Candidate(span.first, span.last, edaDelta.coerceAtLeast(0), tempDelta, hrDelta))
        }

        // 3. Merge confirmed bundles separated by < 20 epochs — one event that dipped briefly.
        val merged = ArrayList<Candidate>()
        for (c in confirmed) {
            val prev = merged.lastOrNull()
            if (prev != null && c.first - prev.last < MERGE_GAP_EPOCHS) {
                prev.last = c.last
                prev.edaDelta = maxOf(prev.edaDelta, c.edaDelta)
                prev.tempDelta = maxOf(prev.tempDelta, c.tempDelta)
                prev.hrDelta = maxOf(prev.hrDelta, c.hrDelta)
            } else merged.add(c)
        }

        // 4. Wake attribution + long-soak classification on the merged spans.
        return merged.map { c ->
            val startTs = records[c.first].tS
            val endTs = records[c.last].tS + Cadence.EPOCH_S // span end is exclusive
            val wakeHi = (c.last + WAKE_TAIL_EPOCHS).coerceAtMost(n - 1)
            val hadWake = (c.first..wakeHi).any {
                records[it].sleepState == SleepState.WAKE || records[it].motionIndex >= WAKE_MOTION_INDEX
            }
            FlashBundle(
                startTs = startTs, endTs = endTs,
                peakEdaDeltaX100 = c.edaDelta, tempDeltaX100 = c.tempDelta, hrDelta = c.hrDelta,
                hadWake = hadWake, longSoak = endTs - startTs >= LONG_SOAK_S,
            )
        }
    }

    /** QUIET 0–1 bundles · MILD 2–4 · MEANINGFUL ≥5 OR any long soak (brief §3). */
    fun nightScore(bundles: List<FlashBundle>): NightScore = when {
        bundles.size >= 5 || bundles.any { it.longSoak } -> NightScore.MEANINGFUL
        bundles.size >= 2 -> NightScore.MILD
        else -> NightScore.QUIET
    }

    /** The info-chip pattern flags (brief §3). Pure observations, never a diagnosis. */
    fun nightFlags(records: List<LogRecord>): NightFlags {
        val n = records.size
        if (n == 0) return NightFlags(notFlashPattern = false, warmRoom = false, allNightHighHr = false)

        // warmRoom: ambient > 26 °C or > 60 %RH for more than half the night.
        // Epochs without a room sensor (hardware pod sentinel) can never count as warm.
        val warm = records.count { HwAdapter.hasAmbient(it.ambTempX100) && (it.ambTempX100 > 2600 || it.ambRhX100 > 6000) }
        val warmRoom = warm * 2 > n

        // allNightHighHr: HR baseline (median of readable epochs) of the last third ≥ first third + 10.
        val firstThird = records.take(n / 3).filter { it.hrBpm > 0 }.map { it.hrBpm }
        val lastThird = records.drop(n - n / 3).filter { it.hrBpm > 0 }.map { it.hrBpm }
        val allNightHighHr = medianOrNull(firstThird)?.let { f ->
            medianOrNull(lastThird)?.let { l -> l >= f + 10 }
        } ?: false

        // notFlashPattern: ≥3 separate 5-min windows of HR up + SpO2 down + NO sweat.
        // Needs an SpO2 channel — a v1 night can never raise this flag.
        val hr = IntArray(n) { records[it].hrBpm }
        val hrValid = BooleanArray(n) { records[it].hrBpm > 0 }
        val hrBase = rollingBaseline(hr, hrValid)
        val spo2 = IntArray(n) { records[it].validSpo2X10 ?: 0 }
        val spo2Valid = BooleanArray(n) { records[it].validSpo2X10 != null }
        val spo2Base = rollingBaseline(spo2, spo2Valid)
        val elevated = sweatElevationMask(records)
        val cond = BooleanArray(n) { i ->
            hrValid[i] && hrBase[i] != null && hr[i] >= hrBase[i]!! + HR_CONFIRM_DELTA &&
                spo2Valid[i] && spo2Base[i] != null && spo2[i] <= spo2Base[i]!! - SPO2_DROP_X10 &&
                !elevated[i] && records[i].sweatFlag == SweatFlag.NONE
        }
        // Non-overlapping windows; 8/10 epochs must match so single noisy epochs don't split one.
        var windows = 0
        var i = 0
        while (i + NOT_FLASH_WINDOW_EPOCHS <= n) {
            val hits = (i until i + NOT_FLASH_WINDOW_EPOCHS).count { cond[it] }
            if (hits >= NOT_FLASH_WINDOW_EPOCHS - 2) { windows++; i += NOT_FLASH_WINDOW_EPOCHS } else i++
        }
        return NightFlags(
            notFlashPattern = windows >= NOT_FLASH_MIN_WINDOWS,
            warmRoom = warmRoom,
            allNightHighHr = allNightHighHr,
        )
    }

    /**
     * The Vital Sheet's two data columns (§4): per channel, median over quiet (non-bundle)
     * epochs vs median + peak over bundle epochs. See the header comment for null semantics.
     */
    fun quietVsEvent(records: List<LogRecord>, bundles: List<FlashBundle>): NightComparison {
        val inBundle = BooleanArray(records.size) { i ->
            bundles.any { records[i].tS >= it.startTs && records[i].tS < it.endTs }
        }

        fun channel(extract: (LogRecord) -> Float?): VitalComparison {
            val quiet = ArrayList<Float>()
            val event = ArrayList<Float>()
            records.forEachIndexed { i, r ->
                extract(r)?.let { if (inBundle[i]) event.add(it) else quiet.add(it) }
            }
            return VitalComparison(
                quietMedian = medianOrNull(quiet),
                eventMedian = medianOrNull(event),
                eventPeak = event.maxOrNull(),
            )
        }

        return NightComparison(
            hrBpm = channel { if (it.hasHr) it.hrBpm.toFloat() else null },
            rmssdMs = channel { if (it.hrvFresh && it.hrvValid) it.hrvRmssdMsX10 / 10f else null },
            skinTempC = channel { it.skinTempC },
            edaUs = channel { it.edaUs },
            dahGm3 = channel { it.dah },
            perfusionPct = channel { it.perfusionPct },
            spo2Pct = channel { it.spo2Pct },
            motion = channel { it.motionIndex.toFloat() },
            // No room sensor (hardware sentinel) → null, so the climate row is skipped, not "-327 °C".
            ambTempC = channel { if (HwAdapter.hasAmbient(it.ambTempX100)) it.ambTempC else null },
            ambRhPct = channel { if (HwAdapter.hasAmbient(it.ambTempX100)) it.ambRhX100 / 100f else null },
        )
    }
}
