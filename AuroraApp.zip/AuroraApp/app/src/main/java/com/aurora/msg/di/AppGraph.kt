package com.aurora.msg.di

import android.content.Context
import com.aurora.msg.data.db.AuroraDatabase
import com.aurora.msg.data.repo.AuthRepository
import com.aurora.msg.data.repo.CustomPagesRepository
import com.aurora.msg.data.repo.SessionRepository
import com.aurora.msg.data.repo.SettingsRepository
import com.aurora.msg.data.sync.NoOpSyncGateway
import com.aurora.msg.data.sync.SyncGateway
import com.aurora.msg.pod.DemoController
import com.aurora.msg.pod.PodConnectionManager

/**
 * Tiny service locator. Swap [sync] for a real implementation when a server exists.
 */
class AppGraph(context: Context) {
    val appContext: Context = context.applicationContext
    val db: AuroraDatabase = AuroraDatabase.build(appContext)
    val settings = SettingsRepository(appContext)
    val customPages = CustomPagesRepository(appContext)
    val auth = AuthRepository(db.users(), settings)
    val sessions = SessionRepository(db)
    val sync: SyncGateway = NoOpSyncGateway()
    val pod = PodConnectionManager(appContext, sessions)
    val demo = DemoController(pod, sessions, settings)
}
