package com.aurora.msg.pod

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/*
 * Link diagnostics for the custom-page Diagnostics sections (link_health, packet_inspector,
 * hardware_check). Same model as the iPhone app (PodSource.swift: LinkStats / RawPacket /
 * LinkRecorder). Pure Kotlin — no Android APIs.
 */

/** Link-level counters of the current connection (reset on every new connection). */
data class LinkStats(
    /** Packets that passed their length / header / CRC checks (every characteristic). */
    val packets: Int = 0,
    /** FE01 live-vitals packets among them (≈ 1 Hz on a healthy link). */
    val vitalsPackets: Int = 0,
    /** FE05 HRV packets among them. */
    val hrvPackets: Int = 0,
    /** Packets dropped by the length / header / CRC check (PROTOCOL: must stay 0). */
    val crcFailures: Int = 0,
    /**
     * FE01 notifications missing according to the pod's 8-bit sequence counter (HwVitals.seq).
     * Real pod only — the demo pod has no counter and reports 0.
     */
    val seqGaps: Int = 0,
    /** FE01 arrival rate over the last ~10 s; null until two packets have arrived. */
    val rateHz: Double? = null,
    /** Wall-clock time (ms) of the most recent packet, valid or not. */
    val lastPacketAtMs: Long? = null,
)

/** What a raw packet decoded to — formatted (and localized) by the UI, never here. */
sealed class RawPacketKind {
    data class Vitals(val seq: Int?, val hrBpm: Float?, val absHumX100: Int?, val skinTempX100: Int?) : RawPacketKind()
    data class Hrv(val rmssdX10: Int, val beats: Int) : RawPacketKind()
    data class Summary(val durationS: Long) : RawPacketKind()
    data class Replay(val seq: Int) : RawPacketKind()
    /** The decoder rejected the packet; [reason] is the decoder's technical message. */
    data class Invalid(val reason: String) : RawPacketKind()
}

/** One entry of the raw-packet ring buffer. */
data class RawPacket(
    val id: Long,
    val timeMs: Long,
    /** Characteristic short name ("FE01", "FE02", "FE04", "FE05"). */
    val characteristic: String,
    /** Bytes as spaced upper-case hex ("A1 0C 3F …"). */
    val hex: String,
    /** Passed the length / header / CRC checks. */
    val ok: Boolean,
    val decoded: RawPacketKind,
)

internal val NO_LINK_STATS: StateFlow<LinkStats> = MutableStateFlow(LinkStats()).asStateFlow()
internal val NO_RAW_PACKETS: StateFlow<List<RawPacket>> = MutableStateFlow<List<RawPacket>>(emptyList()).asStateFlow()

/**
 * Shared bookkeeping behind [PodSource.linkStats] / [PodSource.rawPackets]. Thread-safe:
 * the BLE stack calls [record] from its binder thread.
 */
class LinkRecorder(private val nowMs: () -> Long = { System.currentTimeMillis() }) {

    enum class Counted { VITALS, HRV, OTHER }

    private val _stats = MutableStateFlow(LinkStats())
    val stats: StateFlow<LinkStats> = _stats.asStateFlow()
    private val _packets = MutableStateFlow<List<RawPacket>>(emptyList())
    val packets: StateFlow<List<RawPacket>> = _packets.asStateFlow()

    private var nextId = 0L
    private var lastSeq: Int? = null
    private val arrivals = ArrayDeque<Long>()

    /** Call on every new connection. */
    @Synchronized fun reset() {
        lastSeq = null
        arrivals.clear()
        _stats.value = LinkStats()
        _packets.value = emptyList()
    }

    /**
     * Count one packet and append it to the ring buffer. [seq] is the FE01 8-bit sequence
     * counter when the pod sends one (gaps = notifications that never arrived).
     */
    @Synchronized fun record(
        characteristic: String, bytes: ByteArray, ok: Boolean, decoded: RawPacketKind,
        seq: Int? = null, counted: Counted = Counted.OTHER,
    ) {
        val now = nowMs()
        var s = _stats.value
        if (ok) {
            s = s.copy(packets = s.packets + 1)
            when (counted) {
                Counted.VITALS -> {
                    s = s.copy(vitalsPackets = s.vitalsPackets + 1)
                    if (seq != null) {
                        val last = lastSeq
                        if (last != null && seq != last) {
                            val expected = (last + 1) and 0xFF
                            if (seq != expected) s = s.copy(seqGaps = s.seqGaps + ((seq - expected + 256) and 0xFF))
                        }
                        lastSeq = seq
                    }
                    arrivals.addLast(now)
                    while (arrivals.isNotEmpty() && now - arrivals.first() > 10_000L) arrivals.removeFirst()
                    val first = arrivals.firstOrNull()
                    if (arrivals.size > 1 && first != null && now > first) {
                        s = s.copy(rateHz = (arrivals.size - 1) * 1000.0 / (now - first))
                    }
                }
                Counted.HRV -> s = s.copy(hrvPackets = s.hrvPackets + 1)
                Counted.OTHER -> Unit
            }
        } else {
            s = s.copy(crcFailures = s.crcFailures + 1)
        }
        _stats.value = s.copy(lastPacketAtMs = now)

        nextId += 1
        val ring = _packets.value + RawPacket(nextId, now, characteristic, hex(bytes), ok, decoded)
        _packets.value = if (ring.size > RING_CAPACITY) ring.drop(ring.size - RING_CAPACITY) else ring
    }

    companion object {
        const val RING_CAPACITY = 50

        fun hex(bytes: ByteArray): String = bytes.joinToString(" ") { String.format("%02X", it.toInt() and 0xFF) }
    }
}
