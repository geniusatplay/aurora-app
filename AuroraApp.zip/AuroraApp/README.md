# Aurora — Menopause Sleep Monitoring App (Android)

Companion app for the **Aurora Pod** (Menopause Sleep Glove, carrier RevA, firmware 1.0.0).
Native Android · Kotlin 2.0 · Jetpack Compose · Material 3 · Room · Bluetooth Low Energy.

The pod has no screen; this app is the entire product surface. Everything it does is driven by
`docs/app build details.txt` (the device-to-app interface spec). `PLAN.md` explains the architecture.

> **Status — please read.** This project was written and reviewed in an environment that has no
> Android SDK, so **the Android/Compose layer has not yet been compiled or run on a device**.
> The pure-Kotlin core (BLE protocol, CRC, packet parsers, replay reassembly, night analytics and
> the demo simulator — about a third of the code) *was* compiled with Kotlin 2.0.21 and its
> 9 unit tests pass. Expect to fix a handful of small compile issues on the first Android Studio
> build; the code was reviewed twice for exactly that, but nothing replaces a real build.

---

## 1. First build — step by step (Windows)

You do **not** need Visual Studio for this; Android needs Android Studio (free).

1. **Install Android Studio** — https://developer.android.com/studio (Ladybug or newer).
   Accept the defaults; the installer brings its own JDK and Android SDK.
2. **Open the project** — *File ▸ Open…* and pick the `AuroraApp` folder (the one containing
   `settings.gradle.kts`). Wait for "Gradle sync" to finish; the first sync downloads ~1 GB
   of libraries (AGP 8.7.3, Compose BOM 2024.12.01, Room 2.6.1). If Studio asks to install
   **SDK Platform 35** or **Build-Tools**, click *Install*.
3. **Run the unit tests** (optional but recommended): right-click `app/src/test` ▸ *Run tests*.
   All 9 protocol tests should pass.
4. **Run on a phone** — enable *Developer options ▸ USB debugging* on an Android 8.0+ phone,
   plug it in, choose it in the device dropdown and press **Run ▶**. (A phone is needed for
   Bluetooth. The emulator works fine for the **demo**.)
5. **Sign in with the demo account**: `aurorademo@gmail.com` / `pswd` (the "Use the demo
   account" button fills it in).
6. Tap the **Demo** button at the bottom → **Add 14 nights** to fill Home and Trends, then
   **Start demo night** and switch activities to watch the live charts.

### Building a release APK / AAB
*Build ▸ Generate Signed Bundle / APK…* → create a keystore → choose **release**. The
`release` build type has minification off so nothing needs ProGuard rules yet.

### If Gradle sync complains
| Symptom | Fix |
|---|---|
| "Unsupported class file major version" | Studio's JDK must be 17+. *File ▸ Settings ▸ Build Tools ▸ Gradle ▸ Gradle JDK* → pick the embedded JDK. |
| Version catalog errors | Ensure `gradle/libs.versions.toml` is present and Studio ≥ Ladybug. |
| KSP / Room errors | Versions are pinned (`ksp = 2.0.21-1.0.28`); don't let Studio "upgrade" only one of Kotlin/KSP. |
| `gradle-wrapper.jar` missing | Run `gradle wrapper --gradle-version 8.9` or let Studio regenerate the wrapper. |

---

## 2. What the app does

| Screen | Contents |
|---|---|
| **Sign in** | Local accounts (salted SHA-256, on-device). Demo account pre-seeded. |
| **Home** | Hero card: last night's **sweat-event count** and **peak ΔAH** (the number a wrist tracker can't measure); morning card (time in bed, sleep ring, HR min/avg/max); 7-night sparkline; pod status with the 14-slot warning; recent nights. |
| **Live** | 1 Hz vitals: HR with *Measuring… / Next reading in N min* states (never "0 bpm"), HRV gated on `HRV_FLAG_VALID`, skin/room temperature and humidity, live ΔAH, sleep state (flagged as 60 s behind), battery, sensor-fault banner, rolling 15-minute charts. |
| **Night detail** | Stacked panels on one shared clock axis (no dual-axis): skin & room temperature, ΔAH with **sweat-event bands**, hypnogram, movement, HR dots, HRV dots (hollow = invalid). Drag to scrub with tooltips. Activity markers from the demo/pod. Sweat-event list, event log, diagnostics (battery/cell voltage/CRC drops), replay download with % progress + cancel, CSV share, delete. |
| **Trends** | 7/14/30/90-day: sweat events per night, peak ΔAH, sleep composition (stacked), resting HR, time in bed, with simple "up/down/steady" notes. |
| **Pod** | Scan by service UUID, connect, device info with firmware-mismatch warning, time-sync status, **Start / Stop session**, download progress, the app's own 14-slot inventory, haptic test, fuel-gauge re-learn, and *Format flash* behind a typed **ERASE** confirmation. |
| **Settings** | °C/°F, 12/24 h, demo toggle, privacy text, sign out, delete all, about + wellness disclaimer. |
| **Demo sheet** | Always-visible **Demo** button. Modes: *Up & about · Light exercise · Heavy exercise · Sleeping · Night flash · Night sweats*; speed 1×/10×/30×/60×; Start / Stop (→ morning card); *Add 14 nights* of generated history. |

### Spec rules enforced in code
* `CMD_TIME_SYNC` is the first write after **every** connection, confirmed by `FLAG_TIME_SYNCED`, 3 attempts (`PodConnectionManager.syncTime`).
* Wall-clock session start is stored by the app when `FLAG_LOGGING` confirms the start (`SessionRepository.startSession`).
* CRC-16/CCITT-FALSE checked on every 34-byte record; failures dropped and counted (`LogRecord.parse`).
* Replay record size derived from the header, not hard-coded; 24-byte legacy files are refused with a message (`ReplayAssembler`).
* HRV never displayed unless `HRV_FLAG_VALID`; invalid windows are hollow with the reason (`DotPanel`).
* The true HRV series is filtered on `FLAG_HRV_FRESH`, never de-duplicated by value.
* Every command is confirmed by observing its effect, with timeout + retry (spec §15.2).
* Night download runs under a foreground service so it survives screen-lock; visible cancel sends `CMD_REPLAY_ABORT`.
* Detect-and-log only: no prediction, no automatic actuation, no medical claims, temperatures at one decimal.

### The demo is the real code path
`DemoPodSource` produces byte-identical FE01/FE02/FE04/FE05 packets. They go through the same
parsers, CRC verification, replay reassembly, Room database and charts as the hardware. Switching
activity in the demo sheet writes an *activity marker* onto the night so the chart and event log
show it. "Add 14 nights" generates realistic full nights (with flashes and sweats scattered
through them) and also installs them into the simulated pod's slots so **Download** works.

---

## 3. Project layout

```
app/src/main/java/com/aurora/msg
├── protocol/   UUIDs, packets, flags, commands, CRC-16, replay assembler   (pure Kotlin, tested)
├── domain/     NightAnalytics: ΔAH physics, sweat spans, summary recompute (pure Kotlin)
├── pod/        PodSource interface · BlePodSource · DemoPodSource · DemoScenario · DemoHistory
│               PodConnectionManager (orchestration) · DemoController · ReplayService
├── data/db     Room entities + DAOs + database
├── data/repo   SessionRepository · AuthRepository · SettingsRepository (DataStore)
├── data/sync   SyncGateway interface + NoOpSyncGateway (server-ready seam)
├── di/         AppGraph service locator
└── ui/         theme · charts (Canvas) · components · navigation · screens
```

---

## 4. Server later

The app is **on-device only** today. `data/sync/SyncGateway.kt` is the seam; `SERVER_API.md`
documents the REST contract a backend should implement. Swapping `NoOpSyncGateway` for a real
implementation in `AppGraph` is the only app change needed to start syncing.

---

## 5. Notes for the firmware team / known spec quirks

* Spec §6 example: the bytes `03 00 6E 8D 6A` decode (little-endian) to **1787653632**, not the
  1786579200 written in the prose. The bytes are what the test asserts.
* Rev A has no pairing/encryption (§13). The app's Pod screen is laid out so a pairing step can be
  inserted before "Start session" without redesign.
* Requested for Rev B: slot inventory command, command ACKs, replay resume, low-storage warning.

---

## 6. Round 2 additions

* **Themes** (Settings ▸ Appearance): Aurora Pink (follows system light/dark), Light, High contrast, Dark. All accents, pills, buttons, progress bars and hero cards follow the chosen theme.
* **Readability**: small text is now Medium/SemiBold and one point larger; secondary text is darker.
* **Language** (Settings): Use phone setting / English / Español / Tiếng Việt — switches instantly, no restart. All ~430 strings live in `res/values*/strings_*.xml`.
* **Low / Medium / High guides** (Settings ▸ Appearance): shades reference zones on every chart and tags tiles with a Low/Medium/High badge. Ranges are in `domain/Ranges.kt` and shown in Settings; they are wellness guides, not medical limits.
* **Live heart rate**: the demo pod streams pulse every second (the real pod measures 2 min in every 10, per spec §5) and delivers its first HRV window after 2 minutes. Between the real pod's bursts the Live screen keeps showing the last reading with its age plus a live HR chart, so it is never blank.
* **Live screen**: Sleep level and Pod battery are separate cards; the two HRV numbers are labelled *Beat-to-beat variability (RMSSD)* and *Overall variability (SDNN)*; "ΔAH" is now called **Sweat moisture** everywhere.
