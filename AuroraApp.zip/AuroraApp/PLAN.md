# Aurora — Menopause Sleep Monitoring App · Build Plan

Companion app for the **Aurora Pod** (Menopause Sleep Glove, carrier RevA, firmware 1.0.0).
Native Android · Kotlin · Jetpack Compose · Room · Android BLE.

The device has no screen. **The app is the entire product surface.** Everything below is
derived from `app build details.txt` (the device-to-app interface spec). Where this plan and
the spec disagree, the spec wins; where the spec and the firmware disagree, the firmware wins.

---

## 1. Product principles (non-negotiable, from spec §8, §13, §14)

| Rule | How the app enforces it |
|---|---|
| Send `CMD_TIME_SYNC` first after **every** connection | `PodConnectionManager.onConnected()` writes `0x03 + unix_s` before subscribing to anything, then waits for `FLAG_TIME_SYNCED` in FE01 (timeout → retry ×3 → warn). |
| App stores wall-clock session start | `SessionEntity.startedAtEpochMs` written the instant `CMD_START_SESSION` is confirmed via `FLAG_LOGGING`. All absolute times = start + `t_s`. |
| Verify CRC-16/CCITT-FALSE on every 34-byte record | `Crc16.ccittFalse()` in the protocol layer; failures dropped and counted; count shown in replay result. |
| Record size comes from replay header, never hard-coded | `ReplayAssembler` computes `recordSize = totalBytes / recordCount`; refuses sizes it cannot parse (< 34 for firmware 1.0.0 → "older log format" message). |
| Never show HRV unless `HRV_FLAG_VALID` | `HrvPoint.isValid` gates every render; invalid windows render as hollow markers with the reason chip ("movement", "weak pulse", "few beats", "sample loss"). |
| Never show "0 bpm" or stale HR | Live screen shows **Measuring…** while `PPG_ACTIVE`, else **Next reading in N min** computed from the 600 s cadence. |
| Detect & log, never predict/intervene | No forecasting features, no automatic haptic. Copy is always past-tense: "what happened", "your pattern". |
| No medical claims | Copy reviewed: no staging, no diagnosis, no treatment advice. Persistent "General wellness · not a medical device" footer on Settings and first-run. |
| Don't invent precision | Temperatures rendered to **one decimal**; primary temperature visual is **change from baseline** (Δ °C), not absolute. |
| Privacy | **On-device only** by default. A `SyncGateway` interface exists but the shipping implementation is `NoOpSyncGateway`. |

---

## 2. Architecture

Single-module app, clean layering, no DI framework (a tiny hand-rolled `AppGraph` service locator
keeps the project buildable without extra annotation processors — only Room/KSP is used).

```
com.aurora.msg
├── AuroraApp.kt                 Application: builds AppGraph
├── di/AppGraph.kt               service locator (db, repos, pod manager, settings)
├── protocol/                    PURE KOTLIN, no Android imports — unit-testable
│   ├── AuroraUuids.kt           service + 5 characteristic UUIDs, std services
│   ├── Packets.kt               LiveVitals, HrvSummary, SessionSummary, LogRecord + parsers
│   ├── Flags.kt                 flag/enum constants + helpers
│   ├── Commands.kt              opcode byte-array builders (time sync, start, stop, replay…)
│   ├── Crc16.kt                 CRC-16/CCITT-FALSE
│   └── ReplayAssembler.kt       frame reassembly (18-byte payloads → contiguous buffer → records)
├── pod/                         device abstraction
│   ├── PodSource.kt             interface: connection state, vitals/hrv/summary/replay flows, commands
│   ├── BlePodSource.kt          real BluetoothGatt implementation (scan by service UUID, MTU-agnostic)
│   ├── DemoPodSource.kt         simulator emitting IDENTICAL packet types
│   ├── DemoScenario.kt          activity modes + physiological parameter model
│   └── PodConnectionManager.kt  orchestration: time-sync-first, command confirm + retry, replay w/ progress
├── data/
│   ├── db/  AuroraDatabase, entities, DAOs
│   ├── repo/ AuthRepository, SessionRepository, TrendRepository, SettingsRepository
│   └── sync/ SyncGateway (interface), NoOpSyncGateway, SyncModels
├── domain/                      derived analytics (night summary recompute, baselines, trends)
└── ui/
    ├── theme/                   Aurora pink system (Color, Type, Shape, Theme)
    ├── charts/                  Canvas-drawn: TimelineChart, Hypnogram, MotionTrace, HrvDots,
    │                            TrendBars, RingGauge, Sparkline
    ├── components/              cards, chips, banners, hero metric, section headers
    ├── navigation/              NavHost + bottom bar + demo FAB
    └── screens/                 SignIn, Home, Live, NightDetail, Trends, Pod, Settings, DemoSheet
```

### Threading & lifecycle
* All pod I/O on a `CoroutineScope(SupervisorJob() + Dispatchers.Default)` owned by `PodConnectionManager`.
* Replay runs inside a **foreground service** (`ReplayService`) so it survives screen-lock (spec §9).
* UI observes `StateFlow`s; ViewModels are lightweight and hold no device references.

---

## 3. Data model (Room)

```
users            id, email(unique), passwordHash(salted SHA-256), displayName, createdAt
sessions         id, userId, startedAtEpochMs, endedAtEpochMs?, slot?, source(BLE|DEMO),
                 replayState(NONE|PARTIAL|COMPLETE), crcFailures, note
session_summary  sessionId(pk), sessionLenS, epochsLogged, sweatEvents, longestSweatS,
                 peakDahX100, hrMean, hrMin, hrMax, pctWake, pctLight, pctDeep, battPct, slot
epochs           id, sessionId, tS, hrBpm, hrQuality, skinTempX100, skinRhX100, ambTempX100,
                 ambRhX100, motionIndex, sleepState, sweatFlag, battPct, flags, dahX100,
                 hrvMeanIbi, hrvSdnnX10, hrvRmssdX10, hrvPnn50, hrvQuality, hrvFlags, vcellCv
                 (index sessionId, tS)
hrv_points       id, sessionId, windowEndS, meanIbi, sdnnX10, rmssdX10, pnn50, accepted,
                 rejected, quality, flags        ← only FLAG_HRV_FRESH records / FE05 notifies
sweat_events     id, sessionId, startS, endS, peakDahX100     ← derived from sweat_flag transitions
activity_events  id, sessionId, tS, kind(UP|LIGHT_EX|HEAVY_EX|SLEEP|NIGHT_FLASH|NIGHT_SWEAT|…),
                 label, source(DEMO|USER)        ← demo mode markers + future manual tagging
pod_slots        slot(pk), sessionId, lastSeenAt  ← the app's own slot inventory (spec §15.1)
```
Every entity carries `userId` transitively via session; `syncedAt` nullable column on
sessions/summary so a future server sync can diff.

---

## 4. Colour system — "Aurora Pink"

Multi-tone pink with white and black accents, tested for 4.5:1 text contrast.

| Token | Hex | Use |
|---|---|---|
| `Blossom` | `#FFE3EE` | page background tint / card fill |
| `Petal` | `#FFB8D1` | secondary surfaces, chips |
| `Rose` | `#FF6FA6` | primary accent, buttons, active nav |
| `Fuchsia` | `#E8308A` | hero metric, sweat series, emphasis |
| `Magenta` | `#B3125F` | pressed/dark accent, headline gradient stop |
| `Plum` | `#5E0A3A` | deep accent text on light pink |
| `Ink` | `#17111A` | primary text (black accent) |
| `Cloud` | `#FFFFFF` | cards, chart plot area |
| `Mist` | `#F7F2F5` | dividers, muted surface |

Chart series (distinct hue-luminance so they separate in a pink world):
skin temp `#E8308A`, ambient temp `#B98BA8` (dusty mauve), DAH (sweat) `#FF6FA6` area fill,
heart rate `#17111A` dots, HRV valid `#7A1F5C` / invalid hollow, sleep Deep `#5E0A3A`, Light `#FF8DB8`,
Wake `#FFD6E4`, motion `#C9A0B8`. Sweat-event bands: `Fuchsia` at 14 % alpha.

Dark mode: Ink background with the same accents, cards `#221722`.

---

## 5. Screens

1. **Sign in** — gradient hero, email/password, "Use demo account" fills `aurorademo@gmail.com / pswd`. Local auth; create-account also local.
2. **Home** — hero card = last night's **sweat events** + **peak ΔAH (g/m³)**; morning card (time asleep, sleep ring wake/light/deep, HR mean/min/max, longest sweat); 7-night sparkline; pod status strip (battery, connection, nights stored 14-slot warning).
3. **Live** — only meaningful when connected/demo: HR with measuring/next-reading state, skin & ambient temp (Δ and absolute), skin/ambient RH, ΔAH live area chart (rolling 10 min), movement bar, sleep-state pill (with "~60 s behind"), battery, sensor-fault banner, "pod keeps recording when you put the phone down" notice.
4. **Night detail** — timeline chart (skin/ambient temp + ΔAH with sweat bands + activity markers), hypnogram, motion trace, HR dots (quality-banded), HRV series (valid/invalid), diagnostics (battery/cell voltage), replay status + CRC failures, event log list.
5. **Trends** — sweat events/night, peak ΔAH, sleep composition stacked bars, resting HR & RMSSD trend, 7/30/90-day range.
6. **Pod** — scan/connect, device info (revision check warning), time-sync status, start/stop session, download night (progress %, cancel, retry), 14-slot inventory, format flash behind typed confirmation, haptic test.
7. **Settings** — °C/°F, 12/24 h, data & privacy (on-device only; export CSV; delete all), account, about + wellness disclaimer.
8. **Demo sheet** (bottom "Demo" button, always visible) — mode chips: **Up & about · Light exercise · Heavy exercise · Sleeping · Night flash · Night sweats**; speed 1×/10×/60×; "Start demo night", "Stop & make morning card", "Seed 14 nights of history".

---

## 6. Demo simulator model

`DemoScenario` holds targets per mode; `DemoPodSource` ticks every 1 s of real time, advancing
simulated time by `speed` seconds and easing each signal toward its target with per-signal
noise (Ornstein-Uhlenbeck style) so charts look organic.

| Mode | HR | Skin T | Skin RH | ΔAH g/m³ | Motion | Sleep | Sweat flag |
|---|---|---|---|---|---|---|---|
| Up & about | 72±6 | 33.4 | 45 | 0.6 | 40–120 | Wake | 0 |
| Light exercise | 105±8 | 33.9 | 60 | 1.8 | 200–400 | Wake | 0 |
| Heavy exercise | 148±10 | 34.6 | 85 | 4.2 | 500–900 | Wake | 1 (start=2) |
| Sleeping | 58±4 | 33.1→32.6 | 40 | 0.3 | 0–15 (occasional 60) | Light/Deep cycles | 0 |
| Night flash | 58→84 in 90 s, back over 6 min | +1.1 °C rise over 2 min | 70 | 2.6 | 30–80 | Wake→Light | 2 then 1 |
| Night sweats | 62→92 | +1.4 °C | 95 | 6.5 peak | 60–150 | Wake | 2 then 1 (8–15 min) |

Every tick emits FE01-equivalent `LiveVitals`; each simulated 30 s emits a `LogRecord` (with CRC
so the SAME parser path is exercised); each 600 s emits `HrvSummary` (valid unless motion high).
"Stop" produces an FE02 `SessionSummary` computed exactly as the firmware would.
Mode changes write an `activity_events` marker so the chart shows and logs them.
"Seed history" generates 14 nights with realistic variation (2–7 sweat events, 6.5–8.2 h).

---

## 7. Charts (custom Compose Canvas, no third-party dependency)

* `TimelineChart` — multi-axis (temp left, ΔAH right), smooth Catmull-Rom paths, gradient area
  under ΔAH, shaded sweat bands, activity markers as labelled pins, pinch/drag to scrub with
  a tooltip crosshair.
* `Hypnogram` — stepped Wake/Light/Deep with a soft-rounded rail.
* `MotionTrace` — mirrored bar area.
* `HrDots` / `HrvDots` — dots sized by quality; invalid HRV hollow.
* `SleepRing` — three-segment ring gauge.
* `TrendBars` / `StackedBars` / `Sparkline`.
Animated on first draw (`Animatable` progress), theme-aware, `contentDescription` for a11y.

---

## 8. Server readiness

`SyncGateway` interface with `pushSession`, `pullSessions`, `auth`. Ships with `NoOpSyncGateway`.
`SERVER_API.md` documents the REST contract (JSON, bearer auth, idempotent session upsert,
epochs chunked) so a backend can be built to match with zero app changes beyond swapping
the gateway implementation in `AppGraph`.

---

## 9. Verification strategy (no compiler in this workspace)

1. Protocol layer has JUnit tests (CRC vector, packet round-trips, replay misalignment, header-derived record size).
2. Independent review agent reads every source file for compile-level defects (imports, types, Compose API misuse).
3. README lists the exact Android Studio / SDK versions and a "first build" checklist.

---

## 10. Risks & mitigations

* **BLE variance across phones** — connection retry with backoff, `autoConnect=false`, refresh-cache workaround, all GATT ops serialised through a queue.
* **Replay drops** — seq-gap detection, restart-from-scratch retry, foreground service.
* **Slot inventory loss on reinstall** — "Recover nights" tries all 14 slots.
* **Firmware version drift** — Device Info Software Revision compared to `BUILT_AGAINST_FW = "1.0.0"`.
