// Low / Medium / High reference guides for the overnight measurements — port of Ranges.kt.
import Foundation

/// These are GENERAL-WELLNESS reference bands for a resting adult asleep in a glove, chosen so
/// a user can tell at a glance whether a number is unremarkable or worth a look. They are not
/// clinical thresholds and the app never turns them into a diagnosis (spec §14.2).
/// All values are in the app's canonical units (°C, bpm, g/m³, ms, motion counts / 30 s).
enum Level {
    case low, medium, high

    /// Localization key for the badge text (Resources/*.lproj: level_low / level_medium / level_high).
    var labelKey: String {
        switch self {
        case .low: return "level_low"
        case .medium: return "level_medium"
        case .high: return "level_high"
        }
    }
}

enum Metric: CaseIterable {
    case sleepHr, skinRise, sweatDah, movement, hrvRmssd, skinTemp, roomTemp, skinRh, roomRh
    case conductance, spo2, perfusion // extended sensors (ext brief §6: new range guides)
}

struct RangeGuide: Equatable {
    var metric: Metric
    /// Values below this are LOW.
    var lowMax: Double
    /// Values above this are HIGH; in between is MEDIUM.
    var highMin: Double
    /// For HRV a higher value is the reassuring one; used for colouring.
    var higherIsBetter: Bool = false

    func levelOf(_ value: Double) -> Level {
        if value < lowMax { return .low }
        if value > highMin { return .high }
        return .medium
    }
}

enum Ranges {
    static let sleepHeartRate = RangeGuide(metric: .sleepHr, lowMax: 50, highMin: 70)
    /// Skin-temperature rise above the night's baseline, °C. A hot flash is typically ≥ 1 °C.
    static let skinRise = RangeGuide(metric: .skinRise, lowMax: 0.4, highMin: 1.0)
    /// Differential absolute humidity, g/m³ — the sweat number.
    static let sweat = RangeGuide(metric: .sweatDah, lowMax: 5, highMin: 12)
    static let movement = RangeGuide(metric: .movement, lowMax: 20, highMin: 100)
    static let rmssd = RangeGuide(metric: .hrvRmssd, lowMax: 20, highMin: 50, higherIsBetter: true)
    static let skinTemp = RangeGuide(metric: .skinTemp, lowMax: 32.5, highMin: 34.5)
    static let roomTemp = RangeGuide(metric: .roomTemp, lowMax: 17, highMin: 23)
    static let skinRh = RangeGuide(metric: .skinRh, lowMax: 35, highMin: 60)
    static let roomRh = RangeGuide(metric: .roomRh, lowMax: 30, highMin: 60)
    /// Tonic skin conductance during sleep, µS. Sleeping baseline sits at 2–6 µS (ext brief §2).
    static let conductance = RangeGuide(metric: .conductance, lowMax: 2, highMin: 6)
    /// Overnight blood oxygen, %. Here HIGH is the reassuring side — the label stays a neutral
    /// Low/Medium/High, never a judgment (spec §14.2) — so higherIsBetter drives the colouring.
    static let spo2 = RangeGuide(metric: .spo2, lowMax: 94, highMin: 96, higherIsBetter: true)
    /// PPG perfusion index, %. Typical resting sleep sits at 1.0–3.5 % (ext brief §2).
    static let perfusion = RangeGuide(metric: .perfusion, lowMax: 1, highMin: 3.5)

    static func forMetric(_ m: Metric) -> RangeGuide {
        switch m {
        case .sleepHr: return sleepHeartRate
        case .skinRise: return skinRise
        case .sweatDah: return sweat
        case .movement: return movement
        case .hrvRmssd: return rmssd
        case .skinTemp: return skinTemp
        case .roomTemp: return roomTemp
        case .skinRh: return skinRh
        case .roomRh: return roomRh
        case .conductance: return conductance
        case .spo2: return spo2
        case .perfusion: return perfusion
        }
    }
}
