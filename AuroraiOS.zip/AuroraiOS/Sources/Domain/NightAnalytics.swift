// Pure analytics over verified log records — the iOS port of NightAnalytics.kt.
import Foundation

/// A contiguous sweat event derived from sweat_flag transitions.
struct SweatSpan: Equatable {
    var startS: Int64
    var endS: Int64
    var peakDahX100: Int
    var durationS: Int64 { endS - startS }
}

/*
 * ===========================================================================
 * Vital Sheet analytics — ext brief §3. Everything here is a PURE function over
 * verified log records; bundles are detected AFTER the data exists (detect-
 * and-log only, never prediction — patent US11804301B2).
 *
 * quietVsEvent() feeds the sheet's two data columns (§4): for each channel a
 * `VitalComparison` with the median over quiet (non-bundle) epochs, the median
 * over bundle epochs and the peak inside bundles — all in DISPLAY units (bpm,
 * ms, °C, µS, %, g/m³, counts) as optional Doubles. A value is nil when the
 * channel has no usable epochs on that side: eda/spo2/perfusion when the pod
 * has no extended sensors (or no VALID samples), hr when no epoch had a
 * readable heart rate, rmssd when no VALID HRV window closed, event columns
 * when the night has no bundles. The UI skips a row when quietMedian AND
 * eventMedian are both nil.
 * ===========================================================================
 */

/// One detected "bundle" (Mailyn's definition, ext brief §3): a sweat spike confirmed by
/// warmer skin AND a faster heart, ± a wake-up. Timestamps are pod-relative seconds.
struct FlashBundle: Equatable {
    var startTs: Int64
    var endTs: Int64
    /// Peak EDA rise over the pre-onset baseline, µS ×100. 0 when detected via v1 sweat flags.
    var peakEdaDeltaX100: Int
    /// Peak skin-temperature rise over baseline in the confirmation window, °C ×100.
    var tempDeltaX100: Int
    /// Peak heart-rate rise over baseline in the confirmation window, bpm.
    var hrDelta: Int
    /// A wake (sleep state or motion ≥ 40) inside [onset, end + 10 min].
    var hadWake: Bool
    /// Duration ≥ 20 min — the "night sweats" shape.
    var longSoak: Bool

    var durationS: Int64 { endTs - startTs }
}

/// Whole-night classification from the bundle count (ext brief §3). Wording lives in strings
/// (vs_score_quiet / vs_score_mild / vs_score_meaningful).
enum NightScore: Equatable {
    case quiet, mild, meaningful
}

/// Extra pattern flags, shown as info chips when true (ext brief §3). Never a diagnosis.
struct NightFlags: Equatable {
    /// HR rises with falling SpO2 and NO sweat — pattern not typical of hot flashes.
    var notFlashPattern: Bool
    /// Bedroom above 26 °C or 60 %RH for most of the night.
    var warmRoom: Bool
    /// HR baseline of the last third of the night ≥ first third + 10 bpm.
    var allNightHighHr: Bool
}

/// Quiet-vs-event numbers for ONE channel, display units; see the header comment.
struct VitalComparison: Equatable {
    var quietMedian: Double?
    var eventMedian: Double?
    var eventPeak: Double?

    /// Nothing to show on either side → the sheet skips this row.
    var isEmpty: Bool { quietMedian == nil && eventMedian == nil }
}

/// quietVsEvent() result: one `VitalComparison` per sheet row (§4 row order).
struct NightComparison: Equatable {
    var hrBpm: VitalComparison
    var rmssdMs: VitalComparison
    var skinTempC: VitalComparison
    var edaUs: VitalComparison
    var dahGm3: VitalComparison
    var perfusionPct: VitalComparison
    var spo2Pct: VitalComparison
    var motion: VitalComparison
    var ambTempC: VitalComparison
    var ambRhPct: VitalComparison
}

/// Pure analytics over verified log records. Spec §15.3: FE02 only describes the most recent
/// session, so older nights' summaries must be recomputed by the app from replayed data.
enum NightAnalytics {

    /// Absolute humidity g/m³ from temperature °C and relative humidity %. (Magnus formula.)
    static func absoluteHumidity(tempC: Double, rh: Double) -> Double {
        let svp = 6.112 * exp((17.67 * tempC) / (tempC + 243.5)) // hPa
        return (svp * rh * 2.1674) / (273.15 + tempC)
    }

    /// Differential absolute humidity (skin − ambient), clamped at zero, ×100 as the firmware stores it.
    static func dahX100(skinTempC: Double, skinRh: Double, ambTempC: Double, ambRh: Double) -> Int {
        let d = absoluteHumidity(tempC: skinTempC, rh: skinRh) - absoluteHumidity(tempC: ambTempC, rh: ambRh)
        return Int((max(d, 0) * 100).rounded())
    }

    /// Walk sweat_flag: START (2) opens an event; ONGOING (1) extends it; NONE (0) closes it.
    /// An ONGOING without a START (e.g. connected mid-event) also opens one.
    static func sweatSpans(_ records: [LogRecord]) -> [SweatSpan] {
        var spans: [SweatSpan] = []
        var start: Int64? = nil
        var peak = 0
        var lastT: Int64 = 0
        for r in records {
            lastT = r.tS
            switch r.sweatFlag {
            case .start:
                if let s = start { spans.append(SweatSpan(startS: s, endS: r.tS, peakDahX100: peak)) }
                start = r.tS
                peak = r.dahX100
            case .ongoing:
                if start == nil { start = r.tS; peak = 0 }
                peak = max(peak, r.dahX100)
            case .none:
                if let s = start {
                    spans.append(SweatSpan(startS: s, endS: r.tS, peakDahX100: peak))
                    start = nil
                    peak = 0
                }
            }
        }
        if let s = start { spans.append(SweatSpan(startS: s, endS: lastT + Int64(Cadence.epochS), peakDahX100: peak)) }
        return spans
    }

    /// Recompute the FE02-equivalent summary from records, exactly as the firmware would.
    static func summarize(_ records: [LogRecord], slot: Int = 0) -> SessionSummary {
        guard !records.isEmpty else {
            return SessionSummary(sessionLenS: 0, epochsLogged: 0, sweatEvents: 0, longestSweatS: 0,
                                  peakDahX100: 0, hrMeanBpm: 0, hrMinBpm: 0, hrMaxBpm: 0,
                                  pctWake: 0, pctLight: 0, pctDeep: 0, battPct: 0, slot: slot)
        }
        let lenS = records[records.count - 1].tS + Int64(Cadence.epochS)
        let spans = sweatSpans(records)
        let hrs = records.filter { $0.hasHr }.map { $0.hrBpm }
        let classified = records.filter { $0.sleepState != .unknown }
        let n = max(classified.count, 1)
        let pctWake = 100 * classified.filter { $0.sleepState == .wake }.count / n
        let pctDeep = 100 * classified.filter { $0.sleepState == .deep }.count / n
        let pctLight = max(100 - pctWake - pctDeep, 0)
        let hrMean = hrs.isEmpty ? 0 : Int((Double(hrs.reduce(0, +)) / Double(hrs.count)).rounded())
        return SessionSummary(
            sessionLenS: lenS,
            epochsLogged: records.count,
            sweatEvents: spans.count,
            longestSweatS: Int(spans.map { $0.durationS }.max() ?? 0),
            peakDahX100: records.map { $0.dahX100 }.max() ?? 0,
            hrMeanBpm: hrMean,
            hrMinBpm: hrs.min() ?? 0,
            hrMaxBpm: hrs.max() ?? 0,
            pctWake: pctWake, pctLight: pctLight, pctDeep: pctDeep,
            battPct: records[records.count - 1].battPct,
            slot: slot
        )
    }

    /// The true HRV series: only records flagged HRV_FRESH (spec §10). Never de-dup by value.
    static func hrvSeries(_ records: [LogRecord]) -> [LogRecord] {
        records.filter { $0.hrvFresh }
    }

    /// Baseline skin temperature = median of the first 30 minutes of classified records.
    static func skinBaselineX100(_ records: [LogRecord]) -> Int? {
        let first = records.filter { $0.tS < 1800 }.map { $0.skinTempX100 }.sorted()
        if first.isEmpty { return nil }
        return first[first.count / 2]
    }

    /// Mean RMSSD of VALID windows, or nil if none.
    static func meanValidRmssdX10(_ records: [LogRecord]) -> Int? {
        let v = hrvSeries(records)
            .filter { HrvFlags.has($0.hrvFlags, HrvFlags.valid) }
            .map { $0.hrvRmssdMsX10 }
        if v.isEmpty { return nil }
        return Int((Double(v.reduce(0, +)) / Double(v.count)).rounded())
    }

    // ------------------------------------------------------------------ bundles (ext brief §3)

    /// Rolling baseline window: the previous 20 epochs = 10 min, clamped to what exists.
    private static let baselineEpochs = 20
    /// Sweat onset: EDA ≥ baseline + 1.5 µS.
    private static let edaOnsetDeltaX100 = 150
    /// Confirmation: skin temp ≥ baseline + 0.3 °C …
    private static let tempConfirmDeltaX100 = 30
    /// … AND heart rate ≥ baseline + 8 bpm …
    private static let hrConfirmDelta = 8
    /// … within ±10 epochs (±5 min) of the onset.
    private static let confirmWindowEpochs = 10
    /// Bundles closer than 20 epochs (10 min) are one event that dipped briefly.
    private static let mergeGapEpochs = 20
    /// Wake-ups are attributed to a bundle up to 20 epochs (10 min) after it ends.
    private static let wakeTailEpochs = 20
    private static let wakeMotionIndex = 40
    private static let longSoakS: Int64 = 20 * 60
    /// notFlashPattern: SpO2 ≤ baseline − 3 % (×10 wire units).
    private static let spo2DropX10 = 30
    private static let notFlashWindowEpochs = 10 // 5 min
    private static let notFlashMinWindows = 3

    /// Median of the ints, or nil when empty (upper-middle, matching skinBaselineX100).
    private static func medianOrNull(_ values: [Int]) -> Int? {
        if values.isEmpty { return nil }
        let s = values.sorted()
        return s[s.count / 2]
    }

    private static func medianOrNull(_ values: [Double]) -> Double? {
        if values.isEmpty { return nil }
        let s = values.sorted()
        return s[s.count / 2]
    }

    /// Per-epoch rolling baseline: median of the VALID samples among the previous
    /// `baselineEpochs` epochs (never including the current one, so a spike cannot
    /// raise its own baseline). Nil when no valid sample precedes the epoch yet.
    private static func rollingBaseline(_ values: [Int], valid: [Bool]) -> [Int?] {
        (0..<values.count).map { i in
            let from = max(0, i - baselineEpochs)
            return medianOrNull((from..<i).filter { valid[$0] }.map { values[$0] })
        }
    }

    /// Per-epoch "sweat is elevated" mask: EDA rule for v2 nights, sweat_flag fallback for v1.
    private static func sweatElevationMask(_ records: [LogRecord]) -> [Bool] {
        let n = records.count
        let eda = records.map { $0.validEdaX100 ?? 0 }
        let edaValid = records.map { $0.validEdaX100 != nil }
        if edaValid.contains(true) {
            let base = rollingBaseline(eda, valid: edaValid)
            return (0..<n).map { i in
                guard edaValid[i], let b = base[i] else { return false }
                return eda[i] >= b + edaOnsetDeltaX100
            }
        }
        // v1 fallback: reuse the existing sweat-span logic (spans are [startS, endS) ).
        let spans = sweatSpans(records)
        return records.map { r in
            spans.contains { r.tS >= $0.startS && r.tS < $0.endS }
        }
    }

    /// Raw sweat-spike count: contiguous elevated-sweat spans, BEFORE temp/HR
    /// confirmation. The Vital Sheet's sweat row reports this (all sweat activity),
    /// while the hero reports confirmed bundles — the two deliberately differ when a
    /// spike had no temp/HR confirmation (blanket, humid room).
    static func sweatSpikeCount(_ records: [LogRecord]) -> Int {
        var count = 0
        var prev = false
        for e in sweatElevationMask(records) {
            if e && !prev { count += 1 }
            prev = e
        }
        return count
    }

    /// Detect flash/sweat bundles per ext brief §3. Input: one night of 30 s epochs, in time
    /// order. A candidate is a contiguous elevated-sweat span (one onset per span); it
    /// becomes a bundle only when skin temp AND heart rate confirm within ±5 min of the
    /// onset — a sweat-only spike (blanket, humid room) must NOT count.
    static func detectBundles(_ records: [LogRecord]) -> [FlashBundle] {
        let n = records.count
        if n == 0 { return [] }

        let hasEda = records.contains { $0.validEdaX100 != nil }
        let eda = records.map { $0.validEdaX100 ?? 0 }
        let edaValid = records.map { $0.validEdaX100 != nil }
        let edaBase = rollingBaseline(eda, valid: edaValid)
        let temp = records.map { $0.skinTempX100 }
        let tempBase = rollingBaseline(temp, valid: [Bool](repeating: true, count: n))
        let hr = records.map { $0.hrBpm }
        let hrValid = records.map { $0.hrBpm > 0 } // brief: epochs with hrBpm > 0 only
        let hrBase = rollingBaseline(hr, valid: hrValid)

        // 1. Elevated-sweat spans as index ranges [first, last].
        let elevated = sweatElevationMask(records)
        var spans: [(first: Int, last: Int)] = []
        var i = 0
        while i < n {
            if elevated[i] {
                var j = i
                while j + 1 < n && elevated[j + 1] { j += 1 }
                spans.append((first: i, last: j))
                i = j + 1
            } else {
                i += 1
            }
        }

        // 2. Confirm each span at its onset; collect metrics.
        struct Candidate {
            var first: Int
            var last: Int
            var edaDelta: Int
            var tempDelta: Int
            var hrDelta: Int
        }
        var confirmed: [Candidate] = []
        for span in spans {
            let onset = span.first
            // Epoch 0 has no history — nothing to confirm against.
            guard let tBase = tempBase[onset], let hBase = hrBase[onset] else { continue }
            let lo = max(0, onset - confirmWindowEpochs)
            let hi = min(n - 1, onset + confirmWindowEpochs)
            let tempDelta = (lo...hi).map { temp[$0] - tBase }.max() ?? Int.min
            let hrDelta = (lo...hi).filter { hrValid[$0] }.map { hr[$0] - hBase }.max() ?? Int.min
            if tempDelta < tempConfirmDeltaX100 || hrDelta < hrConfirmDelta { continue }
            let edaDelta: Int
            if hasEda, let eBase = edaBase[onset] {
                edaDelta = (span.first...span.last).filter { edaValid[$0] }.map { eda[$0] - eBase }.max() ?? 0
            } else {
                edaDelta = 0 // v1: no conductance channel, delta is 0 by definition
            }
            confirmed.append(Candidate(first: span.first, last: span.last,
                                       edaDelta: max(0, edaDelta), tempDelta: tempDelta, hrDelta: hrDelta))
        }

        // 3. Merge confirmed bundles separated by < 20 epochs — one event that dipped briefly.
        var merged: [Candidate] = []
        for c in confirmed {
            if let prev = merged.last, c.first - prev.last < mergeGapEpochs {
                merged[merged.count - 1].last = c.last
                merged[merged.count - 1].edaDelta = max(prev.edaDelta, c.edaDelta)
                merged[merged.count - 1].tempDelta = max(prev.tempDelta, c.tempDelta)
                merged[merged.count - 1].hrDelta = max(prev.hrDelta, c.hrDelta)
            } else {
                merged.append(c)
            }
        }

        // 4. Wake attribution + long-soak classification on the merged spans.
        return merged.map { c in
            let startTs = records[c.first].tS
            let endTs = records[c.last].tS + Int64(Cadence.epochS) // span end is exclusive
            let wakeHi = min(n - 1, c.last + wakeTailEpochs)
            let hadWake = (c.first...wakeHi).contains {
                records[$0].sleepState == .wake || records[$0].motionIndex >= wakeMotionIndex
            }
            return FlashBundle(startTs: startTs, endTs: endTs,
                               peakEdaDeltaX100: c.edaDelta, tempDeltaX100: c.tempDelta, hrDelta: c.hrDelta,
                               hadWake: hadWake, longSoak: endTs - startTs >= longSoakS)
        }
    }

    /// QUIET 0–1 bundles · MILD 2–4 · MEANINGFUL ≥5 OR any long soak (ext brief §3).
    static func nightScore(_ bundles: [FlashBundle]) -> NightScore {
        if bundles.count >= 5 || bundles.contains(where: { $0.longSoak }) { return .meaningful }
        if bundles.count >= 2 { return .mild }
        return .quiet
    }

    /// The info-chip pattern flags (ext brief §3). Pure observations, never a diagnosis.
    static func nightFlags(_ records: [LogRecord]) -> NightFlags {
        let n = records.count
        if n == 0 { return NightFlags(notFlashPattern: false, warmRoom: false, allNightHighHr: false) }

        // warmRoom: ambient > 26 °C or > 60 %RH for more than half the night.
        let warm = records.filter { $0.ambTempX100 > 2600 || $0.ambRhX100 > 6000 }.count
        let warmRoom = warm * 2 > n

        // allNightHighHr: HR baseline (median of readable epochs) of the last third ≥ first third + 10.
        let firstThird = records.prefix(n / 3).filter { $0.hrBpm > 0 }.map { $0.hrBpm }
        let lastThird = records.suffix(n / 3).filter { $0.hrBpm > 0 }.map { $0.hrBpm }
        var allNightHighHr = false
        if let f = medianOrNull(firstThird), let l = medianOrNull(lastThird) {
            allNightHighHr = l >= f + 10
        }

        // notFlashPattern: ≥3 separate 5-min windows of HR up + SpO2 down + NO sweat.
        // Needs an SpO2 channel — a v1 night can never raise this flag.
        let hr = records.map { $0.hrBpm }
        let hrValid = records.map { $0.hrBpm > 0 }
        let hrBase = rollingBaseline(hr, valid: hrValid)
        let spo2 = records.map { $0.validSpo2X10 ?? 0 }
        let spo2Valid = records.map { $0.validSpo2X10 != nil }
        let spo2Base = rollingBaseline(spo2, valid: spo2Valid)
        let elevated = sweatElevationMask(records)
        let cond: [Bool] = (0..<n).map { i in
            guard hrValid[i], let hb = hrBase[i], hr[i] >= hb + hrConfirmDelta,
                  spo2Valid[i], let sb = spo2Base[i], spo2[i] <= sb - spo2DropX10,
                  !elevated[i], records[i].sweatFlag == SweatFlag.none else { return false }
            return true
        }
        // Non-overlapping windows; 8/10 epochs must match so single noisy epochs don't split one.
        var windows = 0
        var i = 0
        while i + notFlashWindowEpochs <= n {
            let hits = (i..<(i + notFlashWindowEpochs)).filter { cond[$0] }.count
            if hits >= notFlashWindowEpochs - 2 {
                windows += 1
                i += notFlashWindowEpochs
            } else {
                i += 1
            }
        }
        return NightFlags(notFlashPattern: windows >= notFlashMinWindows,
                          warmRoom: warmRoom,
                          allNightHighHr: allNightHighHr)
    }

    /// The Vital Sheet's two data columns (§4): per channel, median over quiet (non-bundle)
    /// epochs vs median + peak over bundle epochs. See the header comment for nil semantics.
    static func quietVsEvent(_ records: [LogRecord], bundles: [FlashBundle]) -> NightComparison {
        let inBundle: [Bool] = records.map { r in
            bundles.contains { r.tS >= $0.startTs && r.tS < $0.endTs }
        }

        func channel(_ extract: (LogRecord) -> Double?) -> VitalComparison {
            var quiet: [Double] = []
            var event: [Double] = []
            for (i, r) in records.enumerated() {
                if let v = extract(r) {
                    if inBundle[i] { event.append(v) } else { quiet.append(v) }
                }
            }
            return VitalComparison(quietMedian: medianOrNull(quiet),
                                   eventMedian: medianOrNull(event),
                                   eventPeak: event.max())
        }

        return NightComparison(
            hrBpm: channel { $0.hasHr ? Double($0.hrBpm) : nil },
            rmssdMs: channel { $0.hrvFresh && $0.hrvValid ? Double($0.hrvRmssdMsX10) / 10 : nil },
            skinTempC: channel { $0.skinTempC },
            edaUs: channel { $0.edaUs },
            dahGm3: channel { $0.dah },
            perfusionPct: channel { $0.perfusionPct },
            spo2Pct: channel { $0.spo2Pct },
            motion: channel { Double($0.motionIndex) },
            ambTempC: channel { $0.ambTempC },
            ambRhPct: channel { Double($0.ambRhX100) / 100 }
        )
    }
}
