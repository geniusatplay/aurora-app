// Pure analytics over verified log records — the iOS port of NightAnalytics.kt.
import Foundation

/// A contiguous sweat event derived from sweat_flag transitions.
struct SweatSpan: Equatable {
    var startS: Int64
    var endS: Int64
    var peakDahX100: Int
    var durationS: Int64 { endS - startS }
}

/// Pure analytics over verified log records. Spec §15.3: FE02 only describes the most recent
/// session, so older nights' summaries must be recomputed by the app from replayed data.
enum NightAnalytics {

    /// Absolute humidity g/m³ from temperature °C and relative humidity %. (Magnus formula.)
    static func absoluteHumidity(tempC: Double, rh: Double) -> Double {
        let svp = 6.112 * exp((17.67 * tempC) / (tempC + 243.5)) // hPa
        return (svp * rh * 2.1674) / (273.15 + tempC)
    }

    /// Differential absolute humidity (skin − ambient), clamped at zero, ×100 as the firmware stores it.
    static func dahX100(skinTempC: Double, skinRh: Double, ambTempC: Double, ambRh: Double) -> Int {
        let d = absoluteHumidity(tempC: skinTempC, rh: skinRh) - absoluteHumidity(tempC: ambTempC, rh: ambRh)
        return Int((max(d, 0) * 100).rounded())
    }

    /// Walk sweat_flag: START (2) opens an event; ONGOING (1) extends it; NONE (0) closes it.
    /// An ONGOING without a START (e.g. connected mid-event) also opens one.
    static func sweatSpans(_ records: [LogRecord]) -> [SweatSpan] {
        var spans: [SweatSpan] = []
        var start: Int64? = nil
        var peak = 0
        var lastT: Int64 = 0
        for r in records {
            lastT = r.tS
            switch r.sweatFlag {
            case .start:
                if let s = start { spans.append(SweatSpan(startS: s, endS: r.tS, peakDahX100: peak)) }
                start = r.tS
                peak = r.dahX100
            case .ongoing:
                if start == nil { start = r.tS; peak = 0 }
                peak = max(peak, r.dahX100)
            case .none:
                if let s = start {
                    spans.append(SweatSpan(startS: s, endS: r.tS, peakDahX100: peak))
                    start = nil
                    peak = 0
                }
            }
        }
        if let s = start { spans.append(SweatSpan(startS: s, endS: lastT + Int64(Cadence.epochS), peakDahX100: peak)) }
        return spans
    }

    /// Recompute the FE02-equivalent summary from records, exactly as the firmware would.
    static func summarize(_ records: [LogRecord], slot: Int = 0) -> SessionSummary {
        guard !records.isEmpty else {
            return SessionSummary(sessionLenS: 0, epochsLogged: 0, sweatEvents: 0, longestSweatS: 0,
                                  peakDahX100: 0, hrMeanBpm: 0, hrMinBpm: 0, hrMaxBpm: 0,
                                  pctWake: 0, pctLight: 0, pctDeep: 0, battPct: 0, slot: slot)
        }
        let lenS = records[records.count - 1].tS + Int64(Cadence.epochS)
        let spans = sweatSpans(records)
        let hrs = records.filter { $0.hasHr }.map { $0.hrBpm }
        let classified = records.filter { $0.sleepState != .unknown }
        let n = max(classified.count, 1)
        let pctWake = 100 * classified.filter { $0.sleepState == .wake }.count / n
        let pctDeep = 100 * classified.filter { $0.sleepState == .deep }.count / n
        let pctLight = max(100 - pctWake - pctDeep, 0)
        let hrMean = hrs.isEmpty ? 0 : Int((Double(hrs.reduce(0, +)) / Double(hrs.count)).rounded())
        return SessionSummary(
            sessionLenS: lenS,
            epochsLogged: records.count,
            sweatEvents: spans.count,
            longestSweatS: Int(spans.map { $0.durationS }.max() ?? 0),
            peakDahX100: records.map { $0.dahX100 }.max() ?? 0,
            hrMeanBpm: hrMean,
            hrMinBpm: hrs.min() ?? 0,
            hrMaxBpm: hrs.max() ?? 0,
            pctWake: pctWake, pctLight: pctLight, pctDeep: pctDeep,
            battPct: records[records.count - 1].battPct,
            slot: slot
        )
    }

    /// The true HRV series: only records flagged HRV_FRESH (spec §10). Never de-dup by value.
    static func hrvSeries(_ records: [LogRecord]) -> [LogRecord] {
        records.filter { $0.hrvFresh }
    }

    /// Baseline skin temperature = median of the first 30 minutes of classified records.
    static func skinBaselineX100(_ records: [LogRecord]) -> Int? {
        let first = records.filter { $0.tS < 1800 }.map { $0.skinTempX100 }.sorted()
        if first.isEmpty { return nil }
        return first[first.count / 2]
    }

    /// Mean RMSSD of VALID windows, or nil if none.
    static func meanValidRmssdX10(_ records: [LogRecord]) -> Int? {
        let v = hrvSeries(records)
            .filter { HrvFlags.has($0.hrvFlags, HrvFlags.valid) }
            .map { $0.hrvRmssdMsX10 }
        if v.isEmpty { return nil }
        return Int((Double(v.reduce(0, +)) / Double(v.count)).rounded())
    }
}
