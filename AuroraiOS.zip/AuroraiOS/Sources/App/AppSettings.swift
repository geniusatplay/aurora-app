import Foundation
import Combine

/// Vital Sheet design scheme (ext brief §5) — Settings ▸ "Vital Sheet style", persisted
/// beside the theme under the "sheet_scheme" key. Applies to the Vital Sheet screen, its
/// PDF export and the new chart panels' frame styling; data/series colors NEVER change
/// between schemes (color follows the entity).
enum SheetScheme: String, CaseIterable, Codable {
    case scheme1, scheme2, scheme3

    /// Localization key for the picker label (scheme_1 "Scheme 1 — Aurora cards", …).
    var titleKey: String {
        switch self {
        case .scheme1: return "scheme_1"
        case .scheme2: return "scheme_2"
        case .scheme3: return "scheme_3"
        }
    }

    /// Localization key for the one-line description (scheme_1_desc, …).
    var blurbKey: String { titleKey + "_desc" }
}

/// User preferences, UserDefaults-backed, observable. The single source of truth for
/// theme, language, units and the range-guide toggle.
final class AppSettings: ObservableObject {
    private let d = UserDefaults.standard

    @Published var userId: String? { didSet { d.set(userId, forKey: "user_id") } }
    @Published var themeMode: ThemeMode { didSet { d.set(themeMode.rawValue, forKey: "theme") } }
    @Published var language: AppLanguage {
        didSet {
            d.set(language.rawValue, forKey: "lang")
            L10n.set(language)
        }
    }
    @Published var useFahrenheit: Bool { didSet { d.set(useFahrenheit, forKey: "fahrenheit") } }
    @Published var use24h: Bool { didSet { d.set(use24h, forKey: "h24") } }
    @Published var demoMode: Bool { didSet { d.set(demoMode, forKey: "demo") } }
    @Published var showRanges: Bool { didSet { d.set(showRanges, forKey: "ranges") } }
    @Published var sheetScheme: SheetScheme { didSet { d.set(sheetScheme.rawValue, forKey: "sheet_scheme") } }

    init() {
        userId = d.string(forKey: "user_id")
        themeMode = ThemeMode(rawValue: d.string(forKey: "theme") ?? "") ?? .aurora
        language = AppLanguage(rawValue: d.string(forKey: "lang") ?? "") ?? .system
        useFahrenheit = d.bool(forKey: "fahrenheit")
        use24h = d.object(forKey: "h24") == nil ? true : d.bool(forKey: "h24")
        demoMode = d.bool(forKey: "demo")
        showRanges = d.bool(forKey: "ranges")
        sheetScheme = SheetScheme(rawValue: d.string(forKey: "sheet_scheme") ?? "") ?? .scheme1
        L10n.set(language)
    }

    var tempUnit: String { useFahrenheit ? "°F" : "°C" }
    func toDisplayTemp(_ c: Double) -> Double { useFahrenheit ? c * 9 / 5 + 32 : c }
    /// Deltas convert without the +32 offset.
    func toDisplayDelta(_ dc: Double) -> Double { useFahrenheit ? dc * 9 / 5 : dc }
}

/// Formatting helpers, localized through L10n.
enum Fmt {
    static func duration(_ seconds: Int64) -> String {
        let h = seconds / 3600, m = (seconds % 3600) / 60
        return h > 0 ? L("fmt_h_m", Int(h), Int(m)) : L("fmt_m", Int(m))
    }

    static func durationShort(_ seconds: Int64) -> String {
        let m = seconds / 60
        return m > 0 ? L("fmt_min", Int(m)) : L("fmt_s", Int(seconds))
    }

    static func clock(_ date: Date, _ settings: AppSettings) -> String {
        let f = DateFormatter()
        f.locale = L10n.locale
        f.dateFormat = settings.use24h ? "HH:mm" : "h:mm a"
        return f.string(from: date)
    }

    static func date(_ date: Date, format: String) -> String {
        let f = DateFormatter()
        f.locale = L10n.locale
        f.setLocalizedDateFormatFromTemplate(format)
        return f.string(from: date)
    }

    static func nightLabel(_ startedAt: Date) -> String {
        L("fmt_night_of", date(startedAt, format: "EEE d MMM"))
    }

    static func temp(_ c: Double, _ s: AppSettings) -> String {
        String(format: "%.1f", s.toDisplayTemp(c)) + s.tempUnit
    }

    static func delta(_ dc: Double, _ s: AppSettings) -> String {
        (dc >= 0 ? "+" : "") + String(format: "%.1f", s.toDisplayDelta(dc)) + s.tempUnit
    }

    static func dah(_ gm3: Double) -> String { String(format: "%.1f", gm3) }
}
