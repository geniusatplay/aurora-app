import Foundation

/// App language. `.system` follows the phone; others force a bundle.
enum AppLanguage: String, CaseIterable, Codable {
    case system = ""
    case english = "en"
    case spanish = "es"
    case vietnamese = "vi"
}

/// In-app language switching: strings are resolved from the selected language's .lproj bundle
/// so changing language takes effect immediately, without restarting the app.
enum L10n {
    private static var bundle: Bundle = .main
    private(set) static var current: AppLanguage = .system

    static func set(_ language: AppLanguage) {
        current = language
        if language == .system {
            bundle = .main
        } else if let path = Bundle.main.path(forResource: language.rawValue, ofType: "lproj"),
                  let b = Bundle(path: path) {
            bundle = b
        } else {
            bundle = .main
        }
    }

    static func t(_ key: String) -> String {
        bundle.localizedString(forKey: key, value: nil, table: nil)
    }

    static func t(_ key: String, _ args: CVarArg...) -> String {
        String(format: bundle.localizedString(forKey: key, value: nil, table: nil), arguments: args)
    }

    static var locale: Locale {
        current == .system ? .current : Locale(identifier: current.rawValue)
    }
}

/// Shorthand used across the UI: `L("home_title")`, `L("live_next_reading_min", 7)`.
func L(_ key: String) -> String { L10n.t(key) }
func L(_ key: String, _ args: CVarArg...) -> String {
    String(format: L10n.t(key), arguments: args)
}
