import Foundation
import Combine

/// One user-built page (custom pages brief): its number 1…5 and the section IDs in order.
/// Section IDs are the catalogue's stable strings (`SectionId.rawValue`); IDs this build
/// does not know (written by a newer version) are kept untouched and skipped when rendering.
struct CustomPage: Codable, Equatable, Identifiable {
    var n: Int
    var sections: [String]

    var id: Int { n }

    init(n: Int, sections: [String] = []) {
        self.n = n
        self.sections = sections
    }

    private enum CodingKeys: String, CodingKey {
        case n, sections
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        n = try c.decode(Int.self, forKey: .n)
        // A page without a list (hand-edited / older writer) is an empty page, not an error.
        sections = (try? c.decodeIfPresent([String].self, forKey: .sections)) ?? []
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(n, forKey: .n)
        try c.encode(sections, forKey: .sections)
    }
}

/// The user's custom pages, persisted to UserDefaults key `custom_pages` as the JSON string
/// `[{"n":1,"sections":["live_hr","night_timeline"]}, …]`, pages sorted by n — the same
/// shape Android (DataStore) and the web app (localStorage) use.
///
/// Main thread only (driven by the UI). Every mutation saves immediately.
///
/// Positions passed to `move` / `removeSections(at:)` index the VISIBLE list (the known
/// sections the page renders); unknown IDs keep their absolute slots in the stored array.
final class CustomPagesStore: ObservableObject {

    static let defaultsKey = "custom_pages"
    static let maxPages = 5

    @Published private(set) var pages: [CustomPage] = []

    private let defaults: UserDefaults
    private let isKnown: (String) -> Bool

    /// - Parameters:
    ///   - defaults: injected for tests (a suite); `.standard` in the app.
    ///   - isKnown: which section IDs this build can render (default: the catalogue).
    init(defaults: UserDefaults = .standard,
         isKnown: @escaping (String) -> Bool = { SectionId(rawValue: $0) != nil }) {
        self.defaults = defaults
        self.isKnown = isKnown
        self.pages = CustomPagesStore.load(from: defaults)
    }

    // MARK: - Queries

    var canCreatePage: Bool { pages.count < CustomPagesStore.maxPages }

    func page(_ n: Int) -> CustomPage? {
        pages.first { $0.n == n }
    }

    /// Stored IDs of a page, unknown ones included.
    func sections(of n: Int) -> [String] {
        page(n)?.sections ?? []
    }

    /// The sections a page renders, in order (unknown IDs skipped).
    func visibleSections(of n: Int) -> [SectionId] {
        sections(of: n).compactMap { isKnown($0) ? SectionId(rawValue: $0) : nil }
    }

    func contains(_ sectionId: String, on n: Int) -> Bool {
        sections(of: n).contains(sectionId)
    }

    /// Lowest unused page number 1…5, or nil when all five exist.
    func nextPageNumber() -> Int? {
        let used = Set(pages.map { $0.n })
        return (1...CustomPagesStore.maxPages).first { !used.contains($0) }
    }

    // MARK: - Mutations

    /// Creates the lowest unused page number and returns it; nil when 5 pages exist.
    @discardableResult
    func createNextPage() -> Int? {
        guard let n = nextPageNumber() else { return nil }
        var next = pages
        next.append(CustomPage(n: n))
        commit(next)
        return n
    }

    func deletePage(_ n: Int) {
        guard page(n) != nil else { return }
        commit(pages.filter { $0.n != n })
    }

    /// Appends a section to the end of a page. A section may be on several pages but only
    /// once per page; returns false when it is already there or the page does not exist.
    @discardableResult
    func addSection(_ sectionId: String, to n: Int) -> Bool {
        guard let idx = pages.firstIndex(where: { $0.n == n }),
              !pages[idx].sections.contains(sectionId) else { return false }
        var next = pages
        next[idx].sections.append(sectionId)
        commit(next)
        return true
    }

    func removeSection(_ sectionId: String, from n: Int) {
        guard let idx = pages.firstIndex(where: { $0.n == n }),
              pages[idx].sections.contains(sectionId) else { return }
        var next = pages
        next[idx].sections.removeAll { $0 == sectionId }
        commit(next)
    }

    /// Removes sections by their positions in the visible list (List `.onDelete`).
    func removeSections(at offsets: IndexSet, from n: Int) {
        guard let idx = pages.firstIndex(where: { $0.n == n }) else { return }
        let visible = pages[idx].sections.filter(isKnown)
        let doomed = Set(offsets.filter { $0 >= 0 && $0 < visible.count }.map { visible[$0] })
        guard !doomed.isEmpty else { return }
        var next = pages
        next[idx].sections.removeAll { doomed.contains($0) }
        commit(next)
    }

    /// Reorders a page's sections with List `.onMove` semantics (`toOffset` is a position
    /// in the visible list BEFORE the move). Unknown IDs stay in their stored slots.
    func move(page n: Int, fromOffsets: IndexSet, toOffset: Int) {
        guard let idx = pages.firstIndex(where: { $0.n == n }) else { return }
        let stored = pages[idx].sections
        let visible = stored.filter(isKnown)
        let moved = CustomPagesStore.moved(visible, fromOffsets: fromOffsets, toOffset: toOffset)
        guard moved != visible else { return }
        // Refill the known slots in their new order; unknown IDs keep their positions.
        var it = moved.makeIterator()
        var rebuilt: [String] = []
        rebuilt.reserveCapacity(stored.count)
        for id in stored {
            if isKnown(id), let nextKnown = it.next() {
                rebuilt.append(nextKnown)
            } else {
                rebuilt.append(id)
            }
        }
        var next = pages
        next[idx].sections = rebuilt
        commit(next)
    }

    /// Accessibility / keyboard "move up / move down": shifts one section by `delta`
    /// positions within the visible list.
    func moveSection(_ sectionId: String, by delta: Int, on n: Int) {
        let visible = sections(of: n).filter(isKnown)
        guard let from = visible.firstIndex(of: sectionId) else { return }
        let to = min(max(from + delta, 0), visible.count - 1)
        guard to != from else { return }
        // onMove offsets point BEFORE the destination row when moving down.
        move(page: n, fromOffsets: IndexSet(integer: from), toOffset: to > from ? to + 1 : to)
    }

    // MARK: - Pure helpers (unit-tested)

    /// `Array.move(fromOffsets:toOffset:)` semantics without importing SwiftUI.
    static func moved(_ items: [String], fromOffsets: IndexSet, toOffset: Int) -> [String] {
        let valid = fromOffsets.filter { $0 >= 0 && $0 < items.count }
        guard !valid.isEmpty else { return items }
        let moving = valid.sorted().map { items[$0] }
        var rest: [String] = []
        for (i, item) in items.enumerated() where !valid.contains(i) {
            rest.append(item)
        }
        let removedBefore = valid.filter { $0 < toOffset }.count
        let insertAt = min(max(toOffset - removedBefore, 0), rest.count)
        rest.insert(contentsOf: moving, at: insertAt)
        return rest
    }

    /// Parses the stored JSON: pages sorted by n, numbers outside 1…5 and duplicate numbers
    /// dropped, duplicate section IDs within a page dropped; anything unreadable → no pages.
    static func decode(_ json: String) -> [CustomPage] {
        guard let data = json.data(using: .utf8),
              let raw = try? JSONDecoder().decode([CustomPage].self, from: data) else { return [] }
        var seen = Set<Int>()
        var out: [CustomPage] = []
        for p in raw where p.n >= 1 && p.n <= maxPages && !seen.contains(p.n) {
            seen.insert(p.n)
            var ids: [String] = []
            for id in p.sections where !ids.contains(id) { ids.append(id) }
            out.append(CustomPage(n: p.n, sections: ids))
        }
        return out.sorted { $0.n < $1.n }
    }

    /// `[{"n":1,"sections":[…]}, …]` — sorted keys so "n" comes first, pages sorted by n.
    static func encode(_ pages: [CustomPage]) -> String {
        let enc = JSONEncoder()
        enc.outputFormatting = [.sortedKeys]
        guard let data = try? enc.encode(pages.sorted { $0.n < $1.n }),
              let s = String(data: data, encoding: .utf8) else { return "[]" }
        return s
    }

    // MARK: - Persistence

    private static func load(from defaults: UserDefaults) -> [CustomPage] {
        if let s = defaults.string(forKey: defaultsKey) { return decode(s) }
        if let d = defaults.data(forKey: defaultsKey), let s = String(data: d, encoding: .utf8) {
            return decode(s)
        }
        return []
    }

    private func commit(_ next: [CustomPage]) {
        let sorted = next.sorted { $0.n < $1.n }
        pages = sorted
        defaults.set(CustomPagesStore.encode(sorted), forKey: CustomPagesStore.defaultsKey)
    }
}
