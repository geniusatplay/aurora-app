import SwiftUI
import SwiftData

/// App entry point: builds the object graph (SwiftData container, repositories, pod manager,
/// demo controller) and hands everything to RootView through the environment.
@main
struct AuroraApp: App {
    private let container: ModelContainer
    @StateObject private var settings: AppSettings
    @StateObject private var repo: SessionRepository
    @StateObject private var pod: PodConnectionManager
    @StateObject private var demoController: DemoController
    private let auth: AuthRepository

    init() {
        let container: ModelContainer
        do {
            container = try ModelContainer(for: Schema(AuroraSchema.models))
        } catch {
            // Last resort: wipe-and-recreate is acceptable for a v1 local store.
            fatalError("Could not create SwiftData container: \(error)")
        }
        self.container = container
        let context = container.mainContext

        let settings = AppSettings()
        let repo = SessionRepository(context: context)
        let auth = AuthRepository(context: context, settings: settings)
        let pod = PodConnectionManager(repo: repo)
        let demo = DemoController(pod: pod, repo: repo, settings: settings)

        _settings = StateObject(wrappedValue: settings)
        _repo = StateObject(wrappedValue: repo)
        _pod = StateObject(wrappedValue: pod)
        _demoController = StateObject(wrappedValue: demo)
        self.auth = auth

        auth.seedDemoAccount()
        pod.setUser(settings.userId.flatMap(UUID.init(uuidString:)))
        if settings.demoMode { pod.useDemo(true) }
    }

    var body: some Scene {
        WindowGroup {
            RootView(auth: auth)
                .environmentObject(settings)
                .environmentObject(repo)
                .environmentObject(pod)
                .environmentObject(demoController)
                .modelContainer(container)
                .onChange(of: settings.userId) { _, newValue in
                    pod.setUser(newValue.flatMap(UUID.init(uuidString:)))
                }
        }
    }
}
