// Data-presence gates for the real Aurora Pod (hardware protocol v1, PROTOCOL §3/§4/§9) —
// the iOS port of ui/HardwareUi.kt.
//
// Stored nights are gated on their DATA, never only on the current pod: a night recorded
// on the real glove stays a hardware night even while the app is in demo mode.
// The real glove has no room sensor, so every record it produces carries the
// HwAdapter.NO_AMBIENT_TEMP_X100 sentinel — that is what identifies a hardware night.

import Foundation

// MARK: - Hardware night (no room sensor reading anywhere)

/// A night whose records have no ambient (room) sensor reading is a hardware night.
func isHardwareNight(_ records: [LogRecord]) -> Bool {
    !records.isEmpty && !records.contains { HwAdapter.hasAmbient($0.ambTempX100) }
}

func isHardwareNight(_ epochs: [EpochModel]) -> Bool {
    !epochs.isEmpty && !epochs.contains { HwAdapter.hasAmbient($0.ambTempX100) }
}

/// At least one record carries a real room temperature/humidity reading.
func hasAmbientData(_ records: [LogRecord]) -> Bool {
    records.contains { HwAdapter.hasAmbient($0.ambTempX100) }
}

func hasAmbientData(_ epochs: [EpochModel]) -> Bool {
    epochs.contains { HwAdapter.hasAmbient($0.ambTempX100) }
}

// MARK: - Sleep staging / movement presence

private func summaryHasSleepSplit(_ summary: SummaryModel) -> Bool {
    summary.pctWake + summary.pctLight + summary.pctDeep > 0
}

/// True when the night has no sleep staging to show (no hypnogram, no sleep ring, no
/// % deep/light/awake): every record is UNKNOWN AND the night is either a hardware night
/// or a finished night whose summary carries no split. A demo night that is still being
/// recorded (UNKNOWN for its first minutes, no summary yet) keeps its charts as before.
func nightLacksSleep(_ records: [LogRecord], summary: SummaryModel?) -> Bool {
    let allUnknown = records.allSatisfy { $0.sleepState == .unknown }
    guard allUnknown else { return false }
    if isHardwareNight(records) { return true }
    if let s = summary { return !summaryHasSleepSplit(s) }
    return false
}

func nightLacksSleep(_ epochs: [EpochModel], summary: SummaryModel?) -> Bool {
    let allUnknown = epochs.allSatisfy { SleepState.from($0.sleepState) == .unknown }
    guard allUnknown else { return false }
    if isHardwareNight(epochs) { return true }
    if let s = summary { return !summaryHasSleepSplit(s) }
    return false
}

/// No sleep staging AND no movement at all (no accelerometer) → hide movement panels too.
func nightLacksMotion(_ records: [LogRecord], summary: SummaryModel?) -> Bool {
    nightLacksSleep(records, summary: summary) && records.allSatisfy { $0.motionIndex == 0 }
}

func nightLacksMotion(_ epochs: [EpochModel], summary: SummaryModel?) -> Bool {
    nightLacksSleep(epochs, summary: summary) && epochs.allSatisfy { $0.motionIndex == 0 }
}

/// Summary-only check (Trends, night lists): a split exists to draw.
func summaryHasSleep(_ summary: SummaryModel?) -> Bool {
    guard let s = summary else { return false }
    return summaryHasSleepSplit(s)
}

/// Same check on the protocol struct (code that speaks SessionSummary).
func summaryHasSleep(_ summary: SessionSummary?) -> Bool {
    guard let s = summary else { return false }
    return s.pctWake + s.pctLight + s.pctDeep > 0
}

// MARK: - Pod kind

/// The connected / last-seen pod speaks hardware protocol v1 (the real glove).
func isHardwarePod(_ caps: PodCapabilities, _ info: DeviceInfo?) -> Bool {
    if caps == PodCapabilities.hardwareV1 { return true }
    guard let info else { return false }
    return info.hardwareRevision.contains("protocol v1")
}
