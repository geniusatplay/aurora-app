// Shared building-block views — the iOS port of ui/components/Components.kt.
//
// Every component reads its colours from `@Environment(\.theme)` (Theme.swift) so the four
// theme modes (aurora / light / high-contrast / dark) all work without per-screen plumbing.
// All user-visible strings come in already localized, except Disclaimer and LevelBadge,
// which resolve their own keys via L().

import SwiftUI

// MARK: - AuroraCard

/// The standard rounded-22 content card. Optional `onTap` makes the whole card tappable
/// (Android used Card(onClick:)). Content is laid out as a leading-aligned column.
struct AuroraCard<Content: View>: View {
    @Environment(\.theme) private var theme
    private let padding: CGFloat
    private let spacing: CGFloat
    private let onTap: (() -> Void)?
    private let content: Content

    init(padding: CGFloat = 18,
         spacing: CGFloat = 0,
         onTap: (() -> Void)? = nil,
         @ViewBuilder content: () -> Content) {
        self.padding = padding
        self.spacing = spacing
        self.onTap = onTap
        self.content = content()
    }

    var body: some View {
        let card = VStack(alignment: .leading, spacing: spacing) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(padding)
            .background(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(theme.card)
            )
            .overlay(
                // High-contrast mode has a white background AND white cards; the outline
                // is what keeps the card readable there. Invisible otherwise.
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(theme.highContrast ? theme.outline : Color.clear, lineWidth: 1)
            )
        if let onTap {
            Button(action: onTap) { card }.buttonStyle(.plain)
        } else {
            card
        }
    }
}

// MARK: - HeroCard

/// Gradient hero card (pink → magenta, theme.heroGradient) with white content on top.
struct HeroCard<Content: View>: View {
    @Environment(\.theme) private var theme
    private let onTap: (() -> Void)?
    private let content: Content

    init(onTap: (() -> Void)? = nil, @ViewBuilder content: () -> Content) {
        self.onTap = onTap
        self.content = content()
    }

    var body: some View {
        let card = VStack(alignment: .leading, spacing: 0) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(22)
            .background(
                RoundedRectangle(cornerRadius: 26, style: .continuous)
                    .fill(LinearGradient(colors: theme.heroGradient,
                                         startPoint: .topLeading,
                                         endPoint: .bottomTrailing))
            )
        if let onTap {
            Button(action: onTap) { card }.buttonStyle(.plain)
        } else {
            card
        }
    }
}

// MARK: - SectionHeader

/// Title + optional subtitle row with an optional trailing accessory (e.g. a range picker).
struct SectionHeader<Trailing: View>: View {
    @Environment(\.theme) private var theme
    private let title: String
    private let subtitle: String?
    private let trailing: Trailing

    init(title: String, subtitle: String? = nil, @ViewBuilder trailing: () -> Trailing) {
        self.title = title
        self.subtitle = subtitle
        self.trailing = trailing()
    }

    var body: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
                if let subtitle {
                    Text(subtitle)
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
            }
            Spacer(minLength: 8)
            trailing
        }
        .padding(.vertical, 8)
    }
}

extension SectionHeader where Trailing == EmptyView {
    init(title: String, subtitle: String? = nil) {
        self.init(title: title, subtitle: subtitle) { EmptyView() }
    }
}

// MARK: - LevelBadge

/// Small Low / Medium / High badge shown on tiles when range guides are enabled.
/// Colour logic mirrors Android: LOW is a calm blue tint and HIGH a red tint, SWAPPED when
/// higher is the reassuring direction (HRV). Fixed light chip colours read fine on dark
/// cards too, exactly like the Android build.
struct LevelBadge: View {
    let level: Level
    var higherIsBetter: Bool = false

    var body: some View {
        // (bg, fg) pairs — calm blue vs. alert red, medium is neutral grey.
        let calm = (bg: Color(hex: 0xDDE4FA), fg: Color(hex: 0x243A8A))
        let alert = (bg: Color(hex: 0xFFE1E4), fg: Color(hex: 0x7A0F22))
        let neutral = (bg: Color(hex: 0xEDEAEE), fg: Color(hex: 0x3F3742))
        let c: (bg: Color, fg: Color)
        switch level {
        case .low: c = higherIsBetter ? alert : calm
        case .medium: c = neutral
        case .high: c = higherIsBetter ? calm : alert
        }
        return Text(L(level.labelKey))
            .font(.system(size: 11, weight: .bold))
            .foregroundStyle(c.fg)
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .background(RoundedRectangle(cornerRadius: 6, style: .continuous).fill(c.bg))
    }
}

// MARK: - StatTile

/// Metric tile: accent dot + label, big value with unit, optional note and level badge.
struct StatTile: View {
    @Environment(\.theme) private var theme
    private let label: String
    private let value: String
    private let unit: String
    private let accent: Color?
    private let note: String?
    private let level: Level?
    private let higherIsBetter: Bool

    init(label: String, value: String, unit: String = "",
         accent: Color? = nil, note: String? = nil,
         level: Level? = nil, higherIsBetter: Bool = false) {
        self.label = label
        self.value = value
        self.unit = unit
        self.accent = accent
        self.note = note
        self.level = level
        self.higherIsBetter = higherIsBetter
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Circle().fill(accent ?? theme.primary).frame(width: 8, height: 8)
                Text(label)
                    .font(AuroraFont.labelS())
                    .foregroundStyle(theme.textSecondary)
                    .lineLimit(1)
                Spacer(minLength: 0)
                if let level {
                    LevelBadge(level: level, higherIsBetter: higherIsBetter)
                }
            }
            HStack(alignment: .lastTextBaseline, spacing: 4) {
                Text(value)
                    .font(AuroraFont.headline())
                    .foregroundStyle(theme.textPrimary)
                if !unit.isEmpty {
                    Text(unit)
                        .font(AuroraFont.labelS())
                        .foregroundStyle(theme.textSecondary)
                }
            }
            if let note {
                Text(note)
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(theme.cardAlt))
    }
}

// MARK: - Pill

/// Small capsule chip. Defaults to the theme pill colours; pass `bg`/`fg` to override
/// (e.g. connection status pills).
struct Pill: View {
    @Environment(\.theme) private var theme
    private let text: String
    private let bg: Color?
    private let fg: Color?
    private let systemImage: String?

    init(text: String, bg: Color? = nil, fg: Color? = nil, systemImage: String? = nil) {
        self.text = text
        self.bg = bg
        self.fg = fg
        self.systemImage = systemImage
    }

    var body: some View {
        let fgColor = fg ?? theme.pillFg
        HStack(spacing: 4) {
            if let systemImage {
                Image(systemName: systemImage)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(fgColor)
            }
            Text(text)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(fgColor)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(Capsule().fill(bg ?? theme.pillBg))
    }
}

// MARK: - InfoBanner

enum BannerTone {
    case info, warning, error, success
}

/// Full-width tinted banner with a leading icon. Android used fixed light containers; here
/// each tone keeps its hue but the background is a translucent tint and the text swaps to a
/// light variant in dark themes, so banners stay readable on dark cards.
struct InfoBanner: View {
    @Environment(\.theme) private var theme
    private let text: String
    private let tone: BannerTone

    init(text: String, tone: BannerTone = .info) {
        self.text = text
        self.tone = tone
    }

    var body: some View {
        let dark = theme.isDark
        let base: Color   // the tone's hue, used for the tinted background
        let fg: Color     // dark text in light themes, light text in dark themes
        let icon: String
        switch tone {
        case .info:
            base = Color(hex: 0x5B6ECF)
            fg = dark ? Color(hex: 0xC9D2F7) : Color(hex: 0x243A8A)
            icon = "info.circle.fill"
        case .warning:
            base = Color(hex: 0xE8940A)
            fg = dark ? Color(hex: 0xFFD9A0) : Color(hex: 0x6B4300)
            icon = "exclamationmark.triangle.fill"
        case .error:
            base = Aurora.bad
            fg = dark ? Color(hex: 0xFFB4C0) : Color(hex: 0x7A0F22)
            icon = "exclamationmark.octagon.fill"
        case .success:
            base = Aurora.good
            fg = dark ? Color(hex: 0xA8E8C8) : Color(hex: 0x0E5A34)
            icon = "checkmark.circle.fill"
        }
        return HStack(alignment: .center, spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundStyle(fg)
            Text(text)
                .font(AuroraFont.bodyS())
                .foregroundStyle(fg)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(base.opacity(dark ? 0.30 : 0.15))
        )
    }
}

// MARK: - EmptyState

/// Centered placeholder: decorative gradient circle, title, body, optional action buttons.
struct EmptyState<Actions: View>: View {
    @Environment(\.theme) private var theme
    private let title: String
    private let bodyText: String
    private let actions: Actions

    init(title: String, body: String, @ViewBuilder actions: () -> Actions) {
        self.title = title
        self.bodyText = body
        self.actions = actions()
    }

    var body: some View {
        VStack(spacing: 0) {
            Circle()
                .fill(LinearGradient(colors: [Aurora.blossom, Aurora.petal],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(Circle().stroke(Aurora.petal, lineWidth: 2))
                .frame(width: 64, height: 64)
            Spacer().frame(height: 14)
            Text(title)
                .font(AuroraFont.title())
                .foregroundStyle(theme.textPrimary)
                .multilineTextAlignment(.center)
            Spacer().frame(height: 6)
            Text(bodyText)
                .font(AuroraFont.body())
                .foregroundStyle(theme.textSecondary)
                .multilineTextAlignment(.center)
            actions
                .padding(.top, 14)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
    }
}

extension EmptyState where Actions == EmptyView {
    init(title: String, body: String) {
        self.init(title: title, body: body) { EmptyView() }
    }
}

// MARK: - LabeledValue

/// Tiny label over value, in theme colours.
struct LabeledValue: View {
    @Environment(\.theme) private var theme
    let label: String
    let value: String

    init(label: String, value: String) {
        self.label = label
        self.value = value
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(AuroraFont.labelS())
                .foregroundStyle(theme.textSecondary)
            Text(value)
                .font(AuroraFont.title())
                .foregroundStyle(theme.textPrimary)
        }
    }
}

/// Same, but fixed white — for use on the HeroCard gradient.
struct WhiteLabeledValue: View {
    let label: String
    let value: String

    init(label: String, value: String) {
        self.label = label
        self.value = value
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(AuroraFont.labelS())
                .foregroundStyle(Color.white.opacity(0.8))
            Text(value)
                .font(AuroraFont.title())
                .foregroundStyle(Color.white)
        }
    }
}

// MARK: - Disclaimer

/// The general-wellness disclaimer, shown at the bottom of data screens. Never omit it
/// where the Android app shows it (convention #6: no medical claims).
struct Disclaimer: View {
    @Environment(\.theme) private var theme

    var body: some View {
        Text(L("wellness_disclaimer"))
            .font(AuroraFont.bodyS())
            .foregroundStyle(theme.textSecondary)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 4)
    }
}

// MARK: - VSpace

/// Fixed vertical gap, mirroring Android's VSpace helper.
struct VSpace: View {
    private let height: CGFloat
    init(_ height: CGFloat = 12) { self.height = height }
    var body: some View { Spacer().frame(height: height) }
}
