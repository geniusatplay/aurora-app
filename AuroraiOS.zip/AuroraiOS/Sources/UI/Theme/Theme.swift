import SwiftUI

/// Visual theme. `.aurora` follows the system light/dark switch; the others are fixed.
enum ThemeMode: String, CaseIterable, Codable {
    case aurora, light, highContrast, dark
}

/// The Aurora Pink base palette (identical values to the Android app).
enum Aurora {
    static let blossom = Color(hex: 0xFFE3EE)
    static let petal = Color(hex: 0xFFB8D1)
    static let rose = Color(hex: 0xFF6FA6)
    static let fuchsia = Color(hex: 0xE8308A)
    static let magenta = Color(hex: 0xB3125F)
    static let plum = Color(hex: 0x5E0A3A)
    static let ink = Color(hex: 0x17111A)
    static let cloud = Color.white
    static let mist = Color(hex: 0xF7F2F5)
    static let ash = Color(hex: 0x5A4F5C)
    static let darkCard = Color(hex: 0x241826)
    static let darkBg = Color(hex: 0x15101A)

    // Chart series (validated pair: fuchsia ↔ periwinkle pass CVD separation)
    static let seriesSkin = fuchsia
    static let seriesAmbient = Color(hex: 0x5B6ECF)
    static let seriesSweat = rose
    static let seriesHrv = Color(hex: 0x7A1F5C)
    static let seriesMotion = Color(hex: 0xB98BA8)
    static let sleepWake = Color(hex: 0xFFD6E4)
    static let sleepLight = Color(hex: 0xFF8DB8)
    static let sleepDeep = Color(hex: 0x8E1352)
    static let good = Color(hex: 0x1F8A5A)
    static let warn = Color(hex: 0xB8740A)
    static let bad = Color(hex: 0xC62840)
}

/// Resolved theme tokens for the current mode; injected via the SwiftUI environment.
struct AuroraTheme: Equatable {
    var mode: ThemeMode
    var isDark: Bool

    var background: Color
    var card: Color
    var cardAlt: Color          // tinted container inside cards (stat tiles)
    var textPrimary: Color
    var textSecondary: Color
    var outline: Color
    var primary: Color          // main accent (buttons, active states)
    var onPrimary: Color
    var inverse: Color          // "ink" buttons
    var onInverse: Color
    var pillBg: Color
    var pillFg: Color
    var track: Color            // progress track
    var heroGradient: [Color]
    var chartGrid: Color
    var chartAxisText: Color
    var tooltipBg: Color
    var tooltipFg: Color
    var seriesHeart: Color
    var highContrast: Bool

    static func resolve(mode: ThemeMode, systemDark: Bool) -> AuroraTheme {
        let dark = mode == .dark || (mode == .aurora && systemDark)
        switch (mode, dark) {
        case (.highContrast, _):
            return AuroraTheme(
                mode: mode, isDark: false,
                background: .white, card: .white, cardAlt: Color(hex: 0xF2F2F2),
                textPrimary: .black, textSecondary: Color(hex: 0x1A1A1A),
                outline: .black,
                primary: Color(hex: 0x9E0A52), onPrimary: .white,
                inverse: .black, onInverse: .white,
                pillBg: Color(hex: 0xFFC6DB), pillFg: .black,
                track: Color(hex: 0xDDDDDD),
                heroGradient: [Aurora.magenta, Aurora.plum],
                chartGrid: Color.black.opacity(0.33), chartAxisText: .black,
                tooltipBg: .black, tooltipFg: .white,
                seriesHeart: .black, highContrast: true
            )
        case (.light, _):
            return AuroraTheme(
                mode: mode, isDark: false,
                background: Color(hex: 0xFAFAFB), card: .white, cardAlt: Color(hex: 0xF4F3F6),
                textPrimary: Color(hex: 0x1B1B1F), textSecondary: Color(hex: 0x4B4650),
                outline: Color(hex: 0xC9C4CC),
                primary: Color(hex: 0xD1206F), onPrimary: .white,
                inverse: Color(hex: 0x2E2A30), onInverse: .white,
                pillBg: Color(hex: 0xFFD9E6), pillFg: Aurora.plum,
                track: Color(hex: 0xEDEDF0),
                heroGradient: [Color(hex: 0xFF8DB8), Aurora.fuchsia, Color(hex: 0xC81A6F)],
                chartGrid: Aurora.plum.opacity(0.12), chartAxisText: Aurora.ash,
                tooltipBg: Aurora.ink, tooltipFg: .white,
                seriesHeart: Aurora.ink, highContrast: false
            )
        case (_, true):
            return AuroraTheme(
                mode: mode, isDark: true,
                background: Aurora.darkBg, card: Aurora.darkCard, cardAlt: Color(hex: 0x2B1C2A),
                textPrimary: Color(hex: 0xF7E9F0), textSecondary: Color(hex: 0xD9C6D0),
                outline: Color(hex: 0x6B5262),
                primary: Aurora.rose, onPrimary: Aurora.ink,
                inverse: Aurora.blossom, onInverse: Aurora.ink,
                pillBg: Color(hex: 0x4A2038), pillFg: Aurora.blossom,
                track: Color(hex: 0x3A2A38),
                heroGradient: [Color(hex: 0xFF7FB4), Aurora.fuchsia, Aurora.magenta],
                chartGrid: Color.white.opacity(0.19), chartAxisText: Color(hex: 0xD9C6D0),
                tooltipBg: Aurora.blossom, tooltipFg: Aurora.ink,
                seriesHeart: Color(hex: 0xF7E9F0), highContrast: false
            )
        default:
            return AuroraTheme(
                mode: mode, isDark: false,
                background: Aurora.blossom, card: .white, cardAlt: Color(hex: 0xFFF4F8),
                textPrimary: Aurora.ink, textSecondary: Aurora.ash,
                outline: Color(hex: 0xD9C3CE),
                primary: Aurora.fuchsia, onPrimary: .white,
                inverse: Aurora.ink, onInverse: .white,
                pillBg: Aurora.petal, pillFg: Aurora.plum,
                track: Aurora.mist,
                heroGradient: [Color(hex: 0xFF7FB4), Aurora.fuchsia, Aurora.magenta],
                chartGrid: Aurora.plum.opacity(0.12), chartAxisText: Aurora.ash,
                tooltipBg: Aurora.ink, tooltipFg: .white,
                seriesHeart: Aurora.ink, highContrast: false
            )
        }
    }
}

private struct AuroraThemeKey: EnvironmentKey {
    static let defaultValue = AuroraTheme.resolve(mode: .aurora, systemDark: false)
}

extension EnvironmentValues {
    var theme: AuroraTheme {
        get { self[AuroraThemeKey.self] }
        set { self[AuroraThemeKey.self] = newValue }
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }
}

/// Typography: small text deliberately heavier and a point larger than defaults.
enum AuroraFont {
    static func display() -> Font { .system(size: 52, weight: .bold) }
    static func headlineL() -> Font { .system(size: 30, weight: .bold) }
    static func headline() -> Font { .system(size: 24, weight: .bold) }
    static func headlineS() -> Font { .system(size: 20, weight: .bold) }
    static func titleL() -> Font { .system(size: 18, weight: .bold) }
    static func title() -> Font { .system(size: 16, weight: .semibold) }
    static func titleS() -> Font { .system(size: 14.5, weight: .semibold) }
    static func body() -> Font { .system(size: 15, weight: .regular) }
    static func bodyM() -> Font { .system(size: 14, weight: .medium) }
    static func bodyS() -> Font { .system(size: 13, weight: .medium) }
    static func label() -> Font { .system(size: 13, weight: .semibold) }
    static func labelS() -> Font { .system(size: 12, weight: .semibold) }
}
