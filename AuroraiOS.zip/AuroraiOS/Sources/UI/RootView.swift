// App root — the iOS port of ui/navigation/AuroraRoot.kt: theme + locale injection,
// sign-in gate, the tab shell with per-tab NavigationStacks (Home, Live, Trends, Pod,
// Settings + custom pages 1…5 in a horizontally scrollable bottom bar), the floating Demo
// capsule, the + button for a new custom page, the pod-message toast and morning-card
// navigation.

import SwiftUI
import Combine

struct RootView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var repo: SessionRepository
    @EnvironmentObject private var demoController: DemoController
    @EnvironmentObject private var customPages: CustomPagesStore
    /// Plain dependency (not observable) — passed by the App, forwarded to screens.
    let auth: AuthRepository

    @Environment(\.colorScheme) private var colorScheme

    /// The five fixed tabs plus the user's custom pages 1…5.
    enum AppTab: Hashable {
        case home, live, trends, pod, settings
        case custom(Int)

        var isCustom: Bool {
            if case .custom = self { return true }
            return false
        }
    }

    /// Identifiable wrapper for the section-library sheet (`.sheet(item:)`).
    private struct LibraryTarget: Identifiable {
        let page: Int
        var id: Int { page }
    }

    /// What the bottom bar shows as selected (a main tab or a custom page).
    @State private var selectedTab: AppTab = .home
    /// The TabView's own selection — always one of the five main tabs. Custom pages are
    /// NOT TabView tabs: on iPhone a TabView with more than five tabs pushes the extra ones
    /// into UIKit's "More" navigation controller (nested navigation bars), so the selected
    /// custom page is layered above the (kept-alive) TabView instead.
    @State private var mainTab: AppTab = .home
    // One navigation path per tab that can push a night (Home, Trends, Pod, custom pages).
    @State private var homePath = NavigationPath()
    @State private var trendsPath = NavigationPath()
    @State private var podPath = NavigationPath()
    @State private var customPaths: [Int: NavigationPath] = [:]
    @State private var demoOpen = false
    @State private var library: LibraryTarget?
    // Transient pod-message toast (Android's snackbar); generation counter cancels
    // an older auto-dismiss when a newer message replaces the toast.
    @State private var toast: PodMessage?
    @State private var toastGen = 0

    var body: some View {
        let theme = AuroraTheme.resolve(mode: settings.themeMode, systemDark: colorScheme == .dark)
        Group {
            if settings.userId == nil {
                SignInScreen(auth: auth)
                    .background(theme.background.ignoresSafeArea())
            } else {
                tabShell(theme: theme)
            }
        }
        .environment(\.theme, theme)
        .tint(theme.primary)
        // Aurora follows the system light/dark switch; dark is forced dark; light and
        // high-contrast are forced light (they are light palettes).
        .preferredColorScheme(settings.themeMode == .dark ? .dark
                              : settings.themeMode == .aurora ? nil : .light)
        // In-app language switch: L() already resolves from the forced bundle; the locale
        // + id() make SwiftUI's own formatting follow and re-render the whole tree.
        .environment(\.locale, L10n.locale)
        .id(settings.language)
    }

    // MARK: - Tab shell

    /// The five main tabs stay in a TabView (each keeps its state and NavigationStack
    /// exactly as before) whose system bar is hidden and replaced by a horizontally
    /// scrollable bar: Home … Settings, then custom pages 1…5. The selected custom page is
    /// shown above the TabView in its own NavigationStack (its path is kept per page).
    private func tabShell(theme: AuroraTheme) -> some View {
        let showingCustom = selectedTab.isCustom
        return VStack(spacing: 0) {
            ZStack {
                tabContent(theme: theme)
                    .opacity(showingCustom ? 0 : 1)
                    .allowsHitTesting(!showingCustom)
                    .accessibilityHidden(showingCustom)
                if case .custom(let n) = selectedTab {
                    customPageStack(n)
                        .id(n)
                        .background(theme.background.ignoresSafeArea())
                }
            }
            .overlay(alignment: .bottomTrailing) { addPageButton(theme: theme) }
            // On the always-visible container (not the TabView, which is transparent while
            // a custom page shows) so the Demo sheet opens from every tab and page.
            .sheet(isPresented: $demoOpen) {
                DemoSheet()
                    .environment(\.theme, theme)
                    .environment(\.locale, L10n.locale)
            }
            BottomTabBar(items: tabItems, selection: Binding(get: { selectedTab }, set: { select($0) }))
        }
        .overlay(alignment: .bottom) {
            if let toast {
                ToastCapsule(message: toast)
                    .padding(.bottom, 72) // float just above the tab bar
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onReceive(pod.messages) { msg in
            withAnimation { toast = msg }
            toastGen += 1
            let gen = toastGen
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                if toastGen == gen { withAnimation { toast = nil } }
            }
        }
        // Morning card (FE02 closed the session): jump to that night on the Home tab.
        .onReceive(pod.morningCard) { id in
            select(.home)
            homePath.append(id)
        }
        // A page deleted elsewhere (or never created) must not stay selected.
        .onChange(of: customPages.pages) { _, pages in
            if case .custom(let n) = selectedTab, !pages.contains(where: { $0.n == n }) {
                select(.home)
            }
        }
        .sheet(item: $library) { target in
            SectionLibrarySheet(pageNumber: target.page)
                .environment(\.theme, theme)
                .environment(\.locale, L10n.locale)
        }
    }

    private func tabContent(theme: AuroraTheme) -> some View {
        TabView(selection: $mainTab) {
            NavigationStack(path: $homePath) {
                HomeScreen(auth: auth,
                           onOpenNight: { homePath.append($0) },
                           onOpenPod: { select(.pod) },
                           onOpenLive: { select(.live) },
                           onDemo: { demoOpen = true },
                           onOpenVitalSheet: { homePath.append(VitalSheetRoute(sessionId: $0)) })
                    .navigationDestination(for: UUID.self) { id in
                        nightDetail(id,
                                    pop: { if !homePath.isEmpty { homePath.removeLast() } },
                                    openVitalSheet: { homePath.append(VitalSheetRoute(sessionId: id)) })
                    }
                    .navigationDestination(for: VitalSheetRoute.self) { route in
                        vitalSheet(route)
                    }
                    .safeAreaInset(edge: .bottom) { demoBar }
                    .toolbar(.hidden, for: .tabBar)
            }
            .toolbar(.hidden, for: .tabBar)
            .tag(AppTab.home)

            NavigationStack {
                LiveScreen(onOpenPod: { select(.pod) },
                           onDemo: { demoOpen = true })
                    .safeAreaInset(edge: .bottom) { demoBar }
                    .toolbar(.hidden, for: .tabBar)
            }
            .toolbar(.hidden, for: .tabBar)
            .tag(AppTab.live)

            NavigationStack(path: $trendsPath) {
                TrendsScreen(onOpenNight: { trendsPath.append($0) },
                             onDemo: { demoOpen = true })
                    .navigationDestination(for: UUID.self) { id in
                        nightDetail(id,
                                    pop: { if !trendsPath.isEmpty { trendsPath.removeLast() } },
                                    openVitalSheet: { trendsPath.append(VitalSheetRoute(sessionId: id)) })
                    }
                    .navigationDestination(for: VitalSheetRoute.self) { route in
                        vitalSheet(route)
                    }
                    .safeAreaInset(edge: .bottom) { demoBar }
                    .toolbar(.hidden, for: .tabBar)
            }
            .toolbar(.hidden, for: .tabBar)
            .tag(AppTab.trends)

            NavigationStack(path: $podPath) {
                PodScreen(onOpenNight: { podPath.append($0) })
                    .navigationDestination(for: UUID.self) { id in
                        nightDetail(id,
                                    pop: { if !podPath.isEmpty { podPath.removeLast() } },
                                    openVitalSheet: { podPath.append(VitalSheetRoute(sessionId: id)) })
                    }
                    .navigationDestination(for: VitalSheetRoute.self) { route in
                        vitalSheet(route)
                    }
                    .safeAreaInset(edge: .bottom) { demoBar }
                    .toolbar(.hidden, for: .tabBar)
            }
            .toolbar(.hidden, for: .tabBar)
            .tag(AppTab.pod)

            NavigationStack {
                SettingsScreen(auth: auth)
                    .safeAreaInset(edge: .bottom) { demoBar }
                    .toolbar(.hidden, for: .tabBar)
            }
            .toolbar(.hidden, for: .tabBar)
            .tag(AppTab.settings)
        }
    }

    // MARK: - Custom pages

    /// Every tab switch goes through here so the TabView's selection follows main tabs.
    private func select(_ tab: AppTab) {
        selectedTab = tab
        if !tab.isCustom { mainTab = tab }
    }

    private func customPath(_ n: Int) -> Binding<NavigationPath> {
        Binding(get: { customPaths[n] ?? NavigationPath() },
                set: { customPaths[n] = $0 })
    }

    private func customPageStack(_ n: Int) -> some View {
        let path = customPath(n)
        let actions = SectionActions(
            openNight: { id in customPaths[n, default: NavigationPath()].append(id) },
            openVitalSheet: { id in customPaths[n, default: NavigationPath()].append(VitalSheetRoute(sessionId: id)) },
            openPod: { select(.pod) },
            openDemo: { demoOpen = true })
        return NavigationStack(path: path) {
            CustomPageView(pageNumber: n,
                           onAddSection: { library = LibraryTarget(page: n) },
                           onDeletePage: { deletePage(n) })
                .environment(\.sectionActions, actions)
                .navigationDestination(for: UUID.self) { id in
                    nightDetail(id,
                                pop: { popCustom(n) },
                                openVitalSheet: { customPaths[n, default: NavigationPath()].append(VitalSheetRoute(sessionId: id)) })
                }
                .navigationDestination(for: VitalSheetRoute.self) { route in
                    vitalSheet(route)
                }
                .safeAreaInset(edge: .bottom) { demoBar }
        }
    }

    private func popCustom(_ n: Int) {
        guard var p = customPaths[n], !p.isEmpty else { return }
        p.removeLast()
        customPaths[n] = p
    }

    /// + : create the lowest free page, switch to it and open the library straight away.
    private func createPage() {
        guard let n = customPages.createNextPage() else { return }
        select(.custom(n))
        library = LibraryTarget(page: n)
    }

    private func deletePage(_ n: Int) {
        if selectedTab == .custom(n) { select(.home) }
        customPaths[n] = nil
        customPages.deletePage(n)
    }

    /// The + floats above the bar (and above the Demo capsule) on every tab root — never on
    /// pushed detail screens — and disappears once all five pages exist.
    @ViewBuilder
    private func addPageButton(theme: AuroraTheme) -> some View {
        if customPages.canCreatePage && !isShowingDetail {
            Button(action: createPage) {
                Image(systemName: "plus")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(theme.onPrimary)
                    .frame(width: 56, height: 56)
                    .background(Circle().fill(theme.primary))
                    .shadow(color: Color.black.opacity(0.22), radius: 8, y: 3)
            }
            .buttonStyle(.plain)
            .padding(.trailing, 20)
            .padding(.bottom, 68) // clear of the Demo capsule (8 + 44 + 8) at the tab root
            .accessibilityLabel(L("cp_add_page"))
            .accessibilityHint(L("cp_add_page_hint"))
            .transition(.scale.combined(with: .opacity))
        }
    }

    /// A detail screen (night / Vital Sheet) is pushed on the selected tab.
    private var isShowingDetail: Bool {
        switch selectedTab {
        case .home: return !homePath.isEmpty
        case .trends: return !trendsPath.isEmpty
        case .pod: return !podPath.isEmpty
        case .live, .settings: return false
        case .custom(let n): return !(customPaths[n]?.isEmpty ?? true)
        }
    }

    private var tabItems: [BottomTabItem] {
        var items: [BottomTabItem] = [
            BottomTabItem(tab: .home, title: L("app_tab_home"), systemImage: "house.fill", accessibility: L("app_tab_home")),
            BottomTabItem(tab: .live, title: L("app_tab_live"), systemImage: "waveform.path.ecg", accessibility: L("app_tab_live")),
            BottomTabItem(tab: .trends, title: L("app_tab_trends"), systemImage: "chart.bar.fill", accessibility: L("app_tab_trends")),
            BottomTabItem(tab: .pod, title: L("app_tab_pod"), systemImage: "dot.radiowaves.left.and.right", accessibility: L("app_tab_pod")),
            BottomTabItem(tab: .settings, title: L("app_tab_settings"), systemImage: "gearshape.fill", accessibility: L("app_tab_settings")),
        ]
        for page in customPages.pages {
            items.append(BottomTabItem(tab: .custom(page.n), title: "\(page.n)", systemImage: nil,
                                       accessibility: L("cp_tab_accessibility", page.n)))
        }
        return items
    }

    // MARK: - Destinations

    private func nightDetail(_ id: UUID, pop: @escaping () -> Void,
                             openVitalSheet: @escaping () -> Void) -> some View {
        NightDetailScreen(sessionId: id, onBack: pop, onOpenPod: { select(.pod) },
                          onOpenVitalSheet: openVitalSheet)
            .toolbar(.hidden, for: .tabBar)
    }

    private func vitalSheet(_ route: VitalSheetRoute) -> some View {
        VitalSheetScreen(sessionId: route.sessionId)
            .toolbar(.hidden, for: .tabBar)
    }

    // MARK: - Demo capsule (Android's DemoBar, floated above the tab bar per tab root)

    private var demoBar: some View {
        DemoCapsuleBar { demoOpen = true }
    }
}

// MARK: - Bottom tab bar (horizontally scrollable)

struct BottomTabItem: Identifiable {
    let tab: RootView.AppTab
    let title: String
    /// nil for custom pages, which show their number instead of an icon.
    let systemImage: String?
    let accessibility: String

    var id: RootView.AppTab { tab }
}

/// The app's bottom menu: Home, Live, Trends, Pod, Settings, then custom pages "1"…"5".
/// Scrolls sideways when it does not fit; the selected tab is scrolled into view.
private struct BottomTabBar: View {
    @Environment(\.theme) private var theme
    let items: [BottomTabItem]
    @Binding var selection: RootView.AppTab

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 2) {
                    ForEach(items) { item in
                        tabButton(item)
                            .id(item.tab)
                    }
                }
                .padding(.horizontal, 8)
            }
            .onAppear { proxy.scrollTo(selection, anchor: .center) }
            .onChange(of: selection) { _, newValue in
                withAnimation(.easeInOut(duration: 0.25)) { proxy.scrollTo(newValue, anchor: .center) }
            }
            .onChange(of: items.count) { _, _ in
                withAnimation(.easeInOut(duration: 0.25)) { proxy.scrollTo(selection, anchor: .center) }
            }
        }
        .frame(height: 54)
        .padding(.top, 2)
        .background(theme.card.ignoresSafeArea(edges: .bottom))
        .overlay(alignment: .top) {
            Rectangle()
                .fill(theme.outline.opacity(0.5))
                .frame(height: 0.5)
        }
    }

    private func tabButton(_ item: BottomTabItem) -> some View {
        let selected = item.tab == selection
        let color = selected ? theme.primary : theme.textSecondary
        return Button {
            selection = item.tab
        } label: {
            VStack(spacing: 3) {
                if let icon = item.systemImage {
                    Image(systemName: icon)
                        .font(.system(size: 19, weight: .semibold))
                        .frame(height: 24)
                    Text(item.title)
                        .font(.system(size: 10, weight: .semibold))
                        .lineLimit(1)
                } else {
                    // Custom page: its number, in a rounded badge.
                    Text(item.title)
                        .font(.system(size: 15, weight: .bold))
                        .frame(width: 30, height: 26)
                        .background(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .fill(selected ? theme.primary.opacity(0.16) : Color.clear)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .stroke(color, lineWidth: 1.5)
                        )
                        .frame(height: 38)
                }
            }
            .foregroundStyle(color)
            .frame(minWidth: item.systemImage == nil ? 50 : 66)
            .frame(height: 50)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(item.accessibility)
        .accessibilityAddTraits(selected ? [.isButton, .isSelected] : [.isButton])
    }
}

// MARK: - Demo capsule bar

private struct DemoCapsuleBar: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    let onTap: () -> Void

    var body: some View {
        let recording = pod.activeSession != nil
        let isDemo = settings.demoMode
        let labelKey = recording && isDemo ? "app_demo_recording"
            : isDemo ? "app_demo_mode" : "common_demo"
        Button(action: onTap) {
            HStack(spacing: 8) {
                Image(systemName: recording ? "moon.fill" : "play.fill")
                    .font(.system(size: 13, weight: .semibold))
                Text(L(labelKey))
                    .font(.system(size: 14, weight: .semibold))
                    .lineLimit(1)
                if recording {
                    Circle().fill(Aurora.petal).frame(width: 8, height: 8)
                }
            }
            .foregroundStyle(isDemo ? theme.onPrimary : theme.onInverse)
            .frame(maxWidth: .infinity)
            .frame(height: 44)
            .background(Capsule().fill(isDemo ? theme.primary : theme.inverse))
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

// MARK: - Toast (Android's snackbar for PodMessage)

private struct ToastCapsule: View {
    @Environment(\.theme) private var theme
    let message: PodMessage

    var body: some View {
        Text(message.text)
            .font(AuroraFont.bodyS())
            .foregroundStyle(message.isError ? Color.white : theme.tooltipFg)
            .lineLimit(3)
            .multilineTextAlignment(.center)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(Capsule().fill(message.isError ? Aurora.bad : theme.tooltipBg))
            .padding(.horizontal, 24)
            .shadow(color: .black.opacity(0.2), radius: 8, y: 2)
    }
}
