// App root — the iOS port of ui/navigation/AuroraRoot.kt: theme + locale injection,
// sign-in gate, the five-tab shell with per-tab NavigationStacks, the floating Demo
// capsule, the pod-message toast and morning-card navigation.

import SwiftUI
import Combine

struct RootView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var repo: SessionRepository
    @EnvironmentObject private var demoController: DemoController
    /// Plain dependency (not observable) — passed by the App, forwarded to screens.
    let auth: AuthRepository

    @Environment(\.colorScheme) private var colorScheme

    private enum AppTab: Hashable {
        case home, live, trends, pod, settings
    }

    @State private var selectedTab: AppTab = .home
    // One navigation path per tab that can push a night (Home, Trends, Pod).
    @State private var homePath = NavigationPath()
    @State private var trendsPath = NavigationPath()
    @State private var podPath = NavigationPath()
    @State private var demoOpen = false
    // Transient pod-message toast (Android's snackbar); generation counter cancels
    // an older auto-dismiss when a newer message replaces the toast.
    @State private var toast: PodMessage?
    @State private var toastGen = 0

    var body: some View {
        let theme = AuroraTheme.resolve(mode: settings.themeMode, systemDark: colorScheme == .dark)
        Group {
            if settings.userId == nil {
                SignInScreen(auth: auth)
                    .background(theme.background.ignoresSafeArea())
            } else {
                tabShell(theme: theme)
            }
        }
        .environment(\.theme, theme)
        .tint(theme.primary)
        // Aurora follows the system light/dark switch; dark is forced dark; light and
        // high-contrast are forced light (they are light palettes).
        .preferredColorScheme(settings.themeMode == .dark ? .dark
                              : settings.themeMode == .aurora ? nil : .light)
        // In-app language switch: L() already resolves from the forced bundle; the locale
        // + id() make SwiftUI's own formatting follow and re-render the whole tree.
        .environment(\.locale, L10n.locale)
        .id(settings.language)
    }

    // MARK: - Tab shell

    private func tabShell(theme: AuroraTheme) -> some View {
        TabView(selection: $selectedTab) {
            NavigationStack(path: $homePath) {
                HomeScreen(auth: auth,
                           onOpenNight: { homePath.append($0) },
                           onOpenPod: { selectedTab = .pod },
                           onOpenLive: { selectedTab = .live },
                           onDemo: { demoOpen = true })
                    .navigationDestination(for: UUID.self) { id in
                        nightDetail(id) { if !homePath.isEmpty { homePath.removeLast() } }
                    }
                    .safeAreaInset(edge: .bottom) { demoBar }
            }
            .tabItem { Label(L("app_tab_home"), systemImage: "house.fill") }
            .tag(AppTab.home)

            NavigationStack {
                LiveScreen(onOpenPod: { selectedTab = .pod },
                           onDemo: { demoOpen = true })
                    .safeAreaInset(edge: .bottom) { demoBar }
            }
            .tabItem { Label(L("app_tab_live"), systemImage: "waveform.path.ecg") }
            .tag(AppTab.live)

            NavigationStack(path: $trendsPath) {
                TrendsScreen(onOpenNight: { trendsPath.append($0) },
                             onDemo: { demoOpen = true })
                    .navigationDestination(for: UUID.self) { id in
                        nightDetail(id) { if !trendsPath.isEmpty { trendsPath.removeLast() } }
                    }
                    .safeAreaInset(edge: .bottom) { demoBar }
            }
            .tabItem { Label(L("app_tab_trends"), systemImage: "chart.bar.fill") }
            .tag(AppTab.trends)

            NavigationStack(path: $podPath) {
                PodScreen(onOpenNight: { podPath.append($0) })
                    .navigationDestination(for: UUID.self) { id in
                        nightDetail(id) { if !podPath.isEmpty { podPath.removeLast() } }
                    }
                    .safeAreaInset(edge: .bottom) { demoBar }
            }
            .tabItem { Label(L("app_tab_pod"), systemImage: "dot.radiowaves.left.and.right") }
            .tag(AppTab.pod)

            NavigationStack {
                SettingsScreen(auth: auth)
                    .safeAreaInset(edge: .bottom) { demoBar }
            }
            .tabItem { Label(L("app_tab_settings"), systemImage: "gearshape.fill") }
            .tag(AppTab.settings)
        }
        .overlay(alignment: .bottom) {
            if let toast {
                ToastCapsule(message: toast)
                    .padding(.bottom, 64) // float just above the tab bar
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onReceive(pod.messages) { msg in
            withAnimation { toast = msg }
            toastGen += 1
            let gen = toastGen
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                if toastGen == gen { withAnimation { toast = nil } }
            }
        }
        // Morning card (FE02 closed the session): jump to that night on the Home tab.
        .onReceive(pod.morningCard) { id in
            selectedTab = .home
            homePath.append(id)
        }
        .sheet(isPresented: $demoOpen) {
            DemoSheet()
                .environment(\.theme, theme)
                .environment(\.locale, L10n.locale)
        }
    }

    private func nightDetail(_ id: UUID, pop: @escaping () -> Void) -> some View {
        NightDetailScreen(sessionId: id, onBack: pop, onOpenPod: { selectedTab = .pod })
    }

    // MARK: - Demo capsule (Android's DemoBar, floated above the tab bar per tab root)

    private var demoBar: some View {
        DemoCapsuleBar { demoOpen = true }
    }
}

// MARK: - Demo capsule bar

private struct DemoCapsuleBar: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    let onTap: () -> Void

    var body: some View {
        let recording = pod.activeSession != nil
        let isDemo = settings.demoMode
        let labelKey = recording && isDemo ? "app_demo_recording"
            : isDemo ? "app_demo_mode" : "common_demo"
        Button(action: onTap) {
            HStack(spacing: 8) {
                Image(systemName: recording ? "moon.fill" : "play.fill")
                    .font(.system(size: 13, weight: .semibold))
                Text(L(labelKey))
                    .font(.system(size: 14, weight: .semibold))
                    .lineLimit(1)
                if recording {
                    Circle().fill(Aurora.petal).frame(width: 8, height: 8)
                }
            }
            .foregroundStyle(isDemo ? theme.onPrimary : theme.onInverse)
            .frame(maxWidth: .infinity)
            .frame(height: 44)
            .background(Capsule().fill(isDemo ? theme.primary : theme.inverse))
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

// MARK: - Toast (Android's snackbar for PodMessage)

private struct ToastCapsule: View {
    @Environment(\.theme) private var theme
    let message: PodMessage

    var body: some View {
        Text(message.text)
            .font(AuroraFont.bodyS())
            .foregroundStyle(message.isError ? Color.white : theme.tooltipFg)
            .lineLimit(3)
            .multilineTextAlignment(.center)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(Capsule().fill(message.isError ? Aurora.bad : theme.tooltipBg))
            .padding(.horizontal, 24)
            .shadow(color: .black.opacity(0.2), radius: 8, y: 2)
    }
}
