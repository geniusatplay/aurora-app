// Home dashboard — the iOS port of ui/screens/HomeScreen.kt.
//
// Greeting → recording-now card → last-night hero → morning card → week strip →
// pod strip → recent nights. All data comes from the environment objects; fetched
// state (night cards, latest night, slot count) is reloaded whenever the repository
// bumps `revision` (there are no Room Flows on iOS — see SessionRepository's contract).

import SwiftUI

struct HomeScreen: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var repo: SessionRepository
    @Environment(\.theme) private var theme

    /// Injected by RootView — used only to look up the signed-in user's display name.
    let auth: AuthRepository
    let onOpenNight: (UUID) -> Void
    let onOpenPod: () -> Void
    let onOpenLive: () -> Void
    let onDemo: () -> Void
    /// Push the Vital Sheet for a night (ext brief §4 — latest-night card entry point).
    var onOpenVitalSheet: (UUID) -> Void = { _ in }

    @State private var cards: [(SessionModel, SummaryModel?)] = []
    @State private var latest: NightBundle?
    @State private var slotsUsed = 0
    @State private var displayName: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                greeting

                if pod.activeSession != nil {
                    recordingCard
                }

                if let night = latest {
                    LastNightHero(night: night, onOpen: onOpenNight, onOpenVitalSheet: onOpenVitalSheet)
                    MorningCard(night: night, showRanges: settings.showRanges)
                    if cards.count >= 2 {
                        weekStrip
                    }
                } else {
                    emptyCard
                }

                podStrip

                if cards.count > 1 {
                    SectionHeader(title: L("home_recent_nights"), subtitle: L("home_recent_nights_sub"))
                    // Key paths cannot address tuple elements, so identify rows by index;
                    // the list is tiny (≤6) and rebuilt wholesale on every reload.
                    ForEach(0..<min(cards.count, 6), id: \.self) { i in
                        NightRow(session: cards[i].0, summary: cards[i].1, onOpen: onOpenNight)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
        .onAppear { reload() }
        .onChange(of: repo.revision) { _, _ in reload() }
        .onChange(of: settings.userId) { _, _ in reload() }
    }

    // MARK: - Data

    private var userId: UUID? { UUID(uuidString: settings.userId ?? "") }

    private func reload() {
        guard let uid = userId else {
            cards = []; latest = nil; slotsUsed = 0; displayName = nil
            return
        }
        displayName = auth.user(id: uid)?.displayName
        cards = repo.nightCards(userId: uid)
        latest = repo.latestCompletedNight(userId: uid)
        slotsUsed = repo.slots().count
    }

    // MARK: - Greeting

    private var greeting: some View {
        VStack(alignment: .leading, spacing: 2) {
            let first = displayName?.split(separator: " ").first.map(String.init)
            let name = (first?.isEmpty == false ? first! : L("home_greeting_fallback_name"))
            Text(L(greetingKey(), name))
                .font(AuroraFont.headline())
                .foregroundStyle(theme.textPrimary)
            Text(Fmt.date(Date(), format: "EEEE d MMMM"))
                .font(AuroraFont.body())
                .foregroundStyle(theme.textSecondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 8)
    }

    /// Day-part bucket, same thresholds as Android's dayPart().
    private func greetingKey() -> String {
        let h = Calendar.current.component(.hour, from: Date())
        if h < 5 { return "home_greeting_night" }
        if h < 12 { return "home_greeting_morning" }
        if h < 17 { return "home_greeting_afternoon" }
        return "home_greeting_evening"
    }

    // MARK: - Recording now

    private var recordingCard: some View {
        AuroraCard(onTap: onOpenLive) {
            HStack {
                Pill(text: L("common_recording"), bg: theme.primary, fg: theme.onPrimary)
                Spacer().frame(width: 10)
                if let active = pod.activeSession {
                    Text(L("home_since", Fmt.clock(active.startedAt, settings)))
                        .font(AuroraFont.body())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(theme.textSecondary)
            }
            VSpace(8)
            Text(L(pod.connectionState.isConnected ? "home_live_streaming" : "home_phone_disconnected"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            if let v = pod.latestVitals {
                VSpace(10)
                HStack(spacing: 10) {
                    StatTile(label: L("home_tile_skin"), value: Fmt.temp(v.skinTempC, settings),
                             accent: Aurora.seriesSkin)
                    StatTile(label: L("home_tile_heart"),
                             value: v.hasHr ? "\(v.hrBpm)" : "—",
                             unit: v.hasHr ? L("common_bpm") : "",
                             accent: theme.seriesHeart)
                    StatTile(label: L("home_tile_sleep"), value: L(sleepKey(v.sleepState)),
                             accent: Aurora.sleepDeep)
                }
            }
        }
    }

    private func sleepKey(_ s: SleepState) -> String {
        switch s {
        case .wake: return "app_sleep_awake"
        case .light: return "app_sleep_light"
        case .deep: return "app_sleep_deep"
        case .unknown: return "app_sleep_unknown"
        }
    }

    // MARK: - Empty state

    private var emptyCard: some View {
        AuroraCard {
            EmptyState(title: L("home_empty_title"), body: L("home_empty_body")) {
                HStack(spacing: 10) {
                    Button(action: onOpenPod) {
                        Text(L("home_connect_pod"))
                            .font(AuroraFont.title())
                            .foregroundStyle(theme.onPrimary)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(Capsule().fill(theme.primary))
                    }
                    .buttonStyle(.plain)
                    Button(action: onDemo) {
                        Text(L("home_try_demo"))
                            .font(AuroraFont.title())
                            .foregroundStyle(theme.textPrimary)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .overlay(Capsule().stroke(theme.outline, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: - Week strip

    private var weekStrip: some View {
        let recent = Array(cards.prefix(7)).reversed()
        let values = recent.map { Double($0.1?.sweatEvents ?? 0) }
        let avg = values.isEmpty ? 0 : values.reduce(0, +) / Double(values.count)
        return AuroraCard {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L(values.count == 1 ? "home_last_n_nights_one" : "home_last_n_nights_other", values.count))
                        .font(AuroraFont.titleL())
                        .foregroundStyle(theme.textPrimary)
                    Text(L("home_events_per_night"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer()
                Text(L("home_avg", String(format: "%.1f", avg)))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.primary)
            }
            VSpace(10)
            Sparkline(values: values, color: Aurora.fuchsia)
                .frame(maxWidth: .infinity)
                .frame(height: 56)
        }
    }

    // MARK: - Pod strip

    private var podStrip: some View {
        let connected = pod.connectionState.isConnected
        return AuroraCard(padding: 14, onTap: onOpenPod) {
            HStack {
                Image(systemName: connected ? "antenna.radiowaves.left.and.right"
                                            : "antenna.radiowaves.left.and.right.slash")
                    .foregroundStyle(connected ? theme.primary : theme.textSecondary)
                Spacer().frame(width: 10)
                VStack(alignment: .leading, spacing: 2) {
                    Text(L(connected
                           ? (settings.demoMode ? "home_demo_pod_connected" : "home_pod_connected")
                           : "home_pod_not_connected"))
                        .font(AuroraFont.titleS())
                        .foregroundStyle(theme.textPrimary)
                    Text(L("home_nights_stored", slotsUsed, Cadence.nightSlots))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer()
                if let battery = pod.batteryPct {
                    Image(systemName: "battery.100percent")
                        .foregroundStyle(battery <= 15 ? Aurora.bad : Aurora.good)
                    Spacer().frame(width: 4)
                    Text("\(battery)%")
                        .font(AuroraFont.label())
                        .foregroundStyle(theme.textPrimary)
                }
                Spacer().frame(width: 6)
                Image(systemName: "chevron.right").foregroundStyle(theme.textSecondary)
            }
            // Night 15 silently overwrites night 1 (spec §9) — warn as the ring fills.
            if slotsUsed >= 12 {
                VSpace(10)
                InfoBanner(text: L("home_pod_nearly_full"), tone: .warning)
            }
        }
    }
}

// MARK: - LastNightHero

private struct LastNightHero: View {
    let night: NightBundle
    let onOpen: (UUID) -> Void
    let onOpenVitalSheet: (UUID) -> Void

    var body: some View {
        let s = night.summary
        let eventCount = s.map { $0.sweatEvents } ?? night.sweat.count
        HeroCard(onTap: { onOpen(night.session.id) }) {
            HStack {
                Text(L("home_last_night"))
                    .font(AuroraFont.label())
                    .foregroundStyle(Color.white.opacity(0.85))
                Spacer()
                Text(Fmt.date(night.session.startedAt, format: "EEE d MMM"))
                    .font(AuroraFont.label())
                    .foregroundStyle(Color.white.opacity(0.85))
            }
            VSpace(10)
            HStack(alignment: .bottom, spacing: 10) {
                Text("\(eventCount)")
                    .font(AuroraFont.display())
                    .foregroundStyle(Color.white)
                VStack(alignment: .leading, spacing: 0) {
                    Text(L(eventCount == 1 ? "home_hero_line1_one" : "home_hero_line1_other"))
                        .font(AuroraFont.title())
                        .foregroundStyle(Color.white)
                    Text(L(eventCount == 1 ? "home_hero_line2_one" : "home_hero_line2_other"))
                        .font(AuroraFont.title())
                        .foregroundStyle(Color.white)
                }
                .padding(.bottom, 10)
            }
            VSpace(14)
            HStack(spacing: 22) {
                WhiteLabeledValue(label: L("home_peak_sweat"),
                                  value: "\(Fmt.dah(Double(s?.peakDahX100 ?? 0) / 100)) \(L("common_gm3"))")
                WhiteLabeledValue(label: L("home_asleep"),
                                  value: Fmt.duration(s?.sessionLenS ?? 0))
                WhiteLabeledValue(label: L("home_longest_event"),
                                  value: Fmt.durationShort(Int64(s?.longestSweatS ?? 0)))
            }
            VSpace(12)
            Text(L("home_peak_sweat_note"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(Color.white.opacity(0.85))
            VSpace(12)
            // Nighttime Vital Sheet entry point (ext brief §4)
            Button(action: { onOpenVitalSheet(night.session.id) }) {
                Text(L("vs_open"))
                    .font(AuroraFont.label())
                    .foregroundStyle(Color.white)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 9)
                    .background(Capsule().fill(Color.white.opacity(0.22)))
            }
            .buttonStyle(.plain)
        }
    }
}

// MARK: - MorningCard

private struct MorningCard: View {
    @Environment(\.theme) private var theme
    let night: NightBundle
    let showRanges: Bool

    var body: some View {
        let s = night.summary
        AuroraCard {
            Text(L("home_morning_card"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            Text(L("home_morning_card_sub"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(14)
            HStack {
                SleepRing(pctWake: s?.pctWake ?? 0, pctLight: s?.pctLight ?? 0, pctDeep: s?.pctDeep ?? 0,
                          centerTop: Fmt.duration(s?.sessionLenS ?? 0),
                          centerBottom: L("home_in_bed"))
                Spacer().frame(width: 18)
                VStack(alignment: .leading, spacing: 8) {
                    ringLegend(Aurora.sleepDeep, L("home_deep"), "\(s?.pctDeep ?? 0)%")
                    ringLegend(Aurora.sleepLight, L("home_light"), "\(s?.pctLight ?? 0)%")
                    ringLegend(Aurora.sleepWake, L("home_awake"), "\(s?.pctWake ?? 0)%")
                }
            }
            VSpace(14)
            HStack(spacing: 10) {
                StatTile(label: L("home_resting_hr"), value: "\(s?.hrMin ?? 0)", unit: L("common_bpm"),
                         accent: theme.seriesHeart, note: L("home_resting_hr_note"),
                         level: showRanges ? Ranges.sleepHeartRate.levelOf(Double(s?.hrMin ?? 0)) : nil)
                StatTile(label: L("home_average_hr"), value: "\(s?.hrMean ?? 0)", unit: L("common_bpm"),
                         accent: theme.seriesHeart)
                StatTile(label: L("home_peak_hr"), value: "\(s?.hrMax ?? 0)", unit: L("common_bpm"),
                         accent: Aurora.fuchsia)
            }
        }
    }

    private func ringLegend(_ color: Color, _ label: String, _ value: String) -> some View {
        HStack(spacing: 0) {
            Circle().fill(color).frame(width: 10, height: 10)
            Spacer().frame(width: 8)
            Text(label)
                .font(AuroraFont.body())
                .foregroundStyle(theme.textPrimary)
                .frame(width: 52, alignment: .leading)
            Text(value)
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
        }
    }
}

// MARK: - NightRow (shared — the Trends screen reuses it, so keep it internal)

/// One row of the "Recent nights" list: night label, times, duration and event count.
struct NightRow: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme
    let session: SessionModel
    let summary: SummaryModel?
    let onOpen: (UUID) -> Void

    var body: some View {
        AuroraCard(padding: 14, onTap: { onOpen(session.id) }) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(Fmt.nightLabel(session.startedAt))
                        .font(AuroraFont.titleS())
                        .foregroundStyle(theme.textPrimary)
                    let end = session.endedAt.map { Fmt.clock($0, settings) } ?? "…"
                    Text("\(Fmt.clock(session.startedAt, settings)) → \(end)  ·  \(Fmt.duration(summary?.sessionLenS ?? 0))")
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 0) {
                    Text("\(summary?.sweatEvents ?? 0)")
                        .font(AuroraFont.headlineS())
                        .foregroundStyle(theme.primary)
                    Text(L("home_sweat_events_label"))
                        .font(AuroraFont.labelS())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer().frame(width: 6)
                Image(systemName: "chevron.right").foregroundStyle(theme.textSecondary)
            }
        }
    }
}
