// Nighttime Vital Sheet — the iOS port of ui/screens/VitalSheetScreen.kt (ext brief §4/§5):
// one shared row model rendered by three selectable schemes and the one-page PDF export.

import SwiftUI
import UIKit

// MARK: - Navigation route

/// Identifiable wrapper so `.sheet(item:)` can present the freshly rendered PDF.
struct SharePdf: Identifiable {
    let id = UUID()
    let url: URL
}

/// UIActivityViewController bridge — the PDF is rendered ON the share tap, so a plain
/// ShareLink (which wants its item up front) would force eager rendering on every reload.
struct ActivityShareView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Pushed onto a tab's NavigationPath to open the Vital Sheet for one night
/// (a UUID alone would collide with the NightDetail destination).
struct VitalSheetRoute: Hashable {
    let sessionId: UUID
}

/* ====================================================================== row model
 * ONE row model shared by the three schemes AND the PDF (ext brief §5): all strings are
 * resolved here, data colours follow the channel and never the scheme. */

enum SheetRowId {
    case hr, hrv, skin, sweat, bloodFlow, oxygen, movement, climate
}

struct SheetRowUi {
    let id: SheetRowId
    let title: String
    /// Formatted "Quiet sleep" column value (median over non-bundle epochs).
    let quiet: String
    /// Formatted "Flash events" column value (median over bundle epochs, peak in parens).
    let event: String
    /// Plain-language verdict line for the row.
    let verdict: String
    /// Channel colour — identical in every scheme.
    let accent: Color
    var level: Level? = nil
    var higherIsBetter: Bool = false
    /// Optional "▲ +12" style delta badge (Scheme 2 / PDF flowsheet look).
    var delta: String? = nil
}

struct VitalSheetUi {
    let title: String
    let nightLabel: String
    let bundleCount: Int
    let bundleCountLabel: String
    let scoreLabel: String
    let score: NightScore
    let flagChips: [String]
    /// Bundle spans in pod-relative seconds (timeline strip + PDF).
    let bundles: [(Double, Double)]
    /// Wake-up times in pod-relative seconds (timeline ticks).
    let wakes: [Double]
    let lengthS: Double
    let quietCol: String
    let eventCol: String
    let timelineTitle: String
    let timelineSub: String
    let rows: [SheetRowUi]
    let footer: String
    let disclaimer: String
}

/* ============================ CORE ADAPTER — keep tiny ============================
 * Maps NightAnalytics.quietVsEvent()'s comparison structure into the row model's
 * numbers. If the core's NightComparison / VitalComparison shape drifts, reconcile
 * HERE ONLY — each mapping is a one-line fix. */
private struct RowNumbers {
    var quiet: Double?
    var event: Double?
    var peak: Double?
}

private extension VitalComparison {
    var row: RowNumbers { RowNumbers(quiet: quietMedian, event: eventMedian, peak: eventPeak) }
}

/* ====================================================================== screen */

struct VitalSheetScreen: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var repo: SessionRepository

    let sessionId: UUID

    @State private var bundle: NightBundle?
    /// "Compare her to herself": mean valid RMSSD over her other recent nights (up to 14).
    @State private var baselineRmssdX10: Int?
    /// Row model cached in state: detectBundles + quietVsEvent over a full night are too
    /// heavy to re-run on every body evaluation or every repo revision tick — reload()
    /// rebuilds only when this night's epoch count actually changes.
    @State private var ui: VitalSheetUi?
    @State private var cachedRecords: [LogRecord] = []
    @State private var lastEpochCount = -1
    /// Set when the user taps share: the PDF renders ON TAP (always fresh, never eagerly
    /// on the reload path) and presents in a share sheet.
    @State private var sharePdf: SharePdf?

    var body: some View {
        ZStack {
            theme.background.ignoresSafeArea()
            if let ui {
                switch settings.sheetScheme {
                case .scheme1: Scheme1Sheet(ui: ui)
                case .scheme2: Scheme2Sheet(ui: ui)
                case .scheme3: Scheme3Sheet(ui: ui, records: cachedRecords, settings: settings)
                }
            } else {
                EmptyState(title: L("vs_no_data_title"), body: L("vs_no_data_body"))
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) { titleStack }
            ToolbarItem(placement: .topBarTrailing) {
                if ui != nil {
                    Button {
                        if let ui,
                           let url = VitalSheetPdf.render(ui: ui, scheme: settings.sheetScheme,
                                                          sessionId: sessionId) {
                            sharePdf = SharePdf(url: url)
                        }
                    } label: {
                        Image(systemName: "square.and.arrow.up")
                    }
                    .accessibilityLabel(L("vs_cd_share_pdf"))
                }
            }
        }
        .sheet(item: $sharePdf) { item in
            ActivityShareView(items: [item.url])
        }
        .onAppear { reload() }
        // Re-fetch whenever the repository mutates (replay finishing, deletions, …);
        // reload() itself skips the heavy rebuild unless the epoch count changed.
        .onReceive(repo.$revision) { _ in reload() }
        // Units change the resolved strings baked into the row model.
        .onChange(of: settings.useFahrenheit) { _, _ in reload(force: true) }
    }

    // MARK: title

    private var titleStack: some View {
        VStack(spacing: 0) {
            Text(L("vs_title"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            if let b = bundle {
                Text(Fmt.nightLabel(b.session.startedAt))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }

    // MARK: data

    private func reload(force: Bool = false) {
        bundle = repo.nightBundle(sessionId: sessionId)
        let count = bundle?.epochs.count ?? 0
        guard force || count != lastEpochCount else { return }
        lastEpochCount = count
        // Her-own-baseline scans up to 14 other nights' epochs — compute it once per
        // visit, not on every revision tick (a live recording elsewhere bumps revision
        // every provisional epoch).
        if baselineRmssdX10 == nil { baselineRmssdX10 = computeBaselineRmssd() }
        cachedRecords = bundle?.epochs.map { $0.toRecord() } ?? []
        ui = makeUi()
    }

    /// Mean of the mean-valid-RMSSD of her OTHER recent nights (up to 14) — her own
    /// baseline, never a chart norm (ext brief §4).
    private func computeBaselineRmssd() -> Int? {
        guard let uid = settings.userId.flatMap({ UUID(uuidString: $0) }) else { return nil }
        let means: [Int] = repo.nightCards(userId: uid)
            .filter { $0.0.id != sessionId }
            .prefix(14)
            .compactMap { card in
                NightAnalytics.meanValidRmssdX10(repo.epochs(for: card.0.id).map { $0.toRecord() })
            }
        if means.isEmpty { return nil }
        return Int((Double(means.reduce(0, +)) / Double(means.count)).rounded())
    }

    // MARK: row building

    private func makeUi() -> VitalSheetUi? {
        guard let b = bundle else { return nil }
        let records = cachedRecords
        if records.isEmpty { return nil }
        let bundles = NightAnalytics.detectBundles(records)
        let score = NightAnalytics.nightScore(bundles)
        let flags = NightAnalytics.nightFlags(records)
        let cmp = NightAnalytics.quietVsEvent(records, bundles: bundles)
        return buildVitalSheetUi(b: b, records: records, bundles: bundles,
                                 score: score, flags: flags, cmp: cmp)
    }

    /// Wake-up onsets (transition into WAKE), pod-relative seconds. Being awake at
    /// bedtime is the starting state, not a wake-up — seed prevWake from epoch 0.
    private func wakeTimes(_ records: [LogRecord]) -> [Int64] {
        var out: [Int64] = []
        var prevWake = records.first?.sleepState == .wake
        for (i, r) in records.enumerated() {
            let w = r.sleepState == .wake
            if w && !prevWake && i > 0 { out.append(r.tS) }
            prevWake = w
        }
        return out
    }

    private func scoreLabelKey(_ score: NightScore) -> String {
        switch score {
        case .quiet: return "vs_score_quiet"
        case .mild: return "vs_score_mild"
        case .meaningful: return "vs_score_meaningful"
        }
    }

    private func buildVitalSheetUi(b: NightBundle, records: [LogRecord], bundles: [FlashBundle],
                                   score: NightScore, flags: NightFlags, cmp: NightComparison) -> VitalSheetUi {
        let show = settings.showRanges
        let dash = "—"
        let noEvents = L("vs_no_events")
        var rows: [SheetRowUi] = []

        // ---- Heart rate
        let hr = cmp.hrBpm.row
        if !(hr.quiet == nil && hr.event == nil) {
            let d: Int? = (hr.quiet != nil && hr.event != nil) ? Int((hr.event! - hr.quiet!).rounded()) : nil
            let verdict: String
            if flags.allNightHighHr {
                verdict = L("vs_hr_verdict_high")
            } else if let d, d >= 5 {
                verdict = L("vs_hr_verdict_up", d)
            } else if d != nil {
                verdict = L("vs_hr_verdict_flat")
            } else {
                verdict = noEvents
            }
            let bpm = L("common_bpm")
            var event = dash
            if let e = hr.event {
                event = "\(Int(e.rounded())) \(bpm)"
                if let p = hr.peak { event += " " + L("vs_peak_paren", "\(Int(p.rounded()))") }
            }
            rows.append(SheetRowUi(
                id: .hr, title: L("vs_row_hr"),
                quiet: hr.quiet.map { "\(Int($0.rounded())) \(bpm)" } ?? dash,
                event: event,
                verdict: verdict, accent: theme.seriesHeart,
                level: (show && hr.quiet != nil) ? Ranges.sleepHeartRate.levelOf(hr.quiet!) : nil,
                delta: d.map { $0 >= 0 ? "▲ +\($0)" : "▼ \($0)" }
            ))
        }

        // ---- Heart-rate variability — Δ vs HER 14-night average, not a chart norm.
        let rmssd = cmp.rmssdMs.row
        let nightMeanX10 = NightAnalytics.meanValidRmssdX10(records)
        if !(rmssd.quiet == nil && rmssd.event == nil) || nightMeanX10 != nil {
            let verdict: String
            if let mean = nightMeanX10, let base = baselineRmssdX10 {
                verdict = L("vs_hrv_vs_avg",
                            String(format: "%+.0f", Double(mean - base) / 10),
                            String(format: "%.0f", Double(base) / 10))
            } else if nightMeanX10 != nil {
                verdict = L("vs_hrv_no_avg")
            } else {
                verdict = L("vs_hrv_no_data")
            }
            let ms = L("common_ms")
            rows.append(SheetRowUi(
                id: .hrv, title: L("vs_row_hrv"),
                quiet: rmssd.quiet.map { String(format: "%.0f \(ms)", $0) } ?? dash,
                event: rmssd.event.map { String(format: "%.0f \(ms)", $0) } ?? dash,
                verdict: verdict, accent: Aurora.seriesHrv,
                level: (show && rmssd.quiet != nil) ? Ranges.rmssd.levelOf(rmssd.quiet!) : nil,
                higherIsBetter: true
            ))
        }

        // ---- Skin temperature
        let skin = cmp.skinTempC.row
        if !(skin.quiet == nil && skin.event == nil) {
            let dC: Double? = (skin.quiet != nil && skin.event != nil) ? skin.event! - skin.quiet! : nil
            let verdict: String
            if let dC {
                verdict = L("vs_skin_delta_events", Fmt.delta(dC, settings))
                    + (dC < 2 ? " " + L("vs_skin_not_fever") : "")
            } else {
                verdict = noEvents
            }
            var event = dash
            if let e = skin.event {
                event = Fmt.temp(e, settings)
                if let p = skin.peak { event += " " + L("vs_peak_paren", Fmt.temp(p, settings)) }
            }
            rows.append(SheetRowUi(
                id: .skin, title: L("vs_row_skin"),
                quiet: skin.quiet.map { Fmt.temp($0, settings) } ?? dash,
                event: event,
                verdict: verdict, accent: Aurora.seriesSkin,
                level: (show && dC != nil) ? Ranges.skinRise.levelOf(dC!) : nil,
                delta: dC.map { ($0 >= 0 ? "▲ " : "▼ ") + Fmt.delta($0, settings) }
            ))
        }

        // ---- Sweat: v2 conductance, v1 fallback to sweat moisture (ΔAH)
        let eda = cmp.edaUs.row
        if !(eda.quiet == nil && eda.event == nil) {
            let us = L("ext_us")
            var event = dash
            if let e = eda.event {
                event = String(format: "%.1f \(us)", e)
                if let p = eda.peak { event += " " + L("vs_peak_paren", String(format: "%.1f \(us)", p)) }
            }
            rows.append(SheetRowUi(
                id: .sweat, title: L("ext_conductance"),
                quiet: eda.quiet.map { String(format: "%.1f \(us)", $0) } ?? dash,
                event: event,
                // Raw elevated-EDA spans, NOT the confirmed-bundle count: the sweat row
                // reports all sweat activity; the hero reports temp+HR-confirmed bundles.
                verdict: {
                    let n = NightAnalytics.sweatSpikeCount(records)
                    return L(n == 1 ? "vs_sweat_spikes_one" : "vs_sweat_spikes_other", n)
                }(),
                accent: theme.seriesConductance,
                level: (show && eda.quiet != nil)
                    ? ExtGuideBands.level(eda.quiet!, lowMax: ExtGuideBands.conductanceLowMax,
                                          highMin: ExtGuideBands.conductanceHighMin) : nil
            ))
        } else {
            let dah = cmp.dahGm3.row
            if !(dah.quiet == nil && dah.event == nil) {
                let gm3 = L("common_gm3")
                var event = dash
                if let e = dah.event {
                    event = String(format: "%.1f \(gm3)", e)
                    if let p = dah.peak { event += " " + L("vs_peak_paren", String(format: "%.1f \(gm3)", p)) }
                }
                let spikes = L(b.sweat.count == 1 ? "vs_sweat_spikes_one" : "vs_sweat_spikes_other", b.sweat.count)
                rows.append(SheetRowUi(
                    id: .sweat, title: L("vs_row_sweat_moisture"),
                    quiet: dah.quiet.map { String(format: "%.1f \(gm3)", $0) } ?? dash,
                    event: event,
                    verdict: spikes + " · " + L("vs_sweat_fallback_note"),
                    accent: Aurora.seriesSweat,
                    level: (show && dah.quiet != nil) ? Ranges.sweat.levelOf(dah.quiet!) : nil
                ))
            }
        }

        // ---- Blood flow (perfusion index) — skipped when the sensor is absent (no fallback)
        let pi = cmp.perfusionPct.row
        if !(pi.quiet == nil && pi.event == nil) {
            let verdict = (pi.quiet != nil && pi.event != nil && pi.event! >= pi.quiet! * 1.3)
                ? L("vs_bloodflow_rise") : L("vs_bloodflow_steady")
            var event = dash
            if let e = pi.event {
                event = String(format: "%.1f%%", e)
                if let p = pi.peak { event += " " + L("vs_peak_paren", String(format: "%.1f%%", p)) }
            }
            rows.append(SheetRowUi(
                id: .bloodFlow, title: L("ext_bloodflow"),
                quiet: pi.quiet.map { String(format: "%.1f%%", $0) } ?? dash,
                event: event,
                verdict: verdict, accent: theme.seriesBloodFlow,
                level: (show && pi.quiet != nil)
                    ? ExtGuideBands.level(pi.quiet!, lowMax: ExtGuideBands.bloodFlowLowMax,
                                          highMin: ExtGuideBands.bloodFlowHighMin) : nil
            ))
        }

        // ---- Oxygen — explicit "sensor not in this pod" state when absent (ext brief §4)
        let spo2 = cmp.spo2Pct.row
        if spo2.quiet == nil && spo2.event == nil {
            rows.append(SheetRowUi(id: .oxygen, title: L("ext_oxygen"), quiet: dash, event: dash,
                                   verdict: L("ext_not_present"), accent: theme.seriesOxygen))
        } else {
            let minSpo2 = records.compactMap { $0.spo2Pct }.min()
            let verdict = (spo2.quiet != nil && minSpo2 != nil && minSpo2! <= spo2.quiet! - 3)
                ? L("vs_oxygen_dips") : L("vs_oxygen_steady")
            rows.append(SheetRowUi(
                id: .oxygen, title: L("ext_oxygen"),
                quiet: spo2.quiet.map { String(format: "%.1f%%", $0) } ?? dash,
                event: spo2.event.map { String(format: "%.1f%%", $0) } ?? dash,
                verdict: verdict, accent: theme.seriesOxygen,
                level: (show && spo2.quiet != nil)
                    ? ExtGuideBands.level(spo2.quiet!, lowMax: ExtGuideBands.oxygenLowMax,
                                          highMin: ExtGuideBands.oxygenHighMin) : nil,
                higherIsBetter: true
            ))
        }

        // ---- Movement & wake-ups
        let wakes = wakeTimes(records)
        let motion = cmp.motion.row
        rows.append(SheetRowUi(
            id: .movement, title: L("vs_row_movement"),
            quiet: motion.quiet.map { String(format: "%.0f", $0) } ?? dash,
            event: motion.event.map { String(format: "%.0f", $0) } ?? dash,
            verdict: L("vs_wake_verdict", wakes.count, bundles.filter { $0.hadWake }.count),
            accent: Aurora.seriesMotion,
            level: (show && motion.quiet != nil) ? Ranges.movement.levelOf(motion.quiet!) : nil
        ))

        // ---- Room climate
        let ambT = cmp.ambTempC.row
        let ambRh = cmp.ambRhPct.row
        let quietClimate: String = (ambT.quiet != nil && ambRh.quiet != nil)
            ? L("vs_climate_fmt", Fmt.temp(ambT.quiet!, settings), String(format: "%.0f", ambRh.quiet!)) : dash
        let eventClimate: String = (ambT.event != nil && ambRh.event != nil)
            ? L("vs_climate_fmt", Fmt.temp(ambT.event!, settings), String(format: "%.0f", ambRh.event!)) : dash
        rows.append(SheetRowUi(
            id: .climate, title: L("vs_row_climate"),
            quiet: quietClimate, event: eventClimate,
            verdict: flags.warmRoom ? L("vs_flag_warm_room") : L("vs_climate_ok"),
            accent: Aurora.seriesAmbient,
            level: (show && ambT.quiet != nil) ? Ranges.roomTemp.levelOf(ambT.quiet!) : nil
        ))

        var flagChips: [String] = []
        if flags.notFlashPattern { flagChips.append(L("vs_flag_not_flash")) }
        if flags.warmRoom { flagChips.append(L("vs_flag_warm_room")) }
        if flags.allNightHighHr { flagChips.append(L("vs_flag_hr_stayed_high")) }

        let lenS = max(b.summary?.sessionLenS ?? records.last.map { $0.tS + 30 } ?? 0, 600)

        return VitalSheetUi(
            title: L("vs_title"),
            nightLabel: Fmt.nightLabel(b.session.startedAt),
            bundleCount: bundles.count,
            bundleCountLabel: L(bundles.count == 1 ? "vs_bundle_count_one" : "vs_bundle_count_other"),
            scoreLabel: L(scoreLabelKey(score)),
            score: score,
            flagChips: flagChips,
            bundles: bundles.map { (Double($0.startTs), Double($0.endTs)) },
            wakes: wakes.map { Double($0) },
            lengthS: Double(lenS),
            quietCol: L("vs_quiet_col"),
            eventCol: L("vs_event_col"),
            timelineTitle: L("vs_timeline_title"),
            timelineSub: L("vs_timeline_sub"),
            rows: rows,
            footer: L("vs_footer"),
            disclaimer: L("wellness_disclaimer")
        )
    }
}

/* ====================================================================== shared pieces */

private struct SheetHero: View {
    let ui: VitalSheetUi

    var body: some View {
        HeroCard {
            HStack {
                Pill(text: ui.title.uppercased(), bg: Color.white.opacity(0.22), fg: .white)
                Spacer()
                Text(ui.nightLabel)
                    .font(AuroraFont.label())
                    .foregroundStyle(Color.white.opacity(0.85))
            }
            VSpace(10)
            HStack(alignment: .bottom, spacing: 10) {
                Text("\(ui.bundleCount)")
                    .font(AuroraFont.display())
                    .foregroundStyle(Color.white)
                Text(ui.bundleCountLabel)
                    .font(AuroraFont.title())
                    .foregroundStyle(Color.white)
                    .padding(.bottom, 10)
            }
            VSpace(8)
            HStack { Pill(text: ui.scoreLabel, bg: Color.white.opacity(0.22), fg: .white) }
            ForEach(ui.flagChips.indices, id: \.self) { i in
                VSpace(6)
                Pill(text: ui.flagChips[i], bg: Color.white.opacity(0.16), fg: .white)
            }
        }
    }
}

private struct SheetFooter: View {
    @Environment(\.theme) private var theme
    let ui: VitalSheetUi

    var body: some View {
        VStack(spacing: 8) {
            Text(ui.footer)
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 4)
            Disclaimer()
        }
    }
}

/* ====================================================================== Scheme 1 — Aurora cards */

private struct Scheme1Sheet: View {
    let ui: VitalSheetUi

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 12) {
                SheetHero(ui: ui)
                AuroraCard {
                    SectionHeader(title: ui.timelineTitle, subtitle: ui.timelineSub)
                    BundleTimelineStrip(bundles: ui.bundles, wakes: ui.wakes, x0: 0, x1: ui.lengthS)
                }
                ForEach(ui.rows.indices, id: \.self) { i in
                    Scheme1Row(row: ui.rows[i], quietCol: ui.quietCol, eventCol: ui.eventCol)
                }
                SheetFooter(ui: ui)
            }
            .padding(.horizontal, 16)
            .padding(.top, 4)
            .padding(.bottom, 24)
        }
    }
}

/// One vital as a rounded card with a 4 pt rail in its channel colour (ext brief §5.1).
private struct Scheme1Row: View {
    @Environment(\.theme) private var theme
    let row: SheetRowUi
    let quietCol: String
    let eventCol: String

    var body: some View {
        // The 4 pt channel rail is an aligned background so it always spans the card's
        // full height; clipping keeps it inside the rounded-22 corners.
        AuroraCard(padding: 0) {
            inner
                .padding(.leading, 18) // 4 pt rail + 14 content inset
                .padding(.trailing, 14)
                .padding(.vertical, 12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(alignment: .leading) { row.accent.frame(width: 4) }
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
    }

    private var inner: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text(row.title)
                    .font(AuroraFont.titleS())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                if let level = row.level {
                    LevelBadge(level: level, higherIsBetter: row.higherIsBetter)
                }
            }
            VSpace(8)
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(quietCol)
                        .font(AuroraFont.labelS())
                        .foregroundStyle(theme.textSecondary)
                    Text(row.quiet)
                        .font(AuroraFont.title())
                        .foregroundStyle(theme.textPrimary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                VStack(alignment: .leading, spacing: 2) {
                    Text(eventCol)
                        .font(AuroraFont.labelS())
                        .foregroundStyle(theme.textSecondary)
                    Text(row.event)
                        .font(AuroraFont.title())
                        .foregroundStyle(theme.textPrimary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            VSpace(6)
            Text(row.verdict)
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
    }
}

/* ====================================================================== Scheme 2 — Clinic sheet */

private struct Scheme2Sheet: View {
    @Environment(\.theme) private var theme
    let ui: VitalSheetUi

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 12) {
                AuroraCard {
                    // Printed header: near-monochrome ink, ONE accent (fuchsia) for event values.
                    Group {
                        Text(ui.title.uppercased())
                            .font(AuroraFont.labelS())
                            .foregroundStyle(theme.textSecondary)
                        Text(ui.nightLabel)
                            .font(AuroraFont.titleL())
                            .foregroundStyle(theme.textPrimary)
                        Text("\(ui.bundleCount) \(ui.bundleCountLabel) · \(ui.scoreLabel)")
                            .font(AuroraFont.bodyM())
                            .foregroundStyle(theme.textPrimary)
                        ForEach(ui.flagChips.indices, id: \.self) { i in
                            Text("• \(ui.flagChips[i])")
                                .font(AuroraFont.bodyS())
                                .foregroundStyle(theme.textSecondary)
                        }
                    }
                    VSpace(10)
                    BundleTimelineStrip(bundles: ui.bundles, wakes: ui.wakes, x0: 0, x1: ui.lengthS, height: 24)
                    VSpace(12)
                    Divider().overlay(theme.outline)
                    columnHeaders
                    ForEach(ui.rows.indices, id: \.self) { i in
                        Divider().overlay(theme.outline.opacity(0.5))
                        Scheme2Row(row: ui.rows[i])
                    }
                    Divider().overlay(theme.outline)
                }
                SheetFooter(ui: ui)
            }
            .padding(.horizontal, 16)
            .padding(.top, 4)
            .padding(.bottom, 24)
        }
    }

    /// Small-caps column headers, right-aligned over the two value columns.
    private var columnHeaders: some View {
        HStack(alignment: .center) {
            Spacer()
            Text(ui.quietCol.uppercased())
                .font(AuroraFont.labelS())
                .foregroundStyle(theme.textSecondary)
                .frame(width: 96, alignment: .trailing)
            Spacer().frame(width: 16)
            Text(ui.eventCol.uppercased())
                .font(AuroraFont.labelS())
                .foregroundStyle(Aurora.fuchsia)
                .frame(width: 120, alignment: .trailing)
        }
        .padding(.vertical, 6)
    }
}

/// One dense flowsheet row: title + verdict left, tabular values right, event in fuchsia
/// with the "62 → 74 ▲ +12" delta badge beneath it (ext brief §5.2).
private struct Scheme2Row: View {
    @Environment(\.theme) private var theme
    let row: SheetRowUi

    var body: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(row.title)
                        .font(AuroraFont.bodyM())
                        .foregroundStyle(theme.textPrimary)
                    if let level = row.level {
                        LevelBadge(level: level, higherIsBetter: row.higherIsBetter)
                    }
                }
                Text(row.verdict)
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Text(row.quiet)
                .font(AuroraFont.titleS())
                .monospacedDigit()
                .foregroundStyle(theme.textPrimary)
                .frame(width: 96, alignment: .trailing)
            Spacer().frame(width: 16)
            VStack(alignment: .trailing, spacing: 0) {
                Text(row.event)
                    .font(AuroraFont.titleS())
                    .monospacedDigit()
                    .foregroundStyle(Aurora.fuchsia)
                if let delta = row.delta {
                    Text(delta)
                        .font(AuroraFont.labelS())
                        .monospacedDigit()
                        .foregroundStyle(Aurora.fuchsia)
                }
            }
            .frame(width: 120, alignment: .trailing)
        }
        .padding(.vertical, 8)
    }
}

/* ====================================================================== Scheme 3 — Timeline focus */

private struct Scheme3Sheet: View {
    @Environment(\.theme) private var theme
    let ui: VitalSheetUi
    let records: [LogRecord]
    let settings: AppSettings

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 12) {
                SheetHero(ui: ui)
                timelineCard
                ForEach(Array(stride(from: 0, to: ui.rows.count, by: 2)), id: \.self) { i in
                    HStack(alignment: .top, spacing: 10) {
                        Scheme3Tile(row: ui.rows[i], quietCol: ui.quietCol)
                        if i + 1 < ui.rows.count {
                            Scheme3Tile(row: ui.rows[i + 1], quietCol: ui.quietCol)
                        } else {
                            Color.clear.frame(maxWidth: .infinity)
                        }
                    }
                }
                SheetFooter(ui: ui)
            }
            .padding(.horizontal, 16)
            .padding(.top, 4)
            .padding(.bottom, 24)
        }
    }

    /// Tall stacked mini-panel timeline: HR / skin temp / sweat / sleep bands, bundle
    /// shading across every panel (ext brief §5.3).
    private var timelineCard: some View {
        let x0 = 0.0
        let x1 = ui.lengthS
        let edaPoints = records.compactMap { r in r.edaUs.map { TimePoint(t: Double(r.tS), v: $0) } }
        return AuroraCard(padding: 12) {
            SectionHeader(title: ui.timelineTitle, subtitle: ui.timelineSub)
            DotPanel(
                name: L("vs_row_hr"),
                points: records
                    .filter { $0.hrBpm > 0 && QualityBand.of($0.hrQuality) != .hide }
                    .map { (t: Double($0.tS), v: Double($0.hrBpm), valid: QualityBand.of($0.hrQuality) == .normal) },
                color: theme.seriesHeart,
                x0: x0, x1: x1, height: 84,
                connect: true,
                bands: ui.bundles, bandColor: BundleBandColor
            )
            LinePanel(
                series: [(name: L("vs_row_skin"), color: Aurora.seriesSkin,
                          points: records.map { TimePoint(t: Double($0.tS), v: settings.toDisplayTemp($0.skinTempC)) },
                          area: false)],
                x0: x0, x1: x1, height: 84,
                unit: settings.tempUnit,
                bands: ui.bundles, bandColor: BundleBandColor
            )
            if !edaPoints.isEmpty {
                LinePanel(
                    series: [(name: L("ext_conductance"), color: theme.seriesConductance,
                              points: edaPoints, area: true)],
                    x0: x0, x1: x1, height: 84,
                    unit: " " + L("ext_us"),
                    bands: ui.bundles, bandColor: BundleBandColor
                )
            } else {
                LinePanel(
                    series: [(name: L("vs_row_sweat_moisture"), color: Aurora.seriesSweat,
                              points: records.map { TimePoint(t: Double($0.tS), v: $0.dah) },
                              area: true)],
                    x0: x0, x1: x1, height: 84,
                    unit: " g/m³",
                    bands: ui.bundles, bandColor: BundleBandColor
                )
            }
            HypnogramPanel(
                states: records.map { (t: Double($0.tS), state: $0.sleepState) },
                x0: x0, x1: x1, height: 72,
                bands: ui.bundles, bandColor: BundleBandColor,
                showXAxis: true
            )
        }
    }
}

/// Big stat tile: accent dot + caption, headline number, quiet value + verdict beneath.
private struct Scheme3Tile: View {
    @Environment(\.theme) private var theme
    let row: SheetRowUi
    let quietCol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 6) {
                Circle().fill(row.accent).frame(width: 8, height: 8)
                Text(row.title)
                    .font(AuroraFont.labelS())
                    .foregroundStyle(theme.textSecondary)
                    .lineLimit(2)
                Spacer(minLength: 0)
                if let level = row.level {
                    LevelBadge(level: level, higherIsBetter: row.higherIsBetter)
                }
            }
            VSpace(6)
            Text(row.event != "—" ? row.event : row.quiet)
                .font(AuroraFont.headlineS())
                .foregroundStyle(theme.textPrimary)
            Text("\(quietCol): \(row.quiet)")
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(4)
            Text(row.verdict)
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(theme.cardAlt))
    }
}
