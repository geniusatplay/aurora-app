// Trends — the iOS port of ui/screens/TrendsScreen.kt (range chips, stat tiles with
// trend notes, four TrendBars, a stacked sleep-composition chart and the nights list).
//
// The data shaping (TrendSeries) and every card are internal so the custom-page trend
// sections reuse exactly what this screen shows.

import SwiftUI

struct TrendsScreen: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var repo: SessionRepository

    let onOpenNight: (UUID) -> Void
    let onDemo: () -> Void

    @State private var rangeDays = 14

    var body: some View {
        // Reading `repo` (@EnvironmentObject) re-runs this body on every repository
        // mutation, so the fetch below is always current — the iOS stand-in for Android's
        // Flow collection.
        let uid = settings.userId.flatMap { UUID(uuidString: $0) }
        let cards = uid.map { repo.nightCards(userId: $0) } ?? []
        let series = TrendSeries(cards: cards, rangeDays: rangeDays)

        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) {
                header
                TrendRangeChips(rangeDays: $rangeDays)

                if series.inRange.count < 2 {
                    TrendsEmptyCard(onDemo: onDemo)
                } else {
                    trendsContent(series)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 16)
        }
        .background(theme.background.ignoresSafeArea())
    }

    // MARK: header

    private var header: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(L("trends_title"))
                .font(AuroraFont.headlineL())
                .foregroundStyle(theme.textPrimary)
            Text(L("trends_subtitle"))
                .font(AuroraFont.bodyM())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.top, 8)
    }

    // MARK: main content

    @ViewBuilder
    private func trendsContent(_ series: TrendSeries) -> some View {
        let inRange = series.inRange

        Group {
            TrendTiles(series: series)
            TrendFlashesCard(series: series)
            TrendPeakSweatCard(series: series)
            if series.anySleep {
                TrendSleepCard(series: series)
            }
            TrendRestingHrCard(series: series)
            TrendTimeInBedCard(series: series)
        }

        SectionHeader(title: L("trends_nights_in_range"),
                      subtitle: L(inRange.count == 1 ? "trends_nights_count_one" : "trends_nights_count_other",
                                  inRange.count))
        // Key paths cannot address tuple elements, so identify rows by the session id
        // extracted in a closure-free way: iterate indices of the reversed copy.
        // NightRow is A5's shared row (HomeScreen.swift): NightRow(session:summary:onOpen:).
        let reversed = Array(inRange.reversed())
        ForEach(reversed.indices, id: \.self) { i in
            NightRow(session: reversed[i].0, summary: reversed[i].1, onOpen: onOpenNight)
                .id(reversed[i].0.id)
        }
        Text(L("trends_footer"))
            .font(AuroraFont.bodyS())
            .foregroundStyle(theme.textSecondary)
            .padding(.horizontal, 4)
    }
}

// MARK: - Data shaping (shared with the custom-page trend sections)

/// The nights inside a range (oldest first, each with a summary) and the per-night series
/// every trend card plots.
struct TrendSeries {
    let rangeDays: Int
    let inRange: [(SessionModel, SummaryModel?)]
    let labels: [String]
    let sweat: [Double]
    let peak: [Double]
    let sleepLen: [Double]
    let restHr: [Double]
    /// 0 bpm = no heart-rate reading that night: left out of the average (never "0").
    let restHrKnown: [Double]
    /// Nights from the real glove carry no sleep split (no IMU): skip the chart if none has one.
    let anySleep: Bool
    let lastIdx: Int

    init(cards: [(SessionModel, SummaryModel?)], rangeDays: Int, now: Date = Date()) {
        self.rangeDays = rangeDays
        let since = now.addingTimeInterval(-Double(rangeDays) * 86_400)
        let nights = cards
            .filter { $0.0.startedAt >= since && $0.1 != nil }
            .sorted { $0.0.startedAtEpochMs < $1.0.startedAtEpochMs }
        inRange = nights
        labels = TrendSeries.trendLabels(nights.map { $0.0 }, rangeDays: rangeDays)
        sweat = nights.map { Double($0.1!.sweatEvents) }
        peak = nights.map { Double($0.1!.peakDahX100) / 100 }
        sleepLen = nights.map { Double($0.1!.sessionLenS) / 3600 }
        let hr = nights.map { Double($0.1!.hrMin) }
        restHr = hr
        restHrKnown = hr.filter { $0 > 0 }
        anySleep = nights.contains { summaryHasSleep($0.1) }
        lastIdx = nights.count - 1
    }

    static func avg(_ v: [Double]) -> Double {
        v.isEmpty ? 0 : v.reduce(0, +) / Double(v.count)
    }

    func zip3(_ values: [Double]) -> [(label: String, value: Double, highlight: Bool)] {
        values.indices.map { (label: labels[$0], value: values[$0], highlight: $0 == lastIdx) }
    }

    /// Bar labels. Android used bare day-of-month numbers, but TrendBars requires UNIQUE
    /// labels (they are the categorical x domain) and day numbers repeat within 30+ day
    /// windows (and two nights can share a date). So: >30-day ranges use localized short
    /// "d MMM" labels, and any residual duplicate gets invisible zero-width-space suffixes
    /// to stay unique without changing what the user sees.
    static func trendLabels(_ sessions: [SessionModel], rangeDays: Int) -> [String] {
        var labels = sessions.map { s -> String in
            Fmt.date(s.startedAt, format: rangeDays > 30 ? "d MMM" : "d")
        }
        var seen: [String: Int] = [:]
        for i in labels.indices {
            let base = labels[i]
            let n = seen[base] ?? 0
            seen[base] = n + 1
            if n > 0 { labels[i] = base + String(repeating: "\u{200B}", count: n) }
        }
        return labels
    }

    // MARK: trend note (last third of the range vs the first third)

    enum Trend {
        case none, steady
        case down(Int)
        case up(Int)
    }

    static func trendNote(_ values: [Double]) -> Trend {
        guard values.count >= 4 else { return .none }
        let n = values.count / 3
        let first = values.prefix(n).reduce(0, +) / Double(n)
        let last = values.suffix(n).reduce(0, +) / Double(n)
        guard first != 0 else { return .none }
        let change = (last - first) / first * 100
        if abs(change) < 8 { return .steady }
        let pct = Int(abs(change))
        return change < 0 ? .down(pct) : .up(pct)
    }

    static func trendNoteText(_ t: Trend) -> String? {
        switch t {
        case .none: return nil
        case .steady: return L("trends_note_steady")
        case .down(let pct): return L("trends_note_down", pct)
        case .up(let pct): return L("trends_note_up", pct)
        }
    }

    /// Localized trend note for a series, nil when there are too few nights.
    static func note(_ values: [Double]) -> String? {
        trendNoteText(trendNote(values))
    }
}

// MARK: - Range chips

struct TrendRangeChips: View {
    @Environment(\.theme) private var theme
    @Binding var rangeDays: Int

    var body: some View {
        HStack(spacing: 8) {
            ForEach([7, 14, 30, 90], id: \.self) { d in
                let selected = rangeDays == d
                Button { rangeDays = d } label: {
                    Text(L("trends_days", d))
                        .font(AuroraFont.label())
                        .foregroundStyle(selected ? theme.onPrimary : theme.textPrimary)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(Capsule().fill(selected ? theme.primary : theme.card))
                }
                .buttonStyle(.plain)
            }
        }
    }
}

// MARK: - Empty state (fewer than two nights in range)

struct TrendsEmptyCard: View {
    let onDemo: () -> Void

    var body: some View {
        AuroraCard {
            EmptyState(title: L("trends_empty_title"), body: L("trends_empty_body")) {
                Button(L("trends_open_demo")) { onDemo() }
                    .buttonStyle(.bordered)
            }
        }
    }
}

// MARK: - Stat tiles (two rows of averages with trend notes)

struct TrendTiles: View {
    let series: TrendSeries

    var body: some View {
        let s = series
        HStack(spacing: 10) {
            StatTile(label: L("trends_avg_events"),
                     value: String(format: "%.1f", TrendSeries.avg(s.sweat)),
                     accent: Aurora.fuchsia,
                     note: TrendSeries.note(s.sweat))
            StatTile(label: L("trends_avg_peak_sweat"),
                     value: String(format: "%.1f", TrendSeries.avg(s.peak)),
                     unit: L("common_gm3"),
                     accent: Aurora.rose,
                     note: TrendSeries.note(s.peak))
        }
        HStack(spacing: 10) {
            StatTile(label: L("trends_avg_time_in_bed"),
                     value: Fmt.duration(Int64(TrendSeries.avg(s.sleepLen) * 3600)),
                     accent: Aurora.sleepDeep)
            StatTile(label: L("trends_resting_hr"),
                     value: s.restHrKnown.isEmpty ? "—" : String(format: "%.0f", TrendSeries.avg(s.restHrKnown)),
                     unit: s.restHrKnown.isEmpty ? "" : L("common_bpm"),
                     accent: Aurora.ink,
                     note: TrendSeries.note(s.restHrKnown))
        }
    }
}

// MARK: - Chart cards

/// Title + subtitle + chart in a padded card (the screen's former chartCard helper).
struct TrendChartCard<Content: View>: View {
    let title: String
    let subtitle: String
    let content: Content

    init(title: String, subtitle: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.content = content()
    }

    var body: some View {
        AuroraCard(padding: 12) {
            SectionHeader(title: title, subtitle: subtitle)
            content
        }
    }
}

struct TrendFlashesCard: View {
    let series: TrendSeries

    var body: some View {
        TrendChartCard(title: L("trends_sweat_events_title"), subtitle: L("trends_sweat_events_sub")) {
            TrendBars(data: series.zip3(series.sweat), color: Aurora.fuchsia)
        }
    }
}

struct TrendPeakSweatCard: View {
    let series: TrendSeries

    var body: some View {
        TrendChartCard(title: L("trends_peak_sweat_title"), subtitle: L("trends_peak_sweat_sub")) {
            TrendBars(data: series.zip3(series.peak), color: Aurora.rose, unit: " g/m³", decimals: 1)
        }
    }
}

struct TrendSleepCard: View {
    @Environment(\.theme) private var theme
    let series: TrendSeries

    var body: some View {
        let labels = series.labels
        TrendChartCard(title: L("trends_sleep_comp_title"), subtitle: L("trends_sleep_comp_sub")) {
            // Small dot legend (Android's Legend composable); StackedBars adds its own
            // Charts legend too, but this one keeps the deep→light→awake order explicit.
            HStack(spacing: 14) {
                legendDot(L("trends_deep"), Aurora.sleepDeep)
                legendDot(L("trends_light"), Aurora.sleepLight)
                legendDot(L("trends_awake"), Aurora.sleepWake)
            }
            .padding(.bottom, 6)
            StackedBars(
                data: series.inRange.enumerated().map { i, c in
                    let sm = c.1!
                    return (label: labels[i], parts: [Double(sm.pctDeep), Double(sm.pctLight), Double(sm.pctWake)])
                },
                colors: [Aurora.sleepDeep, Aurora.sleepLight, Aurora.sleepWake],
                partLabelKeys: ["trends_deep", "trends_light", "trends_awake"]
            )
        }
    }

    private func legendDot(_ label: String, _ color: Color) -> some View {
        HStack(spacing: 5) {
            Circle().fill(color).frame(width: 9, height: 9)
            Text(label)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(theme.textSecondary)
        }
    }
}

struct TrendRestingHrCard: View {
    let series: TrendSeries

    var body: some View {
        TrendChartCard(title: L("trends_resting_hr_title"), subtitle: L("trends_resting_hr_sub")) {
            // Nights with no heart-rate reading get no bar (never a "0 bpm" bar).
            TrendBars(data: series.zip3(series.restHr).filter { $0.value > 0 },
                      color: Aurora.ink, unit: " bpm")
        }
    }
}

struct TrendTimeInBedCard: View {
    let series: TrendSeries

    var body: some View {
        TrendChartCard(title: L("trends_time_in_bed_title"), subtitle: L("trends_time_in_bed_sub")) {
            TrendBars(data: series.zip3(series.sleepLen), color: Aurora.sleepDeep, unit: " h", decimals: 1)
        }
    }
}
