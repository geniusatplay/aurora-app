// Trends — the iOS port of ui/screens/TrendsScreen.kt (range chips, stat tiles with
// trend notes, four TrendBars, a stacked sleep-composition chart and the nights list).

import SwiftUI

struct TrendsScreen: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var repo: SessionRepository

    let onOpenNight: (UUID) -> Void
    let onDemo: () -> Void

    @State private var rangeDays = 14

    var body: some View {
        // Reading `repo` (@EnvironmentObject) re-runs this body on every repository
        // mutation, so the fetch below is always current — the iOS stand-in for Android's
        // Flow collection.
        let uid = settings.userId.flatMap { UUID(uuidString: $0) }
        let cards = uid.map { repo.nightCards(userId: $0) } ?? []
        let since = Date().addingTimeInterval(-Double(rangeDays) * 86_400)
        let inRange = cards
            .filter { $0.0.startedAt >= since && $0.1 != nil }
            .sorted { $0.0.startedAtEpochMs < $1.0.startedAtEpochMs }

        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) {
                header
                rangeChips

                if inRange.count < 2 {
                    AuroraCard {
                        EmptyState(title: L("trends_empty_title"), body: L("trends_empty_body")) {
                            Button(L("trends_open_demo")) { onDemo() }
                                .buttonStyle(.bordered)
                        }
                    }
                } else {
                    trendsContent(inRange)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 16)
        }
        .background(theme.background.ignoresSafeArea())
    }

    // MARK: header + chips

    private var header: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(L("trends_title"))
                .font(AuroraFont.headlineL())
                .foregroundStyle(theme.textPrimary)
            Text(L("trends_subtitle"))
                .font(AuroraFont.bodyM())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.top, 8)
    }

    private var rangeChips: some View {
        HStack(spacing: 8) {
            ForEach([7, 14, 30, 90], id: \.self) { d in
                let selected = rangeDays == d
                Button { rangeDays = d } label: {
                    Text(L("trends_days", d))
                        .font(AuroraFont.label())
                        .foregroundStyle(selected ? theme.onPrimary : theme.textPrimary)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(Capsule().fill(selected ? theme.primary : theme.card))
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: main content

    @ViewBuilder
    private func trendsContent(_ inRange: [(SessionModel, SummaryModel?)]) -> some View {
        let labels = trendLabels(inRange.map { $0.0 })
        let sweat = inRange.map { Double($0.1!.sweatEvents) }
        let peak = inRange.map { Double($0.1!.peakDahX100) / 100 }
        let sleepLen = inRange.map { Double($0.1!.sessionLenS) / 3600 }
        let restHr = inRange.map { Double($0.1!.hrMin) }
        let lastIdx = inRange.count - 1

        Group {
            HStack(spacing: 10) {
                StatTile(label: L("trends_avg_events"),
                         value: String(format: "%.1f", avg(sweat)),
                         accent: Aurora.fuchsia,
                         note: trendNoteText(trendNote(sweat)))
                StatTile(label: L("trends_avg_peak_sweat"),
                         value: String(format: "%.1f", avg(peak)),
                         unit: L("common_gm3"),
                         accent: Aurora.rose,
                         note: trendNoteText(trendNote(peak)))
            }
            HStack(spacing: 10) {
                StatTile(label: L("trends_avg_time_in_bed"),
                         value: Fmt.duration(Int64(avg(sleepLen) * 3600)),
                         accent: Aurora.sleepDeep)
                StatTile(label: L("trends_resting_hr"),
                         value: String(format: "%.0f", avg(restHr)),
                         unit: L("common_bpm"),
                         accent: Aurora.ink,
                         note: trendNoteText(trendNote(restHr)))
            }

            chartCard(title: L("trends_sweat_events_title"), subtitle: L("trends_sweat_events_sub")) {
                TrendBars(data: zip3(labels, sweat, lastIdx), color: Aurora.fuchsia)
            }
            chartCard(title: L("trends_peak_sweat_title"), subtitle: L("trends_peak_sweat_sub")) {
                TrendBars(data: zip3(labels, peak, lastIdx), color: Aurora.rose, unit: " g/m³", decimals: 1)
            }
            chartCard(title: L("trends_sleep_comp_title"), subtitle: L("trends_sleep_comp_sub")) {
                // Small dot legend (Android's Legend composable); StackedBars adds its own
                // Charts legend too, but this one keeps the deep→light→awake order explicit.
                HStack(spacing: 14) {
                    legendDot(L("trends_deep"), Aurora.sleepDeep)
                    legendDot(L("trends_light"), Aurora.sleepLight)
                    legendDot(L("trends_awake"), Aurora.sleepWake)
                }
                .padding(.bottom, 6)
                StackedBars(
                    data: inRange.enumerated().map { i, c in
                        let sm = c.1!
                        return (label: labels[i], parts: [Double(sm.pctDeep), Double(sm.pctLight), Double(sm.pctWake)])
                    },
                    colors: [Aurora.sleepDeep, Aurora.sleepLight, Aurora.sleepWake],
                    partLabelKeys: ["trends_deep", "trends_light", "trends_awake"]
                )
            }
            chartCard(title: L("trends_resting_hr_title"), subtitle: L("trends_resting_hr_sub")) {
                TrendBars(data: zip3(labels, restHr, lastIdx), color: Aurora.ink, unit: " bpm")
            }
            chartCard(title: L("trends_time_in_bed_title"), subtitle: L("trends_time_in_bed_sub")) {
                TrendBars(data: zip3(labels, sleepLen, lastIdx), color: Aurora.sleepDeep, unit: " h", decimals: 1)
            }
        }

        SectionHeader(title: L("trends_nights_in_range"),
                      subtitle: L(inRange.count == 1 ? "trends_nights_count_one" : "trends_nights_count_other",
                                  inRange.count))
        // Key paths cannot address tuple elements, so identify rows by the session id
        // extracted in a closure-free way: iterate indices of the reversed copy.
        // NightRow is A5's shared row (HomeScreen.swift): NightRow(session:summary:onOpen:).
        let reversed = Array(inRange.reversed())
        ForEach(reversed.indices, id: \.self) { i in
            NightRow(session: reversed[i].0, summary: reversed[i].1, onOpen: onOpenNight)
                .id(reversed[i].0.id)
        }
        Text(L("trends_footer"))
            .font(AuroraFont.bodyS())
            .foregroundStyle(theme.textSecondary)
            .padding(.horizontal, 4)
    }

    private func chartCard<Content: View>(title: String, subtitle: String,
                                          @ViewBuilder content: () -> Content) -> some View {
        AuroraCard(padding: 12) {
            SectionHeader(title: title, subtitle: subtitle)
            content()
        }
    }

    private func legendDot(_ label: String, _ color: Color) -> some View {
        HStack(spacing: 5) {
            Circle().fill(color).frame(width: 9, height: 9)
            Text(label)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(theme.textSecondary)
        }
    }

    // MARK: data helpers

    private func avg(_ v: [Double]) -> Double {
        v.isEmpty ? 0 : v.reduce(0, +) / Double(v.count)
    }

    private func zip3(_ labels: [String], _ values: [Double], _ highlightIdx: Int)
        -> [(label: String, value: Double, highlight: Bool)] {
        values.indices.map { (label: labels[$0], value: values[$0], highlight: $0 == highlightIdx) }
    }

    /// Bar labels. Android used bare day-of-month numbers, but TrendBars requires UNIQUE
    /// labels (they are the categorical x domain) and day numbers repeat within 30+ day
    /// windows (and two nights can share a date). So: >30-day ranges use localized short
    /// "d MMM" labels, and any residual duplicate gets invisible zero-width-space suffixes
    /// to stay unique without changing what the user sees.
    private func trendLabels(_ sessions: [SessionModel]) -> [String] {
        var labels = sessions.map { s -> String in
            Fmt.date(s.startedAt, format: rangeDays > 30 ? "d MMM" : "d")
        }
        var seen: [String: Int] = [:]
        for i in labels.indices {
            let base = labels[i]
            let n = seen[base] ?? 0
            seen[base] = n + 1
            if n > 0 { labels[i] = base + String(repeating: "\u{200B}", count: n) }
        }
        return labels
    }

    // MARK: trend note (last third of the range vs the first third)

    private enum Trend {
        case none, steady
        case down(Int)
        case up(Int)
    }

    private func trendNote(_ values: [Double]) -> Trend {
        guard values.count >= 4 else { return .none }
        let n = values.count / 3
        let first = values.prefix(n).reduce(0, +) / Double(n)
        let last = values.suffix(n).reduce(0, +) / Double(n)
        guard first != 0 else { return .none }
        let change = (last - first) / first * 100
        if abs(change) < 8 { return .steady }
        let pct = Int(abs(change))
        return change < 0 ? .down(pct) : .up(pct)
    }

    private func trendNoteText(_ t: Trend) -> String? {
        switch t {
        case .none: return nil
        case .steady: return L("trends_note_steady")
        case .down(let pct): return L("trends_note_down", pct)
        case .up(let pct): return L("trends_note_up", pct)
        }
    }
}
