// Sign-in / create-account screen — the iOS port of ui/screens/SignInScreen.kt.
//
// Full-screen hero gradient with the logo circles on top, a card holding the form,
// and the wellness disclaimer at the bottom. Auth failures carry a LOCALIZATION KEY
// (AuthResult.failure(messageKey:)) rendered via L(key). On success AuthRepository
// writes settings.userId — RootView (A6) observes that and navigates; this screen
// never navigates itself.

import SwiftUI

struct SignInScreen: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme

    /// Injected by RootView (plain reference — AuthRepository is not observable).
    let auth: AuthRepository

    @State private var email = ""
    @State private var password = ""
    @State private var name = ""
    @State private var creating = false
    @State private var showPassword = false
    @State private var errorKey: String?
    @State private var busy = false

    var body: some View {
        ZStack {
            LinearGradient(colors: theme.heroGradient,
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .ignoresSafeArea()
            ScrollView {
                VStack(spacing: 0) {
                    Spacer().frame(height: 48)
                    logo
                    Spacer().frame(height: 18)
                    Text(L("signin_app_name"))
                        .font(AuroraFont.display())
                        .foregroundStyle(Color.white)
                    Text(L("signin_tagline"))
                        .font(AuroraFont.title())
                        .foregroundStyle(Color.white.opacity(0.9))
                    Spacer().frame(height: 36)
                    formCard
                        .padding(.horizontal, 20)
                    Spacer().frame(height: 20)
                    Text(L("signin_disclaimer"))
                        .font(AuroraFont.labelS())
                        .foregroundStyle(Color.white.opacity(0.85))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 28)
                    Spacer().frame(height: 28)
                }
            }
        }
    }

    // MARK: - Pieces

    /// Three nested circles — same construction as the Android logo mark.
    private var logo: some View {
        ZStack {
            Circle().fill(Color.white.opacity(0.22)).frame(width: 84, height: 84)
            Circle().fill(Color.white.opacity(0.9)).frame(width: 56, height: 56)
            Circle().fill(Aurora.fuchsia).frame(width: 22, height: 22)
        }
    }

    private var formCard: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Grouped: this column otherwise exceeds ViewBuilder's 10-child limit.
            Group {
            Text(L(creating ? "signin_create_title" : "signin_welcome_title"))
                .font(AuroraFont.headlineS())
                .foregroundStyle(theme.textPrimary)
            Text(L("signin_privacy_note"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            Spacer().frame(height: 18)
            }

            Group {
            if creating {
                field {
                    TextField(L("signin_name_label"), text: $name)
                        .textInputAutocapitalization(.words)
                        .autocorrectionDisabled()
                }
                Spacer().frame(height: 12)
            }
            field {
                TextField(L("signin_email_label"), text: $email)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            Spacer().frame(height: 12)
            field {
                HStack(spacing: 8) {
                    Group {
                        if showPassword {
                            TextField(L("signin_password_label"), text: $password)
                        } else {
                            SecureField(L("signin_password_label"), text: $password)
                        }
                    }
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    Button {
                        showPassword.toggle()
                    } label: {
                        Image(systemName: showPassword ? "eye.slash" : "eye")
                            .foregroundStyle(theme.textSecondary)
                    }
                    .accessibilityLabel(L("signin_toggle_password"))
                }
            }
            }

            Group {
            if let errorKey {
                Spacer().frame(height: 10)
                Text(L(errorKey))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(Aurora.bad)
            }
            Spacer().frame(height: 18)

            Button(action: submit) {
                Group {
                    if busy {
                        ProgressView().tint(theme.onPrimary)
                    } else {
                        Text(L(creating ? "signin_create_button" : "signin_signin_button"))
                            .font(AuroraFont.title())
                    }
                }
                .foregroundStyle(theme.onPrimary)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(Capsule().fill(theme.primary))
            }
            .buttonStyle(.plain)
            .disabled(busy)

            Spacer().frame(height: 10)

            Button {
                // One tap fills the demo credentials and signs in (Android parity).
                email = AuthRepository.demoEmail
                password = AuthRepository.demoPassword
                creating = false
                submit()
            } label: {
                Text(L("signin_demo_button"))
                    .font(AuroraFont.title())
                    .foregroundStyle(theme.textPrimary)
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .overlay(Capsule().stroke(theme.outline, lineWidth: 1))
            }
            .buttonStyle(.plain)

            HStack(spacing: 2) {
                Text(L(creating ? "signin_have_account" : "signin_new_here"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
                Button {
                    creating.toggle()
                    errorKey = nil
                } label: {
                    Text(L(creating ? "signin_signin_button" : "signin_create_one"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.primary)
                }
                .buttonStyle(.plain)
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 10)
            }
        }
        .padding(22)
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(theme.card))
    }

    /// Outlined-field look shared by all inputs (SwiftUI has no OutlinedTextField).
    private func field<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        content()
            .font(AuroraFont.body())
            .foregroundStyle(theme.textPrimary)
            .padding(.horizontal, 14)
            .frame(height: 48)
            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(theme.cardAlt))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(theme.outline, lineWidth: 1))
    }

    // MARK: - Actions

    /// AuthRepository is synchronous and main-thread by contract, so submit runs inline;
    /// the busy flag mirrors the Android flow for API parity.
    private func submit() {
        guard !busy else { return }
        busy = true
        errorKey = nil
        let result = creating
            ? auth.register(email: email, password: password, name: name)
            : auth.signIn(email: email, password: password)
        if case let .failure(messageKey) = result {
            errorKey = messageKey
        }
        // On success AuthRepository set settings.userId; RootView navigates.
        busy = false
    }
}
