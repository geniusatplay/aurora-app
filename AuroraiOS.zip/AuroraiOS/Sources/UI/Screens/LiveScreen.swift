// Live vitals screen — the iOS port of ui/screens/LiveScreen.kt (current version).
//
// One card per concern: heart rate (burst-aware, never "0 bpm", never stale — falls back
// to the last valid reading with its age), HRV (RMSSD/SDNN, gated on the valid flag),
// skin & room, sweat moisture, rolling 15-minute charts, sleep level and pod battery.
// Real glove (PodCapabilities.hardwareV1): skin-moisture + SpO₂-estimate cards, skin-only
// card/chart (no room sensor), no movement/sleep/burst countdown, battery text only.
// Range guides (GuideSpec) appear only when settings.showRanges; sleep-HR guides only
// while actually asleep, matching Android.
//
// The cards are internal views (LiveHeartRateCard, LiveChartsView, …) so custom pages
// reuse exactly what this screen shows.

import SwiftUI

struct LiveScreen: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme

    let onOpenPod: () -> Void
    let onDemo: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                header
                if !pod.connectionState.isConnected || pod.latestVitals == nil {
                    LiveNotConnectedCard(onOpenPod: onOpenPod, onDemo: onDemo)
                } else if let vit = pod.latestVitals {
                    connectedContent(vit)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
    }

    // MARK: - Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(L("live_title"))
                    .font(AuroraFont.headline())
                    .foregroundStyle(theme.textPrimary)
                Spacer().frame(width: 10)
                if pod.connectionState.isConnected {
                    if pod.activeSession != nil {
                        Pill(text: L("common_recording"), bg: theme.primary, fg: theme.onPrimary)
                    } else {
                        Pill(text: L("common_connected"))
                    }
                }
                Spacer()
            }
            Text(L("live_subtitle"))
                .font(AuroraFont.body())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.top, 8)
    }

    // MARK: - Connected content

    @ViewBuilder
    private func connectedContent(_ vit: LiveVitals) -> some View {
        let show = settings.showRanges
        let asleep = vit.sleepState == .light || vit.sleepState == .deep
        // What this pod can measure: demo = full paper spec (UI unchanged); real glove = hardwareV1.
        let caps = pod.capabilities
        // Room climate only when the pod has a room sensor AND this packet carries a reading
        // (the real glove sends the NO_AMBIENT sentinel).
        let showRoom = caps.roomClimate && HwAdapter.hasAmbient(vit.ambTempX100)

        // Grouped: connectedContent otherwise exceeds ViewBuilder's 10-child limit.
        Group {
            if vit.sensorFault { InfoBanner(text: L("live_banner_sensor_fault"), tone: .error) }
            if !pod.timeSynced { InfoBanner(text: L("live_banner_syncing_clock"), tone: .info) }
            if !vit.podDetected { InfoBanner(text: L("live_banner_not_on_skin"), tone: .warning) }
            if show { InfoBanner(text: L("live_banner_guides"), tone: .info) }
        }

        // Skin moisture (absolute humidity) — the real glove's key sweat signal — + SpO₂ estimate.
        if caps.directAbsHumidity {
            Group {
                LiveMoistureCard(vit: vit)
                if caps.spo2Estimate { LiveSpo2Card() }
            }
        }

        LiveHeartRateCard(vit: vit, show: show, asleep: asleep, caps: caps)
        if let h = pod.latestHrv { LiveHrvCard(h: h, show: show, relativeOnly: caps.hrvRelativeOnly) }
        if showRoom {
            LiveSkinRoomCard(vit: vit, show: show)
        } else {
            LiveSkinOnlyCard(vit: vit, show: show)
        }
        // Sweat moisture via skin-vs-room Magnus math — only for pods with a room sensor;
        // the real glove has its own moisture card above.
        if !caps.directAbsHumidity && showRoom { LiveSweatCard(vit: vit, show: show) }
        // Skin conductance — only when this pod exposes the extended sensors (FE06).
        if pod.hasExtendedSensors { LiveConductanceCard(show: show) }
        LiveChartsView(show: show, asleep: asleep, caps: caps, showRoom: showRoom)

        Group {
            // Sleep level — only when the pod stages sleep (needs an IMU).
            if caps.sleepStaging { LiveSleepCard(vit: vit) }
            // Battery unknown (no cell fitted) → no gauge at all, just the text.
            if !caps.battery && pod.batteryPct == nil {
                LiveBatteryUnknownCard()
            } else {
                LiveBatteryCard(vit: vit)
            }
            if pod.activeSession != nil {
                InfoBanner(text: L("live_banner_recording"), tone: .success)
            }
        }
    }
}

// MARK: - Not connected

struct LiveNotConnectedCard: View {
    @Environment(\.theme) private var theme
    let onOpenPod: () -> Void
    let onDemo: () -> Void

    var body: some View {
        AuroraCard {
            EmptyState(title: L("live_not_connected_title"), body: L("live_not_connected_body")) {
                HStack(spacing: 10) {
                    Button(action: onOpenPod) {
                        Text(L("common_connect"))
                            .font(AuroraFont.title())
                            .foregroundStyle(theme.onPrimary)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(Capsule().fill(theme.primary))
                    }
                    .buttonStyle(.plain)
                    Button(action: onDemo) {
                        Text(L("common_demo"))
                            .font(AuroraFont.title())
                            .foregroundStyle(theme.textPrimary)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .overlay(Capsule().stroke(theme.outline, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

// MARK: - Skin moisture (hardware: absolute humidity straight from the pod)

struct LiveMoistureCard: View {
    @Environment(\.theme) private var theme
    let vit: LiveVitals

    var body: some View {
        let ah: Int? = vit.absHumX100
        let rise: Int? = vit.dahDirectX100
        AuroraCard {
            Text(L("hw_live_moisture_title"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            Text(L("hw_live_moisture_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(8)
            HStack(alignment: .lastTextBaseline, spacing: 6) {
                Text(ah.map { String(format: "%.2f", Double($0) / 100) } ?? "—")
                    .font(.system(size: 44, weight: .bold))
                    .foregroundStyle(theme.textPrimary)
                if ah != nil {
                    Text(L("common_gm3"))
                        .font(AuroraFont.title())
                        .foregroundStyle(theme.textSecondary)
                }
            }
            if let d = rise {
                Text(L("hw_live_moisture_vs_baseline", String(format: "%+.2f", Double(d) / 100)))
                    .font(AuroraFont.body())
                    .foregroundStyle(theme.textSecondary)
            }
            if vit.sweatFlag != SweatFlag.none {
                VSpace(8)
                Pill(text: L("hw_live_possible_flush"), bg: Aurora.seriesSweat, fg: theme.onPrimary)
            }
        }
    }
}

/// SpO₂ — an uncalibrated ratio estimate, trend only; hidden below quality 40 (PROTOCOL §3).
struct LiveSpo2Card: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.theme) private var theme

    var body: some View {
        let spo2: Double? = pod.latestExt?.spo2Pct
        AuroraCard {
            HStack(spacing: 10) {
                StatTile(label: L("hw_live_spo2_title"),
                         value: spo2.map { String(format: "%.0f", $0) } ?? "—",
                         unit: spo2 != nil ? "%" : "",
                         accent: theme.seriesOxygen,
                         note: spo2 != nil ? L("hw_live_spo2_note") : L("hw_live_spo2_low_quality"))
            }
        }
    }
}

// MARK: - Heart rate (never "0 bpm", never stale)

struct LiveHeartRateCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme
    let vit: LiveVitals
    let show: Bool
    let asleep: Bool
    let caps: PodCapabilities

    var body: some View {
        AuroraCard {
            HStack {
                Image(systemName: "heart.fill").foregroundStyle(theme.primary)
                Spacer().frame(width: 8)
                Text(L("live_heart_rate"))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                if vit.ppgActive { Pill(text: L("live_pill_measuring")) }
            }
            VSpace(8)
            if vit.ppgActive && vit.hasHr {
                HStack(alignment: .lastTextBaseline, spacing: 6) {
                    Text("\(vit.hrBpm)")
                        .font(.system(size: 44, weight: .bold))
                        .foregroundStyle(theme.textPrimary)
                    Text(L("common_bpm"))
                        .font(AuroraFont.title())
                        .foregroundStyle(theme.textSecondary)
                    if show && asleep {
                        Spacer().frame(width: 6)
                        LevelBadge(level: Ranges.sleepHeartRate.levelOf(Double(vit.hrBpm)))
                    }
                    if QualityBand.of(vit.hrQuality) == .lowConfidence {
                        Spacer().frame(width: 6)
                        Pill(text: L("live_pill_low_confidence"), bg: theme.track)
                    }
                }
                if settings.demoMode {
                    // The demo pod streams pulse continuously — no burst cycle to show.
                    Text(L("live_hr_streaming"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                } else if caps.continuousPpg {
                    // The real glove's optical sensor runs all the time: no burst countdown.
                    Text(L("hw_live_hr_continuous"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                } else {
                    let inBurst = Int(vit.tS % Int64(Cadence.hrvPeriodS))
                    ProgressView(value: Double(min(inBurst, Cadence.ppgBurstS)), total: Double(Cadence.ppgBurstS))
                        .progressViewStyle(.linear)
                        .tint(theme.primary)
                    Text(L("live_optical_burst", inBurst, Cadence.ppgBurstS))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
            } else if vit.ppgActive {
                Text(L("live_measuring"))
                    .font(AuroraFont.headline())
                    .foregroundStyle(theme.textPrimary)
                Text(L("live_measuring_body"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            } else if caps.continuousPpg {
                // Continuous PPG with no skin contact: a dash, never a zero or a countdown.
                Text("—")
                    .font(.system(size: 44, weight: .bold))
                    .foregroundStyle(theme.textSecondary)
                Text(L("hw_live_hr_no_finger"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            } else {
                betweenBurstsBody
            }
        }
    }

    /// Between optical bursts: show the last valid reading (with its age) plus the
    /// countdown to the next burst — the pod measures 2 min out of every 10 by design.
    @ViewBuilder
    private var betweenBurstsBody: some View {
        let minutes = (vit.secondsToNextPpg + 59) / 60
        let last = pod.lastHr
        if let last {
            HStack(alignment: .lastTextBaseline, spacing: 6) {
                Text("\(last.bpm)")
                    .font(.system(size: 44, weight: .bold))
                    .foregroundStyle(theme.textSecondary)
                Text(L("common_bpm"))
                    .font(AuroraFont.title())
                    .foregroundStyle(theme.textSecondary)
                if show && asleep {
                    Spacer().frame(width: 6)
                    LevelBadge(level: Ranges.sleepHeartRate.levelOf(Double(last.bpm)))
                }
            }
            let ageMin = Int((vit.tS - last.tS) / 60)
            Text(ageMin < 1 ? L("live_last_reading_just_now") : L("live_last_reading_ago", ageMin))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
        Text(minutes <= 1 ? L("live_next_reading_minute") : L("live_next_reading_min", minutes))
            .font(last != nil ? AuroraFont.titleS() : AuroraFont.headlineS())
            .foregroundStyle(theme.textPrimary)
        Text(L("live_next_reading_body"))
            .font(AuroraFont.bodyS())
            .foregroundStyle(theme.textSecondary)
    }
}

// MARK: - HRV

struct LiveHrvCard: View {
    @Environment(\.theme) private var theme
    let h: HrvSummary
    let show: Bool
    let relativeOnly: Bool

    var body: some View {
        AuroraCard {
            Text(L("live_hrv_title"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            Text(relativeOnly ? L("hw_live_hrv_body") : L("live_hrv_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            if relativeOnly {
                // Quantisation-limited HRV (20 ms beats): relative trend only, never clinical.
                VSpace(4)
                Text(L("hw_hrv_relative_note"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
            VSpace(10)
            HStack(spacing: 10) {
                if h.isValid {
                    StatTile(label: L("live_hrv_rmssd"), value: String(format: "%.0f", h.rmssdMs),
                             unit: L("common_ms"), accent: Aurora.seriesHrv,
                             note: L("live_hrv_rmssd_note"),
                             level: (show && !relativeOnly) ? Ranges.rmssd.levelOf(h.rmssdMs) : nil,
                             higherIsBetter: true)
                    StatTile(label: L("live_hrv_sdnn"), value: String(format: "%.0f", h.sdnnMs),
                             unit: L("common_ms"), accent: Aurora.seriesHrv,
                             note: L("live_hrv_sdnn_note"))
                } else {
                    // Explain WHY there is no number, in plain words (flags → reason).
                    StatTile(label: L("live_hrv_variability"), value: "—",
                             accent: Aurora.seriesHrv,
                             note: L("live_hrv_not_enough", hrvReason(h.flags)))
                }
            }
        }
    }

    private func hrvReason(_ flags: Int) -> String {
        if HrvFlags.has(flags, HrvFlags.motion) { return L("live_hrv_reason_movement") }
        if HrvFlags.has(flags, HrvFlags.lowPerf) { return L("live_hrv_reason_weak_pulse") }
        if HrvFlags.has(flags, HrvFlags.lowBeats) { return L("live_hrv_reason_few_beats") }
        if HrvFlags.has(flags, HrvFlags.sampleLoss) { return L("live_hrv_reason_sample_loss") }
        return L("live_hrv_reason_low_quality")
    }
}

// MARK: - Skin & room

struct LiveSkinRoomCard: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme
    let vit: LiveVitals
    let show: Bool

    var body: some View {
        AuroraCard {
            Text(L("live_skin_room"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("live_skin_temp"), value: Fmt.temp(vit.skinTempC, settings),
                         accent: Aurora.seriesSkin,
                         level: show ? Ranges.skinTemp.levelOf(vit.skinTempC) : nil)
                StatTile(label: L("live_room_temp"), value: Fmt.temp(vit.ambTempC, settings),
                         accent: Aurora.seriesAmbient,
                         level: show ? Ranges.roomTemp.levelOf(vit.ambTempC) : nil)
            }
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("live_skin_humidity"), value: String(format: "%.0f", vit.skinRh),
                         unit: "%", accent: Aurora.seriesSkin,
                         level: show ? Ranges.skinRh.levelOf(vit.skinRh) : nil)
                StatTile(label: L("live_room_humidity"), value: String(format: "%.0f", vit.ambRh),
                         unit: "%", accent: Aurora.seriesAmbient,
                         level: show ? Ranges.roomRh.levelOf(vit.ambRh) : nil)
            }
        }
    }
}

/// Skin only — a pod without a room sensor (the real glove).
struct LiveSkinOnlyCard: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme
    let vit: LiveVitals
    let show: Bool

    var body: some View {
        AuroraCard {
            Text(L("hw_live_skin_title"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("live_skin_temp"), value: Fmt.temp(vit.skinTempC, settings),
                         accent: Aurora.seriesSkin,
                         level: show ? Ranges.skinTemp.levelOf(vit.skinTempC) : nil)
                StatTile(label: L("live_skin_humidity"), value: String(format: "%.0f", vit.skinRh),
                         unit: "%", accent: Aurora.seriesSkin,
                         level: show ? Ranges.skinRh.levelOf(vit.skinRh) : nil)
            }
        }
    }
}

// MARK: - Sweat moisture

struct LiveSweatCard: View {
    @Environment(\.theme) private var theme
    let vit: LiveVitals
    let show: Bool

    var body: some View {
        let dah = Double(NightAnalytics.dahX100(skinTempC: vit.skinTempC, skinRh: vit.skinRh,
                                                ambTempC: vit.ambTempC, ambRh: vit.ambRh)) / 100
        AuroraCard {
            Text(L("live_sweat_title"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            Text(L("live_sweat_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("live_sweat_now"), value: Fmt.dah(dah), unit: L("common_gm3"),
                         accent: Aurora.seriesSweat,
                         level: show ? Ranges.sweat.levelOf(dah) : nil)
                StatTile(label: L("live_sweat_event"), value: L(sweatEventKey(vit.sweatFlag)),
                         accent: Aurora.seriesSweat)
            }
        }
    }

    private func sweatEventKey(_ flag: SweatFlag) -> String {
        switch flag {
        case .start: return "live_sweat_started"
        case .ongoing: return "live_sweat_ongoing"
        case .none: return "live_sweat_none"
        }
    }
}

// MARK: - Skin conductance (extended sensors, ext brief §6)

struct LiveConductanceCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.theme) private var theme
    let show: Bool

    var body: some View {
        let edaNow = pod.latestExt?.edaUs
        let trail = pod.extWindow.compactMap { $0.edaUs }
        AuroraCard {
            Text(L("ext_live_conductance"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            Text(L("ext_live_conductance_sub"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("ext_conductance"),
                         value: edaNow.map { String(format: "%.1f", $0) } ?? "—",
                         unit: edaNow != nil ? L("ext_us") : "",
                         accent: theme.seriesConductance,
                         level: (show && edaNow != nil)
                            ? ExtGuideBands.level(edaNow!, lowMax: ExtGuideBands.conductanceLowMax,
                                                  highMin: ExtGuideBands.conductanceHighMin) : nil)
            }
            if trail.count > 2 {
                VSpace(10)
                Sparkline(values: trail, color: theme.seriesConductance)
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
            }
        }
    }
}

// MARK: - Rolling charts (last ~15 min)

/// The Live screen's stack of rolling charts (heart rate, skin [+ room], moisture/sweat,
/// movement). Renders nothing until the window holds more than two samples.
struct LiveChartsView: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme
    let show: Bool
    let asleep: Bool
    let caps: PodCapabilities
    let showRoom: Bool

    var body: some View {
        let window = pod.liveWindow
        if window.count > 2 {
            let x0 = Double(window.first!.tS)
            let x1 = max(Double(window.last!.tS), x0 + 60)

            let hrPoints = window.filter { $0.hasHr }
                .map { TimePoint(t: Double($0.tS), v: Double($0.hrBpm)) }
            if hrPoints.count > 1 {
                AuroraCard(padding: 12) {
                    SectionHeader(title: L("live_chart_hr"), subtitle: L("live_chart_hr_sub"))
                    LinePanel(series: [(name: L("live_heart_rate"), color: theme.seriesHeart,
                                        points: hrPoints, area: false)],
                              x0: x0, x1: x1, height: 140,
                              unit: " " + L("common_bpm"), decimals: 0,
                              guides: (show && asleep) ? GuideSpec(Ranges.sleepHeartRate) : nil,
                              showXAxis: true)
                }
            }

            if showRoom {
                skinRoomChart(window, x0: x0, x1: x1, show: show)
            } else {
                skinOnlyChart(window, x0: x0, x1: x1, show: show)
            }

            if caps.directAbsHumidity {
                moistureChart(window, x0: x0, x1: x1)
            } else if showRoom {
                sweatChart(window, x0: x0, x1: x1, show: show)
            }

            if caps.movement {
                AuroraCard(padding: 12) {
                    SectionHeader(title: L("live_chart_movement"), subtitle: L("live_chart_movement_subtitle"))
                    LinePanel(series: [(name: L("live_chart_movement"), color: Aurora.seriesMotion,
                                        points: window.map { TimePoint(t: Double($0.tS), v: Double($0.motionIndex)) },
                                        area: true)],
                              x0: x0, x1: x1, height: 110,
                              decimals: 0,
                              guides: show ? GuideSpec(Ranges.movement) : nil,
                              showXAxis: true)
                }
            }
        }
    }

    private func skinGuides(_ show: Bool) -> GuideSpec? {
        // Guides live in °C — convert the thresholds to display units too.
        show ? GuideSpec(lowMax: settings.toDisplayTemp(Ranges.skinTemp.lowMax),
                         highMin: settings.toDisplayTemp(Ranges.skinTemp.highMin))
             : nil
    }

    private func skinRoomChart(_ window: [LiveVitals], x0: Double, x1: Double, show: Bool) -> some View {
        let minutes = max(Int((x1 - x0) / 60), 1)
        return AuroraCard(padding: 12) {
            SectionHeader(title: L("live_chart_skin_vs_room"),
                          subtitle: L("live_chart_last_min", minutes))
            LinePanel(series: [
                        (name: L("live_series_skin"), color: Aurora.seriesSkin,
                         points: window.map { TimePoint(t: Double($0.tS),
                                                        v: settings.toDisplayTemp($0.skinTempC)) },
                         area: false),
                        (name: L("live_series_room"), color: Aurora.seriesAmbient,
                         points: window.map { TimePoint(t: Double($0.tS),
                                                        v: settings.toDisplayTemp($0.ambTempC)) },
                         area: false),
                      ],
                      x0: x0, x1: x1, height: 150,
                      unit: settings.tempUnit,
                      guides: skinGuides(show),
                      showXAxis: true)
        }
    }

    /// Skin temperature only — a pod without a room sensor (the real glove).
    private func skinOnlyChart(_ window: [LiveVitals], x0: Double, x1: Double, show: Bool) -> some View {
        let minutes = max(Int((x1 - x0) / 60), 1)
        return AuroraCard(padding: 12) {
            SectionHeader(title: L("vs_row_skin"),
                          subtitle: L("live_chart_last_min", minutes))
            LinePanel(series: [
                        (name: L("live_series_skin"), color: Aurora.seriesSkin,
                         points: window.map { TimePoint(t: Double($0.tS),
                                                        v: settings.toDisplayTemp($0.skinTempC)) },
                         area: false),
                      ],
                      x0: x0, x1: x1, height: 150,
                      unit: settings.tempUnit,
                      guides: skinGuides(show),
                      showXAxis: true)
        }
    }

    /// Hardware: absolute humidity at the skin, straight from the pod (g/m³).
    @ViewBuilder
    private func moistureChart(_ window: [LiveVitals], x0: Double, x1: Double) -> some View {
        let points: [TimePoint] = window.compactMap { (w: LiveVitals) -> TimePoint? in
            guard let ah = w.absHumX100 else { return nil }
            return TimePoint(t: Double(w.tS), v: Double(ah) / 100)
        }
        if points.count > 1 {
            AuroraCard(padding: 12) {
                SectionHeader(title: L("hw_live_moisture_title"), subtitle: L("hw_live_chart_moisture_sub"))
                LinePanel(series: [(name: L("hw_series_moisture"), color: Aurora.seriesSweat,
                                    points: points, area: true)],
                          x0: x0, x1: x1, height: 140,
                          unit: " " + L("common_gm3"), decimals: 2,
                          showXAxis: true)
            }
        }
    }

    private func sweatChart(_ window: [LiveVitals], x0: Double, x1: Double, show: Bool) -> some View {
        AuroraCard(padding: 12) {
            SectionHeader(title: L("live_sweat_title"), subtitle: L("live_chart_sweat_subtitle"))
            LinePanel(series: [(name: L("live_series_sweat"), color: Aurora.seriesSweat,
                                points: window.map {
                                    TimePoint(t: Double($0.tS),
                                              v: Double(NightAnalytics.dahX100(skinTempC: $0.skinTempC,
                                                                               skinRh: $0.skinRh,
                                                                               ambTempC: $0.ambTempC,
                                                                               ambRh: $0.ambRh)) / 100)
                                },
                                area: true)],
                      x0: x0, x1: x1, height: 140,
                      unit: " " + L("common_gm3"),
                      guides: show ? GuideSpec(Ranges.sweat) : nil,
                      showXAxis: true)
        }
    }
}

// MARK: - Sleep level

struct LiveSleepCard: View {
    @Environment(\.theme) private var theme
    let vit: LiveVitals

    var body: some View {
        AuroraCard {
            HStack {
                Image(systemName: "moon.fill").foregroundStyle(Aurora.sleepDeep)
                Spacer().frame(width: 8)
                Text(L("live_sleep_level"))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
            }
            VSpace(6)
            Text(L(sleepLevelKey(vit.sleepState)))
                .font(AuroraFont.headline())
                .foregroundStyle(theme.textPrimary)
            Text(L(sleepDescKey(vit.sleepState)) + " " + L("live_sleep_lag_note"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
    }

    private func sleepLevelKey(_ s: SleepState) -> String {
        switch s {
        case .wake: return "live_sleep_awake"
        case .light: return "live_sleep_light"
        case .deep: return "live_sleep_deep"
        case .unknown: return "live_sleep_unknown"
        }
    }

    private func sleepDescKey(_ s: SleepState) -> String {
        switch s {
        case .wake: return "live_sleep_desc_awake"
        case .light: return "live_sleep_desc_light"
        case .deep: return "live_sleep_desc_deep"
        case .unknown: return "live_sleep_desc_unknown"
        }
    }
}

// MARK: - Battery

/// Battery byte 0xFF on the real glove = no cell fitted: text only, never a gauge.
struct LiveBatteryUnknownCard: View {
    @Environment(\.theme) private var theme

    var body: some View {
        AuroraCard {
            HStack {
                Image(systemName: "battery.100percent")
                    .foregroundStyle(theme.textSecondary)
                Spacer().frame(width: 8)
                Text(L("live_battery_title"))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
            }
            VSpace(6)
            Text(L("hw_battery_unknown"))
                .font(AuroraFont.body())
                .foregroundStyle(theme.textSecondary)
        }
    }
}

struct LiveBatteryCard: View {
    @Environment(\.theme) private var theme
    let vit: LiveVitals

    var body: some View {
        AuroraCard {
            HStack {
                Image(systemName: vit.charging ? "battery.100percent.bolt" : "battery.100percent")
                    .foregroundStyle(vit.lowBatt ? Aurora.bad : Aurora.good)
                Spacer().frame(width: 8)
                Text(L("live_battery_title"))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                Text(L("live_battery_pct", vit.battPct))
                    .font(AuroraFont.headline())
                    .foregroundStyle(vit.lowBatt ? Aurora.bad : theme.textPrimary)
            }
            VSpace(8)
            ProgressView(value: Double(vit.battPct), total: 100)
                .progressViewStyle(.linear)
                .tint(vit.lowBatt ? Aurora.bad : Aurora.good)
            VSpace(6)
            Text(L(vit.charging ? "live_battery_charging"
                                : (vit.lowBatt ? "live_battery_low" : "live_battery_normal")))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
    }
}
