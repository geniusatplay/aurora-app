// Live vitals screen — the iOS port of ui/screens/LiveScreen.kt (current version).
//
// One card per concern: heart rate (burst-aware, never "0 bpm", never stale — falls back
// to the last valid reading with its age), HRV (RMSSD/SDNN, gated on the valid flag),
// skin & room, sweat moisture, rolling 15-minute charts, sleep level and pod battery.
// Range guides (GuideSpec) appear only when settings.showRanges; sleep-HR guides only
// while actually asleep, matching Android.

import SwiftUI

struct LiveScreen: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme

    let onOpenPod: () -> Void
    let onDemo: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                header
                if !pod.connectionState.isConnected || pod.latestVitals == nil {
                    notConnectedCard
                } else if let vit = pod.latestVitals {
                    connectedContent(vit)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
    }

    // MARK: - Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(L("live_title"))
                    .font(AuroraFont.headline())
                    .foregroundStyle(theme.textPrimary)
                Spacer().frame(width: 10)
                if pod.connectionState.isConnected {
                    if pod.activeSession != nil {
                        Pill(text: L("common_recording"), bg: theme.primary, fg: theme.onPrimary)
                    } else {
                        Pill(text: L("common_connected"))
                    }
                }
                Spacer()
            }
            Text(L("live_subtitle"))
                .font(AuroraFont.body())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.top, 8)
    }

    private var notConnectedCard: some View {
        AuroraCard {
            EmptyState(title: L("live_not_connected_title"), body: L("live_not_connected_body")) {
                HStack(spacing: 10) {
                    Button(action: onOpenPod) {
                        Text(L("common_connect"))
                            .font(AuroraFont.title())
                            .foregroundStyle(theme.onPrimary)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(Capsule().fill(theme.primary))
                    }
                    .buttonStyle(.plain)
                    Button(action: onDemo) {
                        Text(L("common_demo"))
                            .font(AuroraFont.title())
                            .foregroundStyle(theme.textPrimary)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .overlay(Capsule().stroke(theme.outline, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: - Connected content

    @ViewBuilder
    private func connectedContent(_ vit: LiveVitals) -> some View {
        let show = settings.showRanges
        let asleep = vit.sleepState == .light || vit.sleepState == .deep

        // Grouped: connectedContent otherwise exceeds ViewBuilder's 10-child limit.
        Group {
            if vit.sensorFault { InfoBanner(text: L("live_banner_sensor_fault"), tone: .error) }
            if !pod.timeSynced { InfoBanner(text: L("live_banner_syncing_clock"), tone: .info) }
            if !vit.podDetected { InfoBanner(text: L("live_banner_not_on_skin"), tone: .warning) }
            if show { InfoBanner(text: L("live_banner_guides"), tone: .info) }
        }

        heartRateCard(vit, show: show, asleep: asleep)
        if let h = pod.latestHrv { hrvCard(h, show: show) }
        skinRoomCard(vit, show: show)
        sweatCard(vit, show: show)
        charts(show: show, asleep: asleep)
        sleepCard(vit)
        batteryCard(vit)

        if pod.activeSession != nil {
            InfoBanner(text: L("live_banner_recording"), tone: .success)
        }
    }

    // MARK: - Heart rate (never "0 bpm", never stale)

    private func heartRateCard(_ vit: LiveVitals, show: Bool, asleep: Bool) -> some View {
        AuroraCard {
            HStack {
                Image(systemName: "heart.fill").foregroundStyle(theme.primary)
                Spacer().frame(width: 8)
                Text(L("live_heart_rate"))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                if vit.ppgActive { Pill(text: L("live_pill_measuring")) }
            }
            VSpace(8)
            if vit.ppgActive && vit.hasHr {
                HStack(alignment: .lastTextBaseline, spacing: 6) {
                    Text("\(vit.hrBpm)")
                        .font(.system(size: 44, weight: .bold))
                        .foregroundStyle(theme.textPrimary)
                    Text(L("common_bpm"))
                        .font(AuroraFont.title())
                        .foregroundStyle(theme.textSecondary)
                    if show && asleep {
                        Spacer().frame(width: 6)
                        LevelBadge(level: Ranges.sleepHeartRate.levelOf(Double(vit.hrBpm)))
                    }
                    if QualityBand.of(vit.hrQuality) == .lowConfidence {
                        Spacer().frame(width: 6)
                        Pill(text: L("live_pill_low_confidence"), bg: theme.track)
                    }
                }
                if settings.demoMode {
                    // The demo pod streams pulse continuously — no burst cycle to show.
                    Text(L("live_hr_streaming"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                } else {
                    let inBurst = Int(vit.tS % Int64(Cadence.hrvPeriodS))
                    ProgressView(value: Double(min(inBurst, Cadence.ppgBurstS)), total: Double(Cadence.ppgBurstS))
                        .progressViewStyle(.linear)
                        .tint(theme.primary)
                    Text(L("live_optical_burst", inBurst, Cadence.ppgBurstS))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
            } else if vit.ppgActive {
                Text(L("live_measuring"))
                    .font(AuroraFont.headline())
                    .foregroundStyle(theme.textPrimary)
                Text(L("live_measuring_body"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            } else {
                betweenBurstsBody(vit, show: show, asleep: asleep)
            }
        }
    }

    /// Between optical bursts: show the last valid reading (with its age) plus the
    /// countdown to the next burst — the pod measures 2 min out of every 10 by design.
    @ViewBuilder
    private func betweenBurstsBody(_ vit: LiveVitals, show: Bool, asleep: Bool) -> some View {
        let minutes = (vit.secondsToNextPpg + 59) / 60
        let last = pod.lastHr
        if let last {
            HStack(alignment: .lastTextBaseline, spacing: 6) {
                Text("\(last.bpm)")
                    .font(.system(size: 44, weight: .bold))
                    .foregroundStyle(theme.textSecondary)
                Text(L("common_bpm"))
                    .font(AuroraFont.title())
                    .foregroundStyle(theme.textSecondary)
                if show && asleep {
                    Spacer().frame(width: 6)
                    LevelBadge(level: Ranges.sleepHeartRate.levelOf(Double(last.bpm)))
                }
            }
            let ageMin = Int((vit.tS - last.tS) / 60)
            Text(ageMin < 1 ? L("live_last_reading_just_now") : L("live_last_reading_ago", ageMin))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
        Text(minutes <= 1 ? L("live_next_reading_minute") : L("live_next_reading_min", minutes))
            .font(last != nil ? AuroraFont.titleS() : AuroraFont.headlineS())
            .foregroundStyle(theme.textPrimary)
        Text(L("live_next_reading_body"))
            .font(AuroraFont.bodyS())
            .foregroundStyle(theme.textSecondary)
    }

    // MARK: - HRV

    private func hrvCard(_ h: HrvSummary, show: Bool) -> some View {
        AuroraCard {
            Text(L("live_hrv_title"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            Text(L("live_hrv_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(10)
            HStack(spacing: 10) {
                if h.isValid {
                    StatTile(label: L("live_hrv_rmssd"), value: String(format: "%.0f", h.rmssdMs),
                             unit: L("common_ms"), accent: Aurora.seriesHrv,
                             note: L("live_hrv_rmssd_note"),
                             level: show ? Ranges.rmssd.levelOf(h.rmssdMs) : nil,
                             higherIsBetter: true)
                    StatTile(label: L("live_hrv_sdnn"), value: String(format: "%.0f", h.sdnnMs),
                             unit: L("common_ms"), accent: Aurora.seriesHrv,
                             note: L("live_hrv_sdnn_note"))
                } else {
                    // Explain WHY there is no number, in plain words (flags → reason).
                    StatTile(label: L("live_hrv_variability"), value: "—",
                             accent: Aurora.seriesHrv,
                             note: L("live_hrv_not_enough", hrvReason(h.flags)))
                }
            }
        }
    }

    private func hrvReason(_ flags: Int) -> String {
        if HrvFlags.has(flags, HrvFlags.motion) { return L("live_hrv_reason_movement") }
        if HrvFlags.has(flags, HrvFlags.lowPerf) { return L("live_hrv_reason_weak_pulse") }
        if HrvFlags.has(flags, HrvFlags.lowBeats) { return L("live_hrv_reason_few_beats") }
        if HrvFlags.has(flags, HrvFlags.sampleLoss) { return L("live_hrv_reason_sample_loss") }
        return L("live_hrv_reason_low_quality")
    }

    // MARK: - Skin & room

    private func skinRoomCard(_ vit: LiveVitals, show: Bool) -> some View {
        AuroraCard {
            Text(L("live_skin_room"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("live_skin_temp"), value: Fmt.temp(vit.skinTempC, settings),
                         accent: Aurora.seriesSkin,
                         level: show ? Ranges.skinTemp.levelOf(vit.skinTempC) : nil)
                StatTile(label: L("live_room_temp"), value: Fmt.temp(vit.ambTempC, settings),
                         accent: Aurora.seriesAmbient,
                         level: show ? Ranges.roomTemp.levelOf(vit.ambTempC) : nil)
            }
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("live_skin_humidity"), value: String(format: "%.0f", vit.skinRh),
                         unit: "%", accent: Aurora.seriesSkin,
                         level: show ? Ranges.skinRh.levelOf(vit.skinRh) : nil)
                StatTile(label: L("live_room_humidity"), value: String(format: "%.0f", vit.ambRh),
                         unit: "%", accent: Aurora.seriesAmbient,
                         level: show ? Ranges.roomRh.levelOf(vit.ambRh) : nil)
            }
        }
    }

    // MARK: - Sweat moisture

    private func sweatCard(_ vit: LiveVitals, show: Bool) -> some View {
        let dah = Double(NightAnalytics.dahX100(skinTempC: vit.skinTempC, skinRh: vit.skinRh,
                                                ambTempC: vit.ambTempC, ambRh: vit.ambRh)) / 100
        return AuroraCard {
            Text(L("live_sweat_title"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            Text(L("live_sweat_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("live_sweat_now"), value: Fmt.dah(dah), unit: L("common_gm3"),
                         accent: Aurora.seriesSweat,
                         level: show ? Ranges.sweat.levelOf(dah) : nil)
                StatTile(label: L("live_sweat_event"), value: L(sweatEventKey(vit.sweatFlag)),
                         accent: Aurora.seriesSweat)
            }
        }
    }

    private func sweatEventKey(_ flag: SweatFlag) -> String {
        switch flag {
        case .start: return "live_sweat_started"
        case .ongoing: return "live_sweat_ongoing"
        case .none: return "live_sweat_none"
        }
    }

    // MARK: - Rolling charts (last ~15 min)

    @ViewBuilder
    private func charts(show: Bool, asleep: Bool) -> some View {
        let window = pod.liveWindow
        if window.count > 2 {
            let x0 = Double(window.first!.tS)
            let x1 = max(Double(window.last!.tS), x0 + 60)

            let hrPoints = window.filter { $0.hasHr }
                .map { TimePoint(t: Double($0.tS), v: Double($0.hrBpm)) }
            if hrPoints.count > 1 {
                AuroraCard(padding: 12) {
                    SectionHeader(title: L("live_chart_hr"), subtitle: L("live_chart_hr_sub"))
                    LinePanel(series: [(name: L("live_heart_rate"), color: theme.seriesHeart,
                                        points: hrPoints, area: false)],
                              x0: x0, x1: x1, height: 140,
                              unit: " " + L("common_bpm"), decimals: 0,
                              guides: (show && asleep) ? GuideSpec(Ranges.sleepHeartRate) : nil,
                              showXAxis: true)
                }
            }

            AuroraCard(padding: 12) {
                let minutes = max(Int((x1 - x0) / 60), 1)
                SectionHeader(title: L("live_chart_skin_vs_room"),
                              subtitle: L("live_chart_last_min", minutes))
                LinePanel(series: [
                            (name: L("live_series_skin"), color: Aurora.seriesSkin,
                             points: window.map { TimePoint(t: Double($0.tS),
                                                            v: settings.toDisplayTemp($0.skinTempC)) },
                             area: false),
                            (name: L("live_series_room"), color: Aurora.seriesAmbient,
                             points: window.map { TimePoint(t: Double($0.tS),
                                                            v: settings.toDisplayTemp($0.ambTempC)) },
                             area: false),
                          ],
                          x0: x0, x1: x1, height: 150,
                          unit: settings.tempUnit,
                          // Guides live in °C — convert the thresholds to display units too.
                          guides: show ? GuideSpec(lowMax: settings.toDisplayTemp(Ranges.skinTemp.lowMax),
                                                   highMin: settings.toDisplayTemp(Ranges.skinTemp.highMin))
                                       : nil,
                          showXAxis: true)
            }

            AuroraCard(padding: 12) {
                SectionHeader(title: L("live_sweat_title"), subtitle: L("live_chart_sweat_subtitle"))
                LinePanel(series: [(name: L("live_series_sweat"), color: Aurora.seriesSweat,
                                    points: window.map {
                                        TimePoint(t: Double($0.tS),
                                                  v: Double(NightAnalytics.dahX100(skinTempC: $0.skinTempC,
                                                                                   skinRh: $0.skinRh,
                                                                                   ambTempC: $0.ambTempC,
                                                                                   ambRh: $0.ambRh)) / 100)
                                    },
                                    area: true)],
                          x0: x0, x1: x1, height: 140,
                          unit: " " + L("common_gm3"),
                          guides: show ? GuideSpec(Ranges.sweat) : nil,
                          showXAxis: true)
            }

            AuroraCard(padding: 12) {
                SectionHeader(title: L("live_chart_movement"), subtitle: L("live_chart_movement_subtitle"))
                LinePanel(series: [(name: L("live_chart_movement"), color: Aurora.seriesMotion,
                                    points: window.map { TimePoint(t: Double($0.tS), v: Double($0.motionIndex)) },
                                    area: true)],
                          x0: x0, x1: x1, height: 110,
                          decimals: 0,
                          guides: show ? GuideSpec(Ranges.movement) : nil,
                          showXAxis: true)
            }
        }
    }

    // MARK: - Sleep level

    private func sleepCard(_ vit: LiveVitals) -> some View {
        AuroraCard {
            HStack {
                Image(systemName: "moon.fill").foregroundStyle(Aurora.sleepDeep)
                Spacer().frame(width: 8)
                Text(L("live_sleep_level"))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
            }
            VSpace(6)
            Text(L(sleepLevelKey(vit.sleepState)))
                .font(AuroraFont.headline())
                .foregroundStyle(theme.textPrimary)
            Text(L(sleepDescKey(vit.sleepState)) + " " + L("live_sleep_lag_note"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
    }

    private func sleepLevelKey(_ s: SleepState) -> String {
        switch s {
        case .wake: return "live_sleep_awake"
        case .light: return "live_sleep_light"
        case .deep: return "live_sleep_deep"
        case .unknown: return "live_sleep_unknown"
        }
    }

    private func sleepDescKey(_ s: SleepState) -> String {
        switch s {
        case .wake: return "live_sleep_desc_awake"
        case .light: return "live_sleep_desc_light"
        case .deep: return "live_sleep_desc_deep"
        case .unknown: return "live_sleep_desc_unknown"
        }
    }

    // MARK: - Battery

    private func batteryCard(_ vit: LiveVitals) -> some View {
        AuroraCard {
            HStack {
                Image(systemName: vit.charging ? "battery.100percent.bolt" : "battery.100percent")
                    .foregroundStyle(vit.lowBatt ? Aurora.bad : Aurora.good)
                Spacer().frame(width: 8)
                Text(L("live_battery_title"))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                Text(L("live_battery_pct", vit.battPct))
                    .font(AuroraFont.headline())
                    .foregroundStyle(vit.lowBatt ? Aurora.bad : theme.textPrimary)
            }
            VSpace(8)
            ProgressView(value: Double(vit.battPct), total: 100)
                .progressViewStyle(.linear)
                .tint(vit.lowBatt ? Aurora.bad : Aurora.good)
            VSpace(6)
            Text(L(vit.charging ? "live_battery_charging"
                                : (vit.lowBatt ? "live_battery_low" : "live_battery_normal")))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
    }
}
