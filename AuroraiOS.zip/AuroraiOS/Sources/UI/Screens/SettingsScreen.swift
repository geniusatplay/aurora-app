// Settings — the iOS port of ui/screens/SettingsScreen.kt (appearance with theme
// swatches, language, units, demo toggle, data & privacy, about, disclaimer).

import SwiftUI

struct SettingsScreen: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var repo: SessionRepository
    @EnvironmentObject private var demoController: DemoController

    /// Plain (non-observable) dependency, passed down from RootView like Android's vm.
    let auth: AuthRepository

    @State private var confirmWipe = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                header
                appearanceSection
                schemeCard
                languageCard
                unitsSection
                demoSection
                privacySection
                aboutSection
                Disclaimer()
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 16)
        }
        .background(theme.background.ignoresSafeArea())
        .alert(L("settings_wipe_title"), isPresented: $confirmWipe) {
            Button(L("settings_wipe_confirm"), role: .destructive) {
                if let uid = settings.userId.flatMap({ UUID(uuidString: $0) }) {
                    repo.deleteAll(userId: uid)
                }
            }
            Button(L("common_keep"), role: .cancel) {}
        } message: {
            Text(L("settings_wipe_body"))
        }
    }

    // MARK: header

    private var header: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(L("settings_title"))
                .font(AuroraFont.headlineL())
                .foregroundStyle(theme.textPrimary)
            Text(auth.currentUser()?.email ?? "")
                .font(AuroraFont.bodyM())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.top, 8)
    }

    // MARK: appearance

    @ViewBuilder
    private var appearanceSection: some View {
        SectionHeader(title: L("settings_appearance"), subtitle: L("settings_appearance_sub"))
        AuroraCard {
            // Grouped: this card exceeds ViewBuilder's 10-child limit otherwise.
            Group {
            Text(L("settings_theme"))
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
            VSpace(10)
            HStack(spacing: 10) {
                ThemeSwatch(mode: .aurora, label: L("theme_aurora"),
                            selected: settings.themeMode == .aurora) { settings.themeMode = .aurora }
                ThemeSwatch(mode: .light, label: L("theme_light"),
                            selected: settings.themeMode == .light) { settings.themeMode = .light }
            }
            VSpace(10)
            HStack(spacing: 10) {
                ThemeSwatch(mode: .highContrast, label: L("theme_high_contrast"),
                            selected: settings.themeMode == .highContrast) { settings.themeMode = .highContrast }
                ThemeSwatch(mode: .dark, label: L("theme_dark"),
                            selected: settings.themeMode == .dark) { settings.themeMode = .dark }
            }
            VSpace(6)
            Text(L("settings_theme_note"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            }
            VSpace(6)
            Divider().overlay(theme.outline.opacity(0.5))
            ToggleRow(title: L("settings_ranges"), subtitle: L("settings_ranges_sub"),
                      isOn: $settings.showRanges)
            if settings.showRanges {
                Text(L("settings_ranges_table"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }

    // MARK: vital sheet style (ext brief §5 — frame styling only; data colours never change)

    private var schemeCard: some View {
        AuroraCard(padding: 18) {
            Text(L("scheme_title"))
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
            Text(L("scheme_sub"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(6)
            SchemeRow(scheme: .scheme1, label: L("scheme_1"), description: L("scheme_1_desc"),
                      selected: settings.sheetScheme == .scheme1) { settings.sheetScheme = .scheme1 }
            Divider().overlay(theme.outline.opacity(0.5))
            SchemeRow(scheme: .scheme2, label: L("scheme_2"), description: L("scheme_2_desc"),
                      selected: settings.sheetScheme == .scheme2) { settings.sheetScheme = .scheme2 }
            Divider().overlay(theme.outline.opacity(0.5))
            SchemeRow(scheme: .scheme3, label: L("scheme_3"), description: L("scheme_3_desc"),
                      selected: settings.sheetScheme == .scheme3) { settings.sheetScheme = .scheme3 }
        }
    }

    // MARK: language

    private var languageCard: some View {
        AuroraCard(padding: 18) {
            Text(L("settings_language"))
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
            Text(L("settings_language_sub"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(6)
            LanguageRow(lang: .system, label: L("lang_system"),
                        selected: settings.language == .system) { settings.language = .system }
            Divider().overlay(theme.outline.opacity(0.5))
            LanguageRow(lang: .english, label: "English",
                        selected: settings.language == .english) { settings.language = .english }
            Divider().overlay(theme.outline.opacity(0.5))
            LanguageRow(lang: .spanish, label: "Español",
                        selected: settings.language == .spanish) { settings.language = .spanish }
            Divider().overlay(theme.outline.opacity(0.5))
            LanguageRow(lang: .vietnamese, label: "Tiếng Việt",
                        selected: settings.language == .vietnamese) { settings.language = .vietnamese }
        }
    }

    // MARK: units

    @ViewBuilder
    private var unitsSection: some View {
        SectionHeader(title: L("settings_units"))
        AuroraCard(padding: 18) {
            ToggleRow(title: L("settings_fahrenheit"), subtitle: L("settings_fahrenheit_sub"),
                      isOn: $settings.useFahrenheit)
            Divider().overlay(theme.outline.opacity(0.5))
            ToggleRow(title: L("settings_24h"), subtitle: nil, isOn: $settings.use24h)
        }
    }

    // MARK: demo

    @ViewBuilder
    private var demoSection: some View {
        SectionHeader(title: L("settings_demo"))
        AuroraCard(padding: 18) {
            ToggleRow(title: L("settings_demo_mode"), subtitle: L("settings_demo_mode_sub"),
                      isOn: Binding(
                        get: { settings.demoMode },
                        set: { $0 ? demoController.enable() : demoController.disable() }
                      ))
        }
    }

    // MARK: data & privacy

    @ViewBuilder
    private var privacySection: some View {
        SectionHeader(title: L("settings_privacy"))
        AuroraCard {
            Text(L("settings_privacy_title"))
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
            VSpace(4)
            Text(L("settings_privacy_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(12)
            HStack(spacing: 10) {
                Button(L("settings_sign_out")) { auth.signOut() }
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)
                Button(L("settings_delete_all")) { confirmWipe = true }
                    .foregroundStyle(Aurora.bad)
                    .frame(maxWidth: .infinity)
            }
        }
    }

    // MARK: about

    @ViewBuilder
    private var aboutSection: some View {
        SectionHeader(title: L("settings_about"))
        AuroraCard {
            Text(L("settings_about_version"))
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
            VSpace(6)
            Text(L("settings_about_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(10)
            Text(L("settings_about_not_title"))
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
            VSpace(4)
            Text(L("settings_about_not_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
        }
    }
}

// MARK: - Rows

private struct ToggleRow: View {
    @Environment(\.theme) private var theme
    let title: String
    let subtitle: String?
    @Binding var isOn: Bool

    var body: some View {
        Toggle(isOn: $isOn) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(AuroraFont.titleS())
                    .foregroundStyle(theme.textPrimary)
                if let subtitle {
                    Text(subtitle)
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
            }
        }
        .toggleStyle(.switch)
        .tint(theme.primary)
        .padding(.vertical, 10)
    }
}

private struct LanguageRow: View {
    @Environment(\.theme) private var theme
    let lang: AppLanguage
    let label: String
    let selected: Bool
    let onSelect: () -> Void

    var body: some View {
        Button(action: onSelect) {
            HStack {
                Text(label)
                    .font(selected ? AuroraFont.titleS() : AuroraFont.bodyM())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                if selected {
                    Image(systemName: "checkmark")
                        .foregroundStyle(theme.primary)
                }
            }
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

/// One selectable Vital Sheet scheme (label + one-line description), checkmark when active —
/// same interaction shape as LanguageRow.
private struct SchemeRow: View {
    @Environment(\.theme) private var theme
    let scheme: SheetScheme
    let label: String
    let description: String
    let selected: Bool
    let onSelect: () -> Void

    var body: some View {
        Button(action: onSelect) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(label)
                        .font(selected ? AuroraFont.titleS() : AuroraFont.bodyM())
                        .foregroundStyle(theme.textPrimary)
                    Text(description)
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer()
                if selected {
                    Image(systemName: "checkmark")
                        .foregroundStyle(theme.primary)
                }
            }
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Theme swatch (mini preview: page colour, card colour, accent dot — Android parity)

private struct ThemeSwatch: View {
    @Environment(\.theme) private var theme
    let mode: ThemeMode
    let label: String
    let selected: Bool
    let onSelect: () -> Void

    /// (page, card, accent, text) preview colours per mode, matching AuroraTheme.resolve.
    private var colors: (page: Color, card: Color, accent: Color, text: Color) {
        switch mode {
        case .aurora: return (Aurora.blossom, Aurora.cloud, Aurora.fuchsia, Aurora.ink)
        case .light: return (Color(hex: 0xFAFAFB), Aurora.cloud, Color(hex: 0xD1206F), Color(hex: 0x1B1B1F))
        case .highContrast: return (Aurora.cloud, Color(hex: 0xF2F2F2), Color(hex: 0x9E0A52), .black)
        case .dark: return (Aurora.darkBg, Aurora.darkCard, Aurora.rose, Color(hex: 0xF7E9F0))
        }
    }

    var body: some View {
        let c = colors
        Button(action: onSelect) {
            VStack(spacing: 0) {
                // Mini page with a mini card holding an accent dot, a text bar and a button pill.
                ZStack {
                    c.page
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .fill(c.card)
                        .padding(8)
                        .overlay(
                            HStack(spacing: 6) {
                                Circle().fill(c.accent).frame(width: 12, height: 12)
                                Capsule().fill(c.text.opacity(0.8)).frame(width: 40, height: 6)
                                Spacer(minLength: 0)
                                Capsule()
                                    .fill(LinearGradient(colors: [c.accent, c.accent.opacity(0.6)],
                                                         startPoint: .leading, endPoint: .trailing))
                                    .frame(width: 22, height: 10)
                            }
                            .padding(16)
                        )
                }
                .frame(height: 58)
                HStack {
                    Text(label)
                        .font(AuroraFont.label())
                        .foregroundStyle(theme.textPrimary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    Spacer(minLength: 0)
                    if selected {
                        Image(systemName: "checkmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(theme.primary)
                    }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .background(theme.cardAlt)
            }
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(selected ? theme.primary : theme.outline,
                            lineWidth: selected ? 2.5 : 1)
            )
        }
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity)
    }
}
