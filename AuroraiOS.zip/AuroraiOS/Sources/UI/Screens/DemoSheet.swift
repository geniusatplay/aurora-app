// Demo control sheet — the iOS port of ui/screens/DemoSheet.kt (activity grid, speed
// chips, live "Now:" line, start/stop, history seeding, leave-demo).

import SwiftUI

struct DemoSheet: View {
    @Environment(\.theme) private var theme
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var repo: SessionRepository
    @EnvironmentObject private var demoController: DemoController

    private var recording: Bool { pod.activeSession != nil && settings.demoMode }

    var body: some View {
        ScrollView {
            // Sections are grouped to stay under ViewBuilder's 10-child limit.
            VStack(alignment: .leading, spacing: 0) {
                Group {
                    header
                    VSpace(14)
                    if !settings.demoMode {
                        InfoBanner(text: L("demo_swap_banner"), tone: .info)
                        VSpace(12)
                    }
                }
                Group {
                    Text(L("demo_activity"))
                        .font(AuroraFont.titleS())
                        .foregroundStyle(theme.textPrimary)
                    VSpace(8)
                    activityGrid
                    Text(L(recording ? "demo_tap_switch" : "demo_tap_start"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                        .padding(.top, 8)
                }
                Group {
                    VSpace(14)
                    speedRow
                    Text(L("demo_speed_note"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                    nowLine
                }
                Group {
                    VSpace(16)
                    actionButtons
                    if let busy = demoController.busy {
                        Text(L(busy))
                            .font(AuroraFont.bodyS())
                            .foregroundStyle(theme.textSecondary)
                            .padding(.top, 6)
                    }
                    if settings.demoMode {
                        VSpace(8)
                        Button {
                            demoController.disable()
                            dismiss()
                        } label: {
                            Text(L("demo_leave")).frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 20)
            .padding(.bottom, 16)
        }
        .background(theme.card.ignoresSafeArea())
    }

    // MARK: header

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(L("common_demo"))
                    .font(AuroraFont.headlineS())
                    .foregroundStyle(theme.textPrimary)
                Text(L("demo_intro"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
            Spacer(minLength: 8)
            if recording {
                Pill(text: L("common_recording"), bg: theme.primary, fg: theme.onPrimary)
            }
        }
    }

    // MARK: activity grid

    private var activityGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)],
                  spacing: 10) {
            ForEach(DemoMode.allCases) { m in
                let selected = m == demoController.mode && settings.demoMode
                Button {
                    // Recording → live activity switch; otherwise start a night in that state.
                    if recording {
                        demoController.setMode(m)
                    } else {
                        demoController.startDemoNight(initialMode: m)
                    }
                } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 8) {
                            Text(m.emoji).font(.system(size: 18))
                            Text(L(m.titleKey))
                                .font(AuroraFont.titleS())
                                .foregroundStyle(selected ? theme.onPrimary : theme.textPrimary)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                        }
                        Text(L(m.blurbKey))
                            .font(AuroraFont.bodyS())
                            .foregroundStyle(selected ? theme.onPrimary.opacity(0.9) : theme.textSecondary)
                            .lineLimit(2)
                            .multilineTextAlignment(.leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .padding(12)
                    .frame(maxWidth: .infinity, minHeight: 84, alignment: .topLeading)
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(selected ? theme.primary : theme.cardAlt)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(selected ? theme.primary : theme.outline, lineWidth: 1)
                    )
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: speed

    private var speedRow: some View {
        HStack(spacing: 6) {
            Text(L("demo_speed"))
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
                .frame(width: 60, alignment: .leading)
            ForEach([1, 10, 30, 60], id: \.self) { s in
                let selected = demoController.speed == s
                Button { demoController.setSpeed(s) } label: {
                    Text("\(s)×")
                        .font(AuroraFont.label())
                        .foregroundStyle(selected ? theme.onInverse : theme.textPrimary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(Capsule().fill(selected ? theme.inverse : theme.cardAlt))
                }
                .buttonStyle(.plain)
            }
            Spacer(minLength: 0)
        }
    }

    // MARK: "Now:" line

    @ViewBuilder
    private var nowLine: some View {
        if settings.demoMode, pod.connectionState.isConnected, let v = pod.latestVitals {
            let hrText = v.hasHr ? L("demo_now_hr", v.hrBpm) : L("demo_now_hr_between")
            let sleepText: String = {
                switch v.sleepState {
                case .wake: return L("demo_sleep_awake")
                case .light: return L("demo_sleep_light")
                case .deep: return L("demo_sleep_deep")
                case .unknown: return L("demo_sleep_unknown")
                }
            }()
            // demo_now_line args, in en.lproj order: %1$@ hr, %2$@ skin °C, %3$@ skin RH,
            // %4$d motion, %5$@ sleep state.
            let line = L("demo_now_line",
                         hrText,
                         String(format: "%.1f", v.skinTempC),
                         String(format: "%.0f", v.skinRh),
                         v.motionIndex,
                         sleepText)
                + (v.sweatFlag != SweatFlag.none ? L("demo_now_sweating") : "")
            Text(line)
                .font(AuroraFont.label())
                .foregroundStyle(theme.isDark ? Aurora.petal : Aurora.plum)
                .padding(.top, 12)
        }
    }

    // MARK: actions

    private var actionButtons: some View {
        let uid = settings.userId.flatMap { UUID(uuidString: $0) }
        let hasCards = uid.map { !repo.nightCards(userId: $0).isEmpty } ?? false
        return HStack(spacing: 10) {
            if recording {
                Button {
                    demoController.stopDemoNight()
                } label: {
                    Text(L("demo_stop")).frame(maxWidth: .infinity).frame(height: 30)
                }
                .buttonStyle(.borderedProminent)
                .tint(theme.inverse)
                .foregroundStyle(theme.onInverse)
            } else {
                Button {
                    demoController.startDemoNight(initialMode: .sleeping)
                } label: {
                    Text(L("demo_start_night")).frame(maxWidth: .infinity).frame(height: 30)
                }
                .buttonStyle(.borderedProminent)
                .tint(theme.primary)
            }
            Button {
                demoController.seedHistory()
            } label: {
                HStack(spacing: 8) {
                    if demoController.busy != nil {
                        ProgressView().controlSize(.small)
                        Text(L("demo_working"))
                    } else {
                        Text(L(hasCards ? "demo_add_more_nights" : "demo_add_nights"))
                    }
                }
                .frame(maxWidth: .infinity)
                .frame(height: 30)
            }
            .buttonStyle(.bordered)
            .disabled(demoController.busy != nil)
        }
    }
}
