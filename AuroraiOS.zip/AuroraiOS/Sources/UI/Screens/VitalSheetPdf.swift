// One-page PDF of the Nighttime Vital Sheet — the iOS port of ui/screens/VitalSheetPdf.kt.
//
// The SAME row model the screen renders ([VitalSheetUi], strings already resolved and
// localised), drawn in the ACTIVE scheme's look (ext brief §4/§5) with
// UIGraphicsPDFRenderer, written to a temp file and shared via ShareLink (mirroring the
// NightDetail CSV export pattern). The PDF always uses the LIGHT channel colours — it is
// a printed page.

import UIKit

enum VitalSheetPdf {

    // A4 @ 72 dpi.
    private static let pageW: CGFloat = 595
    private static let pageH: CGFloat = 842
    private static let margin: CGFloat = 40

    // Print palette (fixed light ink, matching the Android PDF byte-for-byte).
    private static let ink = rgb(0x17111A)
    private static let gray = rgb(0x5A4F5C)
    private static let rule = rgb(0xD9C3CE)
    private static let cardBg = rgb(0xF7F2F5)
    private static let track = rgb(0xEFE6EB)
    private static let fuchsia = rgb(0xE8308A)
    private static let magenta = rgb(0xB3125F)

    private static func rgb(_ hex: UInt32) -> UIColor {
        UIColor(red: CGFloat((hex >> 16) & 0xFF) / 255,
                green: CGFloat((hex >> 8) & 0xFF) / 255,
                blue: CGFloat(hex & 0xFF) / 255,
                alpha: 1)
    }

    /// Data colours never vary by scheme; the PDF pins them to the light variants for print.
    private static func accent(_ id: SheetRowId) -> UIColor {
        switch id {
        case .hr: return ink                     // Aurora light seriesHeart
        case .hrv: return rgb(0x7A1F5C)          // Aurora.seriesHrv
        case .skin: return fuchsia               // Aurora.seriesSkin
        case .sweat: return rgb(0x0F8C6C)        // Aurora.seriesConductance (light)
        case .bloodFlow: return rgb(0xC97B1B)    // Aurora.seriesBloodFlow (light)
        case .oxygen: return rgb(0x7A4FBF)       // Aurora.seriesOxygen (light)
        case .movement: return rgb(0xB98BA8)     // Aurora.seriesMotion
        case .climate: return rgb(0x5B6ECF)      // Aurora.seriesAmbient
        }
    }

    // MARK: - Text helpers

    private static func attrs(_ sizePt: CGFloat, _ color: UIColor, bold: Bool = false,
                              rightAligned: Bool = false) -> [NSAttributedString.Key: Any] {
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineHeightMultiple = 1.05
        paragraph.alignment = rightAligned ? .right : .natural
        return [
            .font: UIFont.systemFont(ofSize: sizePt, weight: bold ? .bold : .regular),
            .foregroundColor: color,
            .paragraphStyle: paragraph,
        ]
    }

    private static func textHeight(_ text: String, _ a: [NSAttributedString.Key: Any], width: CGFloat) -> CGFloat {
        let bounds = (text as NSString).boundingRect(
            with: CGSize(width: max(width, 1), height: .greatestFiniteMagnitude),
            options: [.usesLineFragmentOrigin, .usesFontLeading],
            attributes: a, context: nil)
        return ceil(bounds.height)
    }

    /// Draws wrapped text at (x, y); returns the height used.
    @discardableResult
    private static func drawWrapped(_ text: String, _ a: [NSAttributedString.Key: Any],
                                    x: CGFloat, y: CGFloat, width: CGFloat) -> CGFloat {
        let h = textHeight(text, a, width: width)
        (text as NSString).draw(with: CGRect(x: x, y: y, width: max(width, 1), height: h),
                                options: [.usesLineFragmentOrigin, .usesFontLeading],
                                attributes: a, context: nil)
        return h
    }

    private static func fillRoundRect(_ ctx: CGContext, _ rect: CGRect, radius: CGFloat, color: UIColor) {
        ctx.saveGState()
        ctx.setFillColor(color.cgColor)
        UIBezierPath(roundedRect: rect, cornerRadius: radius).addClip()
        ctx.fill(rect)
        ctx.restoreGState()
    }

    private static func line(_ ctx: CGContext, from: CGPoint, to: CGPoint, color: UIColor, width: CGFloat) {
        ctx.saveGState()
        ctx.setStrokeColor(color.cgColor)
        ctx.setLineWidth(width)
        ctx.move(to: from)
        ctx.addLine(to: to)
        ctx.strokePath()
        ctx.restoreGState()
    }

    // MARK: - Shared pieces

    private static func drawTimeline(_ ctx: CGContext, _ ui: VitalSheetUi,
                                     x: CGFloat, y: CGFloat, w: CGFloat, h: CGFloat) {
        fillRoundRect(ctx, CGRect(x: x, y: y, width: w, height: h), radius: h / 2, color: track)
        let span = max(ui.lengthS, 1)
        for (a, b) in ui.bundles {
            let xa = x + CGFloat(min(max(a / span, 0), 1)) * w
            let xb = x + CGFloat(min(max(b / span, 0), 1)) * w
            fillRoundRect(ctx, CGRect(x: xa, y: y, width: max(xb - xa, 2.5), height: h),
                          radius: h / 2, color: fuchsia)
        }
        for t in ui.wakes {
            let xt = x + CGFloat(min(max(t / span, 0), 1)) * w
            line(ctx, from: CGPoint(x: xt, y: y - 4), to: CGPoint(x: xt, y: y), color: gray, width: 1)
        }
    }

    /// Header shared by the three scheme looks; returns the y after it.
    private static func drawHeader(_ ctx: CGContext, _ ui: VitalSheetUi) -> CGFloat {
        var y = margin
        let w = pageW - 2 * margin
        y += drawWrapped(ui.title.uppercased(), attrs(8.5, gray, bold: true), x: margin, y: y, width: w) + 4
        y += drawWrapped(ui.nightLabel, attrs(19, ink, bold: true), x: margin, y: y, width: w) + 6
        y += drawWrapped("\(ui.bundleCount) \(ui.bundleCountLabel) · \(ui.scoreLabel)",
                         attrs(11, magenta, bold: true), x: margin, y: y, width: w) + 4
        for chip in ui.flagChips {
            y += drawWrapped("• \(chip)", attrs(8.5, gray), x: margin, y: y, width: w) + 2
        }
        y += 8
        drawTimeline(ctx, ui, x: margin, y: y, w: w, h: 12)
        y += 12 + 14
        return y
    }

    /// Footer pinned to the bottom of the page.
    private static func drawFooter(_ ctx: CGContext, _ ui: VitalSheetUi) {
        let w = pageW - 2 * margin
        let a = attrs(7.5, gray)
        let footerH = textHeight(ui.footer, a, width: w)
        let discH = textHeight(ui.disclaimer, a, width: w)
        var y = pageH - margin - footerH - discH - 6
        y += drawWrapped(ui.footer, a, x: margin, y: y, width: w) + 6
        drawWrapped(ui.disclaimer, a, x: margin, y: y, width: w)
    }

    // MARK: - Scheme looks

    /// Scheme 1 — Aurora cards: rounded cards, 4 pt colour rail, two value columns.
    private static func drawScheme1(_ ctx: CGContext, _ ui: VitalSheetUi, yStart: CGFloat) {
        var y = yStart
        let w = pageW - 2 * margin
        for row in ui.rows {
            let verdictA = attrs(8, gray)
            let verdictH = textHeight(row.verdict, verdictA, width: w - 24)
            let cardH = 44 + verdictH
            fillRoundRect(ctx, CGRect(x: margin, y: y, width: w, height: cardH), radius: 8, color: cardBg)
            fillRoundRect(ctx, CGRect(x: margin, y: y, width: 4, height: cardH), radius: 2, color: accent(row.id))
            let xText = margin + 12
            drawWrapped(row.title, attrs(10, ink, bold: true), x: xText, y: y + 7, width: w - 24)
            let colW = (w - 24) / 2
            drawWrapped(ui.quietCol, attrs(7.5, gray), x: xText, y: y + 21, width: colW)
            drawWrapped(row.quiet, attrs(11, ink, bold: true), x: xText, y: y + 30, width: colW)
            drawWrapped(ui.eventCol, attrs(7.5, gray), x: xText + colW, y: y + 21, width: colW)
            drawWrapped(row.event, attrs(11, ink, bold: true), x: xText + colW, y: y + 30, width: colW)
            drawWrapped(row.verdict, verdictA, x: xText, y: y + 44 - 2, width: w - 24)
            y += cardH + 7
        }
    }

    /// Scheme 2 — Clinic sheet: ruled flowsheet, dense rows, one accent for event values.
    private static func drawScheme2(_ ctx: CGContext, _ ui: VitalSheetUi, yStart: CGFloat) {
        var y = yStart
        let w = pageW - 2 * margin
        let colQuietX = margin + w - 190
        let colEventX = margin + w - 90
        // Small-caps column headers, right-aligned over their columns.
        drawWrapped(ui.quietCol.uppercased(), attrs(7.5, gray, bold: true, rightAligned: true),
                    x: colQuietX, y: y, width: 90)
        drawWrapped(ui.eventCol.uppercased(), attrs(7.5, fuchsia, bold: true, rightAligned: true),
                    x: colEventX, y: y, width: 90)
        y += 13
        line(ctx, from: CGPoint(x: margin, y: y), to: CGPoint(x: margin + w, y: y), color: ink, width: 1.2)
        y += 4
        for row in ui.rows {
            let verdictA = attrs(7.5, gray)
            let titleW = w - 200
            let verdictH = textHeight(row.verdict, verdictA, width: titleW)
            let rowH = max(26, 13 + verdictH + 5)
            drawWrapped(row.title, attrs(9.5, ink, bold: true), x: margin, y: y + 3, width: titleW)
            drawWrapped(row.verdict, verdictA, x: margin, y: y + 15, width: titleW)
            drawWrapped(row.quiet, attrs(10, ink, rightAligned: true), x: colQuietX, y: y + 5, width: 90)
            let eventText = row.event + (row.delta.map { "  \($0)" } ?? "")
            drawWrapped(eventText, attrs(10, fuchsia, bold: true, rightAligned: true),
                        x: colEventX, y: y + 5, width: 90)
            y += rowH
            line(ctx, from: CGPoint(x: margin, y: y), to: CGPoint(x: margin + w, y: y), color: rule, width: 0.75)
            y += 3
        }
    }

    /// Scheme 3 — Timeline focus: a taller timeline, then a 2-per-row grid of big stat tiles.
    private static func drawScheme3(_ ctx: CGContext, _ ui: VitalSheetUi, yStart: CGFloat) {
        var y = yStart
        let w = pageW - 2 * margin
        // A second, taller timeline band is this scheme's lead visual.
        drawTimeline(ctx, ui, x: margin, y: y, w: w, h: 22)
        y += 22 + 16
        let tileW = (w - 10) / 2
        var col = 0
        var rowTop = y
        var rowMaxH: CGFloat = 0
        for row in ui.rows {
            let x = margin + CGFloat(col) * (tileW + 10)
            let verdictA = attrs(7.5, gray)
            let innerW = tileW - 20
            let verdictH = textHeight(row.verdict, verdictA, width: innerW)
            let tileH = 58 + verdictH
            fillRoundRect(ctx, CGRect(x: x, y: rowTop, width: tileW, height: tileH), radius: 10, color: cardBg)
            ctx.setFillColor(accent(row.id).cgColor)
            ctx.fillEllipse(in: CGRect(x: x + 14 - 3.5, y: rowTop + 13 - 3.5, width: 7, height: 7))
            drawWrapped(row.title, attrs(8.5, gray, bold: true), x: x + 22, y: rowTop + 8, width: innerW - 12)
            let big = row.event != "—" ? row.event : row.quiet
            drawWrapped(big, attrs(15, ink, bold: true), x: x + 10, y: rowTop + 24, width: innerW)
            drawWrapped("\(ui.quietCol): \(row.quiet)", attrs(7.5, gray), x: x + 10, y: rowTop + 44, width: innerW)
            drawWrapped(row.verdict, verdictA, x: x + 10, y: rowTop + 55, width: innerW)
            rowMaxH = max(rowMaxH, tileH)
            col += 1
            if col == 2 {
                col = 0
                rowTop += rowMaxH + 8
                rowMaxH = 0
            }
        }
    }

    // MARK: - Entry point

    /// Renders the sheet as a one-page PDF in the active scheme's look and returns the
    /// temp-file URL for ShareLink (the CSV export's share pattern). Returns nil only if
    /// the file cannot be written.
    static func render(ui: VitalSheetUi, scheme: SheetScheme, sessionId: UUID) -> URL? {
        let bounds = CGRect(x: 0, y: 0, width: pageW, height: pageH)
        let renderer = UIGraphicsPDFRenderer(bounds: bounds)
        let data = renderer.pdfData { pdfContext in
            pdfContext.beginPage()
            let ctx = pdfContext.cgContext
            ctx.setFillColor(UIColor.white.cgColor)
            ctx.fill(bounds)
            let yAfterHeader = drawHeader(ctx, ui)
            switch scheme {
            case .scheme1: drawScheme1(ctx, ui, yStart: yAfterHeader)
            case .scheme2: drawScheme2(ctx, ui, yStart: yAfterHeader)
            case .scheme3: drawScheme3(ctx, ui, yStart: yAfterHeader)
            }
            drawFooter(ctx, ui)
        }
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("aurora_vital_sheet_\(sessionId.uuidString).pdf")
        do {
            try data.write(to: url, options: .atomic)
            return url
        } catch {
            return nil
        }
    }
}
