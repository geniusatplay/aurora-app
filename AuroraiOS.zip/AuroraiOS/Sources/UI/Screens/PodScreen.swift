// Pod — the iOS port of ui/screens/PodScreen.kt (connection, device info, tonight's
// session, replay progress, the app-side slot inventory and maintenance commands).
//
// iOS note: unlike Android there is no runtime permission launcher — CoreBluetooth shows
// the system Bluetooth permission prompt automatically on first CBCentralManager use, and
// a denial surfaces as ConnectionState.off, for which we keep the InfoBanner hint.

import SwiftUI

struct PodScreen: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var repo: SessionRepository

    let onOpenNight: (UUID) -> Void

    @State private var showFormat = false
    @State private var formatText = ""

    var body: some View {
        let uid = settings.userId.flatMap { UUID(uuidString: $0) }
        let cards = uid.map { repo.nightCards(userId: $0) } ?? []
        let slots = repo.slots()

        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) {
                header
                connectionCard
                if pod.connectionState.isConnected { deviceCard }
                tonightCard
                if pod.replayStatus.isActive { replayCard }
                slotSection(slots: slots, cards: cards)
                maintenanceSection
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 16)
        }
        .background(theme.background.ignoresSafeArea())
        .alert(L("pod_erase_title"), isPresented: $showFormat) {
            TextField(L("pod_erase_placeholder"), text: $formatText)
            Button(L("pod_erase_confirm"), role: .destructive) {
                // Keep the literal check even here: alert button enablement is not
                // reliably re-evaluated while the dialog is up (Android gated the same way).
                if formatText == "ERASE" { pod.formatFlash() }
            }
            Button(L("common_cancel"), role: .cancel) {}
        } message: {
            Text(L("pod_erase_body"))
        }
    }

    // MARK: header

    private var header: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(L("pod_title"))
                .font(AuroraFont.headlineL())
                .foregroundStyle(theme.textPrimary)
            Text(L(settings.demoMode ? "pod_subtitle_demo" : "pod_subtitle_hw"))
                .font(AuroraFont.bodyM())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.top, 8)
    }

    // MARK: connection

    private var connectionCard: some View {
        let conn = pod.connectionState
        let scanning: Bool = { if case .scanning = conn { return true }; return false }()
        let connecting: Bool = { if case .connecting = conn { return true }; return false }()

        return AuroraCard {
            HStack(spacing: 10) {
                Image(systemName: scanning ? "antenna.radiowaves.left.and.right" : "dot.radiowaves.left.and.right")
                    .font(.system(size: 20))
                    .foregroundStyle(conn.isConnected ? theme.primary : theme.textSecondary)
                VStack(alignment: .leading, spacing: 2) {
                    Text(connectionTitle(conn))
                        .font(AuroraFont.title())
                        .foregroundStyle(theme.textPrimary)
                    if case let .error(key, arg) = conn {
                        Text(Self.errorText(key: key, arg: arg))
                            .font(AuroraFont.bodyS())
                            .foregroundStyle(Aurora.bad)
                    }
                    if conn.isConnected {
                        Text(L(pod.timeSynced ? "pod_clock_synced" : "pod_clock_syncing"))
                            .font(AuroraFont.bodyS())
                            .foregroundStyle(theme.textSecondary)
                    }
                }
                Spacer(minLength: 8)
                if scanning || connecting {
                    ProgressView().tint(theme.primary)
                }
            }
            VSpace(12)
            if conn.isConnected {
                Button(L("pod_disconnect")) { pod.disconnect() }
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)
            } else {
                Button(L("pod_find")) { pod.startScan() }
                    .buttonStyle(.borderedProminent)
                    .tint(theme.primary)
                    .frame(maxWidth: .infinity)
                    .disabled(scanning)
            }
            if !pod.scanResults.isEmpty && !conn.isConnected {
                VSpace(10)
                ForEach(pod.scanResults) { p in
                    HStack {
                        VStack(alignment: .leading, spacing: 1) {
                            Text(p.name)
                                .font(AuroraFont.titleS())
                                .foregroundStyle(theme.textPrimary)
                            Text(L("pod_scan_detail", p.id, p.rssi))
                                .font(AuroraFont.bodyS())
                                .foregroundStyle(theme.textSecondary)
                        }
                        Spacer()
                        Button(L("common_connect")) { pod.connect(id: p.id) }
                            .buttonStyle(.borderedProminent)
                            .tint(theme.inverse)
                            .foregroundStyle(theme.onInverse)
                    }
                    .padding(.vertical, 4)
                }
            }
            if case .off = conn {
                VSpace(8)
                InfoBanner(text: L("pod_bt_off_hint"), tone: .warning)
            }
        }
    }

    private func connectionTitle(_ conn: ConnectionState) -> String {
        switch conn {
        case .connected(let name, _): return L("pod_conn_connected", name)
        case .connecting(let name): return L("pod_conn_connecting", name)
        case .scanning: return L("pod_conn_scanning")
        case .off: return L("pod_conn_off")
        case .error: return L("pod_conn_error")
        case .disconnected: return L("pod_conn_disconnected")
        }
    }

    /// app_err_scan_failed / app_err_connection_lost format their arg as %d — coerce a
    /// numeric string back to Int so String(format:) fills the placeholder correctly.
    static func errorText(key: String, arg: String?) -> String {
        guard let arg else { return L(key) }
        if let n = Int(arg) { return L(key, n) }
        return L(key, arg)
    }

    // MARK: device info

    private var deviceCard: some View {
        let info = pod.deviceInfo
        return AuroraCard {
            Text(L("pod_device"))
                .font(AuroraFont.title())
                .foregroundStyle(theme.textPrimary)
            VSpace(10)
            HStack(alignment: .top, spacing: 16) {
                LabeledValue(label: L("pod_model"), value: nonBlank(info?.model))
                LabeledValue(label: L("pod_firmware"), value: nonBlank(info?.softwareRevision))
                LabeledValue(label: L("pod_battery"), value: pod.batteryPct.map { "\($0)%" } ?? "—")
            }
            VSpace(6)
            Text(info?.hardwareRevision ?? "")
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            if info?.firmwareMismatch == true {
                VSpace(8)
                InfoBanner(text: L("pod_fw_mismatch", info?.softwareRevision ?? "", AuroraUUID.builtAgainstFirmware),
                           tone: .warning)
            }
        }
    }

    private func nonBlank(_ s: String?) -> String {
        guard let s, !s.isEmpty else { return "—" }
        return s
    }

    // MARK: tonight

    private var tonightCard: some View {
        let active = pod.activeSession
        let connected = pod.connectionState.isConnected
        return AuroraCard {
            HStack {
                Text(L("pod_tonight"))
                    .font(AuroraFont.title())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                if active != nil {
                    Pill(text: L("common_recording"), bg: theme.primary, fg: theme.onPrimary)
                }
            }
            VSpace(6)
            Text(active.map { L("pod_recording_since", Fmt.clock($0.startedAt, settings)) }
                    ?? L("pod_not_recording_hint"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(12)
            if active == nil {
                Button {
                    pod.startSession()
                } label: {
                    Text(L("pod_start")).frame(maxWidth: .infinity).frame(height: 32)
                }
                .buttonStyle(.borderedProminent)
                .tint(theme.primary)
                .disabled(!connected)
            } else {
                Button {
                    pod.stopSession()
                } label: {
                    Text(L("pod_stop")).frame(maxWidth: .infinity).frame(height: 32)
                }
                .buttonStyle(.borderedProminent)
                .tint(theme.inverse)
                .foregroundStyle(theme.onInverse)
                .disabled(!connected)
                if !connected {
                    VSpace(8)
                    InfoBanner(text: L("pod_reconnect_to_stop"), tone: .info)
                }
            }
        }
    }

    // MARK: replay progress

    private var replayCard: some View {
        AuroraCard {
            Text(L("pod_downloading"))
                .font(AuroraFont.title())
                .foregroundStyle(theme.textPrimary)
            VSpace(8)
            switch pod.replayStatus {
            case .downloading(let slot, let percent, _, _):
                ProgressView(value: Double(percent) / 100).tint(theme.primary)
                Text(L("pod_download_progress", percent, slot))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textPrimary)
            case .waitingForHeader(let slot):
                ProgressView().progressViewStyle(.linear).tint(theme.primary)
                Text(L("pod_waiting_slot", slot))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textPrimary)
            default:
                EmptyView()
            }
            Button(L("common_cancel")) { pod.cancelDownload() }
                .padding(.top, 4)
        }
    }

    // MARK: slot inventory (spec §15.1 — the app's own record of what the pod holds)

    @ViewBuilder
    private func slotSection(slots: [PodSlotModel], cards: [(SessionModel, SummaryModel?)]) -> some View {
        SectionHeader(title: L("pod_nights_title"), subtitle: L("pod_nights_sub", slots.count))
        if slots.count >= 12 {
            InfoBanner(text: L("pod_nearly_full"), tone: .warning)
        }
        if slots.isEmpty {
            AuroraCard {
                Text(L("pod_no_nights"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
        ForEach(slots, id: \.slot) { s in
            slotRow(s, cards: cards)
        }
    }

    private func slotRow(_ s: PodSlotModel, cards: [(SessionModel, SummaryModel?)]) -> some View {
        let card = cards.first { $0.0.id == s.sessionId }
        let connected = pod.connectionState.isConnected
        return AuroraCard(padding: 14, onTap: { if let id = s.sessionId { onOpenNight(id) } }) {
            HStack(spacing: 10) {
                Pill(text: L("pod_slot", s.slot))
                VStack(alignment: .leading, spacing: 1) {
                    Text(card.map { Fmt.nightLabel($0.0.startedAt) } ?? L("pod_unknown_night"))
                        .font(AuroraFont.titleS())
                        .foregroundStyle(theme.textPrimary)
                    Text(downloadStateText(card?.0.replayState))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer(minLength: 8)
                if let card, card.0.replayState != .complete, connected, !pod.replayStatus.isActive {
                    Button(L("common_download")) {
                        pod.downloadNight(sessionId: card.0.id, slot: s.slot)
                    }
                    .font(AuroraFont.label())
                }
            }
        }
    }

    private func downloadStateText(_ state: ReplayState?) -> String {
        switch state {
        case .none? : return L("pod_download_none")
        case .partial?: return L("pod_download_partial")
        case .complete?: return L("pod_download_complete")
        case nil: return ""
        }
    }

    // MARK: maintenance

    @ViewBuilder
    private var maintenanceSection: some View {
        SectionHeader(title: L("pod_maintenance"))
        AuroraCard {
            let connected = pod.connectionState.isConnected
            HStack(spacing: 10) {
                Button(L("pod_buzz_test")) { pod.hapticTest() }
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)
                    .disabled(!connected)
                Button(L("pod_batt_relearn")) { pod.fuelGaugeRelearn() }
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)
                    .disabled(!connected)
            }
            VSpace(8)
            Text(L("pod_maintenance_note"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(12)
            Button {
                formatText = ""
                showFormat = true
            } label: {
                Text(L("pod_erase_all")).foregroundStyle(Aurora.bad)
            }
            .disabled(!connected)
        }
    }
}
