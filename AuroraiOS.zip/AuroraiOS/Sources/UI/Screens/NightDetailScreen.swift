// Night detail — the iOS port of ui/screens/NightDetailScreen.kt (hero, replay card,
// stacked chart panels with one shared scrub, sweat events, event log, diagnostics).

import SwiftUI

// MARK: - ActivityKind display helpers (chart marker colours, same mapping as Android)

extension ActivityKind {
    var markerColor: Color {
        switch self {
        case .nightFlash: return Aurora.fuchsia
        case .nightSweats: return Aurora.magenta
        case .heavyExercise: return Aurora.plum
        case .lightExercise: return Aurora.seriesAmbient
        case .sleeping: return Aurora.sleepDeep
        case .up: return Aurora.seriesMotion
        case .sessionStart, .sessionEnd: return Aurora.ash
        }
    }
}

extension EventSource {
    /// night_source_* localization key ("demo" / "you" / "pod").
    var labelKey: String {
        switch self {
        case .demo: return "night_source_demo"
        case .user: return "night_source_user"
        case .pod: return "night_source_pod"
        }
    }
}

// MARK: - Screen

struct NightDetailScreen: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var repo: SessionRepository

    let sessionId: UUID
    let onBack: () -> Void
    /// Jump to the Pod tab (the replay card's "Connect" action). Optional so previews work.
    var onOpenPod: () -> Void = {}
    /// Push this night's Vital Sheet (ext brief §4). Optional so previews work.
    var onOpenVitalSheet: () -> Void = {}

    @State private var bundle: NightBundle?
    @State private var scrub: Double? = nil
    @State private var confirmDelete = false
    @State private var csv = ""
    @State private var csvEpochCount = -1
    /// Cached in state: every scrub-drag frame re-evaluates body, and re-running
    /// detectBundles (rolling medians over the whole night ×3 channels) plus the
    /// records mapping per frame makes the crosshair visibly janky on full nights.
    @State private var records: [LogRecord] = []
    @State private var bundles: [FlashBundle] = []
    /// The real pod holds only its most recent session: the newest finished BLE night
    /// is the only one its log can be downloaded into (refreshed in reload()).
    @State private var latestBleNightId: UUID?

    var body: some View {
        ZStack {
            theme.background.ignoresSafeArea()
            if let b = bundle {
                content(b)
            } else {
                EmptyState(title: L("common_loading"), body: "")
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) { titleStack }
            ToolbarItem(placement: .topBarTrailing) {
                ShareLink(item: csv, subject: Text(L("night_export_subject"))) {
                    Image(systemName: "square.and.arrow.up")
                }
                .disabled(csv.isEmpty)
                .accessibilityLabel(L("night_cd_share_csv"))
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button { confirmDelete = true } label: { Image(systemName: "trash") }
                    .accessibilityLabel(L("night_cd_delete_night"))
            }
        }
        .alert(L("night_delete_title"), isPresented: $confirmDelete) {
            Button(L("common_delete"), role: .destructive) {
                repo.deleteSession(id: sessionId)
                onBack()
            }
            Button(L("common_keep"), role: .cancel) {}
        } message: {
            Text(L("night_delete_text"))
        }
        .onAppear { reload() }
        // Re-fetch whenever the repository mutates (live epochs, replay finishing, …).
        .onReceive(repo.$revision) { _ in reload() }
    }

    private var isLive: Bool { pod.activeSession?.id == sessionId }

    private func reload() {
        let b = repo.nightBundle(sessionId: sessionId)
        bundle = b
        // CSV is only rebuilt when the epoch count changes — exporting is O(n) and the
        // revision counter ticks on every provisional epoch while live.
        if let b, b.epochs.count != csvEpochCount {
            csvEpochCount = b.epochs.count
            records = b.epochs.map { $0.toRecord() }
            bundles = NightAnalytics.detectBundles(records)
            csv = repo.exportCsv(sessionId: sessionId)
        }
        if let uid = UUID(uuidString: settings.userId ?? "") {
            latestBleNightId = repo.nightCards(userId: uid)
                .first(where: { $0.0.source == .ble && $0.0.endedAtEpochMs != nil })?.0.id
        } else {
            latestBleNightId = nil
        }
    }

    // MARK: title

    private var titleStack: some View {
        VStack(spacing: 0) {
            Text(bundle.map { Fmt.nightLabel($0.session.startedAt) } ?? L("night_title_fallback"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            if let b = bundle {
                let end = b.session.endedAt.map { Fmt.clock($0, settings) } ?? L("night_recording_lower")
                Text(L("night_time_range", Fmt.clock(b.session.startedAt, settings), end))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }

    // MARK: content

    private func content(_ b: NightBundle) -> some View {
        // Session-relative axis, bands, markers and data gates — shared with the custom-page
        // `night_timeline` section (NightChartContext).
        let ctx = NightChartContext(bundle: b, records: records, bundles: bundles,
                                    settings: settings, caps: pod.capabilities)
        let xFormat = ctx.xFormat
        // Skin baseline = median of the first 30 min; the hero's "skin rise" number.
        let baselineSamples = b.epochs.filter { $0.tS < 1800 }.map { $0.skinTempX100 }.sorted()
        let baseline = baselineSamples.isEmpty ? nil : baselineSamples[baselineSamples.count / 2]
        let maxRise = baseline.flatMap { bl in b.epochs.map { Double($0.skinTempX100 - bl) / 100 }.max() }
        // Gate on the night's DATA (a hardware night stays one even in demo mode).
        let gates = ctx.gates
        let hwLog = gates.hwNight || (b.session.source == .ble && isHardwarePod(pod.capabilities, pod.deviceInfo))
        let canDownload = !hwLog || latestBleNightId == sessionId

        return ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) {
                NightHero(bundle: b, maxRise: maxRise, settings: settings, isLive: isLive, show: settings.showRanges,
                          hw: gates.hwNight, noSleep: gates.noSleep)

                // Nighttime Vital Sheet entry point (ext brief §4)
                if !b.epochs.isEmpty {
                    Button(action: onOpenVitalSheet) {
                        Text(L("vs_open"))
                            .font(AuroraFont.title())
                            .foregroundStyle(theme.onPrimary)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(Capsule().fill(theme.primary))
                    }
                    .buttonStyle(.plain)
                }

                if !isLive {
                    ReplayCard(bundle: b,
                               replay: pod.replayStatus,
                               connected: pod.connectionState.isConnected,
                               hwLog: hwLog,
                               canDownload: canDownload,
                               onDownload: { slot in pod.downloadNight(sessionId: sessionId, slot: slot) },
                               onCancel: { pod.cancelDownload() },
                               onOpenPod: onOpenPod)
                }

                if b.epochs.isEmpty {
                    AuroraCard {
                        EmptyState(title: L("night_no_detail_title"),
                                   body: L(isLive ? "night_no_detail_live" : "night_no_detail_offline"))
                    }
                } else {
                    NightChartsCard(bundle: b, records: records, ctx: ctx, scrub: $scrub)
                }

                if !b.sweat.isEmpty {
                    NightSweatEventsSection(bundle: b, provisional: gates.hwNight, xFormat: xFormat)
                }

                if !b.events.isEmpty {
                    SectionHeader(title: L("night_event_log_title"), subtitle: L("night_event_log_sub"))
                    ForEach(b.events, id: \.id) { e in
                        EventRow(event: e, xFormat: xFormat)
                    }
                }

                DiagnosticsCard(bundle: b)
                Disclaimer()
            }
            .padding(.horizontal, 16)
            .padding(.top, 4)
            .padding(.bottom, 24)
        }
    }
}

// MARK: - Shared chart inputs (NightDetail + custom-page night_timeline)

/// Everything the stacked night charts need besides the data itself: the session-relative
/// axis, the shaded spans (flash bundles, else sweat events), activity markers, the wall-
/// clock tick formatter and the data-presence gates.
struct NightChartContext {
    let x0: Double
    let x1: Double
    let bands: [(Double, Double)]
    let markers: [(t: Double, color: Color, label: String)]
    let xFormat: (Double) -> String
    let gates: NightGates

    init(bundle b: NightBundle, records: [LogRecord], bundles: [FlashBundle],
         settings: AppSettings, caps: PodCapabilities) {
        // Session-relative seconds → wall clock, e.g. "23:41" (Android's xFormat).
        let start = b.session.startedAt
        xFormat = { t in Fmt.clock(start.addingTimeInterval(t), settings) }
        let lenS = max(b.summary?.sessionLenS ?? b.epochs.last.map { $0.tS + 30 } ?? 0, 600)
        x0 = 0.0
        x1 = Double(lenS)
        let sweatBands = b.sweat.map { (Double($0.startS), Double($0.endS)) }
        // Flash bundles (ext brief §3): their spans shade ALL panels at 0.10-alpha fuchsia (§6).
        let bundleBands = bundles.map { (Double($0.startTs), Double($0.endTs)) }
        bands = bundleBands.isEmpty ? sweatBands : bundleBands
        markers = b.events
            .filter { $0.kind != .sessionStart && $0.kind != .sessionEnd }
            .map { (Double($0.tS), $0.kind.markerColor, L($0.kind.labelKey)) }
        gates = NightGates(
            hwNight: isHardwareNight(records),
            showAmbient: hasAmbientData(records),
            noSleep: nightLacksSleep(records, summary: b.summary),
            noMotion: nightLacksMotion(records, summary: b.summary),
            hrvRelative: isHardwareNight(records) || caps.hrvRelativeOnly)
    }
}

// MARK: - Chart card (stacked panels, one shared scrub)

struct NightChartsCard: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    let bundle: NightBundle
    let records: [LogRecord]
    let ctx: NightChartContext
    @Binding var scrub: Double?

    var body: some View {
        chartCard(bundle, records: records, gates: ctx.gates, x0: ctx.x0, x1: ctx.x1,
                  bands: ctx.bands, markers: ctx.markers, xFormat: ctx.xFormat)
    }

    private func chartCard(_ b: NightBundle, records: [LogRecord], gates: NightGates, x0: Double, x1: Double,
                           bands: [(Double, Double)],
                           markers: [(t: Double, color: Color, label: String)],
                           xFormat: @escaping (Double) -> String) -> some View {
        let show = settings.showRanges
        let epochs = b.epochs
        // Extended-sensor panels appear only when the night carries valid v2 data (§6);
        // the x-axis moves to whichever panel is last in the stack.
        let hasEda = records.contains { $0.edaUs != nil }
        let hasPi = records.contains { $0.perfusionPct != nil }
        let hasSpo2 = records.contains { $0.spo2Pct != nil }
        let hasExt = hasEda || hasPi || hasSpo2
        // Room series only when the records carry a real room reading (not the hardware sentinel).
        var tempSeries: [(name: String, color: Color, points: [TimePoint], area: Bool)] = [
            (name: L("night_series_skin"), color: Aurora.seriesSkin,
             points: epochs.map { TimePoint(t: Double($0.tS), v: settings.toDisplayTemp(Double($0.skinTempX100) / 100)) },
             area: false),
        ]
        if gates.showAmbient {
            tempSeries.append((name: L("night_series_room"), color: Aurora.seriesAmbient,
                               points: epochs.filter { HwAdapter.hasAmbient($0.ambTempX100) }
                                   .map { TimePoint(t: Double($0.tS), v: settings.toDisplayTemp(Double($0.ambTempX100) / 100)) },
                               area: false))
        }
        let temps = tempSeries
        let hw = gates.hwNight
        // Grouped in threes: ViewBuilder tops out at 10 direct children and this card has 14.
        return AuroraCard(padding: 12, spacing: 0) {
            Group {
                SectionHeader(title: L("night_charts_title"), subtitle: L("night_charts_sub"))

                PanelTitle(title: gates.showAmbient ? L("night_panel_temp") : L("vs_row_skin"), sub: settings.tempUnit)
                LinePanel(
                series: temps,
                x0: x0, x1: x1, height: 160,
                unit: settings.tempUnit,
                bands: bands, bandColor: BundleBandColor, markers: markers,
                guides: guides(Ranges.skinTemp, show) { settings.toDisplayTemp($0) },
                scrub: $scrub, xFormat: xFormat
            )
            }

            Group {
            // Hardware nights: dah is the rise of skin absolute humidity over the glove's own
            // baseline (no room sensor), so it can dip below zero and the room-based guides don't apply.
            PanelTitle(title: hw ? L("hw_night_moisture_title") : L("night_panel_sweat"),
                       sub: hw ? L("hw_night_moisture_sub") : L("night_panel_sweat_sub"))
            LinePanel(
                series: [
                    (name: L("night_series_sweat"), color: Aurora.seriesSweat,
                     points: epochs.map { TimePoint(t: Double($0.tS), v: Double($0.dahX100) / 100) },
                     area: true),
                ],
                x0: x0, x1: x1, height: 140,
                unit: " g/m³",
                decimals: hw ? 2 : 1,
                bands: bands, bandColor: BundleBandColor, markers: markers,
                guides: hw ? nil : guides(Ranges.sweat, show),
                scrub: $scrub, xFormat: xFormat
            )

            // No sleep staging / no accelerometer → no hypnogram, no movement panel (not an empty chart).
            if !gates.noSleep {
                PanelTitle(title: L("night_panel_sleep"), sub: L("night_panel_sleep_sub"))
                HypnogramPanel(
                    states: epochs.map { (t: Double($0.tS), state: SleepState.from($0.sleepState)) },
                    x0: x0, x1: x1, height: 96,
                    bands: bands, bandColor: BundleBandColor,
                    scrub: $scrub, xFormat: xFormat
                )
            }
            }

            Group {
            if !gates.noMotion {
                PanelTitle(title: L("night_panel_movement"), sub: L("night_panel_movement_sub"))
                MotionPanel(
                    points: epochs.map { TimePoint(t: Double($0.tS), v: Double($0.motionIndex)) },
                    x0: x0, x1: x1, height: 90,
                    bands: bands, bandColor: BundleBandColor,
                    guides: guides(Ranges.movement, show),
                    scrub: $scrub, xFormat: xFormat
                )
            }

            PanelTitle(title: L("night_panel_hr"), sub: hw ? L("hw_night_hr_sub") : L("night_panel_hr_sub"))
            DotPanel(
                name: L("night_series_hr"),
                points: epochs
                    .filter { $0.hrBpm > 0 && QualityBand.of($0.hrQuality) != .hide }
                    .map { (t: Double($0.tS), v: Double($0.hrBpm), valid: QualityBand.of($0.hrQuality) == .normal) },
                color: theme.seriesHeart,
                x0: x0, x1: x1, height: 120,
                unit: " bpm",
                bands: bands, bandColor: BundleBandColor,
                guides: guides(Ranges.sleepHeartRate, show),
                scrub: $scrub, xFormat: xFormat
            )
            }

            Group {
            PanelTitle(title: L("night_panel_rmssd"), sub: L("night_panel_rmssd_sub"))
            if gates.hrvRelative {
                // Quantisation-limited HRV (20 ms at 50 Hz): relative trend only, no reference guides.
                Text(L("hw_hrv_relative_note"))
                    .font(AuroraFont.labelS())
                    .foregroundStyle(theme.textSecondary)
                    .padding(.bottom, 2)
            }
            DotPanel(
                name: L("night_series_rmssd"),
                points: b.hrv.map { (t: Double($0.windowEndS), v: Double($0.rmssdX10) / 10, valid: $0.isValid) },
                color: Aurora.seriesHrv,
                x0: x0, x1: x1, height: 120,
                unit: " ms",
                connect: true,
                bands: bands, bandColor: BundleBandColor,
                guides: gates.hrvRelative ? nil : guides(Ranges.rmssd, show),
                scrub: $scrub, xFormat: xFormat,
                showXAxis: !hasExt
            )
            }

            // Extended-sensor panels (ext brief §6) — skipped silently when the night has
            // no valid v2 data for a channel.
            Group {
            if hasEda {
                PanelTitle(title: L("ext_conductance"), sub: L("ext_panel_conductance_sub"))
                ConductancePanel(
                    name: L("ext_series_conductance"),
                    points: records.compactMap { r in r.edaUs.map { TimePoint(t: Double(r.tS), v: $0) } },
                    x0: x0, x1: x1,
                    bands: bands,
                    guides: extGuides(show, lowMax: ExtGuideBands.conductanceLowMax,
                                      highMin: ExtGuideBands.conductanceHighMin),
                    scrub: $scrub, xFormat: xFormat,
                    showXAxis: !hasPi && !hasSpo2
                )
            }
            if hasPi {
                PanelTitle(title: L("ext_bloodflow"), sub: L("ext_panel_bloodflow_sub"))
                BloodFlowPanel(
                    name: L("ext_series_bloodflow"),
                    points: records.compactMap { r in r.perfusionPct.map { TimePoint(t: Double(r.tS), v: $0) } },
                    x0: x0, x1: x1,
                    bands: bands,
                    guides: extGuides(show, lowMax: ExtGuideBands.bloodFlowLowMax,
                                      highMin: ExtGuideBands.bloodFlowHighMin),
                    scrub: $scrub, xFormat: xFormat,
                    showXAxis: !hasSpo2
                )
            }
            if hasSpo2 {
                PanelTitle(title: L("ext_oxygen"), sub: L("ext_panel_oxygen_sub"))
                OxygenPanel(
                    name: L("ext_series_oxygen"),
                    points: records.compactMap { r in r.spo2Pct.map { TimePoint(t: Double(r.tS), v: $0) } },
                    x0: x0, x1: x1,
                    bands: bands,
                    // Hardware nights: uncalibrated estimate — no guide bands.
                    guides: extGuides(show && !gates.hwNight, lowMax: ExtGuideBands.oxygenLowMax,
                                      highMin: ExtGuideBands.oxygenHighMin, higherIsBetter: true),
                    scrub: $scrub, xFormat: xFormat,
                    showXAxis: true
                )
            }

            MarkerLegend(markers: markers)
            }
        }
    }

    /// Range guides only when the settings toggle is on; `transform` converts the
    /// thresholds into display units (°F for the temperature panel).
    private func guides(_ r: RangeGuide, _ show: Bool,
                        transform: (Double) -> Double = { $0 }) -> GuideSpec? {
        guard show else { return nil }
        return GuideSpec(lowMax: transform(r.lowMax), highMin: transform(r.highMin),
                         higherIsBetter: r.higherIsBetter)
    }
}

// MARK: - Sweat events

/// "Sweat events" header + numbered list of one night's events (NightDetail and the
/// custom-page `sweat_events` section).
struct NightSweatEventsSection: View {
    @Environment(\.theme) private var theme
    let bundle: NightBundle
    let provisional: Bool
    let xFormat: (Double) -> String

    var body: some View {
        let b = bundle
        let longest = b.sweat.map { $0.durationS }.max() ?? 0
        // Sweat events from the real pod are provisional (flush detection not yet validated).
        let sub = L("night_sweat_events_sub", b.sweat.count, Fmt.durationShort(longest))
            + (provisional ? " · " + L("hw_provisional") : "")
        Group {
            SectionHeader(title: L("night_sweat_events_title"), subtitle: sub)
            AuroraCard(padding: 8) {
                // Indices, not enumerated(): key paths cannot address tuple elements.
                ForEach(b.sweat.indices, id: \.self) { i in
                    let e = b.sweat[i]
                    HStack(spacing: 10) {
                        Pill(text: "\(i + 1)")
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L("night_sweat_row_range", xFormat(Double(e.startS)), xFormat(Double(e.endS))))
                                .font(AuroraFont.titleS())
                                .foregroundStyle(theme.textPrimary)
                            Text(L("night_sweat_row_detail", Fmt.durationShort(e.durationS), Fmt.dah(e.peakDah)))
                                .font(AuroraFont.bodyS())
                                .foregroundStyle(theme.textSecondary)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                }
            }
        }
    }
}

// MARK: - Panel title

private struct PanelTitle: View {
    @Environment(\.theme) private var theme
    let title: String
    let sub: String

    var body: some View {
        HStack(spacing: 8) {
            Text(title)
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
            Text(sub)
                .font(AuroraFont.labelS())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.top, 10)
        .padding(.bottom, 2)
    }
}

// MARK: - Data-presence gates for one stored night

/// Which panels a stored night can show, decided from its DATA (HardwareUi.swift).
struct NightGates {
    /// Recorded on the real glove (no room reading in any record).
    var hwNight: Bool
    /// At least one record carries a real room temperature.
    var showAmbient: Bool
    /// No sleep staging → no hypnogram / sleep ring.
    var noSleep: Bool
    /// No staging and no movement → no movement panel.
    var noMotion: Bool
    /// HRV is quantisation-limited: relative trend only, no guides.
    var hrvRelative: Bool
}

// MARK: - Hero

private struct NightHero: View {
    let bundle: NightBundle
    let maxRise: Double?
    let settings: AppSettings
    let isLive: Bool
    let show: Bool
    var hw: Bool = false
    var noSleep: Bool = false

    var body: some View {
        let s = bundle.summary
        let sweatCount = s?.sweatEvents ?? bundle.sweat.count
        let peak = Double(s?.peakDahX100 ?? bundle.epochs.map { $0.dahX100 }.max() ?? 0) / 100

        HeroCard {
            HStack {
                Pill(text: L(isLive ? "common_recording" : "night_summary_pill"),
                     bg: Color.white.opacity(0.22), fg: .white)
                Spacer()
                if bundle.session.source == .demo {
                    Pill(text: L("night_demo_pill"), bg: Color.white.opacity(0.22), fg: .white)
                }
            }
            VSpace(10)
            HStack(alignment: .bottom) {
                Text("\(sweatCount)")
                    .font(AuroraFont.display())
                    .foregroundStyle(.white)
                VStack(alignment: .leading, spacing: 4) {
                    Text(L(sweatCount == 1 ? "night_sweat_event_count_one" : "night_sweat_event_count_other"))
                        .font(AuroraFont.title())
                        .foregroundStyle(.white)
                    // The real pod's flush count is a placeholder detector (PROTOCOL §9).
                    if hw {
                        Pill(text: L("hw_provisional"), bg: Color.white.opacity(0.22), fg: .white)
                    }
                }
                .padding(.bottom, 10)
                .padding(.leading, 10)
                Spacer()
                if noSleep {
                    // No sleep staging for this night: time in bed only, no ring.
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(Fmt.duration(s?.sessionLenS ?? 0))
                            .font(AuroraFont.titleL())
                            .foregroundStyle(.white)
                        Text(L("night_in_bed"))
                            .font(AuroraFont.label())
                            .foregroundStyle(Color.white.opacity(0.85))
                    }
                    .padding(.bottom, 10)
                } else {
                    SleepRing(pctWake: s?.pctWake ?? 0, pctLight: s?.pctLight ?? 0, pctDeep: s?.pctDeep ?? 0,
                              size: 92,
                              centerTop: Fmt.duration(s?.sessionLenS ?? 0),
                              centerBottom: L("night_in_bed"))
                }
            }
            VSpace(12)
            HStack(spacing: 18) {
                WhiteLabeledValue(label: L("night_peak_sweat"), value: L("night_gm3_value", Fmt.dah(peak)))
                WhiteLabeledValue(label: L("night_skin_rise"), value: skinRiseText)
                // 0 bpm is the internal "no reading" — a dash, never "0–0".
                WhiteLabeledValue(label: L("night_heart"), value: hrRangeText(s))
            }
        }
    }

    private func hrRangeText(_ s: SummaryModel?) -> String {
        guard let s, s.hrMin > 0, s.hrMax > 0 else { return "—" }
        return L("night_hr_range", s.hrMin, s.hrMax)
    }

    private var skinRiseText: String {
        guard let rise = maxRise else { return "—" }
        var text = L("night_up_to", Fmt.delta(rise, settings))
        if show {
            text += " · " + L(Ranges.skinRise.levelOf(rise).labelKey).lowercased()
        }
        return text
    }
}

// MARK: - Replay / download card

private struct ReplayCard: View {
    @Environment(\.theme) private var theme
    let bundle: NightBundle
    let replay: ReplayStatus
    let connected: Bool
    /// The real pod keeps ONE RAM log, not 14 slots.
    var hwLog: Bool = false
    /// Hardware: only the newest finished BLE night can receive the pod's log.
    var canDownload: Bool = true
    let onDownload: (Int) -> Void
    let onCancel: () -> Void
    let onOpenPod: () -> Void

    var body: some View {
        let slot = bundle.session.slot
        let state = bundle.session.replayState
        // Is the in-flight download the one for THIS night's slot?
        let mine: Bool = {
            switch replay {
            case .waitingForHeader(let s), .downloading(let s, _, _, _): return s == slot
            default: return false
            }
        }()

        AuroraCard {
            HStack(spacing: 10) {
                Image(systemName: "arrow.down.circle.fill")
                    .font(.system(size: 20))
                    .foregroundStyle(theme.primary)
                VStack(alignment: .leading, spacing: 2) {
                    Text(titleText(state: state))
                        .font(AuroraFont.titleS())
                        .foregroundStyle(theme.textPrimary)
                    Text(subText(slot: slot, state: state))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer(minLength: 8)
                if let slot, state != .complete, !mine, canDownload {
                    if connected {
                        Button(L("common_download")) { onDownload(slot) }
                            .buttonStyle(.borderedProminent)
                            .tint(theme.primary)
                            .disabled(replay.isActive)
                    } else {
                        Button(L("common_connect")) { onOpenPod() }
                            .buttonStyle(.bordered)
                    }
                }
            }

            if mine {
                VSpace(10)
                switch replay {
                case .waitingForHeader:
                    ProgressView().progressViewStyle(.linear).tint(theme.primary)
                    Text(L("night_replay_waiting"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textPrimary)
                case .downloading(_, let percent, let frames, let expected):
                    ProgressView(value: Double(percent) / 100).tint(theme.primary)
                    HStack {
                        Text(L("night_replay_progress", percent, frames, expected))
                            .font(AuroraFont.bodyS())
                            .foregroundStyle(theme.textPrimary)
                        Spacer()
                        Button(L("common_cancel")) { onCancel() }
                    }
                    Text(L("night_replay_lock_hint"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                default:
                    EmptyView()
                }
            }

            if case .failed(let s, _, _) = replay, s == slot, let failure = replay.failureText {
                VSpace(8)
                InfoBanner(text: failure, tone: .error)
            }
            if case .done(let s, let records, let crc, let complete) = replay, s == slot {
                VSpace(8)
                InfoBanner(text: doneText(records: records, crc: crc, complete: complete),
                           tone: complete ? .success : .warning)
            }
        }
    }

    private func titleText(state: ReplayState) -> String {
        if state == .complete { return L("night_replay_complete") }
        if state == .partial { return L("night_replay_partial") }
        if !bundle.epochs.isEmpty { return L("night_replay_live_data") }
        return L("night_replay_not_downloaded")
    }

    private func subText(slot: Int?, state: ReplayState) -> String {
        guard let slot else { return L("night_replay_no_slot") }
        if hwLog {
            guard state == .complete else { return L("hw_night_replay_stored") }
            var t = L("hw_night_replay_records", bundle.epochs.count)
            if bundle.session.crcFailures > 0 { t += L("night_replay_dropped_crc", bundle.session.crcFailures) }
            return t
        }
        if state == .complete {
            var t = L("night_replay_slot_records", slot, bundle.epochs.count)
            if bundle.session.crcFailures > 0 { t += L("night_replay_dropped_crc", bundle.session.crcFailures) }
            return t
        }
        return L("night_replay_stored_in_slot", slot)
    }

    private func doneText(records: Int, crc: Int, complete: Bool) -> String {
        var t = L("night_done_records", records)
        if crc > 0 { t += L("night_done_crc", crc) }
        t += complete ? "." : L("night_done_incomplete")
        return t
    }
}

// MARK: - Event log row

private struct EventRow: View {
    @Environment(\.theme) private var theme
    let event: ActivityEventModel
    let xFormat: (Double) -> String

    var body: some View {
        AuroraCard(padding: 12) {
            HStack(spacing: 10) {
                Circle().fill(event.kind.markerColor).frame(width: 10, height: 10)
                Text(xFormat(Double(event.tS)))
                    .font(AuroraFont.label())
                    .foregroundStyle(theme.textPrimary)
                    .frame(width: 64, alignment: .leading)
                Text(L(event.labelKey))
                    .font(AuroraFont.bodyM())
                    .foregroundStyle(theme.textPrimary)
                Spacer(minLength: 0)
                Text(L(event.source.labelKey))
                    .font(AuroraFont.labelS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }
}

// MARK: - Diagnostics (expandable)

private struct DiagnosticsCard: View {
    @Environment(\.theme) private var theme
    @State private var open = false
    let bundle: NightBundle

    var body: some View {
        AuroraCard(onTap: { open.toggle() }) {
            HStack {
                Text(L("night_diagnostics"))
                    .font(AuroraFont.titleS())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                Text(L(open ? "common_hide" : "common_show"))
                    .font(AuroraFont.label())
                    .foregroundStyle(theme.primary)
            }
            if open {
                VSpace(10)
                let first = bundle.epochs.first
                let last = bundle.epochs.last
                let volts: Double? = last.flatMap { $0.vcellCv > 0 ? 2.50 + Double($0.vcellCv) / 100 : nil }
                HStack(spacing: 10) {
                    StatTile(label: L("night_diag_battery"),
                             value: "\(first?.battPct ?? 0)→\(last?.battPct ?? 0)", unit: "%",
                             accent: Aurora.good)
                    StatTile(label: L("night_diag_cell"),
                             value: volts.map { String(format: "%.2f", $0) } ?? "—",
                             unit: volts != nil ? "V" : "",
                             accent: Aurora.good)
                    StatTile(label: L("night_diag_records"),
                             value: "\(bundle.epochs.count)",
                             accent: Aurora.ash,
                             note: bundle.session.crcFailures > 0
                                ? L("night_diag_crc_drops", bundle.session.crcFailures)
                                : L("night_diag_crc_ok"))
                }
                VSpace(8)
                Text(L("night_diag_summary",
                       bundle.session.source.rawValue.lowercased(),
                       bundle.session.slot.map(String.init) ?? "—",
                       bundle.session.replayState.rawValue.lowercased(),
                       bundle.hrv.count,
                       bundle.hrv.filter { $0.isValid }.count))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }
}
