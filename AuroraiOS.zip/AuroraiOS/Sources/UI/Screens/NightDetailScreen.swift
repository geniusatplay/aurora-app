// Night detail — the iOS port of ui/screens/NightDetailScreen.kt (hero, replay card,
// stacked chart panels with one shared scrub, sweat events, event log, diagnostics).

import SwiftUI

// MARK: - ActivityKind display helpers (chart marker colours, same mapping as Android)

extension ActivityKind {
    var markerColor: Color {
        switch self {
        case .nightFlash: return Aurora.fuchsia
        case .nightSweats: return Aurora.magenta
        case .heavyExercise: return Aurora.plum
        case .lightExercise: return Aurora.seriesAmbient
        case .sleeping: return Aurora.sleepDeep
        case .up: return Aurora.seriesMotion
        case .sessionStart, .sessionEnd: return Aurora.ash
        }
    }
}

extension EventSource {
    /// night_source_* localization key ("demo" / "you" / "pod").
    var labelKey: String {
        switch self {
        case .demo: return "night_source_demo"
        case .user: return "night_source_user"
        case .pod: return "night_source_pod"
        }
    }
}

// MARK: - Screen

struct NightDetailScreen: View {
    @Environment(\.theme) private var theme
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var repo: SessionRepository

    let sessionId: UUID
    let onBack: () -> Void
    /// Jump to the Pod tab (the replay card's "Connect" action). Optional so previews work.
    var onOpenPod: () -> Void = {}

    @State private var bundle: NightBundle?
    @State private var scrub: Double? = nil
    @State private var confirmDelete = false
    @State private var csv = ""
    @State private var csvEpochCount = -1

    var body: some View {
        ZStack {
            theme.background.ignoresSafeArea()
            if let b = bundle {
                content(b)
            } else {
                EmptyState(title: L("common_loading"), body: "")
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) { titleStack }
            ToolbarItem(placement: .topBarTrailing) {
                ShareLink(item: csv, subject: Text(L("night_export_subject"))) {
                    Image(systemName: "square.and.arrow.up")
                }
                .disabled(csv.isEmpty)
                .accessibilityLabel(L("night_cd_share_csv"))
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button { confirmDelete = true } label: { Image(systemName: "trash") }
                    .accessibilityLabel(L("night_cd_delete_night"))
            }
        }
        .alert(L("night_delete_title"), isPresented: $confirmDelete) {
            Button(L("common_delete"), role: .destructive) {
                repo.deleteSession(id: sessionId)
                onBack()
            }
            Button(L("common_keep"), role: .cancel) {}
        } message: {
            Text(L("night_delete_text"))
        }
        .onAppear { reload() }
        // Re-fetch whenever the repository mutates (live epochs, replay finishing, …).
        .onReceive(repo.$revision) { _ in reload() }
    }

    private var isLive: Bool { pod.activeSession?.id == sessionId }

    private func reload() {
        let b = repo.nightBundle(sessionId: sessionId)
        bundle = b
        // CSV is only rebuilt when the epoch count changes — exporting is O(n) and the
        // revision counter ticks on every provisional epoch while live.
        if let b, b.epochs.count != csvEpochCount {
            csvEpochCount = b.epochs.count
            csv = repo.exportCsv(sessionId: sessionId)
        }
    }

    // MARK: title

    private var titleStack: some View {
        VStack(spacing: 0) {
            Text(bundle.map { Fmt.nightLabel($0.session.startedAt) } ?? L("night_title_fallback"))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            if let b = bundle {
                let end = b.session.endedAt.map { Fmt.clock($0, settings) } ?? L("night_recording_lower")
                Text(L("night_time_range", Fmt.clock(b.session.startedAt, settings), end))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }

    // MARK: content

    private func content(_ b: NightBundle) -> some View {
        // Session-relative seconds → wall clock, e.g. "23:41" (Android's xFormat).
        let start = b.session.startedAt
        let xFormat: (Double) -> String = { t in Fmt.clock(start.addingTimeInterval(t), settings) }
        let lenS = max(b.summary?.sessionLenS ?? b.epochs.last.map { $0.tS + 30 } ?? 0, 600)
        let x0 = 0.0
        let x1 = Double(lenS)
        let bands = b.sweat.map { (Double($0.startS), Double($0.endS)) }
        let markers: [(t: Double, color: Color, label: String)] = b.events
            .filter { $0.kind != .sessionStart && $0.kind != .sessionEnd }
            .map { (Double($0.tS), $0.kind.markerColor, L($0.kind.labelKey)) }
        // Skin baseline = median of the first 30 min; the hero's "skin rise" number.
        let baselineSamples = b.epochs.filter { $0.tS < 1800 }.map { $0.skinTempX100 }.sorted()
        let baseline = baselineSamples.isEmpty ? nil : baselineSamples[baselineSamples.count / 2]
        let maxRise = baseline.flatMap { bl in b.epochs.map { Double($0.skinTempX100 - bl) / 100 }.max() }

        return ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) {
                NightHero(bundle: b, maxRise: maxRise, settings: settings, isLive: isLive, show: settings.showRanges)

                if !isLive {
                    ReplayCard(bundle: b,
                               replay: pod.replayStatus,
                               connected: pod.connectionState.isConnected,
                               onDownload: { slot in pod.downloadNight(sessionId: sessionId, slot: slot) },
                               onCancel: { pod.cancelDownload() },
                               onOpenPod: onOpenPod)
                }

                if b.epochs.isEmpty {
                    AuroraCard {
                        EmptyState(title: L("night_no_detail_title"),
                                   body: L(isLive ? "night_no_detail_live" : "night_no_detail_offline"))
                    }
                } else {
                    chartCard(b, x0: x0, x1: x1, bands: bands, markers: markers, xFormat: xFormat)
                }

                if !b.sweat.isEmpty {
                    sweatSection(b, xFormat: xFormat)
                }

                if !b.events.isEmpty {
                    SectionHeader(title: L("night_event_log_title"), subtitle: L("night_event_log_sub"))
                    ForEach(b.events, id: \.id) { e in
                        EventRow(event: e, xFormat: xFormat)
                    }
                }

                DiagnosticsCard(bundle: b)
                Disclaimer()
            }
            .padding(.horizontal, 16)
            .padding(.top, 4)
            .padding(.bottom, 24)
        }
    }

    // MARK: chart card

    private func chartCard(_ b: NightBundle, x0: Double, x1: Double,
                           bands: [(Double, Double)],
                           markers: [(t: Double, color: Color, label: String)],
                           xFormat: @escaping (Double) -> String) -> some View {
        let show = settings.showRanges
        let epochs = b.epochs
        // Grouped in threes: ViewBuilder tops out at 10 direct children and this card has 14.
        return AuroraCard(padding: 12, spacing: 0) {
            Group {
                SectionHeader(title: L("night_charts_title"), subtitle: L("night_charts_sub"))

                PanelTitle(title: L("night_panel_temp"), sub: settings.tempUnit)
                LinePanel(
                series: [
                    (name: L("night_series_skin"), color: Aurora.seriesSkin,
                     points: epochs.map { TimePoint(t: Double($0.tS), v: settings.toDisplayTemp(Double($0.skinTempX100) / 100)) },
                     area: false),
                    (name: L("night_series_room"), color: Aurora.seriesAmbient,
                     points: epochs.map { TimePoint(t: Double($0.tS), v: settings.toDisplayTemp(Double($0.ambTempX100) / 100)) },
                     area: false),
                ],
                x0: x0, x1: x1, height: 160,
                unit: settings.tempUnit,
                bands: bands, markers: markers,
                guides: guides(Ranges.skinTemp, show) { settings.toDisplayTemp($0) },
                scrub: $scrub, xFormat: xFormat
            )
            }

            Group {
            PanelTitle(title: L("night_panel_sweat"), sub: L("night_panel_sweat_sub"))
            LinePanel(
                series: [
                    (name: L("night_series_sweat"), color: Aurora.seriesSweat,
                     points: epochs.map { TimePoint(t: Double($0.tS), v: Double($0.dahX100) / 100) },
                     area: true),
                ],
                x0: x0, x1: x1, height: 140,
                unit: " g/m³",
                bands: bands, markers: markers,
                guides: guides(Ranges.sweat, show),
                scrub: $scrub, xFormat: xFormat
            )

            PanelTitle(title: L("night_panel_sleep"), sub: L("night_panel_sleep_sub"))
            HypnogramPanel(
                states: epochs.map { (t: Double($0.tS), state: SleepState.from($0.sleepState)) },
                x0: x0, x1: x1, height: 96,
                scrub: $scrub, xFormat: xFormat
            )
            }

            Group {
            PanelTitle(title: L("night_panel_movement"), sub: L("night_panel_movement_sub"))
            MotionPanel(
                points: epochs.map { TimePoint(t: Double($0.tS), v: Double($0.motionIndex)) },
                x0: x0, x1: x1, height: 90,
                guides: guides(Ranges.movement, show),
                scrub: $scrub, xFormat: xFormat
            )

            PanelTitle(title: L("night_panel_hr"), sub: L("night_panel_hr_sub"))
            DotPanel(
                name: L("night_series_hr"),
                points: epochs
                    .filter { $0.hrBpm > 0 && QualityBand.of($0.hrQuality) != .hide }
                    .map { (t: Double($0.tS), v: Double($0.hrBpm), valid: QualityBand.of($0.hrQuality) == .normal) },
                color: theme.seriesHeart,
                x0: x0, x1: x1, height: 120,
                unit: " bpm",
                guides: guides(Ranges.sleepHeartRate, show),
                scrub: $scrub, xFormat: xFormat
            )
            }

            Group {
            PanelTitle(title: L("night_panel_rmssd"), sub: L("night_panel_rmssd_sub"))
            DotPanel(
                name: L("night_series_rmssd"),
                points: b.hrv.map { (t: Double($0.windowEndS), v: Double($0.rmssdX10) / 10, valid: $0.isValid) },
                color: Aurora.seriesHrv,
                x0: x0, x1: x1, height: 120,
                unit: " ms",
                connect: true,
                guides: guides(Ranges.rmssd, show),
                scrub: $scrub, xFormat: xFormat,
                showXAxis: true
            )

            MarkerLegend(markers: markers)
            }
        }
    }

    /// Range guides only when the settings toggle is on; `transform` converts the
    /// thresholds into display units (°F for the temperature panel).
    private func guides(_ r: RangeGuide, _ show: Bool,
                        transform: (Double) -> Double = { $0 }) -> GuideSpec? {
        guard show else { return nil }
        return GuideSpec(lowMax: transform(r.lowMax), highMin: transform(r.highMin),
                         higherIsBetter: r.higherIsBetter)
    }

    // MARK: sweat events

    private func sweatSection(_ b: NightBundle, xFormat: @escaping (Double) -> String) -> some View {
        let longest = b.sweat.map { $0.durationS }.max() ?? 0
        return Group {
            SectionHeader(title: L("night_sweat_events_title"),
                          subtitle: L("night_sweat_events_sub", b.sweat.count, Fmt.durationShort(longest)))
            AuroraCard(padding: 8) {
                // Indices, not enumerated(): key paths cannot address tuple elements.
                ForEach(b.sweat.indices, id: \.self) { i in
                    let e = b.sweat[i]
                    HStack(spacing: 10) {
                        Pill(text: "\(i + 1)")
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L("night_sweat_row_range", xFormat(Double(e.startS)), xFormat(Double(e.endS))))
                                .font(AuroraFont.titleS())
                                .foregroundStyle(theme.textPrimary)
                            Text(L("night_sweat_row_detail", Fmt.durationShort(e.durationS), Fmt.dah(e.peakDah)))
                                .font(AuroraFont.bodyS())
                                .foregroundStyle(theme.textSecondary)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                }
            }
        }
    }
}

// MARK: - Panel title

private struct PanelTitle: View {
    @Environment(\.theme) private var theme
    let title: String
    let sub: String

    var body: some View {
        HStack(spacing: 8) {
            Text(title)
                .font(AuroraFont.titleS())
                .foregroundStyle(theme.textPrimary)
            Text(sub)
                .font(AuroraFont.labelS())
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.top, 10)
        .padding(.bottom, 2)
    }
}

// MARK: - Hero

private struct NightHero: View {
    let bundle: NightBundle
    let maxRise: Double?
    let settings: AppSettings
    let isLive: Bool
    let show: Bool

    var body: some View {
        let s = bundle.summary
        let sweatCount = s?.sweatEvents ?? bundle.sweat.count
        let peak = Double(s?.peakDahX100 ?? bundle.epochs.map { $0.dahX100 }.max() ?? 0) / 100

        HeroCard {
            HStack {
                Pill(text: L(isLive ? "common_recording" : "night_summary_pill"),
                     bg: Color.white.opacity(0.22), fg: .white)
                Spacer()
                if bundle.session.source == .demo {
                    Pill(text: L("night_demo_pill"), bg: Color.white.opacity(0.22), fg: .white)
                }
            }
            VSpace(10)
            HStack(alignment: .bottom) {
                Text("\(sweatCount)")
                    .font(AuroraFont.display())
                    .foregroundStyle(.white)
                Text(L(sweatCount == 1 ? "night_sweat_event_count_one" : "night_sweat_event_count_other"))
                    .font(AuroraFont.title())
                    .foregroundStyle(.white)
                    .padding(.bottom, 10)
                    .padding(.leading, 10)
                Spacer()
                SleepRing(pctWake: s?.pctWake ?? 0, pctLight: s?.pctLight ?? 0, pctDeep: s?.pctDeep ?? 0,
                          size: 92,
                          centerTop: Fmt.duration(s?.sessionLenS ?? 0),
                          centerBottom: L("night_in_bed"))
            }
            VSpace(12)
            HStack(spacing: 18) {
                WhiteLabeledValue(label: L("night_peak_sweat"), value: L("night_gm3_value", Fmt.dah(peak)))
                WhiteLabeledValue(label: L("night_skin_rise"), value: skinRiseText)
                WhiteLabeledValue(label: L("night_heart"),
                                  value: s.map { L("night_hr_range", $0.hrMin, $0.hrMax) } ?? "—")
            }
        }
    }

    private var skinRiseText: String {
        guard let rise = maxRise else { return "—" }
        var text = L("night_up_to", Fmt.delta(rise, settings))
        if show {
            text += " · " + L(Ranges.skinRise.levelOf(rise).labelKey).lowercased()
        }
        return text
    }
}

// MARK: - Replay / download card

private struct ReplayCard: View {
    @Environment(\.theme) private var theme
    let bundle: NightBundle
    let replay: ReplayStatus
    let connected: Bool
    let onDownload: (Int) -> Void
    let onCancel: () -> Void
    let onOpenPod: () -> Void

    var body: some View {
        let slot = bundle.session.slot
        let state = bundle.session.replayState
        // Is the in-flight download the one for THIS night's slot?
        let mine: Bool = {
            switch replay {
            case .waitingForHeader(let s), .downloading(let s, _, _, _): return s == slot
            default: return false
            }
        }()

        AuroraCard {
            HStack(spacing: 10) {
                Image(systemName: "arrow.down.circle.fill")
                    .font(.system(size: 20))
                    .foregroundStyle(theme.primary)
                VStack(alignment: .leading, spacing: 2) {
                    Text(titleText(state: state))
                        .font(AuroraFont.titleS())
                        .foregroundStyle(theme.textPrimary)
                    Text(subText(slot: slot, state: state))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
                Spacer(minLength: 8)
                if let slot, state != .complete, !mine {
                    if connected {
                        Button(L("common_download")) { onDownload(slot) }
                            .buttonStyle(.borderedProminent)
                            .tint(theme.primary)
                            .disabled(replay.isActive)
                    } else {
                        Button(L("common_connect")) { onOpenPod() }
                            .buttonStyle(.bordered)
                    }
                }
            }

            if mine {
                VSpace(10)
                switch replay {
                case .waitingForHeader:
                    ProgressView().progressViewStyle(.linear).tint(theme.primary)
                    Text(L("night_replay_waiting"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textPrimary)
                case .downloading(_, let percent, let frames, let expected):
                    ProgressView(value: Double(percent) / 100).tint(theme.primary)
                    HStack {
                        Text(L("night_replay_progress", percent, frames, expected))
                            .font(AuroraFont.bodyS())
                            .foregroundStyle(theme.textPrimary)
                        Spacer()
                        Button(L("common_cancel")) { onCancel() }
                    }
                    Text(L("night_replay_lock_hint"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                default:
                    EmptyView()
                }
            }

            if case .failed(let s, _, _) = replay, s == slot, let failure = replay.failureText {
                VSpace(8)
                InfoBanner(text: failure, tone: .error)
            }
            if case .done(let s, let records, let crc, let complete) = replay, s == slot {
                VSpace(8)
                InfoBanner(text: doneText(records: records, crc: crc, complete: complete),
                           tone: complete ? .success : .warning)
            }
        }
    }

    private func titleText(state: ReplayState) -> String {
        if state == .complete { return L("night_replay_complete") }
        if state == .partial { return L("night_replay_partial") }
        if !bundle.epochs.isEmpty { return L("night_replay_live_data") }
        return L("night_replay_not_downloaded")
    }

    private func subText(slot: Int?, state: ReplayState) -> String {
        guard let slot else { return L("night_replay_no_slot") }
        if state == .complete {
            var t = L("night_replay_slot_records", slot, bundle.epochs.count)
            if bundle.session.crcFailures > 0 { t += L("night_replay_dropped_crc", bundle.session.crcFailures) }
            return t
        }
        return L("night_replay_stored_in_slot", slot)
    }

    private func doneText(records: Int, crc: Int, complete: Bool) -> String {
        var t = L("night_done_records", records)
        if crc > 0 { t += L("night_done_crc", crc) }
        t += complete ? "." : L("night_done_incomplete")
        return t
    }
}

// MARK: - Event log row

private struct EventRow: View {
    @Environment(\.theme) private var theme
    let event: ActivityEventModel
    let xFormat: (Double) -> String

    var body: some View {
        AuroraCard(padding: 12) {
            HStack(spacing: 10) {
                Circle().fill(event.kind.markerColor).frame(width: 10, height: 10)
                Text(xFormat(Double(event.tS)))
                    .font(AuroraFont.label())
                    .foregroundStyle(theme.textPrimary)
                    .frame(width: 64, alignment: .leading)
                Text(L(event.labelKey))
                    .font(AuroraFont.bodyM())
                    .foregroundStyle(theme.textPrimary)
                Spacer(minLength: 0)
                Text(L(event.source.labelKey))
                    .font(AuroraFont.labelS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }
}

// MARK: - Diagnostics (expandable)

private struct DiagnosticsCard: View {
    @Environment(\.theme) private var theme
    @State private var open = false
    let bundle: NightBundle

    var body: some View {
        AuroraCard(onTap: { open.toggle() }) {
            HStack {
                Text(L("night_diagnostics"))
                    .font(AuroraFont.titleS())
                    .foregroundStyle(theme.textPrimary)
                Spacer()
                Text(L(open ? "common_hide" : "common_show"))
                    .font(AuroraFont.label())
                    .foregroundStyle(theme.primary)
            }
            if open {
                VSpace(10)
                let first = bundle.epochs.first
                let last = bundle.epochs.last
                let volts: Double? = last.flatMap { $0.vcellCv > 0 ? 2.50 + Double($0.vcellCv) / 100 : nil }
                HStack(spacing: 10) {
                    StatTile(label: L("night_diag_battery"),
                             value: "\(first?.battPct ?? 0)→\(last?.battPct ?? 0)", unit: "%",
                             accent: Aurora.good)
                    StatTile(label: L("night_diag_cell"),
                             value: volts.map { String(format: "%.2f", $0) } ?? "—",
                             unit: volts != nil ? "V" : "",
                             accent: Aurora.good)
                    StatTile(label: L("night_diag_records"),
                             value: "\(bundle.epochs.count)",
                             accent: Aurora.ash,
                             note: bundle.session.crcFailures > 0
                                ? L("night_diag_crc_drops", bundle.session.crcFailures)
                                : L("night_diag_crc_ok"))
                }
                VSpace(8)
                Text(L("night_diag_summary",
                       bundle.session.source.rawValue.lowercased(),
                       bundle.session.slot.map(String.init) ?? "—",
                       bundle.session.replayState.rawValue.lowercased(),
                       bundle.hrv.count,
                       bundle.hrv.filter { $0.isValid }.count))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }
}
