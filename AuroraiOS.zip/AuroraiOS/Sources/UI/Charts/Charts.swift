// Time-series chart panels (Swift Charts) — the iOS port of ui/charts/ChartCore.kt + NightCharts.kt.
//
// Unlike Android (hand-drawn Canvas), these panels are built on Apple's Charts framework
// (brief convention #4). Panels stack over a SHARED x-domain in seconds (Double) so
// NightDetail/Live can align several of them vertically; a shared `scrub: Binding<Double?>`
// gives one crosshair across the whole stack. One y-axis per panel — never dual-axis.
//
// Colours come from @Environment(\.theme): grid = theme.chartGrid, axis text =
// theme.chartAxisText, tooltips = theme.tooltipBg/tooltipFg. Backgrounds stay clear so the
// panels sit directly on cards.

import SwiftUI
import Charts

// MARK: - Data types

/// One sample on the shared time axis: `t` seconds since session start, `v` display units.
struct TimePoint: Identifiable, Equatable {
    var t: Double
    var v: Double
    var id: Double { t }

    init(t: Double, v: Double) {
        self.t = t
        self.v = v
    }
}

/// Low / Medium / High reference zones for a panel, in the panel's display units.
/// Mirrors RangeGuide but carries only what the chart needs.
struct GuideSpec: Equatable {
    var lowMax: Double
    var highMin: Double
    var higherIsBetter: Bool

    init(lowMax: Double, highMin: Double, higherIsBetter: Bool = false) {
        self.lowMax = lowMax
        self.highMin = highMin
        self.higherIsBetter = higherIsBetter
    }

    /// Convenience: build straight from a domain RangeGuide (Ranges.swift).
    init(_ r: RangeGuide) {
        self.init(lowMax: r.lowMax, highMin: r.highMin, higherIsBetter: r.higherIsBetter)
    }
}

// MARK: - Formatting helpers

/// Hours:minutes label for seconds since start ("7:05").
func fmtHm(_ seconds: Double) -> String {
    let s = max(0, Int(seconds))
    return String(format: "%d:%02d", s / 3600, (s % 3600) / 60)
}

/// Plain numeric label with fixed decimals.
func fmtNum(_ v: Double, _ decimals: Int) -> String {
    String(format: "%.\(decimals)f", v)
}

/// "Nice" tick step for a numeric range (1/2/5 × 10^n), same algorithm as Android.
func niceStep(_ range: Double, targetTicks: Int = 4) -> Double {
    guard range > 0 else { return 1 }
    let raw = range / Double(targetTicks)
    let mag = pow(10.0, floor(log10(raw)))
    let n = raw / mag
    let step: Double
    if n < 1.5 { step = 1 } else if n < 3 { step = 2 } else if n < 7 { step = 5 } else { step = 10 }
    return step * mag
}

/// Padded, tick-aligned y bounds.
func niceBounds(_ lo: Double, _ hi: Double, targetTicks: Int = 4, padFrac: Double = 0.08) -> (Double, Double) {
    if hi - lo < 1e-4 { return (lo - 1, hi + 1) }
    let pad = (hi - lo) * padFrac
    let step = niceStep(hi - lo + 2 * pad, targetTicks: targetTicks)
    return (floor((lo - pad) / step) * step, ceil((hi + pad) / step) * step)
}

/// Time ticks on the shared x axis: hourly past 5 h, half-hourly past 1 h, else 10-minutely.
func timeTicks(x0: Double, x1: Double) -> [Double] {
    let span = x1 - x0
    let step: Double = span > 5 * 3600 ? 3600 : (span > 3600 ? 1800 : 600)
    var t = (x0 / step).rounded(.up) * step
    var out: [Double] = []
    while t <= x1 + 0.001 { out.append(t); t += step }
    return out
}

/// y tick values from an aligned lower bound.
private func yTickValues(_ lo: Double, _ hi: Double, step: Double) -> [Double] {
    var v = lo
    var out: [Double] = []
    while v <= hi + 1e-6 { out.append(v); v += step }
    return out
}

/// Nearest sample to a time (points are time-sorted; linear scan is fine at epoch counts).
private func nearestPoint(_ points: [TimePoint], to t: Double) -> TimePoint? {
    points.min(by: { abs($0.t - t) < abs($1.t - t) })
}

// MARK: - Shared chart pieces

/// Tooltip chip used by every panel's crosshair annotation.
struct ChartTooltip: View {
    @Environment(\.theme) private var theme
    let text: String

    var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(theme.tooltipFg)
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(RoundedRectangle(cornerRadius: 8, style: .continuous).fill(theme.tooltipBg))
    }
}

/// Low / mid / high background zones + dashed boundary rules with zone labels.
/// LOW is the calm blue tint and HIGH the alert red tint, swapped when higher is better
/// (HRV) — identical to Android's drawRangeGuides.
@ChartContentBuilder
func guideMarks(_ g: GuideSpec?, yLo: Double, yHi: Double, labelColor: Color) -> some ChartContent {
    if let g {
        let calm = Aurora.seriesAmbient
        let alert = Aurora.bad
        let mid = Color(hex: 0x9A8F9C)
        let lowColor = g.higherIsBetter ? alert : calm
        let highColor = g.higherIsBetter ? calm : alert
        let lowTop = min(max(g.lowMax, yLo), yHi)
        let highBottom = min(max(g.highMin, yLo), yHi)

        RectangleMark(yStart: .value("y", yLo), yEnd: .value("y", lowTop))
            .foregroundStyle(lowColor.opacity(0.10))
            .annotation(position: .overlay, alignment: .topTrailing) {
                Text(L("level_low")).font(.system(size: 9, weight: .bold)).foregroundStyle(labelColor).padding(2)
            }
        RectangleMark(yStart: .value("y", lowTop), yEnd: .value("y", highBottom))
            .foregroundStyle(mid.opacity(0.07))
            .annotation(position: .overlay, alignment: .topTrailing) {
                Text(L("level_medium")).font(.system(size: 9, weight: .bold)).foregroundStyle(labelColor).padding(2)
            }
        RectangleMark(yStart: .value("y", highBottom), yEnd: .value("y", yHi))
            .foregroundStyle(highColor.opacity(0.10))
            .annotation(position: .overlay, alignment: .topTrailing) {
                Text(L("level_high")).font(.system(size: 9, weight: .bold)).foregroundStyle(labelColor).padding(2)
            }
        if g.lowMax > yLo && g.lowMax < yHi {
            RuleMark(y: .value("y", g.lowMax))
                .foregroundStyle(labelColor.opacity(0.45))
                .lineStyle(StrokeStyle(lineWidth: 1, dash: [5, 4]))
        }
        if g.highMin > yLo && g.highMin < yHi {
            RuleMark(y: .value("y", g.highMin))
                .foregroundStyle(labelColor.opacity(0.45))
                .lineStyle(StrokeStyle(lineWidth: 1, dash: [5, 4]))
        }
    }
}

/// Shaded vertical bands (sweat events), full plot height.
@ChartContentBuilder
func bandMarks(_ bands: [(Double, Double)], color: Color) -> some ChartContent {
    ForEach(bands.indices, id: \.self) { i in
        RectangleMark(xStart: .value("t", bands[i].0), xEnd: .value("t", bands[i].1))
            .foregroundStyle(color)
    }
}

/// Drag-to-scrub catcher installed via .chartOverlay on every panel. Converts the touch
/// x to seconds through the chart proxy; a tap on the current scrub position clears it
/// (Android's ScrubBox behaviour).
struct ChartScrubOverlay: View {
    let proxy: ChartProxy
    let x0: Double
    let x1: Double
    @Binding var scrub: Double?
    @State private var scrubAtGestureStart: Double?
    @State private var dragging = false

    var body: some View {
        GeometryReader { geo in
            Rectangle()
                .fill(Color.clear)
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { g in
                            if !dragging {
                                dragging = true
                                scrubAtGestureStart = scrub
                            }
                            if let t = seconds(at: g.location, in: geo) { scrub = t }
                        }
                        .onEnded { g in
                            // A stationary tap on (or near) the existing crosshair clears it.
                            let span = max(x1 - x0, 1e-6)
                            if abs(g.translation.width) < 4,
                               let s0 = scrubAtGestureStart,
                               let t = seconds(at: g.location, in: geo),
                               abs(s0 - t) < span * 0.01 {
                                scrub = nil
                            }
                            dragging = false
                            scrubAtGestureStart = nil
                        }
                )
        }
    }

    private func seconds(at p: CGPoint, in geo: GeometryProxy) -> Double? {
        guard let pf = proxy.plotFrame else { return nil }
        let rect = geo[pf]
        guard let t = proxy.value(atX: p.x - rect.origin.x, as: Double.self) else { return nil }
        return min(max(t, x0), x1)
    }
}

/// Names event markers under a chart stack (one dot + label per distinct marker label).
struct MarkerLegend: View {
    @Environment(\.theme) private var theme
    private let items: [(color: Color, label: String)]

    init(markers: [(t: Double, color: Color, label: String)]) {
        var seen = Set<String>()
        var out: [(Color, String)] = []
        for m in markers where !seen.contains(m.label) {
            seen.insert(m.label)
            out.append((m.color, m.label))
        }
        self.items = out
    }

    var body: some View {
        if items.isEmpty {
            EmptyView()
        } else {
            // Wrapping not needed at ≤4 marker kinds; a scrollable row keeps it safe.
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 14) {
                    ForEach(items.indices, id: \.self) { i in
                        HStack(spacing: 5) {
                            Circle().fill(items[i].color).frame(width: 9, height: 9)
                            Text(items[i].label)
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(theme.textSecondary)
                        }
                    }
                }
            }
            .padding(.top, 4)
        }
    }
}

// MARK: - LinePanel

/// Multi-line panel on the shared time axis. Optional area fill under a series, shaded
/// sweat bands, activity markers, low/mid/high guides and the shared scrub crosshair.
/// Legend appears automatically for ≥2 series and is hidden for 1.
struct LinePanel: View {
    fileprivate struct Series {
        var name: String
        var color: Color
        var points: [TimePoint]
        var area: Bool
    }
    fileprivate struct MarkerSpec {
        var t: Double
        var color: Color
        var label: String
    }

    @Environment(\.theme) private var theme
    private let series: [Series]
    private let x0: Double
    private let x1: Double
    private let height: CGFloat
    private let unit: String
    private let decimals: Int
    private let bands: [(Double, Double)]
    private let bandColor: Color
    private let markers: [MarkerSpec]
    private let guides: GuideSpec?
    @Binding private var scrub: Double?
    private let xFormat: (Double) -> String
    private let showXAxis: Bool
    private let yLo: Double
    private let yHi: Double
    private let yStep: Double

    init(series: [(name: String, color: Color, points: [TimePoint], area: Bool)],
         x0: Double, x1: Double,
         height: CGFloat = 150,
         unit: String = "",
         decimals: Int = 1,
         bands: [(Double, Double)] = [],
         bandColor: Color = Aurora.fuchsia.opacity(0.14),
         markers: [(t: Double, color: Color, label: String)] = [],
         guides: GuideSpec? = nil,
         scrub: Binding<Double?> = .constant(nil),
         xFormat: @escaping (Double) -> String = { fmtHm($0) },
         showXAxis: Bool = false) {
        self.series = series.map { Series(name: $0.name, color: $0.color, points: $0.points, area: $0.area) }
        self.x0 = x0
        self.x1 = x1
        self.height = height
        self.unit = unit
        self.decimals = decimals
        self.bands = bands
        self.bandColor = bandColor
        self.markers = markers.map { MarkerSpec(t: $0.t, color: $0.color, label: $0.label) }
        self.guides = guides
        self._scrub = scrub
        self.xFormat = xFormat
        self.showXAxis = showXAxis
        // y domain covers data AND guide thresholds so zones are always visible (Android parity).
        let vals = series.flatMap { $0.points.map(\.v) }
        let lo = min(vals.min() ?? 0, guides?.lowMax ?? .greatestFiniteMagnitude)
        let hi = max(vals.max() ?? 1, guides?.highMin ?? -.greatestFiniteMagnitude)
        let (b0, b1) = niceBounds(lo, hi)
        self.yLo = b0
        self.yHi = b1
        self.yStep = niceStep(b1 - b0)
    }

    var body: some View {
        let yDecimals = yStep < 1 ? 1 : 0
        let chart = Chart {
            guideMarks(guides, yLo: yLo, yHi: yHi, labelColor: theme.chartAxisText)
            bandMarks(bands, color: bandColor)
            seriesMarks
            markerMarks
            crosshairMarks
        }
        .chartXScale(domain: x0...max(x1, x0 + 1))
        .chartYScale(domain: yLo...yHi)
        .chartForegroundStyleScale(domain: series.map(\.name), range: series.map(\.color))
        .chartLegend(series.count >= 2 ? .visible : .hidden)
        .chartYAxis {
            AxisMarks(position: .leading, values: yTickValues(yLo, yHi, step: yStep)) { value in
                AxisGridLine().foregroundStyle(theme.chartGrid)
                AxisValueLabel {
                    if let d = value.as(Double.self) {
                        Text(fmtNum(d, yDecimals))
                            .font(.system(size: 10))
                            .foregroundStyle(theme.chartAxisText)
                    }
                }
            }
        }
        .chartOverlay { proxy in
            ChartScrubOverlay(proxy: proxy, x0: x0, x1: x1, scrub: $scrub)
        }
        .frame(height: height)

        if showXAxis {
            chart.chartXAxis {
                AxisMarks(values: timeTicks(x0: x0, x1: x1)) { value in
                    AxisTick().foregroundStyle(theme.chartGrid)
                    AxisValueLabel {
                        if let d = value.as(Double.self) {
                            Text(xFormat(d))
                                .font(.system(size: 10))
                                .foregroundStyle(theme.chartAxisText)
                        }
                    }
                }
            }
        } else {
            chart.chartXAxis(.hidden)
        }
    }

    @ChartContentBuilder
    private var seriesMarks: some ChartContent {
        ForEach(series, id: \.name) { s in
            if s.area {
                ForEach(s.points) { p in
                    AreaMark(x: .value("Time", p.t),
                             yStart: .value("Min", yLo),
                             yEnd: .value("Value", p.v))
                        .interpolationMethod(.catmullRom)
                        .foregroundStyle(
                            LinearGradient(colors: [s.color.opacity(0.35), s.color.opacity(0.02)],
                                           startPoint: .top, endPoint: .bottom)
                        )
                }
            }
            ForEach(s.points) { p in
                LineMark(x: .value("Time", p.t), y: .value("Value", p.v))
                    .interpolationMethod(.catmullRom)
                    .lineStyle(StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                    .foregroundStyle(by: .value("Series", s.name))
            }
        }
    }

    @ChartContentBuilder
    private var markerMarks: some ChartContent {
        ForEach(markers.indices, id: \.self) { i in
            RuleMark(x: .value("Time", markers[i].t))
                .foregroundStyle(markers[i].color.opacity(0.55))
                .lineStyle(StrokeStyle(lineWidth: 1.5))
                .annotation(position: .overlay, alignment: .top) {
                    Circle().fill(markers[i].color).frame(width: 7, height: 7)
                }
        }
    }

    @ChartContentBuilder
    private var crosshairMarks: some ChartContent {
        if let t = scrub {
            RuleMark(x: .value("Time", t))
                .foregroundStyle(theme.chartAxisText.opacity(0.7))
                .lineStyle(StrokeStyle(lineWidth: 1))
                .annotation(position: .top, spacing: 2,
                            overflowResolution: .init(x: .fit(to: .chart), y: .disabled)) {
                    ChartTooltip(text: tooltipText(at: t))
                }
            ForEach(series, id: \.name) { s in
                if let p = nearestPoint(s.points, to: t) {
                    PointMark(x: .value("Time", p.t), y: .value("Value", p.v))
                        .foregroundStyle(s.color)
                        .symbolSize(70)
                }
            }
        }
    }

    private func tooltipText(at t: Double) -> String {
        let vals = series.compactMap { s -> String? in
            guard let p = nearestPoint(s.points, to: t) else { return nil }
            return "\(s.name) \(fmtNum(p.v, decimals))\(unit)"
        }
        return ([xFormat(t)] + vals).joined(separator: "  ")
    }
}

// MARK: - HypnogramPanel

/// Sleep hypnogram: stepped Wake / Light / Deep rail at three discrete y levels.
/// Consecutive equal states are merged into runs so a full night stays a few dozen marks.
struct HypnogramPanel: View {
    private struct Run: Identifiable {
        var id: Int
        var t0: Double
        var t1: Double
        var state: SleepState
    }

    @Environment(\.theme) private var theme
    private let states: [(t: Double, state: SleepState)]
    private let runs: [Run]
    private let x0: Double
    private let x1: Double
    private let height: CGFloat
    private let bands: [(Double, Double)]
    private let bandColor: Color
    @Binding private var scrub: Double?
    private let xFormat: (Double) -> String
    private let showXAxis: Bool

    init(states: [(t: Double, state: SleepState)],
         x0: Double, x1: Double,
         height: CGFloat = 96,
         bands: [(Double, Double)] = [],
         bandColor: Color = Aurora.fuchsia.opacity(0.14),
         scrub: Binding<Double?> = .constant(nil),
         xFormat: @escaping (Double) -> String = { fmtHm($0) },
         showXAxis: Bool = false) {
        self.states = states
        self.x0 = x0
        self.x1 = x1
        self.height = height
        self.bands = bands
        self.bandColor = bandColor
        self._scrub = scrub
        self.xFormat = xFormat
        self.showXAxis = showXAxis
        // Merge consecutive equal states into runs; UNKNOWN gaps are simply not drawn.
        var runs: [Run] = []
        var i = 0
        var nextId = 0
        while i < states.count {
            let (t, s) = states[i]
            var j = i + 1
            while j < states.count && states[j].state == s { j += 1 }
            let end = j < states.count ? states[j].t : states[states.count - 1].t + Double(Cadence.epochS)
            if s != .unknown {
                runs.append(Run(id: nextId, t0: t, t1: end, state: s))
                nextId += 1
            }
            i = j
        }
        self.runs = runs
    }

    /// Wake on top (2), light in the middle (1), deep at the bottom (0) — Android parity.
    private static func level(_ s: SleepState) -> Double {
        switch s {
        case .wake: return 2
        case .light: return 1
        case .deep: return 0
        case .unknown: return -1
        }
    }

    private static func color(_ s: SleepState) -> Color {
        switch s {
        case .wake: return Aurora.sleepWake
        case .light: return Aurora.sleepLight
        case .deep: return Aurora.sleepDeep
        case .unknown: return Aurora.mist
        }
    }

    private static func labelKey(_ s: SleepState) -> String {
        switch s {
        case .wake: return "app_sleep_awake"
        case .light: return "app_sleep_light"
        case .deep: return "app_sleep_deep"
        case .unknown: return "app_sleep_unknown"
        }
    }

    var body: some View {
        let chart = Chart {
            bandMarks(bands, color: bandColor)
            ForEach(runs) { r in
                RectangleMark(xStart: .value("Time", r.t0), xEnd: .value("Time", r.t1),
                              yStart: .value("State", Self.level(r.state) - 0.32),
                              yEnd: .value("State", Self.level(r.state) + 0.32))
                    .foregroundStyle(Self.color(r.state))
                    .cornerRadius(5)
            }
            if let t = scrub {
                RuleMark(x: .value("Time", t))
                    .foregroundStyle(theme.chartAxisText.opacity(0.7))
                    .lineStyle(StrokeStyle(lineWidth: 1))
                    .annotation(position: .top, spacing: 2,
                                overflowResolution: .init(x: .fit(to: .chart), y: .disabled)) {
                        ChartTooltip(text: "\(xFormat(t))  \(L(Self.labelKey(state(at: t))))")
                    }
            }
        }
        .chartXScale(domain: x0...max(x1, x0 + 1))
        .chartYScale(domain: -0.5...2.5)
        .chartLegend(.hidden)
        .chartYAxis {
            AxisMarks(position: .leading, values: [0.0, 1.0, 2.0]) { value in
                AxisValueLabel {
                    if let d = value.as(Double.self) {
                        Text(d > 1.5 ? L("app_sleep_awake") : (d > 0.5 ? L("app_sleep_light") : L("app_sleep_deep")))
                            .font(.system(size: 10))
                            .foregroundStyle(theme.chartAxisText)
                    }
                }
            }
        }
        .chartOverlay { proxy in
            ChartScrubOverlay(proxy: proxy, x0: x0, x1: x1, scrub: $scrub)
        }
        .frame(height: height)

        if showXAxis {
            chart.chartXAxis {
                AxisMarks(values: timeTicks(x0: x0, x1: x1)) { value in
                    AxisTick().foregroundStyle(theme.chartGrid)
                    AxisValueLabel {
                        if let d = value.as(Double.self) {
                            Text(xFormat(d))
                                .font(.system(size: 10))
                                .foregroundStyle(theme.chartAxisText)
                        }
                    }
                }
            }
        } else {
            chart.chartXAxis(.hidden)
        }
    }

    private func state(at t: Double) -> SleepState {
        var last: SleepState = .unknown
        for (ts, s) in states {
            if ts > t { break }
            last = s
        }
        return last
    }
}

// MARK: - MotionPanel

/// Movement as thin bars (one per epoch), zero-based y.
struct MotionPanel: View {
    @Environment(\.theme) private var theme
    private let points: [TimePoint]
    private let x0: Double
    private let x1: Double
    private let height: CGFloat
    private let bands: [(Double, Double)]
    private let bandColor: Color
    private let guides: GuideSpec?
    @Binding private var scrub: Double?
    private let xFormat: (Double) -> String
    private let showXAxis: Bool
    private let yHi: Double
    private let yStep: Double

    init(points: [TimePoint],
         x0: Double, x1: Double,
         height: CGFloat = 90,
         bands: [(Double, Double)] = [],
         bandColor: Color = Aurora.fuchsia.opacity(0.14),
         guides: GuideSpec? = nil,
         scrub: Binding<Double?> = .constant(nil),
         xFormat: @escaping (Double) -> String = { fmtHm($0) },
         showXAxis: Bool = false) {
        self.points = points
        self.x0 = x0
        self.x1 = x1
        self.height = height
        self.bands = bands
        self.bandColor = bandColor
        self.guides = guides
        self._scrub = scrub
        self.xFormat = xFormat
        self.showXAxis = showXAxis
        let hi = max(max(points.map(\.v).max() ?? 100, 50), (guides?.highMin ?? 0) * 1.1)
        let (_, b1) = niceBounds(0, hi, padFrac: 0.02)
        self.yHi = b1
        self.yStep = niceStep(b1, targetTicks: 2)
    }

    var body: some View {
        let chart = Chart {
            guideMarks(guides, yLo: 0, yHi: yHi, labelColor: theme.chartAxisText)
            bandMarks(bands, color: bandColor)
            ForEach(points) { p in
                BarMark(x: .value("Time", p.t), y: .value("Motion", p.v), width: .fixed(2))
                    .foregroundStyle(Aurora.seriesMotion)
                    .cornerRadius(1)
            }
            if let t = scrub {
                RuleMark(x: .value("Time", t))
                    .foregroundStyle(theme.chartAxisText.opacity(0.7))
                    .lineStyle(StrokeStyle(lineWidth: 1))
                    .annotation(position: .top, spacing: 2,
                                overflowResolution: .init(x: .fit(to: .chart), y: .disabled)) {
                        if let p = nearestPoint(points, to: t) {
                            ChartTooltip(text: "\(xFormat(t))  \(L("app_movement")) \(Int(p.v))")
                        }
                    }
            }
        }
        .chartXScale(domain: x0...max(x1, x0 + 1))
        .chartYScale(domain: 0...yHi)
        .chartLegend(.hidden)
        .chartYAxis {
            AxisMarks(position: .leading, values: yTickValues(0, yHi, step: yStep)) { value in
                AxisGridLine().foregroundStyle(theme.chartGrid)
                AxisValueLabel {
                    if let d = value.as(Double.self) {
                        Text(fmtNum(d, 0))
                            .font(.system(size: 10))
                            .foregroundStyle(theme.chartAxisText)
                    }
                }
            }
        }
        .chartOverlay { proxy in
            ChartScrubOverlay(proxy: proxy, x0: x0, x1: x1, scrub: $scrub)
        }
        .frame(height: height)

        if showXAxis {
            chart.chartXAxis {
                AxisMarks(values: timeTicks(x0: x0, x1: x1)) { value in
                    AxisTick().foregroundStyle(theme.chartGrid)
                    AxisValueLabel {
                        if let d = value.as(Double.self) {
                            Text(xFormat(d))
                                .font(.system(size: 10))
                                .foregroundStyle(theme.chartAxisText)
                        }
                    }
                }
            }
        } else {
            chart.chartXAxis(.hidden)
        }
    }
}

// MARK: - DotPanel

/// Dots for sparse series (HR, HRV): filled when valid, hollow when not; optional smooth
/// connecting line through the valid points.
struct DotPanel: View {
    private struct DotP: Identifiable {
        var t: Double
        var v: Double
        var valid: Bool
        var id: Double { t }
    }

    @Environment(\.theme) private var theme
    private let name: String
    private let points: [DotP]
    private let color: Color
    private let x0: Double
    private let x1: Double
    private let height: CGFloat
    private let unit: String
    private let decimals: Int
    private let connect: Bool
    private let bands: [(Double, Double)]
    private let bandColor: Color
    private let guides: GuideSpec?
    @Binding private var scrub: Double?
    private let xFormat: (Double) -> String
    private let showXAxis: Bool
    private let yLo: Double
    private let yHi: Double
    private let yStep: Double

    init(name: String,
         points: [(t: Double, v: Double, valid: Bool)],
         color: Color,
         x0: Double, x1: Double,
         height: CGFloat = 120,
         unit: String = "",
         decimals: Int = 0,
         connect: Bool = false,
         bands: [(Double, Double)] = [],
         bandColor: Color = Aurora.fuchsia.opacity(0.14),
         guides: GuideSpec? = nil,
         scrub: Binding<Double?> = .constant(nil),
         xFormat: @escaping (Double) -> String = { fmtHm($0) },
         showXAxis: Bool = false) {
        self.name = name
        self.points = points.map { DotP(t: $0.t, v: $0.v, valid: $0.valid) }
        self.color = color
        self.x0 = x0
        self.x1 = x1
        self.height = height
        self.unit = unit
        self.decimals = decimals
        self.connect = connect
        self.bands = bands
        self.bandColor = bandColor
        self.guides = guides
        self._scrub = scrub
        self.xFormat = xFormat
        self.showXAxis = showXAxis
        let vals = points.map { $0.v }
        let lo = min(vals.min() ?? 0, guides?.lowMax ?? .greatestFiniteMagnitude)
        let hi = max(vals.max() ?? 1, guides?.highMin ?? -.greatestFiniteMagnitude)
        let (b0, b1) = niceBounds(lo, hi)
        self.yLo = b0
        self.yHi = b1
        self.yStep = niceStep(b1 - b0)
    }

    var body: some View {
        let valid = points.filter(\.valid)
        let invalid = points.filter { !$0.valid }
        let chart = Chart {
            guideMarks(guides, yLo: yLo, yHi: yHi, labelColor: theme.chartAxisText)
            bandMarks(bands, color: bandColor)
            if connect {
                ForEach(valid) { p in
                    LineMark(x: .value("Time", p.t), y: .value("Value", p.v))
                        .interpolationMethod(.catmullRom)
                        .lineStyle(StrokeStyle(lineWidth: 1.5))
                        .foregroundStyle(color.opacity(0.5))
                }
            }
            ForEach(valid) { p in
                PointMark(x: .value("Time", p.t), y: .value("Value", p.v))
                    .foregroundStyle(color)
                    .symbolSize(60)
            }
            ForEach(invalid) { p in
                PointMark(x: .value("Time", p.t), y: .value("Value", p.v))
                    .symbol {
                        Circle()
                            .stroke(color.opacity(0.7), lineWidth: 1.5)
                            .frame(width: 7, height: 7)
                    }
            }
            if let t = scrub, let p = points.min(by: { abs($0.t - t) < abs($1.t - t) }) {
                RuleMark(x: .value("Time", t))
                    .foregroundStyle(theme.chartAxisText.opacity(0.7))
                    .lineStyle(StrokeStyle(lineWidth: 1))
                    .annotation(position: .top, spacing: 2,
                                overflowResolution: .init(x: .fit(to: .chart), y: .disabled)) {
                        ChartTooltip(text: p.valid
                            ? "\(xFormat(p.t))  \(name) \(fmtNum(p.v, decimals))\(unit)"
                            : "\(xFormat(p.t))  \(name) — \(L("app_not_enough_signal"))")
                    }
            }
        }
        .chartXScale(domain: x0...max(x1, x0 + 1))
        .chartYScale(domain: yLo...yHi)
        .chartLegend(.hidden)
        .chartYAxis {
            AxisMarks(position: .leading, values: yTickValues(yLo, yHi, step: yStep)) { value in
                AxisGridLine().foregroundStyle(theme.chartGrid)
                AxisValueLabel {
                    if let d = value.as(Double.self) {
                        Text(fmtNum(d, 0))
                            .font(.system(size: 10))
                            .foregroundStyle(theme.chartAxisText)
                    }
                }
            }
        }
        .chartOverlay { proxy in
            ChartScrubOverlay(proxy: proxy, x0: x0, x1: x1, scrub: $scrub)
        }
        .frame(height: height)

        if showXAxis {
            chart.chartXAxis {
                AxisMarks(values: timeTicks(x0: x0, x1: x1)) { value in
                    AxisTick().foregroundStyle(theme.chartGrid)
                    AxisValueLabel {
                        if let d = value.as(Double.self) {
                            Text(xFormat(d))
                                .font(.system(size: 10))
                                .foregroundStyle(theme.chartAxisText)
                        }
                    }
                }
            }
        } else {
            chart.chartXAxis(.hidden)
        }
    }
}
