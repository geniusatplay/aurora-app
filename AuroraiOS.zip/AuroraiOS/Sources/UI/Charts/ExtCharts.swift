// Extended-sensor chart pieces — the iOS port of ui/charts/ExtCharts.kt.
//
// Stacked panels for the extended-sensor channels (ext brief §6): sweat conductance (µS),
// blood flow (perfusion index %), blood oxygen (%). Single series each, shared x-domain
// with the existing panels, one y-axis per panel — never dual-axis. Bundle spans are drawn
// as 0.10-alpha fuchsia background shading via the existing band mechanism (LinePanel
// `bands`/`bandColor`). Channel colours come from @Environment(\.theme) so light/dark
// variants apply; they NEVER vary with the Vital Sheet scheme.

import SwiftUI

/// Bundle shading colour — 0.10 opacity fuchsia across ALL panels (ext brief §6).
let BundleBandColor = Aurora.fuchsia.opacity(0.10)

/// UI-owned Low/Medium/High reference bands for the new channels (shown behind the existing
/// showRanges setting). Guides only — not medical limits, mirroring Domain/Ranges.swift style.
enum ExtGuideBands {
    static let conductanceLowMax = 2.0   // µS
    static let conductanceHighMin = 8.0
    static let bloodFlowLowMax = 1.0     // PI %
    static let bloodFlowHighMin = 4.0
    static let oxygenLowMax = 94.0       // % SpO2 — higher is the reassuring side
    static let oxygenHighMin = 97.0

    /// Level chip helper for the extended channels (same low/high semantics as RangeGuide).
    static func level(_ v: Double, lowMax: Double, highMin: Double) -> Level {
        if v < lowMax { return .low }
        if v > highMin { return .high }
        return .medium
    }
}

/// Guides for an extended channel, or nil when range guides are off.
func extGuides(_ show: Bool, lowMax: Double, highMin: Double, higherIsBetter: Bool = false) -> GuideSpec? {
    show ? GuideSpec(lowMax: lowMax, highMin: highMin, higherIsBetter: higherIsBetter) : nil
}

// MARK: - ConductancePanel

/// Sweat conductance panel — µS, 1 decimal, teal, area fill like the sweat-moisture panel.
struct ConductancePanel: View {
    @Environment(\.theme) private var theme
    let name: String
    let points: [TimePoint]
    let x0: Double
    let x1: Double
    var height: CGFloat = 140
    var bands: [(Double, Double)] = []
    var guides: GuideSpec? = nil
    @Binding var scrub: Double?
    var xFormat: (Double) -> String = { fmtHm($0) }
    var showXAxis: Bool = false

    var body: some View {
        LinePanel(series: [(name: name, color: theme.seriesConductance, points: points, area: true)],
                  x0: x0, x1: x1, height: height,
                  unit: " µS", decimals: 1,
                  bands: bands, bandColor: BundleBandColor,
                  guides: guides, scrub: $scrub, xFormat: xFormat, showXAxis: showXAxis)
    }
}

// MARK: - BloodFlowPanel

/// Blood flow (perfusion index) panel — %, 1 decimal, orange.
struct BloodFlowPanel: View {
    @Environment(\.theme) private var theme
    let name: String
    let points: [TimePoint]
    let x0: Double
    let x1: Double
    var height: CGFloat = 120
    var bands: [(Double, Double)] = []
    var guides: GuideSpec? = nil
    @Binding var scrub: Double?
    var xFormat: (Double) -> String = { fmtHm($0) }
    var showXAxis: Bool = false

    var body: some View {
        LinePanel(series: [(name: name, color: theme.seriesBloodFlow, points: points, area: false)],
                  x0: x0, x1: x1, height: height,
                  unit: "%", decimals: 1,
                  bands: bands, bandColor: BundleBandColor,
                  guides: guides, scrub: $scrub, xFormat: xFormat, showXAxis: showXAxis)
    }
}

// MARK: - OxygenPanel

/// Blood oxygen panel — %, 1 decimal, violet.
struct OxygenPanel: View {
    @Environment(\.theme) private var theme
    let name: String
    let points: [TimePoint]
    let x0: Double
    let x1: Double
    var height: CGFloat = 120
    var bands: [(Double, Double)] = []
    var guides: GuideSpec? = nil
    @Binding var scrub: Double?
    var xFormat: (Double) -> String = { fmtHm($0) }
    var showXAxis: Bool = false

    var body: some View {
        LinePanel(series: [(name: name, color: theme.seriesOxygen, points: points, area: false)],
                  x0: x0, x1: x1, height: height,
                  unit: "%", decimals: 1,
                  bands: bands, bandColor: BundleBandColor,
                  guides: guides, scrub: $scrub, xFormat: xFormat, showXAxis: showXAxis)
    }
}

// MARK: - BundleTimelineStrip

/// The night as one horizontal band (Vital Sheet header, ext brief §4.2): quiet = neutral
/// track, each flash bundle a rounded fuchsia block (width = duration), wake-ups as ticks.
struct BundleTimelineStrip: View {
    @Environment(\.theme) private var theme
    let bundles: [(Double, Double)]
    let wakes: [Double]
    let x0: Double
    let x1: Double
    var height: CGFloat = 36

    var body: some View {
        Canvas { context, size in
            let bandH = size.height * 0.52
            let top = (size.height - bandH) / 2
            let span = max(x1 - x0, 1)
            func px(_ t: Double) -> CGFloat {
                CGFloat(min(max((t - x0) / span, 0), 1)) * size.width
            }
            let radius = bandH / 2
            context.fill(
                Path(roundedRect: CGRect(x: 0, y: top, width: size.width, height: bandH),
                     cornerRadius: radius),
                with: .color(theme.track)
            )
            for (a, b) in bundles {
                let xA = px(a)
                let w = max(px(b) - xA, 3)
                context.fill(
                    Path(roundedRect: CGRect(x: xA, y: top, width: w, height: bandH),
                         cornerRadius: radius),
                    with: .color(Aurora.fuchsia)
                )
            }
            for t in wakes {
                let x = px(t)
                var tick = Path()
                tick.move(to: CGPoint(x: x, y: top - 4))
                tick.addLine(to: CGPoint(x: x, y: top))
                context.stroke(tick, with: .color(theme.chartAxisText), lineWidth: 1.5)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: height)
    }
}
