// Summary charts (Swift Charts) — the iOS port of ui/charts/SummaryCharts.kt.
//
// SleepRing (donut), TrendBars / StackedBars (Trends screen) and Sparkline (cards).
// Same theme rules as Charts.swift: theme.chartGrid grid, theme.chartAxisText labels,
// clear background, one y-axis, no dual axis.

import SwiftUI
import Charts

// MARK: - SleepRing

/// Three-segment donut: wake / light / deep with a centre label (duration + caption).
/// Segments start at 12 o'clock in the order deep → light → wake, like Android.
struct SleepRing: View {
    @Environment(\.theme) private var theme
    private let pctWake: Int
    private let pctLight: Int
    private let pctDeep: Int
    private let size: CGFloat
    private let centerTop: String
    private let centerBottom: String

    init(pctWake: Int, pctLight: Int, pctDeep: Int,
         size: CGFloat = 120,
         centerTop: String, centerBottom: String) {
        self.pctWake = pctWake
        self.pctLight = pctLight
        self.pctDeep = pctDeep
        self.size = size
        self.centerTop = centerTop
        self.centerBottom = centerBottom
    }

    var body: some View {
        let segments: [(String, Int, Color)] = [
            (L("app_sleep_deep"), pctDeep, Aurora.sleepDeep),
            (L("app_sleep_light"), pctLight, Aurora.sleepLight),
            (L("app_sleep_awake"), pctWake, Aurora.sleepWake),
        ]
        let total = pctWake + pctLight + pctDeep
        ZStack {
            if total > 0 {
                Chart {
                    ForEach(segments.indices, id: \.self) { i in
                        SectorMark(angle: .value("Pct", Double(segments[i].1)),
                                   innerRadius: .ratio(0.72),
                                   angularInset: 1.5)
                            .foregroundStyle(segments[i].2)
                    }
                }
                .chartLegend(.hidden)
            } else {
                // No classified epochs yet: an empty track ring.
                Circle()
                    .stroke(theme.track, lineWidth: 12)
                    .padding(6)
            }
            VStack(spacing: 2) {
                Text(centerTop)
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
                Text(centerBottom)
                    .font(AuroraFont.labelS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
        .frame(width: size, height: size)
    }
}

// MARK: - TrendBars

/// One bar per night. Non-highlighted bars are dimmed; tap a bar for its value
/// (tap again to dismiss). Labels must be unique (they are night dates).
struct TrendBars: View {
    private struct Datum: Identifiable {
        var id: Int
        var label: String
        var value: Double
        var highlight: Bool
    }

    @Environment(\.theme) private var theme
    @State private var selected: Int? = nil
    private let data: [Datum]
    private let color: Color
    private let height: CGFloat
    private let unit: String
    private let decimals: Int
    private let yTop: Double
    private let yStep: Double

    init(data: [(label: String, value: Double, highlight: Bool)],
         color: Color,
         height: CGFloat = 170,
         unit: String = "",
         decimals: Int = 0) {
        self.data = data.enumerated().map { i, d in
            Datum(id: i, label: d.label, value: d.value, highlight: d.highlight)
        }
        self.color = color
        self.height = height
        self.unit = unit
        self.decimals = decimals
        let maxV = max(data.map { $0.value }.max() ?? 1, 1)
        let (_, top) = niceBounds(0, maxV, targetTicks: 3, padFrac: 0.05)
        self.yTop = top
        self.yStep = niceStep(top, targetTicks: 3)
    }

    var body: some View {
        let yDecimals = yStep < 1 ? 1 : 0
        Chart {
            ForEach(data) { d in
                BarMark(x: .value("Night", d.label), y: .value("Value", d.value))
                    .foregroundStyle((d.highlight || selected == d.id) ? color : color.opacity(0.55))
                    .cornerRadius(4)
                    .annotation(position: .top, spacing: 2,
                                overflowResolution: .init(x: .fit(to: .chart), y: .disabled)) {
                        if selected == d.id {
                            ChartTooltip(text: "\(d.label): \(fmtNum(d.value, decimals))\(unit)")
                        }
                    }
            }
        }
        .chartXScale(domain: data.map(\.label))
        .chartYScale(domain: 0...yTop)
        .chartLegend(.hidden)
        .chartYAxis {
            AxisMarks(position: .leading, values: yTickValues(0, yTop, step: yStep)) { value in
                AxisGridLine().foregroundStyle(theme.chartGrid)
                AxisValueLabel {
                    if let d = value.as(Double.self) {
                        Text(fmtNum(d, yDecimals))
                            .font(.system(size: 10))
                            .foregroundStyle(theme.chartAxisText)
                    }
                }
            }
        }
        .chartXAxis {
            AxisMarks { value in
                AxisValueLabel {
                    if let s = value.as(String.self) {
                        Text(s)
                            .font(.system(size: 10))
                            .foregroundStyle(theme.chartAxisText)
                    }
                }
            }
        }
        .chartOverlay { proxy in
            barTapCatcher(proxy: proxy)
        }
        .frame(height: height)
    }

    private func barTapCatcher(proxy: ChartProxy) -> some View {
        GeometryReader { geo in
            Rectangle()
                .fill(Color.clear)
                .contentShape(Rectangle())
                .onTapGesture { location in
                    guard let pf = proxy.plotFrame else { return }
                    let rect = geo[pf]
                    if let label = proxy.value(atX: location.x - rect.origin.x, as: String.self),
                       let hit = data.first(where: { $0.label == label }) {
                        selected = (selected == hit.id) ? nil : hit.id
                    } else {
                        selected = nil
                    }
                }
        }
    }
}

// MARK: - StackedBars

/// 100%-stacked composition bars (sleep stages per night). `parts` are raw values in the
/// order matching `colors` and `partLabelKeys` (localization keys, e.g. app_sleep_deep);
/// each bar is normalised to 100%. Tap a bar for its breakdown.
struct StackedBars: View {
    private struct Datum: Identifiable {
        var id: Int
        var label: String
        var parts: [Double]
    }

    @Environment(\.theme) private var theme
    @State private var selected: Int? = nil
    private let data: [Datum]
    private let colors: [Color]
    private let partNames: [String]
    private let height: CGFloat

    init(data: [(label: String, parts: [Double])],
         colors: [Color],
         partLabelKeys: [String],
         height: CGFloat = 170) {
        self.data = data.enumerated().map { i, d in
            Datum(id: i, label: d.label, parts: d.parts)
        }
        self.colors = colors
        self.partNames = partLabelKeys.map { L($0) }
        self.height = height
    }

    var body: some View {
        Chart {
            ForEach(data) { d in
                let total = max(d.parts.reduce(0, +), 1e-9)
                ForEach(d.parts.indices, id: \.self) { k in
                    BarMark(x: .value("Night", d.label),
                            y: .value("Pct", d.parts[k] / total * 100))
                        .foregroundStyle(by: .value("Part", partNames.indices.contains(k) ? partNames[k] : ""))
                        .cornerRadius(3)
                        .opacity(selected == nil || selected == d.id ? 1 : 0.55)
                }
            }
        }
        .chartXScale(domain: data.map(\.label))
        .chartYScale(domain: 0...100)
        .chartForegroundStyleScale(domain: partNames, range: colors)
        .chartLegend(.visible)
        .chartYAxis {
            AxisMarks(position: .leading, values: [0.0, 25.0, 50.0, 75.0, 100.0]) { value in
                AxisGridLine().foregroundStyle(theme.chartGrid)
                AxisValueLabel {
                    if let d = value.as(Double.self) {
                        Text("\(Int(d))%")
                            .font(.system(size: 10))
                            .foregroundStyle(theme.chartAxisText)
                    }
                }
            }
        }
        .chartXAxis {
            AxisMarks { value in
                AxisValueLabel {
                    if let s = value.as(String.self) {
                        Text(s)
                            .font(.system(size: 10))
                            .foregroundStyle(theme.chartAxisText)
                    }
                }
            }
        }
        .chartOverlay { proxy in
            stackTapCatcher(proxy: proxy)
        }
        // The tooltip floats over the top of the plot (Android drew it there too).
        .overlay(alignment: .top) {
            if let sel = selected, let d = data.first(where: { $0.id == sel }) {
                ChartTooltip(text: breakdownText(d))
                    .padding(.top, 2)
            }
        }
        .frame(height: height)
    }

    private func breakdownText(_ d: Datum) -> String {
        let total = max(d.parts.reduce(0, +), 1e-9)
        let parts = d.parts.indices.map { k -> String in
            let name = partNames.indices.contains(k) ? partNames[k] : ""
            return "\(name) \(Int((d.parts[k] / total * 100).rounded()))%"
        }
        return "\(d.label): " + parts.joined(separator: " · ")
    }

    private func stackTapCatcher(proxy: ChartProxy) -> some View {
        GeometryReader { geo in
            Rectangle()
                .fill(Color.clear)
                .contentShape(Rectangle())
                .onTapGesture { location in
                    guard let pf = proxy.plotFrame else { return }
                    let rect = geo[pf]
                    if let label = proxy.value(atX: location.x - rect.origin.x, as: String.self),
                       let hit = data.first(where: { $0.label == label }) {
                        selected = (selected == hit.id) ? nil : hit.id
                    } else {
                        selected = nil
                    }
                }
        }
    }
}

// MARK: - Sparkline

/// Tiny axis-less trend line for cards. Size it with .frame from the caller.
struct Sparkline: View {
    private let values: [Double]
    private let color: Color

    init(values: [Double], color: Color) {
        self.values = values
        self.color = color
    }

    var body: some View {
        if values.count < 2 {
            Color.clear
        } else {
            let lo = values.min() ?? 0
            let hi = values.max() ?? 1
            let pad = max((hi - lo) * 0.1, 0.001)
            Chart {
                ForEach(values.indices, id: \.self) { i in
                    LineMark(x: .value("i", i), y: .value("v", values[i]))
                        .interpolationMethod(.catmullRom)
                        .lineStyle(StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                        .foregroundStyle(color)
                }
                PointMark(x: .value("i", values.count - 1), y: .value("v", values[values.count - 1]))
                    .foregroundStyle(color)
                    .symbolSize(40)
            }
            .chartXAxis(.hidden)
            .chartYAxis(.hidden)
            .chartLegend(.hidden)
            .chartYScale(domain: (lo - pad)...(hi + pad))
            .chartXScale(domain: 0...(values.count - 1))
        }
    }
}

// MARK: - shared tick helper (also used by TrendBars)

/// y tick values from an aligned lower bound. (Internal twin of the one in Charts.swift,
/// kept here so each file stands alone; fileprivate to avoid a duplicate symbol.)
fileprivate func yTickValues(_ lo: Double, _ hi: Double, step: Double) -> [Double] {
    var v = lo
    var out: [Double] = []
    while v <= hi + 1e-6 { out.append(v); v += step }
    return out
}
