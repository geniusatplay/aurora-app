// "Add section" — the section library: a searchable, scrollable list grouped by category
// (Live, Nights, Trends, Pod, Diagnostics). Each row shows the section's name, a one-line
// description and "+ Add"; tapping the row adds it to the end of the page. Sections
// already on this page show "Added" (one copy per page; the same section may be on
// several pages).

import SwiftUI

struct SectionLibrarySheet: View {
    @EnvironmentObject private var store: CustomPagesStore
    @Environment(\.theme) private var theme
    @Environment(\.dismiss) private var dismiss

    let pageNumber: Int

    @State private var query = ""

    var body: some View {
        NavigationStack {
            List {
                ForEach(SectionCategory.allCases) { category in
                    let items = matches(in: category)
                    if !items.isEmpty {
                        Section {
                            ForEach(items) { id in
                                row(id)
                                    .listRowBackground(theme.card)
                            }
                        } header: {
                            Text(L(category.titleKey))
                        }
                    }
                }
                if noMatches {
                    Text(L("cp_library_no_match"))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                        .listRowBackground(Color.clear)
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .background(theme.background.ignoresSafeArea())
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always),
                        prompt: Text(L("cp_library_search")))
            .navigationTitle(L("cp_library_title", pageNumber))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        dismiss()
                    } label: {
                        Text(L("cp_done")).fontWeight(.semibold)
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }

    // MARK: - Rows

    private func row(_ id: SectionId) -> some View {
        let added = store.contains(id.rawValue, on: pageNumber)
        return Button {
            if !added { store.addSection(id.rawValue, to: pageNumber) }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: id.icon)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(theme.primary)
                    .frame(width: 26)
                VStack(alignment: .leading, spacing: 2) {
                    Text(L(id.nameKey))
                        .font(AuroraFont.titleS())
                        .foregroundStyle(theme.textPrimary)
                    Text(L(id.descKey))
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 8)
                if added {
                    Label(L("cp_added"), systemImage: "checkmark")
                        .font(AuroraFont.labelS())
                        .foregroundStyle(theme.textSecondary)
                        .labelStyle(.titleAndIcon)
                } else {
                    Text(L("cp_add"))
                        .font(AuroraFont.labelS())
                        .foregroundStyle(theme.onPrimary)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Capsule().fill(theme.primary))
                }
            }
            .padding(.vertical, 2)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(added)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(L(id.nameKey) + ", " + L(id.descKey))
        .accessibilityValue(added ? L("cp_added") : "")
        .accessibilityHint(added ? "" : L("cp_add_hint"))
    }

    // MARK: - Search

    private var trimmedQuery: String {
        query.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func matches(in category: SectionCategory) -> [SectionId] {
        let q = trimmedQuery
        let all = SectionId.inCategory(category)
        guard !q.isEmpty else { return all }
        let categoryHit = L(category.titleKey).localizedStandardContains(q)
        return all.filter { id in
            categoryHit
                || L(id.nameKey).localizedStandardContains(q)
                || L(id.descKey).localizedStandardContains(q)
                || id.rawValue.localizedStandardContains(q)
        }
    }

    private var noMatches: Bool {
        SectionCategory.allCases.allSatisfy { matches(in: $0).isEmpty }
    }
}
