// Custom pages — the section catalogue (stable IDs shared with Android and the web app,
// CUSTOM_PAGES_BRIEF.md) and `SectionView(id:)`, which renders each section with the SAME
// live data and look as the screen it comes from, by reusing that screen's views
// (LiveHeartRateCard, NightChartsCard, TrendFlashesCard, PodConnectionCard, …).
//
// Every catalogue section has iPhone data. When there is nothing to show yet (no pod
// connected, no finished night, fewer than two nights for a trend) the section renders a
// short explanatory card instead — never fake data.

import SwiftUI

// MARK: - Catalogue

enum SectionCategory: String, CaseIterable, Identifiable {
    case live, nights, trends, pod, diagnostics

    var id: String { rawValue }

    /// Localization key of the library group title.
    var titleKey: String { "cp_cat_" + rawValue }
}

/// Stable section IDs (persisted in `custom_pages`). Declaration order = library order.
enum SectionId: String, CaseIterable, Identifiable {
    // Live
    case liveHr = "live_hr"
    case liveMoisture = "live_moisture"
    case liveSkinTemp = "live_skin_temp"
    case liveSkinRh = "live_skin_rh"
    case liveSpo2 = "live_spo2"
    case liveQuality = "live_quality"
    case liveStatus = "live_status"
    case liveChart = "live_chart"
    case liveHrv = "live_hrv"
    case liveConductance = "live_conductance"
    case sessionControls = "session_controls"
    // Nights
    case lastNight = "last_night"
    case morningCard = "morning_card"
    case nightTimeline = "night_timeline"
    case vitalSheet = "vital_sheet"
    case recentNights = "recent_nights"
    case sweatEvents = "sweat_events"
    // Trends
    case trendsOverview = "trends_overview"
    case trendsFlashes = "trends_flashes"
    case trendsHr = "trends_hr"
    case trendsTimeInBed = "trends_time_in_bed"
    case trendsSleep = "trends_sleep"
    // Pod
    case podConnection = "pod_connection"
    case podInfo = "pod_info"
    case podLog = "pod_log"
    case podControls = "pod_controls"
    case demoControls = "demo_controls"
    // Diagnostics
    case linkHealth = "link_health"
    case packetInspector = "packet_inspector"
    case hardwareCheck = "hardware_check"

    var id: String { rawValue }

    /// Localization keys of the library name / one-line description.
    var nameKey: String { "cp_sec_" + rawValue }
    var descKey: String { "cp_sec_" + rawValue + "_desc" }

    var category: SectionCategory {
        switch self {
        case .liveHr, .liveMoisture, .liveSkinTemp, .liveSkinRh, .liveSpo2, .liveQuality,
             .liveStatus, .liveChart, .liveHrv, .liveConductance, .sessionControls:
            return .live
        case .lastNight, .morningCard, .nightTimeline, .vitalSheet, .recentNights, .sweatEvents:
            return .nights
        case .trendsOverview, .trendsFlashes, .trendsHr, .trendsTimeInBed, .trendsSleep:
            return .trends
        case .podConnection, .podInfo, .podLog, .podControls, .demoControls:
            return .pod
        case .linkHealth, .packetInspector, .hardwareCheck:
            return .diagnostics
        }
    }

    /// SF Symbol shown in the library and in edit mode.
    var icon: String {
        switch self {
        case .liveHr: return "heart.fill"
        case .liveMoisture: return "drop.fill"
        case .liveSkinTemp: return "thermometer.medium"
        case .liveSkinRh: return "humidity.fill"
        case .liveSpo2: return "lungs.fill"
        case .liveQuality: return "speedometer"
        case .liveStatus: return "checklist"
        case .liveChart: return "chart.xyaxis.line"
        case .liveHrv: return "waveform.path.ecg"
        case .liveConductance: return "bolt.heart.fill"
        case .sessionControls: return "record.circle"
        case .lastNight: return "moon.stars.fill"
        case .morningCard: return "sunrise.fill"
        case .nightTimeline: return "chart.line.uptrend.xyaxis"
        case .vitalSheet: return "doc.text.fill"
        case .recentNights: return "list.bullet"
        case .sweatEvents: return "drop.triangle.fill"
        case .trendsOverview: return "square.grid.2x2.fill"
        case .trendsFlashes: return "chart.bar.fill"
        case .trendsHr: return "heart.text.square.fill"
        case .trendsTimeInBed: return "bed.double.fill"
        case .trendsSleep: return "moon.zzz.fill"
        case .podConnection: return "antenna.radiowaves.left.and.right"
        case .podInfo: return "info.circle.fill"
        case .podLog: return "arrow.down.circle.fill"
        case .podControls: return "slider.horizontal.3"
        case .demoControls: return "play.circle.fill"
        case .linkHealth: return "waveform"
        case .packetInspector: return "terminal"
        case .hardwareCheck: return "checkmark.seal.fill"
        }
    }

    static func inCategory(_ category: SectionCategory) -> [SectionId] {
        allCases.filter { $0.category == category }
    }
}

// MARK: - Navigation actions available to sections

/// What a section may ask its host to do (push a night, switch tab, open the demo sheet).
/// RootView injects the real closures for each custom page's NavigationStack.
struct SectionActions {
    var openNight: (UUID) -> Void = { _ in }
    var openVitalSheet: (UUID) -> Void = { _ in }
    var openPod: () -> Void = {}
    var openDemo: () -> Void = {}
}

private struct SectionActionsKey: EnvironmentKey {
    static let defaultValue = SectionActions()
}

extension EnvironmentValues {
    var sectionActions: SectionActions {
        get { self[SectionActionsKey.self] }
        set { self[SectionActionsKey.self] = newValue }
    }
}

// MARK: - SectionView

/// Renders one catalogue section with real data.
struct SectionView: View {
    let id: SectionId

    var body: some View {
        switch id.category {
        case .live: LiveSection(id: id)
        case .nights: NightSection(id: id)
        case .trends: TrendSection(id: id)
        case .pod: PodSection(id: id)
        case .diagnostics: DiagnosticsSection(id: id)
        }
    }
}

// MARK: - Shared placeholder

/// Section title + one honest sentence (+ optional action) when there is nothing to show.
struct SectionPlaceholderCard: View {
    @Environment(\.theme) private var theme
    let id: SectionId
    let message: String
    var actionTitle: String? = nil
    var action: (() -> Void)? = nil

    var body: some View {
        AuroraCard {
            HStack(spacing: 8) {
                Image(systemName: id.icon)
                    .foregroundStyle(theme.primary)
                Text(L(id.nameKey))
                    .font(AuroraFont.titleL())
                    .foregroundStyle(theme.textPrimary)
                Spacer(minLength: 0)
            }
            VSpace(6)
            Text(message)
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            if let actionTitle, let action {
                VSpace(10)
                Button(action: action) {
                    Text(actionTitle)
                        .font(AuroraFont.label())
                }
                .buttonStyle(.bordered)
                .tint(theme.primary)
            }
        }
    }
}

/// Title row used by the cards this file builds itself (section icon + name).
private struct SectionTitleRow: View {
    @Environment(\.theme) private var theme
    let id: SectionId
    var trailing: String? = nil

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: id.icon)
                .foregroundStyle(theme.primary)
            Text(L(id.nameKey))
                .font(AuroraFont.titleL())
                .foregroundStyle(theme.textPrimary)
            Spacer(minLength: 0)
            if let trailing {
                Pill(text: trailing)
            }
        }
    }
}

// MARK: - Live

/// Live sections need a connected pod streaming vitals; otherwise a "connect" card.
private struct LiveGate<Content: View>: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.sectionActions) private var actions
    let id: SectionId
    let content: (LiveVitals) -> Content

    init(_ id: SectionId, @ViewBuilder content: @escaping (LiveVitals) -> Content) {
        self.id = id
        self.content = content
    }

    var body: some View {
        if pod.connectionState.isConnected, let vit = pod.latestVitals {
            content(vit)
        } else {
            SectionPlaceholderCard(id: id, message: L("cp_live_not_connected"),
                                   actionTitle: L("common_connect"), action: actions.openPod)
        }
    }
}

private struct LiveSection: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme
    let id: SectionId

    var body: some View {
        if id == .sessionControls {
            // Start / stop works (and explains itself) without live vitals.
            PodTonightCard()
        } else {
            LiveGate(id) { vit in
                live(vit)
            }
        }
    }

    @ViewBuilder
    private func live(_ vit: LiveVitals) -> some View {
        let show = settings.showRanges
        let asleep = vit.sleepState == .light || vit.sleepState == .deep
        let caps = pod.capabilities
        let showRoom = caps.roomClimate && HwAdapter.hasAmbient(vit.ambTempX100)
        switch id {
        case .liveHr:
            LiveHeartRateCard(vit: vit, show: show, asleep: asleep, caps: caps)
        case .liveMoisture:
            if caps.directAbsHumidity {
                LiveMoistureCard(vit: vit)
            } else if showRoom {
                // Demo / paper-spec pods: sweat moisture from skin vs room (same card as Live).
                LiveSweatCard(vit: vit, show: show)
            } else {
                SectionPlaceholderCard(id: id, message: L("cp_no_moisture"))
            }
        case .liveSkinTemp:
            LiveSkinTempCard(id: id, vit: vit, show: show)
        case .liveSkinRh:
            LiveSkinRhCard(id: id, vit: vit, show: show)
        case .liveSpo2:
            if caps.spo2Estimate {
                LiveSpo2Card()
            } else {
                SectionPlaceholderCard(id: id, message: L("cp_no_spo2"))
            }
        case .liveQuality:
            LiveQualityCard(id: id, vit: vit)
        case .liveStatus:
            LiveStatusCard(id: id, vit: vit)
        case .liveChart:
            if pod.liveWindow.count > 2 {
                VStack(alignment: .leading, spacing: 14) {
                    LiveChartsView(show: show, asleep: asleep, caps: caps, showRoom: showRoom)
                }
            } else {
                SectionPlaceholderCard(id: id, message: L("cp_chart_collecting"))
            }
        case .liveHrv:
            if let h = pod.latestHrv {
                LiveHrvCard(h: h, show: show, relativeOnly: caps.hrvRelativeOnly)
            } else {
                SectionPlaceholderCard(id: id, message: L("cp_hrv_waiting"))
            }
        case .liveConductance:
            if pod.hasExtendedSensors {
                LiveConductanceCard(show: show)
            } else {
                SectionPlaceholderCard(id: id, message: L("cp_no_conductance"))
            }
        default:
            EmptyView()
        }
    }
}

/// Skin temperature now (+ level when range guides are on) and its recent trace.
private struct LiveSkinTempCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var settings: AppSettings
    let id: SectionId
    let vit: LiveVitals
    let show: Bool

    var body: some View {
        let trail: [Double] = pod.liveWindow.map { settings.toDisplayTemp($0.skinTempC) }
        AuroraCard {
            SectionTitleRow(id: id)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("cp_now"), value: Fmt.temp(vit.skinTempC, settings),
                         accent: Aurora.seriesSkin,
                         level: show ? Ranges.skinTemp.levelOf(vit.skinTempC) : nil)
            }
            if trail.count > 2 {
                VSpace(10)
                Sparkline(values: trail, color: Aurora.seriesSkin)
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
            }
        }
    }
}

/// Relative humidity at the skin now (+ level) and its recent trace.
private struct LiveSkinRhCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    let id: SectionId
    let vit: LiveVitals
    let show: Bool

    var body: some View {
        let trail: [Double] = pod.liveWindow.map { $0.skinRh }
        AuroraCard {
            SectionTitleRow(id: id)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("cp_now"), value: String(format: "%.0f", vit.skinRh),
                         unit: "%", accent: Aurora.seriesSkin,
                         level: show ? Ranges.skinRh.levelOf(vit.skinRh) : nil)
            }
            if trail.count > 2 {
                VSpace(10)
                Sparkline(values: trail, color: Aurora.seriesSkin)
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
            }
        }
    }
}

/// The pod's 0–100 signal-quality figure with the app's confidence band.
private struct LiveQualityCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.theme) private var theme
    let id: SectionId
    let vit: LiveVitals

    var body: some View {
        let trail: [Double] = pod.liveWindow.map { Double($0.hrQuality) }
        AuroraCard {
            SectionTitleRow(id: id)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("cp_now"), value: "\(vit.hrQuality)", unit: L("cp_of_100"),
                         accent: theme.primary, note: bandText(QualityBand.of(vit.hrQuality)))
            }
            if trail.count > 2 {
                VSpace(10)
                Sparkline(values: trail, color: theme.primary)
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
            }
        }
    }

    private func bandText(_ band: QualityBand) -> String {
        switch band {
        case .hide: return L("cp_quality_too_low")
        case .lowConfidence: return L("cp_quality_low")
        case .normal: return L("cp_quality_good")
        }
    }
}

/// Pod flags as on/off chips: finger, HR lock, session, clock, flush/sweat, low battery.
private struct LiveStatusCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    let id: SectionId
    let vit: LiveVitals

    var body: some View {
        let hardware = pod.capabilities.directAbsHumidity
        let chips: [(String, Bool)] = [
            (L("cp_status_finger"), vit.ppgActive),
            (L("cp_status_hr_lock"), vit.hasHr),
            (L("cp_status_session"), vit.logging),
            (L("cp_status_clock"), pod.timeSynced),
            (hardware ? L("cp_status_flush") : L("cp_status_sweat"), vit.sweatFlag != SweatFlag.none),
            (L("cp_status_low_batt"), vit.lowBatt),
        ]
        AuroraCard {
            SectionTitleRow(id: id)
            VSpace(10)
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)],
                      alignment: .leading, spacing: 8) {
                ForEach(chips.indices, id: \.self) { i in
                    StatusChip(text: chips[i].0, on: chips[i].1)
                }
            }
        }
    }
}

private struct StatusChip: View {
    @Environment(\.theme) private var theme
    let text: String
    let on: Bool

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: on ? "checkmark.circle.fill" : "circle")
                .font(.system(size: 13, weight: .semibold))
            Text(text)
                .font(AuroraFont.labelS())
                .lineLimit(2)
                .multilineTextAlignment(.leading)
            Spacer(minLength: 0)
        }
        .foregroundStyle(on ? theme.primary : theme.textSecondary)
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(on ? theme.primary.opacity(0.14) : theme.cardAlt)
        )
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(text)
        .accessibilityValue(L(on ? "cp_on" : "cp_off"))
    }
}

// MARK: - Nights

/// Loads the latest finished night (re-fetched whenever the repository changes) and hands
/// it to `content`; without one, an honest empty card.
private struct LatestNightLoader<Content: View>: View {
    @EnvironmentObject private var repo: SessionRepository
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.sectionActions) private var actions
    let id: SectionId
    let content: (NightBundle) -> Content

    @State private var night: NightBundle?
    @State private var loaded = false

    init(id: SectionId, @ViewBuilder content: @escaping (NightBundle) -> Content) {
        self.id = id
        self.content = content
    }

    var body: some View {
        Group {
            if let night {
                content(night)
            } else if loaded {
                SectionPlaceholderCard(id: id, message: L("cp_no_night_yet"),
                                       actionTitle: L("home_try_demo"), action: actions.openDemo)
            } else {
                SectionPlaceholderCard(id: id, message: L("common_loading"))
            }
        }
        .onAppear { reload() }
        .onChange(of: repo.revision) { _, _ in reload() }
        .onChange(of: settings.userId) { _, _ in reload() }
    }

    private func reload() {
        if let uid = UUID(uuidString: settings.userId ?? "") {
            night = repo.latestCompletedNight(userId: uid)
        } else {
            night = nil
        }
        loaded = true
    }
}

private struct NightSection: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.sectionActions) private var actions
    let id: SectionId

    var body: some View {
        if id == .recentNights {
            RecentNightsSection(id: id)
        } else {
            LatestNightLoader(id: id) { night in
                content(night)
            }
        }
    }

    @ViewBuilder
    private func content(_ night: NightBundle) -> some View {
        switch id {
        case .lastNight:
            LastNightHero(night: night, onOpen: actions.openNight, onOpenVitalSheet: actions.openVitalSheet)
        case .morningCard:
            MorningCard(night: night, showRanges: settings.showRanges)
        case .nightTimeline:
            NightTimelineSection(id: id, night: night)
        case .vitalSheet:
            VitalSheetSection(id: id, night: night)
        case .sweatEvents:
            SweatEventsSection(id: id, night: night)
        default:
            EmptyView()
        }
    }
}

/// The latest night's stacked charts with flash-bundle shading (NightDetail's chart card).
private struct NightTimelineSection: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.sectionActions) private var actions
    @Environment(\.theme) private var theme
    let id: SectionId
    let night: NightBundle

    @State private var scrub: Double? = nil
    /// Cached like NightDetail: bundle detection over a full night is too heavy per frame.
    @State private var records: [LogRecord] = []
    @State private var bundles: [FlashBundle] = []
    @State private var cachedKey = ""

    private var key: String { night.session.id.uuidString + "-\(night.epochs.count)" }

    var body: some View {
        Group {
            if night.epochs.isEmpty {
                SectionPlaceholderCard(id: id, message: L("night_no_detail_offline"))
            } else if cachedKey != key {
                SectionPlaceholderCard(id: id, message: L("common_loading"))
            } else {
                let ctx = NightChartContext(bundle: night, records: records, bundles: bundles,
                                            settings: settings, caps: pod.capabilities)
                VStack(alignment: .leading, spacing: 10) {
                    Button { actions.openNight(night.session.id) } label: {
                        HStack(spacing: 6) {
                            Text(Fmt.nightLabel(night.session.startedAt))
                                .font(AuroraFont.titleS())
                                .foregroundStyle(theme.textPrimary)
                            Spacer(minLength: 8)
                            Text(L("cp_open_night"))
                                .font(AuroraFont.label())
                                .foregroundStyle(theme.primary)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(theme.primary)
                        }
                        .padding(.horizontal, 4)
                    }
                    .buttonStyle(.plain)
                    NightChartsCard(bundle: night, records: records, ctx: ctx, scrub: $scrub)
                }
            }
        }
        .onAppear { refresh() }
        .onChange(of: key) { _, _ in refresh() }
    }

    private func refresh() {
        let k = key
        guard k != cachedKey else { return }
        let recs = night.epochs.map { $0.toRecord() }
        records = recs
        bundles = NightAnalytics.detectBundles(recs)
        cachedKey = k
    }
}

/// Quiet sleep vs flash events for the latest night + "Open full sheet".
private struct VitalSheetSection: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var repo: SessionRepository
    @Environment(\.sectionActions) private var actions
    @Environment(\.theme) private var theme
    let id: SectionId
    let night: NightBundle

    @State private var ui: VitalSheetUi?
    @State private var cachedKey = ""

    private var key: String { night.session.id.uuidString + "-\(night.epochs.count)" }

    var body: some View {
        Group {
            if let ui {
                VStack(alignment: .leading, spacing: 12) {
                    VitalSheetPreviewCard(ui: ui, onOpen: { actions.openVitalSheet(night.session.id) })
                }
            } else if cachedKey.isEmpty {
                SectionPlaceholderCard(id: id, message: L("common_loading"))
            } else {
                SectionPlaceholderCard(id: id, message: L("vs_no_data_body"))
            }
        }
        .onAppear { refresh(force: false) }
        .onChange(of: key) { _, _ in refresh(force: false) }
        // Units, range guides and theme are baked into the resolved row model.
        .onChange(of: settings.useFahrenheit) { _, _ in refresh(force: true) }
        .onChange(of: settings.showRanges) { _, _ in refresh(force: true) }
        .onChange(of: theme) { _, _ in refresh(force: true) }
    }

    private func refresh(force: Bool) {
        let k = key
        guard force || k != cachedKey else { return }
        let records = night.epochs.map { $0.toRecord() }
        let baseline = VitalSheetBuilder.baselineRmssd(repo: repo,
                                                       userId: UUID(uuidString: settings.userId ?? ""),
                                                       excluding: night.session.id)
        ui = VitalSheetBuilder(theme: theme, settings: settings, caps: pod.capabilities,
                               baselineRmssdX10: baseline)
            .make(bundle: night, records: records)
        cachedKey = k
    }
}

/// The latest night's sweat events (NightDetail's list).
private struct SweatEventsSection: View {
    @EnvironmentObject private var settings: AppSettings
    let id: SectionId
    let night: NightBundle

    var body: some View {
        if night.sweat.isEmpty {
            SectionPlaceholderCard(id: id, message: L("cp_no_sweat_events"))
        } else {
            let s = settings
            let start = night.session.startedAt
            let xFormat: (Double) -> String = { t in Fmt.clock(start.addingTimeInterval(t), s) }
            VStack(alignment: .leading, spacing: 14) {
                NightSweatEventsSection(bundle: night, provisional: isHardwareNight(night.epochs),
                                        xFormat: xFormat)
            }
        }
    }
}

/// The last nights (Home's "Recent nights" rows), tap to open.
private struct RecentNightsSection: View {
    @EnvironmentObject private var repo: SessionRepository
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.sectionActions) private var actions
    let id: SectionId

    var body: some View {
        // Reading `repo` re-runs this body on every repository mutation (like Trends).
        let uid = UUID(uuidString: settings.userId ?? "")
        let cards: [(SessionModel, SummaryModel?)] = uid.map { repo.nightCards(userId: $0) } ?? []
        if cards.isEmpty {
            SectionPlaceholderCard(id: id, message: L("cp_no_nights"),
                                   actionTitle: L("home_try_demo"), action: actions.openDemo)
        } else {
            VStack(alignment: .leading, spacing: 14) {
                SectionHeader(title: L("home_recent_nights"), subtitle: L("home_recent_nights_sub"))
                ForEach(0..<min(cards.count, 6), id: \.self) { i in
                    NightRow(session: cards[i].0, summary: cards[i].1, onOpen: actions.openNight)
                }
            }
        }
    }
}

// MARK: - Trends

/// Trend sections share one range (chosen in "Trend tiles"), remembered across launches.
private struct TrendSection: View {
    @EnvironmentObject private var repo: SessionRepository
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.sectionActions) private var actions
    @AppStorage("custom_trends_range") private var rangeDays: Int = 14
    let id: SectionId

    var body: some View {
        let uid = UUID(uuidString: settings.userId ?? "")
        let cards: [(SessionModel, SummaryModel?)] = uid.map { repo.nightCards(userId: $0) } ?? []
        let series = TrendSeries(cards: cards, rangeDays: rangeDays)
        VStack(alignment: .leading, spacing: 14) {
            if id == .trendsOverview {
                TrendRangeChips(rangeDays: $rangeDays)
            }
            if series.inRange.count < 2 {
                SectionPlaceholderCard(id: id, message: L("trends_empty_body"),
                                       actionTitle: L("trends_open_demo"), action: actions.openDemo)
            } else {
                chart(series)
            }
        }
    }

    @ViewBuilder
    private func chart(_ series: TrendSeries) -> some View {
        switch id {
        case .trendsOverview:
            TrendTiles(series: series)
        case .trendsFlashes:
            TrendFlashesCard(series: series)
        case .trendsHr:
            TrendRestingHrCard(series: series)
        case .trendsTimeInBed:
            TrendTimeInBedCard(series: series)
        case .trendsSleep:
            // Hidden automatically when no night in range has sleep staging (real glove).
            if series.anySleep {
                TrendSleepCard(series: series)
            } else {
                SectionPlaceholderCard(id: id, message: L("cp_trends_no_sleep"))
            }
        default:
            EmptyView()
        }
    }
}

// MARK: - Pod

private struct PodSection: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var pod: PodConnectionManager
    @EnvironmentObject private var repo: SessionRepository
    @Environment(\.sectionActions) private var actions
    let id: SectionId

    /// Same rule as the Pod screen: the real glove, never while in demo mode.
    private var hwPod: Bool {
        !settings.demoMode && isHardwarePod(pod.capabilities, pod.deviceInfo)
    }

    var body: some View {
        switch id {
        case .podConnection:
            VStack(alignment: .leading, spacing: 14) {
                if hwPod { InfoBanner(text: L("hw_pod_security_note"), tone: .warning) }
                PodConnectionCard()
            }
        case .podInfo:
            if pod.connectionState.isConnected {
                PodDeviceCard(hwPod: hwPod)
            } else {
                SectionPlaceholderCard(id: id, message: L("cp_pod_info_not_connected"),
                                       actionTitle: L("common_connect"), action: actions.openPod)
            }
        case .podLog:
            podLog
        case .podControls:
            VStack(alignment: .leading, spacing: 14) {
                PodMaintenanceSection(hwPod: hwPod, showHeader: false)
                if hwPod { PodLogIntervalCard() }
            }
        case .demoControls:
            AuroraCard {
                DemoControlsContent(onLeave: {})
            }
        default:
            EmptyView()
        }
    }

    private var podLog: some View {
        let uid = UUID(uuidString: settings.userId ?? "")
        let cards: [(SessionModel, SummaryModel?)] = uid.map { repo.nightCards(userId: $0) } ?? []
        return VStack(alignment: .leading, spacing: 14) {
            if pod.replayStatus.isActive { PodReplayProgressCard(hwPod: hwPod) }
            if hwPod {
                PodHwLogSection(cards: cards)
            } else {
                PodSlotSection(slots: repo.slots(), cards: cards, onOpenNight: actions.openNight)
            }
        }
    }
}

/// Real glove only: the pod's log interval (opcode 0x06, PROTOCOL §6). Fire-and-forget
/// like every pod command — the pod does not acknowledge it.
private struct PodLogIntervalCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.theme) private var theme
    @State private var seconds = HwConst.defaultLogPeriodS
    @State private var sentSeconds: Int?

    private static let choices = [5, 10, 30, 60, 120, 240]

    var body: some View {
        AuroraCard {
            Text(L("cp_log_interval_title"))
                .font(AuroraFont.title())
                .foregroundStyle(theme.textPrimary)
            VSpace(4)
            Text(L("cp_log_interval_body"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(10)
            HStack(spacing: 10) {
                Picker(L("cp_log_interval_title"), selection: $seconds) {
                    ForEach(PodLogIntervalCard.choices, id: \.self) { s in
                        Text(L("cp_seconds", s)).tag(s)
                    }
                }
                .pickerStyle(.menu)
                .tint(theme.primary)
                Spacer(minLength: 8)
                Button(L("cp_log_interval_set")) {
                    if pod.setLogInterval(seconds) { sentSeconds = seconds }
                }
                .buttonStyle(.borderedProminent)
                .tint(theme.primary)
                .disabled(!pod.isHardwareLink)
            }
            if let s = sentSeconds {
                VSpace(6)
                Text(L("cp_log_interval_sent", s))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }
}

// MARK: - Diagnostics

private struct DiagnosticsSection: View {
    @EnvironmentObject private var pod: PodConnectionManager
    let id: SectionId

    var body: some View {
        switch id {
        case .linkHealth:
            LinkHealthCard(id: id)
        case .packetInspector:
            PacketInspectorCard(id: id)
        case .hardwareCheck:
            HardwareCheckCard(id: id, check: pod.hardwareCheck)
        default:
            EmptyView()
        }
    }
}

/// Packets, CRC failures, dropped notifications (sequence gaps) and FE01 rate.
private struct LinkHealthCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.theme) private var theme
    let id: SectionId

    var body: some View {
        let st = pod.linkStats
        AuroraCard {
            SectionTitleRow(id: id, trailing: pod.isDemo ? L("common_demo") : nil)
            VSpace(4)
            Text(pod.isDemo ? L("cp_link_demo_note") : L("cp_link_hw_note"))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("cp_link_packets"), value: "\(st.packets)", accent: theme.primary)
                StatTile(label: L("cp_link_rate"),
                         value: st.rateHz.map { String(format: "%.2f", $0) } ?? "—",
                         unit: st.rateHz != nil ? L("cp_hz") : "",
                         accent: theme.primary)
            }
            VSpace(10)
            HStack(spacing: 10) {
                StatTile(label: L("cp_link_crc"), value: "\(st.crcFailures)",
                         accent: st.crcFailures > 0 ? Aurora.bad : Aurora.good)
                StatTile(label: L("cp_link_gaps"), value: "\(st.seqGaps)",
                         accent: st.seqGaps > 0 ? Aurora.bad : Aurora.good)
            }
            VSpace(8)
            TimelineView(.periodic(from: Date(), by: 1)) { context in
                Text(lastPacketText(st, now: context.date))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            }
        }
    }

    private func lastPacketText(_ st: LinkStats, now: Date) -> String {
        if !pod.connectionState.isConnected {
            return st.packets > 0 || st.crcFailures > 0 ? L("cp_link_disconnected_last") : L("cp_link_not_connected")
        }
        guard let last = st.lastPacketAt else { return L("cp_link_no_packets") }
        let ago = max(0, Int(now.timeIntervalSince(last)))
        if ago > 4 { return L("cp_link_stalled", ago) }
        return L("cp_link_last_packet", ago)
    }
}

/// The last ~50 raw packets, newest first: time, characteristic, CRC result, decoded
/// summary and the bytes. Pause freezes the list so it can be read.
private struct PacketInspectorCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.theme) private var theme
    let id: SectionId

    @State private var paused = false
    @State private var frozen: [RawPacket] = []

    var body: some View {
        let source: [RawPacket] = paused ? frozen : pod.rawPackets
        let list: [RawPacket] = Array(source.reversed())
        AuroraCard {
            HStack(spacing: 8) {
                SectionTitleRow(id: id)
                Button {
                    if !paused { frozen = pod.rawPackets }
                    paused.toggle()
                } label: {
                    Text(paused ? L("cp_pi_resume") : L("cp_pi_pause"))
                        .font(AuroraFont.label())
                }
                .buttonStyle(.bordered)
                .tint(theme.primary)
            }
            VSpace(4)
            Text(L("cp_pi_body", LinkRecorder.ringCapacity))
                .font(AuroraFont.bodyS())
                .foregroundStyle(theme.textSecondary)
            VSpace(10)
            if list.isEmpty {
                Text(L("cp_pi_empty"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 10) {
                        ForEach(list) { p in
                            PacketRow(packet: p)
                        }
                    }
                }
                .frame(maxHeight: 360)
            }
        }
    }
}

private struct PacketRow: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.theme) private var theme
    let packet: RawPacket

    var body: some View {
        let decoded = PacketRow.describe(packet.decoded, settings: settings)
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 6) {
                Text(PacketRow.timeText(packet.time, h24: settings.use24h))
                    .font(.system(size: 12, weight: .semibold, design: .monospaced))
                    .foregroundStyle(theme.textSecondary)
                Text(packet.characteristic)
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .foregroundStyle(theme.primary)
                Image(systemName: packet.ok ? "checkmark.circle.fill" : "xmark.octagon.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(packet.ok ? Aurora.good : Aurora.bad)
                Text(decoded)
                    .font(AuroraFont.labelS())
                    .foregroundStyle(theme.textPrimary)
                    .lineLimit(2)
            }
            Text(packet.hex)
                .font(.system(size: 11, design: .monospaced))
                .foregroundStyle(theme.textSecondary)
                .lineLimit(3)
                .textSelection(.enabled)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(packet.characteristic + ", " + L(packet.ok ? "cp_pi_ok" : "cp_pi_bad") + ", " + decoded)
    }

    private static let fmt24: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f
    }()

    private static let fmt12: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "h:mm:ss a"
        return f
    }()

    static func timeText(_ date: Date, h24: Bool) -> String {
        let f = h24 ? fmt24 : fmt12
        f.locale = L10n.locale
        return f.string(from: date)
    }

    static func describe(_ kind: RawPacketKind, settings: AppSettings) -> String {
        switch kind {
        case let .vitals(seq, hrBpm, absHumX100, skinTempX100):
            var parts: [String] = []
            if let seq { parts.append(L("cp_pi_seq", seq)) }
            parts.append(hrBpm.map { L("cp_pi_hr", String(format: "%.1f", $0)) } ?? L("cp_pi_hr_none"))
            if let ah = absHumX100 { parts.append(L("cp_pi_ah", String(format: "%.2f", Double(ah) / 100))) }
            if let t = skinTempX100 { parts.append(L("cp_pi_skin", Fmt.temp(Double(t) / 100, settings))) }
            return parts.joined(separator: " · ")
        case let .hrv(rmssdX10, beats):
            return L("cp_pi_hrv", String(format: "%.1f", Double(rmssdX10) / 10), beats)
        case let .summary(durationS):
            return L("cp_pi_summary", Fmt.durationShort(durationS))
        case let .replay(seq):
            return L("cp_pi_replay", seq)
        case let .invalid(reason):
            return L("cp_pi_invalid", reason)
        }
    }
}

/// One-button hardware check (HardwareCheckRunner, owned by the manager).
private struct HardwareCheckCard: View {
    @EnvironmentObject private var pod: PodConnectionManager
    @Environment(\.theme) private var theme
    let id: SectionId
    @ObservedObject var check: HardwareCheckRunner

    var body: some View {
        let running = check.isRunning
        // Explain up front why it would refuse (recording, not connected, downloading).
        let why: String? = running ? nil : check.refusalReason()
        AuroraCard {
            SectionTitleRow(id: id)
            VSpace(4)
            VStack(alignment: .leading, spacing: 4) {
                Text(L("hc_body", HardwareCheckRunner.streamSeconds))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
                Text(L("hc_test_night_note"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
                if pod.isHardwareLink && !running {
                    // The pod keeps ONE session's log: the test session replaces it.
                    InfoBanner(text: L("hc_log_warning"), tone: .warning)
                        .padding(.top, 4)
                }
            }
            VSpace(12)
            Button {
                check.run()
            } label: {
                HStack(spacing: 8) {
                    if running { ProgressView().controlSize(.small) }
                    Text(running ? L("hc_running") : L("hc_run"))
                }
                .frame(maxWidth: .infinity)
                .frame(height: 32)
            }
            .buttonStyle(.borderedProminent)
            .tint(theme.primary)
            .disabled(running || why != nil)
            if let reason = why ?? check.refusal {
                VSpace(8)
                InfoBanner(text: reason, tone: pod.activeSession != nil ? .warning : .info)
            }
            details
        }
    }

    @ViewBuilder
    private var details: some View {
        if case .running(let status) = check.phase {
            VSpace(10)
            Text(status)
                .font(AuroraFont.label())
                .foregroundStyle(theme.textPrimary)
        }
        if !check.steps.isEmpty {
            VSpace(10)
            ForEach(check.steps) { step in
                CheckStepRow(step: step)
            }
        }
        if case .finished(let passed, let failed, let skipped) = check.phase {
            VSpace(10)
            InfoBanner(text: summaryText(passed: passed, failed: failed, skipped: skipped),
                       tone: failed > 0 ? .error : (passed > 0 ? .success : .warning))
        }
    }

    private func summaryText(passed: Int, failed: Int, skipped: Int) -> String {
        var t: String
        if failed > 0 {
            t = L(failed == 1 ? "hc_summary_failed_one" : "hc_summary_failed_other", failed)
                + " " + L(passed == 1 ? "hc_summary_passed_one" : "hc_summary_passed_other", passed)
        } else if passed > 0 {
            t = L(passed == 1 ? "hc_summary_all_passed_one" : "hc_summary_all_passed_other", passed)
        } else {
            t = L("hc_summary_nothing_ran")
        }
        if skipped > 0 {
            t += " " + L(skipped == 1 ? "hc_summary_skipped_one" : "hc_summary_skipped_other", skipped)
        }
        return t
    }
}

private struct CheckStepRow: View {
    @Environment(\.theme) private var theme
    let step: HardwareCheckStep

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(color)
            VStack(alignment: .leading, spacing: 2) {
                Text(step.title)
                    .font(AuroraFont.titleS())
                    .foregroundStyle(theme.textPrimary)
                if let detail = step.detail {
                    Text(detail)
                        .font(AuroraFont.bodyS())
                        .foregroundStyle(theme.textSecondary)
                }
            }
            Spacer(minLength: 8)
            Text(L(statusKey))
                .font(AuroraFont.labelS())
                .foregroundStyle(color)
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
    }

    private var icon: String {
        switch step.status {
        case .pass: return "checkmark.circle.fill"
        case .fail: return "xmark.circle.fill"
        case .skipped: return "minus.circle"
        }
    }

    private var color: Color {
        switch step.status {
        case .pass: return Aurora.good
        case .fail: return Aurora.bad
        case .skipped: return theme.textSecondary
        }
    }

    private var statusKey: String {
        switch step.status {
        case .pass: return "hc_pass"
        case .fail: return "hc_fail"
        case .skipped: return "hc_skipped"
        }
    }
}
