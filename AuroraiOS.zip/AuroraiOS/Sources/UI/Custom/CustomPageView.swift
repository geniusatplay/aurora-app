// A user-built page ("Page N"): its sections rendered top-to-bottom with real data, an
// "Add section" button, and a toolbar menu with Edit layout / Delete page. Edit mode is a
// native List in permanent edit mode: drag handles reorder rows, delete removes them, and
// every row also offers Move up / Move down accessibility actions. "Done" exits.

import SwiftUI

struct CustomPageView: View {
    @EnvironmentObject private var store: CustomPagesStore
    @Environment(\.theme) private var theme

    let pageNumber: Int
    /// Opens the section library for this page (RootView owns the sheet).
    let onAddSection: () -> Void
    /// Deletes the page (RootView first moves the selection off it).
    let onDeletePage: () -> Void

    @State private var editing = false
    @State private var confirmDelete = false

    var body: some View {
        let sections = store.visibleSections(of: pageNumber)
        Group {
            if editing {
                editList(sections)
            } else {
                content(sections)
            }
        }
        .background(theme.background.ignoresSafeArea())
        // Title "Page N" (large, collapsing like a native screen title).
        .navigationTitle(L("cp_page_title", pageNumber))
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if editing {
                    Button {
                        editing = false
                    } label: {
                        Text(L("cp_done")).fontWeight(.semibold)
                    }
                } else {
                    Menu {
                        Button {
                            editing = true
                        } label: {
                            Label(L("cp_edit_layout"), systemImage: "arrow.up.arrow.down")
                        }
                        .disabled(sections.isEmpty)
                        Button(role: .destructive) {
                            confirmDelete = true
                        } label: {
                            Label(L("cp_delete_page"), systemImage: "trash")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                    .accessibilityLabel(L("cp_page_menu"))
                }
            }
        }
        .confirmationDialog(L("cp_delete_title", pageNumber), isPresented: $confirmDelete,
                            titleVisibility: .visible) {
            Button(L("cp_delete_confirm"), role: .destructive) {
                editing = false
                onDeletePage()
            }
            Button(L("common_cancel"), role: .cancel) {}
        } message: {
            Text(L("cp_delete_body"))
        }
        .onChange(of: sections.isEmpty) { _, isEmpty in
            if isEmpty { editing = false }
        }
    }

    // MARK: - Normal mode

    private func content(_ sections: [SectionId]) -> some View {
        ScrollView {
            // A plain VStack (not lazy): sections keep their state (scrub, pause, …)
            // while scrolled off screen.
            VStack(alignment: .leading, spacing: 14) {
                if sections.isEmpty {
                    emptyCard
                } else {
                    ForEach(sections) { id in
                        SectionView(id: id)
                    }
                    addSectionButton
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 4)
            .padding(.bottom, 16)
        }
    }

    private var emptyCard: some View {
        AuroraCard {
            EmptyState(title: L("cp_empty_title"), body: L("cp_empty_body")) {
                addButtonLabel
            }
        }
    }

    private var addSectionButton: some View {
        addButtonLabel
            .frame(maxWidth: .infinity)
            .padding(.top, 4)
    }

    private var addButtonLabel: some View {
        Button(action: onAddSection) {
            HStack(spacing: 8) {
                Image(systemName: "plus")
                    .font(.system(size: 14, weight: .bold))
                Text(L("cp_add_section"))
                    .font(AuroraFont.title())
            }
            .foregroundStyle(theme.onPrimary)
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .background(Capsule().fill(theme.primary))
        }
        .buttonStyle(.plain)
    }

    // MARK: - Edit mode

    private func editList(_ sections: [SectionId]) -> some View {
        List {
            Section {
                ForEach(sections) { id in
                    SectionEditRow(id: id)
                        .listRowBackground(theme.card)
                        .accessibilityAction(named: Text(L("cp_move_up"))) {
                            store.moveSection(id.rawValue, by: -1, on: pageNumber)
                        }
                        .accessibilityAction(named: Text(L("cp_move_down"))) {
                            store.moveSection(id.rawValue, by: 1, on: pageNumber)
                        }
                        .accessibilityAction(named: Text(L("cp_remove_section"))) {
                            store.removeSection(id.rawValue, from: pageNumber)
                        }
                }
                .onMove { from, to in
                    store.move(page: pageNumber, fromOffsets: from, toOffset: to)
                }
                .onDelete { offsets in
                    store.removeSections(at: offsets, from: pageNumber)
                }
            } header: {
                Text(L("cp_edit_hint"))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
                    .textCase(nil)
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .environment(\.editMode, .constant(.active))
    }
}

/// Compact row for edit mode: icon, name and category · description.
struct SectionEditRow: View {
    @Environment(\.theme) private var theme
    let id: SectionId

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: id.icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(theme.primary)
                .frame(width: 26)
            VStack(alignment: .leading, spacing: 2) {
                Text(L(id.nameKey))
                    .font(AuroraFont.titleS())
                    .foregroundStyle(theme.textPrimary)
                Text(L(id.category.titleKey) + " · " + L(id.descKey))
                    .font(AuroraFont.bodyS())
                    .foregroundStyle(theme.textSecondary)
                    .lineLimit(1)
            }
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
    }
}
