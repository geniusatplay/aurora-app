// Session/night persistence — port of the Android SessionRepository over SwiftData.
//
// THREADING CONTRACT: every method here is synchronous and MUST be called on the main
// thread — the repository wraps the app's main-actor ModelContext (project convention #1:
// BLE/demo callbacks hop to the main queue before touching UI or data). There are no
// Flows on iOS; instead the repository is an ObservableObject that bumps `revision`
// (and fires objectWillChange) after every mutation, and views/view-models re-run their
// fetches when it changes.

import Foundation
import SwiftData
import Combine

/// Everything a Night Detail screen needs, assembled by one fetch.
struct NightBundle {
    let session: SessionModel
    let summary: SummaryModel?
    let epochs: [EpochModel]
    let hrv: [HrvPointModel]
    let sweat: [SweatEventModel]
    let events: [ActivityEventModel]
}

final class SessionRepository: ObservableObject {

    /// Bumped after every mutation; observe this (or the object) and re-fetch.
    @Published private(set) var revision: Int = 0

    /// Fired when sessions are deleted, BEFORE the change notification, so holders of
    /// live SessionModel references (PodConnectionManager's activeSession) can drop them
    /// before any view re-reads an invalidated model. `nil` means "all of a user's
    /// sessions"; a UUID names the one deleted session.
    let deletions = PassthroughSubject<UUID?, Never>()

    private let context: ModelContext

    init(context: ModelContext) {
        self.context = context
    }

    /// Commit + notify. @Published already fires objectWillChange, but we send explicitly
    /// too so callers holding only `AnyObject`-typed references can still rely on it.
    private func mutated() {
        try? context.save()
        objectWillChange.send()
        revision += 1
    }

    private func nowMs() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

    private func fetch<T: PersistentModel>(_ descriptor: FetchDescriptor<T>) -> [T] {
        (try? context.fetch(descriptor)) ?? []
    }

    // ------------------------------------------------------------------ session lifecycle

    /// Called the instant CMD_START_SESSION is confirmed (spec §8.2): the app owns the
    /// wall-clock start — the pod never stores it.
    @discardableResult
    func startSession(userId: UUID, source: SessionSource, startedAtMs: Int64? = nil) -> SessionModel {
        let session = SessionModel(userId: userId, startedAtEpochMs: startedAtMs ?? nowMs(), source: source)
        context.insert(session)
        context.insert(ActivityEventModel(sessionId: session.id, tS: 0, kind: .sessionStart, source: .pod))
        mutated()
        return session
    }

    /// The still-open (not yet ended) session for a user, newest first.
    func openSession(userId: UUID) -> SessionModel? {
        let uid = userId
        var d = FetchDescriptor<SessionModel>(
            predicate: #Predicate { $0.userId == uid && $0.endedAtEpochMs == nil },
            sortBy: [SortDescriptor(\.startedAtEpochMs, order: .reverse)]
        )
        d.fetchLimit = 1
        return fetch(d).first
    }

    /// Called on the FE02 summary after STOP. Saves the slot byte — the only way to
    /// replay this night later (spec §11).
    func endSession(_ session: SessionModel, summary: SessionSummary, endedAtMs: Int64? = nil) {
        let endMs = endedAtMs ?? nowMs()
        // Event timestamps are pod-relative seconds like every epoch's tS; the FE02
        // summary carries the authoritative session length (wall-clock delta is wrong
        // whenever demo time runs faster than real time).
        let endTs = summary.sessionLenS
        session.endedAtEpochMs = endMs
        session.slot = summary.slot
        upsertSummary(sessionId: session.id, summary: summary)
        upsertPodSlot(summary.slot, sessionId: session.id, lastSeenAt: endMs)
        context.insert(ActivityEventModel(sessionId: session.id, tS: endTs, kind: .sessionEnd, source: .pod))
        refreshSweatEvents(sessionId: session.id)
        mutated()
    }

    /// Close a session WITHOUT an FE02, summarizing the epochs we stored ourselves.
    /// Used when the pod no longer has this night (it restarted since recording began,
    /// e.g. the app was killed mid-night in demo mode): asking it for a summary would
    /// return a DIFFERENT night's FE02 and bind this session to the wrong slot.
    /// The slot inventory is deliberately untouched — the pod never told us a slot.
    func endSessionLocally(_ session: SessionModel, endedAtMs: Int64? = nil) {
        let records = epochs(for: session.id).map { $0.toRecord() }
        let summary = NightAnalytics.summarize(records, slot: session.slot ?? 0)
        session.endedAtEpochMs = endedAtMs ?? nowMs()
        upsertSummary(sessionId: session.id, summary: summary)
        context.insert(ActivityEventModel(sessionId: session.id, tS: summary.sessionLenS,
                                          kind: .sessionEnd, source: .pod))
        refreshSweatEvents(sessionId: session.id)
        mutated()
    }

    /// A provisional 30 s epoch synthesised from live FE01 packets while the phone is
    /// connected. REPLACE on (sessionId, tS), like the Room table's unique index.
    func appendProvisionalEpoch(sessionId: UUID, record: LogRecord) {
        let sid = sessionId
        let t = record.tS
        let dupes = fetch(FetchDescriptor<EpochModel>(predicate: #Predicate { $0.sessionId == sid && $0.tS == t }))
        for d in dupes { context.delete(d) }
        context.insert(EpochModel.from(record: record, sessionId: sessionId))
        // Recompute sweat spans on activity, or every 5 min so the chart stays fresh.
        if record.sweatFlag != .none || record.tS % 300 == 0 {
            refreshSweatEvents(sessionId: sessionId)
        }
        mutated()
    }

    /// An FE05 HRV window notify. REPLACE on (sessionId, windowEndS).
    func appendHrv(sessionId: UUID, _ h: HrvSummary, windowEndS: Int64) {
        let sid = sessionId
        let w = windowEndS
        let dupes = fetch(FetchDescriptor<HrvPointModel>(predicate: #Predicate { $0.sessionId == sid && $0.windowEndS == w }))
        for d in dupes { context.delete(d) }
        context.insert(HrvPointModel(sessionId: sessionId, windowEndS: windowEndS, meanIbi: h.meanIbiMs,
                                     sdnnX10: h.sdnnMsX10, rmssdX10: h.rmssdMsX10, pnn50: h.pnn50Pct,
                                     accepted: h.beatsAccepted, rejected: h.beatsRejected,
                                     quality: h.quality, flags: h.flags))
        mutated()
    }

    /// Timeline marker (demo mode change, user tag, pod event). `labelKey` defaults to
    /// the kind's own night_event_* key.
    func addActivityEvent(sessionId: UUID, tS: Int64, kind: ActivityKind, source: EventSource, labelKey: String? = nil) {
        context.insert(ActivityEventModel(sessionId: sessionId, tS: tS, kind: kind, labelKey: labelKey, source: source))
        mutated()
    }

    /// Authoritative data from a replay REPLACES provisional epochs and HRV. Summary is
    /// recomputed if none exists — FE02 only describes the most recent session, so older
    /// nights must be summarized by the app (spec §15.3).
    func storeReplay(sessionId: UUID, records: [LogRecord], crcFailures: Int, complete: Bool) {
        guard let session = self.session(id: sessionId) else { return }
        let sid = sessionId
        for r in fetch(FetchDescriptor<EpochModel>(predicate: #Predicate { $0.sessionId == sid })) { context.delete(r) }
        for r in fetch(FetchDescriptor<HrvPointModel>(predicate: #Predicate { $0.sessionId == sid })) { context.delete(r) }
        for r in records { context.insert(EpochModel.from(record: r, sessionId: sessionId)) }
        for r in NightAnalytics.hrvSeries(records) {
            context.insert(HrvPointModel(sessionId: sessionId, windowEndS: r.tS, meanIbi: r.hrvMeanIbiMs,
                                         sdnnX10: r.hrvSdnnMsX10, rmssdX10: r.hrvRmssdMsX10,
                                         pnn50: r.hrvPnn50Pct, accepted: 0, rejected: 0,
                                         quality: r.hrvQuality, flags: r.hrvFlags))
        }
        session.replayState = complete ? .complete : .partial
        session.crcFailures = crcFailures
        if summary(sessionId: sessionId) == nil {
            upsertSummary(sessionId: sessionId, summary: NightAnalytics.summarize(records, slot: session.slot ?? 0))
        }
        refreshSweatEvents(sessionId: sessionId)
        mutated()
    }

    /// Insert a fully generated night (demo history). Returns the new session's id.
    @discardableResult
    func insertGeneratedNight(userId: UUID, startedAtMs: Int64, records: [LogRecord],
                              events: [(Int64, ActivityKind)], slot: Int) -> UUID {
        let lenS = records.last.map { $0.tS + Int64(Cadence.epochS) } ?? 0
        let session = SessionModel(userId: userId, startedAtEpochMs: startedAtMs,
                                   endedAtEpochMs: startedAtMs + lenS * 1000,
                                   slot: slot, source: .demo, replayState: .complete)
        context.insert(session)
        context.insert(ActivityEventModel(sessionId: session.id, tS: 0, kind: .sessionStart, source: .pod))
        for (t, k) in events {
            context.insert(ActivityEventModel(sessionId: session.id, tS: t, kind: k, source: .demo))
        }
        context.insert(ActivityEventModel(sessionId: session.id, tS: lenS, kind: .sessionEnd, source: .pod))
        storeReplay(sessionId: session.id, records: records, crcFailures: 0, complete: true)
        upsertPodSlot(slot, sessionId: session.id, lastSeenAt: startedAtMs + lenS * 1000)
        mutated()
        return session.id
    }

    /// Rebuild the derived sweat_events rows from stored epochs (delete + reinsert,
    /// like the Room @Transaction replaceForSession).
    private func refreshSweatEvents(sessionId: UUID) {
        let records = epochs(for: sessionId).map { $0.toRecord() }
        let spans = NightAnalytics.sweatSpans(records)
        let sid = sessionId
        for r in fetch(FetchDescriptor<SweatEventModel>(predicate: #Predicate { $0.sessionId == sid })) { context.delete(r) }
        for s in spans {
            context.insert(SweatEventModel(sessionId: sessionId, startS: s.startS, endS: s.endS, peakDahX100: s.peakDahX100))
        }
    }

    // ------------------------------------------------------------------ upserts (no #Unique on iOS 17)

    private func upsertSummary(sessionId: UUID, summary s: SessionSummary) {
        if let existing = summary(sessionId: sessionId) {
            existing.apply(s)
        } else {
            context.insert(SummaryModel(sessionId: sessionId, summary: s))
        }
    }

    private func upsertPodSlot(_ slot: Int, sessionId: UUID?, lastSeenAt: Int64) {
        let n = slot
        if let existing = fetch(FetchDescriptor<PodSlotModel>(predicate: #Predicate { $0.slot == n })).first {
            existing.sessionId = sessionId
            existing.lastSeenAt = lastSeenAt
        } else {
            context.insert(PodSlotModel(slot: slot, sessionId: sessionId, lastSeenAt: lastSeenAt))
        }
    }

    // ------------------------------------------------------------------ queries (re-run when `revision` changes)

    func session(id: UUID) -> SessionModel? {
        let sid = id
        var d = FetchDescriptor<SessionModel>(predicate: #Predicate { $0.id == sid })
        d.fetchLimit = 1
        return fetch(d).first
    }

    func summary(sessionId: UUID) -> SummaryModel? {
        let sid = sessionId
        var d = FetchDescriptor<SummaryModel>(predicate: #Predicate { $0.sessionId == sid })
        d.fetchLimit = 1
        return fetch(d).first
    }

    func epochs(for sessionId: UUID) -> [EpochModel] {
        let sid = sessionId
        return fetch(FetchDescriptor<EpochModel>(predicate: #Predicate { $0.sessionId == sid },
                                                 sortBy: [SortDescriptor(\.tS)]))
    }

    func hrvPoints(for sessionId: UUID) -> [HrvPointModel] {
        let sid = sessionId
        return fetch(FetchDescriptor<HrvPointModel>(predicate: #Predicate { $0.sessionId == sid },
                                                    sortBy: [SortDescriptor(\.windowEndS)]))
    }

    func sweatEvents(for sessionId: UUID) -> [SweatEventModel] {
        let sid = sessionId
        return fetch(FetchDescriptor<SweatEventModel>(predicate: #Predicate { $0.sessionId == sid },
                                                      sortBy: [SortDescriptor(\.startS)]))
    }

    func activityEvents(for sessionId: UUID) -> [ActivityEventModel] {
        let sid = sessionId
        return fetch(FetchDescriptor<ActivityEventModel>(predicate: #Predicate { $0.sessionId == sid },
                                                         sortBy: [SortDescriptor(\.tS)]))
    }

    /// Everything the Night Detail screen shows, in one call.
    func nightBundle(sessionId: UUID) -> NightBundle? {
        guard let s = session(id: sessionId) else { return nil }
        return NightBundle(session: s,
                           summary: summary(sessionId: sessionId),
                           epochs: epochs(for: sessionId),
                           hrv: hrvPoints(for: sessionId),
                           sweat: sweatEvents(for: sessionId),
                           events: activityEvents(for: sessionId))
    }

    /// The most recent completed (ended) night — the Home screen's headline card.
    func latestCompletedNight(userId: UUID) -> NightBundle? {
        let uid = userId
        var d = FetchDescriptor<SessionModel>(
            predicate: #Predicate { $0.userId == uid && $0.endedAtEpochMs != nil },
            sortBy: [SortDescriptor(\.startedAtEpochMs, order: .reverse)]
        )
        d.fetchLimit = 1
        guard let s = fetch(d).first else { return nil }
        return nightBundle(sessionId: s.id)
    }

    /// All sessions for the history list, newest first, each with its summary if any.
    func nightCards(userId: UUID) -> [(SessionModel, SummaryModel?)] {
        let uid = userId
        let sessions = fetch(FetchDescriptor<SessionModel>(
            predicate: #Predicate { $0.userId == uid },
            sortBy: [SortDescriptor(\.startedAtEpochMs, order: .reverse)]
        ))
        if sessions.isEmpty { return [] }
        let ids = sessions.map { $0.id }
        let summaries = fetch(FetchDescriptor<SummaryModel>(predicate: #Predicate { ids.contains($0.sessionId) }))
        let byId = Dictionary(summaries.map { ($0.sessionId, $0) }, uniquingKeysWith: { a, _ in a })
        return sessions.map { ($0, byId[$0.id]) }
    }

    /// Sessions starting at/after a wall-clock time, oldest first — the Trends window.
    func sessionsSince(userId: UUID, sinceMs: Int64) -> [SessionModel] {
        let uid = userId
        let since = sinceMs
        return fetch(FetchDescriptor<SessionModel>(
            predicate: #Predicate { $0.userId == uid && $0.startedAtEpochMs >= since },
            sortBy: [SortDescriptor(\.startedAtEpochMs)]
        ))
    }

    /// The app-side slot inventory, ordered by slot number (spec §15.1).
    func slots() -> [PodSlotModel] {
        fetch(FetchDescriptor<PodSlotModel>(sortBy: [SortDescriptor(\.slot)]))
    }

    func sessionCount(userId: UUID) -> Int {
        let uid = userId
        return (try? context.fetchCount(FetchDescriptor<SessionModel>(predicate: #Predicate { $0.userId == uid }))) ?? 0
    }

    // ------------------------------------------------------------------ deletion

    /// Delete one session and its children (Room did this via ON DELETE CASCADE; without
    /// relationships we cascade by hand). Pod slot rows are left as-is, matching Android —
    /// they only record what the POD stores, which deleting local data does not change.
    func deleteSession(id: UUID) {
        deletions.send(id) // let live-reference holders drop the model first
        deleteChildren(of: id)
        if let s = session(id: id) { context.delete(s) }
        mutated()
    }

    /// Delete every session for a user and clear the slot inventory.
    func deleteAll(userId: UUID) {
        deletions.send(nil) // let live-reference holders drop their models first
        let uid = userId
        for s in fetch(FetchDescriptor<SessionModel>(predicate: #Predicate { $0.userId == uid })) {
            deleteChildren(of: s.id)
            context.delete(s)
        }
        for slot in fetch(FetchDescriptor<PodSlotModel>()) { context.delete(slot) }
        mutated()
    }

    /// Delete every child row keyed on a session's id (epochs, HRV, sweat, events, summary).
    private func deleteChildren(of sessionId: UUID) {
        let sid = sessionId
        for r in fetch(FetchDescriptor<EpochModel>(predicate: #Predicate { $0.sessionId == sid })) { context.delete(r) }
        for r in fetch(FetchDescriptor<HrvPointModel>(predicate: #Predicate { $0.sessionId == sid })) { context.delete(r) }
        for r in fetch(FetchDescriptor<SweatEventModel>(predicate: #Predicate { $0.sessionId == sid })) { context.delete(r) }
        for r in fetch(FetchDescriptor<ActivityEventModel>(predicate: #Predicate { $0.sessionId == sid })) { context.delete(r) }
        if let sum = summary(sessionId: sid) { context.delete(sum) }
    }

    // ------------------------------------------------------------------ export

    /// Simple CSV export of one night (for "take it to your doctor"). Column layout
    /// matches the Android export byte-for-byte; enum names are uppercased to match
    /// Kotlin's WAKE/LIGHT/DEEP/UNKNOWN and NONE/ONGOING/START.
    func exportCsv(sessionId: UUID) -> String {
        guard let s = session(id: sessionId) else { return "" }
        var out = "time_iso,t_s,hr_bpm,hr_quality,skin_temp_c,skin_rh,amb_temp_c,amb_rh,dah_g_m3,motion,sleep_state,sweat_flag,batt_pct,hrv_rmssd_ms,hrv_valid\n"
        let fmt = DateFormatter()
        fmt.locale = Locale(identifier: "en_US_POSIX")
        fmt.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        for e in epochs(for: sessionId) {
            let r = e.toRecord()
            let date = Date(timeIntervalSince1970: Double(s.startedAtEpochMs + e.tS * 1000) / 1000)
            out += fmt.string(from: date) + ","
            out += "\(e.tS),\(e.hrBpm),\(e.hrQuality),"
            out += String(format: "%.2f", r.skinTempC) + "," + String(format: "%.1f", Double(e.skinRhX100) / 100) + ","
            out += String(format: "%.2f", r.ambTempC) + "," + String(format: "%.1f", Double(e.ambRhX100) / 100) + ","
            out += String(format: "%.2f", r.dah) + ",\(e.motionIndex),"
            out += String(describing: r.sleepState).uppercased() + "," + String(describing: r.sweatFlag).uppercased() + ",\(e.battPct),"
            out += (r.hrvFresh ? String(format: "%.1f", Double(e.hrvRmssdX10) / 10) : "") + ","
            out += (r.hrvFresh && r.hrvValid ? "1" : "0") + "\n"
        }
        return out
    }
}

// MARK: - Date-based conveniences (the pod layer thinks in Dates; storage in epoch ms)

extension SessionRepository {
    @discardableResult
    func startSession(userId: UUID, source: SessionSource, startedAt: Date) -> SessionModel {
        startSession(userId: userId, source: source, startedAtMs: Int64(startedAt.timeIntervalSince1970 * 1000))
    }

    func endSession(_ session: SessionModel, summary: SessionSummary, endedAt: Date) {
        endSession(session, summary: summary, endedAtMs: Int64(endedAt.timeIntervalSince1970 * 1000))
    }

    func appendHrv(sessionId: UUID, hrv: HrvSummary, windowEndS: Int64) {
        appendHrv(sessionId: sessionId, hrv, windowEndS: windowEndS)
    }

    @discardableResult
    func insertGeneratedNight(userId: UUID, startedAt: Date, records: [LogRecord],
                              events: [(Int64, ActivityKind)], slot: Int) -> UUID {
        insertGeneratedNight(userId: userId, startedAtMs: Int64(startedAt.timeIntervalSince1970 * 1000),
                             records: records, events: events, slot: slot)
    }
}
