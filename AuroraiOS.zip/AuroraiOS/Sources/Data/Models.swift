// SwiftData models — port of the Android Room schema (data/db/Entities.kt), plus the raw-value enums they store.
//
// Per project convention #2 the models carry only plain Int/Int64/Double/String/Date/Bool
// (enums stored as raw strings) and NO SwiftData relationships: children point at their
// parent through a `sessionId: UUID` foreign key, mirroring the Room schema, and the
// repository does the joins. #Index/#Unique are iOS 18-only, so uniqueness rules the Room
// schema enforced (epochs on (sessionId, tS), hrv on (sessionId, windowEndS), users on
// email, one summary/slot row per key) are enforced by SessionRepository/AuthRepository
// doing delete-then-insert / fetch-then-update ("REPLACE"/"UPSERT" semantics) instead.

import Foundation
import SwiftData

// MARK: - Stored enums (raw values mirror the Android enum names)

enum SessionSource: String {
    case ble = "BLE"
    case demo = "DEMO"
}

enum ReplayState: String {
    case none = "NONE"
    case partial = "PARTIAL"
    case complete = "COMPLETE"
}

/// Timeline marker kinds. NO display strings here — views localize via `labelKey`.
enum ActivityKind: String, CaseIterable {
    case up = "UP"
    case lightExercise = "LIGHT_EXERCISE"
    case heavyExercise = "HEAVY_EXERCISE"
    case sleeping = "SLEEPING"
    case nightFlash = "NIGHT_FLASH"
    case nightSweats = "NIGHT_SWEATS"
    case sessionStart = "SESSION_START"
    case sessionEnd = "SESSION_END"

    /// Localization key for the marker's label (Resources/*.lproj, night_event_* family).
    var labelKey: String {
        switch self {
        case .up: return "night_event_up"
        case .lightExercise: return "night_event_light_exercise"
        case .heavyExercise: return "night_event_heavy_exercise"
        case .sleeping: return "night_event_sleeping"
        case .nightFlash: return "night_event_night_flash"
        case .nightSweats: return "night_event_night_sweats"
        case .sessionStart: return "night_event_session_start"
        case .sessionEnd: return "night_event_session_end"
        }
    }
}

enum EventSource: String {
    case demo = "DEMO"
    case user = "USER"
    case pod = "POD"
}

// MARK: - Users

/// Local user account. Passwords are salted SHA-256; a server can replace this with tokens later.
@Model
final class UserModel {
    var id: UUID
    var email: String
    var passwordHash: String
    var salt: String
    var displayName: String
    var createdAt: Int64            // epoch ms

    init(id: UUID = UUID(), email: String, passwordHash: String, salt: String, displayName: String, createdAt: Int64) {
        self.id = id
        self.email = email
        self.passwordHash = passwordHash
        self.salt = salt
        self.displayName = displayName
        self.createdAt = createdAt
    }
}

// MARK: - Sessions

/// One recording (usually one night). `startedAtEpochMs` is the wall-clock time the app
/// stored when CMD_START_SESSION was confirmed — the pod never stores this (spec §8.2).
@Model
final class SessionModel {
    var id: UUID
    var userId: UUID
    var startedAtEpochMs: Int64
    var endedAtEpochMs: Int64?
    /// Which of the 14 pod slots holds this night; from FE02. Nil for demo/unknown.
    var slot: Int?
    var sourceRaw: String           // SessionSource.rawValue
    var replayStateRaw: String      // ReplayState.rawValue
    var crcFailures: Int
    var note: String
    /// For future server sync.
    var syncedAt: Int64?

    init(id: UUID = UUID(), userId: UUID, startedAtEpochMs: Int64, endedAtEpochMs: Int64? = nil,
         slot: Int? = nil, source: SessionSource, replayState: ReplayState = .none,
         crcFailures: Int = 0, note: String = "", syncedAt: Int64? = nil) {
        self.id = id
        self.userId = userId
        self.startedAtEpochMs = startedAtEpochMs
        self.endedAtEpochMs = endedAtEpochMs
        self.slot = slot
        self.sourceRaw = source.rawValue
        self.replayStateRaw = replayState.rawValue
        self.crcFailures = crcFailures
        self.note = note
        self.syncedAt = syncedAt
    }

    var source: SessionSource {
        get { SessionSource(rawValue: sourceRaw) ?? .ble }
        set { sourceRaw = newValue.rawValue }
    }

    var replayState: ReplayState {
        get { ReplayState(rawValue: replayStateRaw) ?? .none }
        set { replayStateRaw = newValue.rawValue }
    }

    var startedAt: Date { Date(timeIntervalSince1970: Double(startedAtEpochMs) / 1000) }
    var endedAt: Date? { endedAtEpochMs.map { Date(timeIntervalSince1970: Double($0) / 1000) } }
    var isCompleted: Bool { endedAtEpochMs != nil }
}

// MARK: - Session summary

/// The 20-byte FE02 morning card, stored as-is (one row per session).
@Model
final class SummaryModel {
    var id: UUID
    var sessionId: UUID
    var sessionLenS: Int64
    var epochsLogged: Int
    var sweatEvents: Int
    var longestSweatS: Int
    var peakDahX100: Int
    var hrMean: Int
    var hrMin: Int
    var hrMax: Int
    var pctWake: Int
    var pctLight: Int
    var pctDeep: Int
    var battPct: Int
    var slot: Int

    init(id: UUID = UUID(), sessionId: UUID, sessionLenS: Int64, epochsLogged: Int, sweatEvents: Int,
         longestSweatS: Int, peakDahX100: Int, hrMean: Int, hrMin: Int, hrMax: Int,
         pctWake: Int, pctLight: Int, pctDeep: Int, battPct: Int, slot: Int) {
        self.id = id
        self.sessionId = sessionId
        self.sessionLenS = sessionLenS
        self.epochsLogged = epochsLogged
        self.sweatEvents = sweatEvents
        self.longestSweatS = longestSweatS
        self.peakDahX100 = peakDahX100
        self.hrMean = hrMean
        self.hrMin = hrMin
        self.hrMax = hrMax
        self.pctWake = pctWake
        self.pctLight = pctLight
        self.pctDeep = pctDeep
        self.battPct = battPct
        self.slot = slot
    }

    convenience init(sessionId: UUID, summary: SessionSummary) {
        self.init(sessionId: sessionId, sessionLenS: summary.sessionLenS, epochsLogged: summary.epochsLogged,
                  sweatEvents: summary.sweatEvents, longestSweatS: summary.longestSweatS,
                  peakDahX100: summary.peakDahX100, hrMean: summary.hrMeanBpm, hrMin: summary.hrMinBpm,
                  hrMax: summary.hrMaxBpm, pctWake: summary.pctWake, pctLight: summary.pctLight,
                  pctDeep: summary.pctDeep, battPct: summary.battPct, slot: summary.slot)
    }

    /// Copy the protocol struct's fields into this row (upsert path).
    func apply(_ summary: SessionSummary) {
        sessionLenS = summary.sessionLenS
        epochsLogged = summary.epochsLogged
        sweatEvents = summary.sweatEvents
        longestSweatS = summary.longestSweatS
        peakDahX100 = summary.peakDahX100
        hrMean = summary.hrMeanBpm
        hrMin = summary.hrMinBpm
        hrMax = summary.hrMaxBpm
        pctWake = summary.pctWake
        pctLight = summary.pctLight
        pctDeep = summary.pctDeep
        battPct = summary.battPct
        slot = summary.slot
    }

    /// Back to the protocol struct, for code (charts, analytics) that speaks SessionSummary.
    func toSummary() -> SessionSummary {
        SessionSummary(sessionLenS: sessionLenS, epochsLogged: epochsLogged, sweatEvents: sweatEvents,
                       longestSweatS: longestSweatS, peakDahX100: peakDahX100,
                       hrMeanBpm: hrMean, hrMinBpm: hrMin, hrMaxBpm: hrMax,
                       pctWake: pctWake, pctLight: pctLight, pctDeep: pctDeep, battPct: battPct, slot: slot)
    }

    var peakDah: Double { Double(peakDahX100) / 100 }
}

// MARK: - Epochs

/// One 30-second epoch (the 34-byte v1 / 42-byte v2 log record, CRC already verified before
/// it gets here). Room enforced UNIQUE(sessionId, tS) with REPLACE; the repository replicates
/// that. The ext columns (ext brief §7) are nil on every v1 row and carry `= nil` defaults so
/// SwiftData's lightweight migration fills them in on stores created before the extension.
@Model
final class EpochModel {
    var id: UUID
    var sessionId: UUID
    var tS: Int64
    var hrBpm: Int
    var hrQuality: Int
    var skinTempX100: Int
    var skinRhX100: Int
    var ambTempX100: Int
    var ambRhX100: Int
    var motionIndex: Int
    var sleepState: Int             // SleepState.rawValue
    var sweatFlag: Int              // SweatFlag.rawValue
    var battPct: Int
    var flags: Int
    var dahX100: Int
    var hrvMeanIbi: Int
    var hrvSdnnX10: Int
    var hrvRmssdX10: Int
    var hrvPnn50: Int
    var hrvQuality: Int
    var hrvFlags: Int
    var vcellCv: Int
    /// v2 ext fields (ext brief §7) — wire values verbatim; gate on extFlags VALID bits
    /// before showing. Optional WITH defaults: lightweight migration of pre-extension
    /// stores adds the columns as nil.
    var edaX100: Int? = nil
    var spo2X10: Int? = nil
    var perfusionX100: Int? = nil
    var extFlags: Int? = nil

    init(id: UUID = UUID(), sessionId: UUID, tS: Int64, hrBpm: Int, hrQuality: Int,
         skinTempX100: Int, skinRhX100: Int, ambTempX100: Int, ambRhX100: Int,
         motionIndex: Int, sleepState: Int, sweatFlag: Int, battPct: Int, flags: Int, dahX100: Int,
         hrvMeanIbi: Int, hrvSdnnX10: Int, hrvRmssdX10: Int, hrvPnn50: Int,
         hrvQuality: Int, hrvFlags: Int, vcellCv: Int,
         edaX100: Int? = nil, spo2X10: Int? = nil, perfusionX100: Int? = nil, extFlags: Int? = nil) {
        self.id = id
        self.sessionId = sessionId
        self.tS = tS
        self.hrBpm = hrBpm
        self.hrQuality = hrQuality
        self.skinTempX100 = skinTempX100
        self.skinRhX100 = skinRhX100
        self.ambTempX100 = ambTempX100
        self.ambRhX100 = ambRhX100
        self.motionIndex = motionIndex
        self.sleepState = sleepState
        self.sweatFlag = sweatFlag
        self.battPct = battPct
        self.flags = flags
        self.dahX100 = dahX100
        self.hrvMeanIbi = hrvMeanIbi
        self.hrvSdnnX10 = hrvSdnnX10
        self.hrvRmssdX10 = hrvRmssdX10
        self.hrvPnn50 = hrvPnn50
        self.hrvQuality = hrvQuality
        self.hrvFlags = hrvFlags
        self.vcellCv = vcellCv
        self.edaX100 = edaX100
        self.spo2X10 = spo2X10
        self.perfusionX100 = perfusionX100
        self.extFlags = extFlags
    }

    /// Verified LogRecord → row (the Android `LogRecord.toEntity` mapping).
    static func from(record: LogRecord, sessionId: UUID) -> EpochModel {
        EpochModel(sessionId: sessionId, tS: record.tS, hrBpm: record.hrBpm, hrQuality: record.hrQuality,
                   skinTempX100: record.skinTempX100, skinRhX100: record.skinRhX100,
                   ambTempX100: record.ambTempX100, ambRhX100: record.ambRhX100,
                   motionIndex: record.motionIndex, sleepState: record.sleepState.rawValue,
                   sweatFlag: record.sweatFlag.rawValue, battPct: record.battPct, flags: record.flags,
                   dahX100: record.dahX100, hrvMeanIbi: record.hrvMeanIbiMs, hrvSdnnX10: record.hrvSdnnMsX10,
                   hrvRmssdX10: record.hrvRmssdMsX10, hrvPnn50: record.hrvPnn50Pct,
                   hrvQuality: record.hrvQuality, hrvFlags: record.hrvFlags, vcellCv: record.vcellCv,
                   edaX100: record.edaX100, spo2X10: record.spo2X10,
                   perfusionX100: record.perfusionX100, extFlags: record.extFlags)
    }

    /// Row → LogRecord, so analytics/charts run on the same struct the parser produces.
    func toRecord() -> LogRecord {
        LogRecord(tS: tS, hrBpm: hrBpm, hrQuality: hrQuality,
                  skinTempX100: skinTempX100, skinRhX100: skinRhX100,
                  ambTempX100: ambTempX100, ambRhX100: ambRhX100,
                  motionIndex: motionIndex, sleepState: .from(sleepState), sweatFlag: .from(sweatFlag),
                  battPct: battPct, flags: flags, dahX100: dahX100,
                  hrvMeanIbiMs: hrvMeanIbi, hrvSdnnMsX10: hrvSdnnX10, hrvRmssdMsX10: hrvRmssdX10,
                  hrvPnn50Pct: hrvPnn50, hrvQuality: hrvQuality, hrvFlags: hrvFlags, vcellCv: vcellCv,
                  edaX100: edaX100, spo2X10: spo2X10, perfusionX100: perfusionX100, extFlags: extFlags)
    }
}

// MARK: - HRV points

/// True HRV series: one row per closed 10-minute window (FLAG_HRV_FRESH records or FE05 notifies).
/// Room enforced UNIQUE(sessionId, windowEndS) with REPLACE; the repository replicates that.
@Model
final class HrvPointModel {
    var id: UUID
    var sessionId: UUID
    /// Seconds since session start.
    var windowEndS: Int64
    var meanIbi: Int
    var sdnnX10: Int
    var rmssdX10: Int
    var pnn50: Int
    var accepted: Int
    var rejected: Int
    var quality: Int
    var flags: Int

    init(id: UUID = UUID(), sessionId: UUID, windowEndS: Int64, meanIbi: Int, sdnnX10: Int,
         rmssdX10: Int, pnn50: Int, accepted: Int, rejected: Int, quality: Int, flags: Int) {
        self.id = id
        self.sessionId = sessionId
        self.windowEndS = windowEndS
        self.meanIbi = meanIbi
        self.sdnnX10 = sdnnX10
        self.rmssdX10 = rmssdX10
        self.pnn50 = pnn50
        self.accepted = accepted
        self.rejected = rejected
        self.quality = quality
        self.flags = flags
    }

    /// GATE ON THIS — never display HRV without it (HrvFlags.valid).
    var isValid: Bool { HrvFlags.has(flags, HrvFlags.valid) }
    var rmssdMs: Double { Double(rmssdX10) / 10 }
    var sdnnMs: Double { Double(sdnnX10) / 10 }
}

// MARK: - Sweat events

/// Derived from sweat_flag transitions (START → … → NONE); recomputed by the repository.
@Model
final class SweatEventModel {
    var id: UUID
    var sessionId: UUID
    var startS: Int64
    var endS: Int64
    var peakDahX100: Int

    init(id: UUID = UUID(), sessionId: UUID, startS: Int64, endS: Int64, peakDahX100: Int) {
        self.id = id
        self.sessionId = sessionId
        self.startS = startS
        self.endS = endS
        self.peakDahX100 = peakDahX100
    }

    var durationS: Int64 { endS - startS }
    var peakDah: Double { Double(peakDahX100) / 100 }
}

// MARK: - Activity events

/// Timeline markers: demo mode changes, user tags, pod events. Shown on charts and in the log.
/// Unlike Android (which stored an English label string), we store a LOCALIZATION KEY so the
/// event log follows the app language — views render `L(event.labelKey)`.
@Model
final class ActivityEventModel {
    var id: UUID
    var sessionId: UUID
    var tS: Int64
    var kindRaw: String             // ActivityKind.rawValue
    var labelKey: String            // localization key, usually kind.labelKey
    var sourceRaw: String           // EventSource.rawValue

    init(id: UUID = UUID(), sessionId: UUID, tS: Int64, kind: ActivityKind, labelKey: String? = nil, source: EventSource) {
        self.id = id
        self.sessionId = sessionId
        self.tS = tS
        self.kindRaw = kind.rawValue
        self.labelKey = labelKey ?? kind.labelKey
        self.sourceRaw = source.rawValue
    }

    var kind: ActivityKind {
        get { ActivityKind(rawValue: kindRaw) ?? .up }
        set { kindRaw = newValue.rawValue }
    }

    var source: EventSource {
        get { EventSource(rawValue: sourceRaw) ?? .pod }
        set { sourceRaw = newValue.rawValue }
    }
}

// MARK: - Pod slots

/// The app's own slot inventory (spec §15.1 — the pod cannot list what it stores).
/// One row per slot number 0..13; the repository upserts by `slot`.
@Model
final class PodSlotModel {
    var id: UUID
    var slot: Int
    var sessionId: UUID?
    var lastSeenAt: Int64           // epoch ms

    init(id: UUID = UUID(), slot: Int, sessionId: UUID?, lastSeenAt: Int64) {
        self.id = id
        self.slot = slot
        self.sessionId = sessionId
        self.lastSeenAt = lastSeenAt
    }
}

// MARK: - Schema

/// Everything the app's ModelContainer needs — the coordinator builds the container from this.
enum AuroraSchema {
    static let models: [any PersistentModel.Type] = [
        UserModel.self, SessionModel.self, SummaryModel.self, EpochModel.self,
        HrvPointModel.self, SweatEventModel.self, ActivityEventModel.self, PodSlotModel.self,
    ]
}
