// Local-only accounts — port of the Android AuthRepository (salted SHA-256, never plaintext).
//
// THREADING CONTRACT: synchronous, main-thread only, like SessionRepository — it shares
// the app's main ModelContext and writes AppSettings.userId (a @Published var).
//
// When a server exists, a SyncGateway.signIn replaces this and the returned token is
// stored instead of a local hash — the UI contract stays the same.

import Foundation
import SwiftData
import CryptoKit

/// Sign-in/register outcome. Failure carries a LOCALIZATION KEY (app_auth_* family) —
/// views render it with L(key), mirroring Android's @StringRes messageRes.
enum AuthResult {
    case success(UserModel)
    case failure(messageKey: String)
}

final class AuthRepository {

    static let demoEmail = "aurorademo@gmail.com"
    static let demoPassword = "pswd"
    static let demoName = "Aurora Demo"

    private let context: ModelContext
    private let settings: AppSettings

    init(context: ModelContext, settings: AppSettings) {
        self.context = context
        self.settings = settings
    }

    // ------------------------------------------------------------------ public API

    /// Creates the demo account on first launch (idempotent).
    func seedDemoAccount() {
        guard byEmail(AuthRepository.demoEmail) == nil else { return }
        let salt = newSalt()
        context.insert(UserModel(email: AuthRepository.demoEmail,
                                 passwordHash: hash(AuthRepository.demoPassword, salt: salt),
                                 salt: salt,
                                 displayName: AuthRepository.demoName,
                                 createdAt: nowMs()))
        try? context.save()
    }

    func signIn(email: String, password: String) -> AuthResult {
        let e = email.trimmingCharacters(in: .whitespacesAndNewlines)
        if e.isEmpty || password.isEmpty { return .failure(messageKey: "app_auth_enter_credentials") }
        guard let user = byEmail(e) else { return .failure(messageKey: "app_auth_no_account") }
        if hash(password, salt: user.salt) != user.passwordHash {
            return .failure(messageKey: "app_auth_wrong_password")
        }
        settings.userId = user.id.uuidString
        return .success(user)
    }

    func register(email: String, password: String, name: String) -> AuthResult {
        let e = email.trimmingCharacters(in: .whitespacesAndNewlines)
        if !e.contains("@") || !e.contains(".") { return .failure(messageKey: "app_auth_invalid_email") }
        if password.count < 4 { return .failure(messageKey: "app_auth_password_short") }
        if byEmail(e) != nil { return .failure(messageKey: "app_auth_email_exists") }
        let salt = newSalt()
        let display = name.isEmpty ? String(e.prefix(while: { $0 != "@" })) : name
        let user = UserModel(email: e, passwordHash: hash(password, salt: salt), salt: salt,
                             displayName: display, createdAt: nowMs())
        context.insert(user)
        try? context.save()
        settings.userId = user.id.uuidString
        return .success(user)
    }

    func signOut() {
        settings.userId = nil
    }

    func user(id: UUID) -> UserModel? {
        let uid = id
        var d = FetchDescriptor<UserModel>(predicate: #Predicate { $0.id == uid })
        d.fetchLimit = 1
        return (try? context.fetch(d))?.first
    }

    /// The signed-in user per AppSettings.userId, or nil.
    func currentUser() -> UserModel? {
        guard let s = settings.userId, let uid = UUID(uuidString: s) else { return nil }
        return user(id: uid)
    }

    // ------------------------------------------------------------------ internals

    /// Case-insensitive email lookup (Android used COLLATE NOCASE). #Predicate has no
    /// case-insensitive equality, and the users table holds a handful of rows at most,
    /// so we filter in memory.
    private func byEmail(_ email: String) -> UserModel? {
        let all = (try? context.fetch(FetchDescriptor<UserModel>())) ?? []
        return all.first { $0.email.caseInsensitiveCompare(email) == .orderedSame }
    }

    private func nowMs() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

    /// 16 random bytes, hex-encoded. SystemRandomNumberGenerator is cryptographically secure.
    private func newSalt() -> String {
        var rng = SystemRandomNumberGenerator()
        return (0..<16).map { _ in String(format: "%02x", UInt8.random(in: .min ... .max, using: &rng)) }.joined()
    }

    /// SHA-256 of "salt:password", lowercase hex — the exact scheme the Android app uses,
    /// so exported/imported data stays compatible.
    private func hash(_ password: String, salt: String) -> String {
        let digest = SHA256.hash(data: Data((salt + ":" + password).utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }
}
