import Foundation
import CoreBluetooth

// MARK: - UUIDs (spec §2 / §17)

enum AuroraUUID {
    static let service = CBUUID(string: "6E40FE00-B5A3-F393-E0A9-E50E24DCCA9E")
    static let vitals = CBUUID(string: "6E40FE01-B5A3-F393-E0A9-E50E24DCCA9E")   // NOTIFY 20 B 1 Hz
    static let summary = CBUUID(string: "6E40FE02-B5A3-F393-E0A9-E50E24DCCA9E")  // READ+NOTIFY 20 B
    static let control = CBUUID(string: "6E40FE03-B5A3-F393-E0A9-E50E24DCCA9E")  // WRITE 1–16 B
    static let log = CBUUID(string: "6E40FE04-B5A3-F393-E0A9-E50E24DCCA9E")      // NOTIFY 20 B replay
    static let hrv = CBUUID(string: "6E40FE05-B5A3-F393-E0A9-E50E24DCCA9E")      // READ+NOTIFY 15 B
    static let extVitals = CBUUID(string: "6E40FE06-B5A3-F393-E0A9-E50E24DCCA9E") // NOTIFY 20 B 1 Hz (ext brief §1; absent on firmware 1.0.0)

    static let deviceInfoService = CBUUID(string: "180A")
    static let manufacturerName = CBUUID(string: "2A29")
    static let modelNumber = CBUUID(string: "2A24")
    static let hardwareRevision = CBUUID(string: "2A27")
    static let softwareRevision = CBUUID(string: "2A28")
    static let batteryService = CBUUID(string: "180F")
    static let batteryLevel = CBUUID(string: "2A19")

    static let advertisedName = "AuroraPod"
    static let builtAgainstFirmware = "1.0.0"
}

// MARK: - Little-endian reader/writer (every field is LE, spec §2)

struct LEReader {
    let data: Data
    private(set) var offset: Int
    init(_ data: Data, offset: Int = 0) { self.data = data; self.offset = offset }

    mutating func u8() -> Int { defer { offset += 1 }; return Int(data[data.startIndex + offset]) }
    mutating func u16() -> Int {
        let b0 = Int(data[data.startIndex + offset]); let b1 = Int(data[data.startIndex + offset + 1])
        offset += 2; return b0 | (b1 << 8)
    }
    mutating func s16() -> Int { let v = u16(); return v >= 0x8000 ? v - 0x10000 : v }
    mutating func u32() -> Int64 {
        let b0 = Int64(data[data.startIndex + offset]); let b1 = Int64(data[data.startIndex + offset + 1])
        let b2 = Int64(data[data.startIndex + offset + 2]); let b3 = Int64(data[data.startIndex + offset + 3])
        offset += 4; return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
    }
}

struct LEWriter {
    private(set) var data = Data()
    mutating func raw(_ d: Data) { data.append(d) }
    mutating func u8(_ v: Int) { data.append(UInt8(v & 0xFF)) }
    mutating func u16(_ v: Int) { data.append(UInt8(v & 0xFF)); data.append(UInt8((v >> 8) & 0xFF)) }
    mutating func s16(_ v: Int) { u16(v < 0 ? v + 0x10000 : v) }
    mutating func u32(_ v: Int64) {
        data.append(UInt8(v & 0xFF)); data.append(UInt8((v >> 8) & 0xFF))
        data.append(UInt8((v >> 16) & 0xFF)); data.append(UInt8((v >> 24) & 0xFF))
    }
}

// MARK: - Enums & flags (spec §7)

enum SleepState: Int, Codable, CaseIterable {
    case wake = 0, light = 1, deep = 2, unknown = 3
    static func from(_ code: Int) -> SleepState { SleepState(rawValue: code) ?? .unknown }
}

enum SweatFlag: Int, Codable {
    case none = 0, ongoing = 1, start = 2
    static func from(_ code: Int) -> SweatFlag { SweatFlag(rawValue: code) ?? .none }
}

enum PodFlags {
    static let ppgActive = 0x01
    static let podDetected = 0x02
    static let charging = 0x04
    static let lowBatt = 0x08
    static let sensorFault = 0x10
    static let logging = 0x20
    static let timeSynced = 0x40
    static let hrvFresh = 0x80 // log records only
    static func has(_ flags: Int, _ bit: Int) -> Bool { flags & bit != 0 }
}

enum HrvFlags {
    static let valid = 0x01      // GATE ON THIS — never display HRV without it
    static let lowBeats = 0x02
    static let motion = 0x04
    static let lowPerf = 0x08
    static let bufFull = 0x10
    static let wallClock = 0x20
    static let sampleLoss = 0x40
    static func has(_ flags: Int, _ bit: Int) -> Bool { flags & bit != 0 }
}

/// ext_flags bitfield (uint8) — FE06 and every v2 log record (ext brief §1).
/// A field is shown ONLY when its VALID bit is set; the raw value is meaningless otherwise.
enum ExtFlags {
    static let edaValid = 0x01
    static let spo2Valid = 0x02
    static let piValid = 0x04
    static func has(_ flags: Int, _ bit: Int) -> Bool { flags & bit != 0 }
}

enum QualityBand {
    case hide, lowConfidence, normal
    static func of(_ quality: Int) -> QualityBand {
        if quality < 40 { return .hide }
        if quality < 70 { return .lowConfidence }
        return .normal
    }
}

enum Cadence {
    static let epochS = 30
    static let hrvPeriodS = 600
    static let ppgBurstS = 120
    static let batteryUpdateS = 60
    static let nightSlots = 14
}

// MARK: - CRC-16/CCITT-FALSE (spec §8.3)

enum Crc16 {
    /// Poly 0x1021, init 0xFFFF, no reflection, no final XOR.
    static func ccittFalse(_ data: Data, offset: Int = 0, length: Int? = nil) -> Int {
        var crc = 0xFFFF
        let len = length ?? (data.count - offset)
        for i in offset..<(offset + len) {
            crc ^= Int(data[data.startIndex + i]) << 8
            for _ in 0..<8 {
                crc = (crc & 0x8000) != 0 ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF
            }
        }
        return crc
    }
}

// MARK: - FE01 Live Vitals (20 B, 1 Hz, spec §3)

struct LiveVitals: Equatable {
    static let size = 20
    var tS: Int64
    var hrBpm: Int
    var hrQuality: Int
    var skinTempX100: Int   // SIGNED
    var skinRhX100: Int
    var ambTempX100: Int    // SIGNED
    var ambRhX100: Int
    var motionIndex: Int
    var sleepState: SleepState
    var sweatFlag: SweatFlag
    var battPct: Int
    var flags: Int

    var skinTempC: Double { Double(skinTempX100) / 100 }
    var ambTempC: Double { Double(ambTempX100) / 100 }
    var skinRh: Double { Double(skinRhX100) / 100 }
    var ambRh: Double { Double(ambRhX100) / 100 }
    var ppgActive: Bool { PodFlags.has(flags, PodFlags.ppgActive) }
    var logging: Bool { PodFlags.has(flags, PodFlags.logging) }
    var timeSynced: Bool { PodFlags.has(flags, PodFlags.timeSynced) }
    var sensorFault: Bool { PodFlags.has(flags, PodFlags.sensorFault) }
    var podDetected: Bool { PodFlags.has(flags, PodFlags.podDetected) }
    var charging: Bool { PodFlags.has(flags, PodFlags.charging) }
    var lowBatt: Bool { PodFlags.has(flags, PodFlags.lowBatt) }
    /// Valid HR this second? 0 means no reading — never show "0 bpm".
    var hasHr: Bool { hrBpm > 0 && QualityBand.of(hrQuality) != .hide }
    var secondsToNextPpg: Int {
        let inCycle = Int(tS % Int64(Cadence.hrvPeriodS))
        return inCycle < Cadence.ppgBurstS ? 0 : Cadence.hrvPeriodS - inCycle
    }

    static func parse(_ data: Data) -> LiveVitals? {
        guard data.count >= size else { return nil }
        var r = LEReader(data)
        return LiveVitals(
            tS: r.u32(), hrBpm: r.u8(), hrQuality: r.u8(),
            skinTempX100: r.s16(), skinRhX100: r.u16(), ambTempX100: r.s16(), ambRhX100: r.u16(),
            motionIndex: r.u16(), sleepState: .from(r.u8()), sweatFlag: .from(r.u8()),
            battPct: r.u8(), flags: r.u8()
        )
    }

    func encode() -> Data {
        var w = LEWriter()
        w.u32(tS); w.u8(hrBpm); w.u8(hrQuality)
        w.s16(skinTempX100); w.u16(skinRhX100); w.s16(ambTempX100); w.u16(ambRhX100)
        w.u16(motionIndex); w.u8(sleepState.rawValue); w.u8(sweatFlag.rawValue)
        w.u8(battPct); w.u8(flags)
        return w.data
    }
}

// MARK: - FE05 HRV Summary (15 B, every 10 min, spec §4)

struct HrvSummary: Equatable {
    static let size = 15
    var windowEndTimeS: Int64
    var meanIbiMs: Int
    var sdnnMsX10: Int
    var rmssdMsX10: Int
    var pnn50Pct: Int
    var beatsAccepted: Int
    var beatsRejected: Int
    var quality: Int
    var flags: Int

    /// THE ONE RULE: never display unless valid.
    var isValid: Bool { HrvFlags.has(flags, HrvFlags.valid) }
    var isWallClock: Bool { HrvFlags.has(flags, HrvFlags.wallClock) }
    var sdnnMs: Double { Double(sdnnMsX10) / 10 }
    var rmssdMs: Double { Double(rmssdMsX10) / 10 }

    static func parse(_ data: Data) -> HrvSummary? {
        guard data.count >= size else { return nil }
        var r = LEReader(data)
        return HrvSummary(
            windowEndTimeS: r.u32(), meanIbiMs: r.u16(), sdnnMsX10: r.u16(), rmssdMsX10: r.u16(),
            pnn50Pct: r.u8(), beatsAccepted: r.u8(), beatsRejected: r.u8(), quality: r.u8(), flags: r.u8()
        )
    }

    func encode() -> Data {
        var w = LEWriter()
        w.u32(windowEndTimeS); w.u16(meanIbiMs); w.u16(sdnnMsX10); w.u16(rmssdMsX10)
        w.u8(pnn50Pct); w.u8(beatsAccepted); w.u8(beatsRejected); w.u8(quality); w.u8(flags)
        return w.data
    }
}

// MARK: - FE06 Extended Vitals (20 B, 1 Hz, ext brief §1)

/// EDA / SpO2 / perfusion, same tick as the FE01 packet it accompanies.
/// Firmware 1.0.0 never sends this; the demo pod does, and a future firmware just works.
struct ExtendedVitals: Equatable {
    static let size = 20
    var tS: Int64
    /// Skin conductance, microsiemens ×100 (typ 100–2000; flash spike +200–1000).
    var edaX100: Int
    /// Blood oxygen % ×10 (e.g. 968 = 96.8 %).
    var spo2X10: Int
    /// PPG perfusion index % ×100 (blood flow; typ 50–400).
    var perfusionX100: Int
    var extFlags: Int

    var edaValid: Bool { ExtFlags.has(extFlags, ExtFlags.edaValid) }
    var spo2Valid: Bool { ExtFlags.has(extFlags, ExtFlags.spo2Valid) }
    var perfusionValid: Bool { ExtFlags.has(extFlags, ExtFlags.piValid) }

    /// Display values — nil unless the VALID bit is set (ext brief §1: show ONLY when valid).
    var edaUs: Double? { edaValid ? Double(edaX100) / 100 : nil }
    var spo2Pct: Double? { spo2Valid ? Double(spo2X10) / 10 : nil }
    var perfusionPct: Double? { perfusionValid ? Double(perfusionX100) / 100 : nil }

    /// Returns nil on wrong length (ext brief §1) — unlike the v1 parsers, no exceptions anywhere.
    static func parse(_ data: Data) -> ExtendedVitals? {
        guard data.count >= size else { return nil }
        var r = LEReader(data)
        return ExtendedVitals(tS: r.u32(), edaX100: r.u16(), spo2X10: r.u16(),
                              perfusionX100: r.u16(), extFlags: r.u8())
    }

    func encode() -> Data {
        var w = LEWriter()
        w.u32(tS); w.u16(edaX100); w.u16(spo2X10); w.u16(perfusionX100); w.u8(extFlags)
        while w.data.count < ExtendedVitals.size { w.u8(0) } // bytes 11–19 reserved, zero
        return w.data
    }
}

// MARK: - FE02 Session Summary (20 B, the "morning card", spec §11)

struct SessionSummary: Equatable {
    static let size = 20
    var sessionLenS: Int64
    var epochsLogged: Int
    var sweatEvents: Int
    var longestSweatS: Int
    var peakDahX100: Int
    var hrMeanBpm: Int
    var hrMinBpm: Int
    var hrMaxBpm: Int
    var pctWake: Int
    var pctLight: Int
    var pctDeep: Int
    var battPct: Int
    var slot: Int   // SAVE THIS — the only way to replay later

    var peakDah: Double { Double(peakDahX100) / 100 }

    static func parse(_ data: Data) -> SessionSummary? {
        guard data.count >= size else { return nil }
        var r = LEReader(data)
        return SessionSummary(
            sessionLenS: r.u32(), epochsLogged: r.u16(), sweatEvents: r.u16(),
            longestSweatS: r.u16(), peakDahX100: r.u16(),
            hrMeanBpm: r.u8(), hrMinBpm: r.u8(), hrMaxBpm: r.u8(),
            pctWake: r.u8(), pctLight: r.u8(), pctDeep: r.u8(), battPct: r.u8(), slot: r.u8()
        )
    }

    func encode() -> Data {
        var w = LEWriter()
        w.u32(sessionLenS); w.u16(epochsLogged); w.u16(sweatEvents); w.u16(longestSweatS); w.u16(peakDahX100)
        w.u8(hrMeanBpm); w.u8(hrMinBpm); w.u8(hrMaxBpm); w.u8(pctWake); w.u8(pctLight); w.u8(pctDeep)
        w.u8(battPct); w.u8(slot)
        return w.data
    }
}

// MARK: - Log record (34 B v1 / 42 B v2 inside FE04 stream, spec §10; v2 ext brief §1)

struct LogRecord: Equatable {
    static let size = 34
    static let sizeV2 = 42
    static let crcCoverage = 32

    var tS: Int64
    var hrBpm: Int
    var hrQuality: Int
    var skinTempX100: Int
    var skinRhX100: Int
    var ambTempX100: Int
    var ambRhX100: Int
    var motionIndex: Int
    var sleepState: SleepState
    var sweatFlag: SweatFlag
    var battPct: Int
    var flags: Int
    var dahX100: Int          // differential absolute humidity ×100 — THE sweat number
    var hrvMeanIbiMs: Int
    var hrvSdnnMsX10: Int
    var hrvRmssdMsX10: Int
    var hrvPnn50Pct: Int
    var hrvQuality: Int
    var hrvFlags: Int
    var vcellCv: Int          // volts = 2.50 + cv/100; 0 = no reading
    /// v2 ext fields (ext brief §1): nil on every v1 record. `extFlags` non-nil marks a v2
    /// record; the value fields hold the wire bytes verbatim — use the gated accessors
    /// below for anything user-visible (a field counts only when its VALID bit is set).
    var edaX100: Int? = nil
    var spo2X10: Int? = nil
    var perfusionX100: Int? = nil
    var extFlags: Int? = nil

    var dah: Double { Double(dahX100) / 100 }
    var skinTempC: Double { Double(skinTempX100) / 100 }
    var ambTempC: Double { Double(ambTempX100) / 100 }
    var hrvFresh: Bool { PodFlags.has(flags, PodFlags.hrvFresh) }
    var hrvValid: Bool { HrvFlags.has(hrvFlags, HrvFlags.valid) }
    var hasHr: Bool { hrBpm > 0 && QualityBand.of(hrQuality) != .hide }

    /// True for a v2 record (any record parsed from / destined for the 42-byte layout).
    var hasExt: Bool { extFlags != nil }

    /// Gated ext readings — non-nil ONLY when the record is v2 AND the VALID bit is set.
    var validEdaX100: Int? {
        guard let f = extFlags, ExtFlags.has(f, ExtFlags.edaValid) else { return nil }
        return edaX100
    }
    var validSpo2X10: Int? {
        guard let f = extFlags, ExtFlags.has(f, ExtFlags.spo2Valid) else { return nil }
        return spo2X10
    }
    var validPerfusionX100: Int? {
        guard let f = extFlags, ExtFlags.has(f, ExtFlags.piValid) else { return nil }
        return perfusionX100
    }

    /// Display conveniences over the gated readings.
    var edaUs: Double? { validEdaX100.map { Double($0) / 100 } }
    var spo2Pct: Double? { validSpo2X10.map { Double($0) / 10 } }
    var perfusionPct: Double? { validPerfusionX100.map { Double($0) / 100 } }

    /// Returns nil when the CRC fails — such records must be DROPPED (spec §8.3) — or when
    /// `size` is not a supported record size (34 = v1, 42 = v2; ext brief §1). The CRC always
    /// covers the first size−2 bytes and sits in the last two.
    static func parse(_ data: Data, offset: Int = 0, size: Int = LogRecord.size) -> LogRecord? {
        guard size == LogRecord.size || size == LogRecord.sizeV2 else { return nil }
        guard data.count - offset >= size else { return nil }
        let base = data.startIndex + offset
        let stored = Int(data[base + size - 2]) | (Int(data[base + size - 1]) << 8)
        let computed = Crc16.ccittFalse(data, offset: offset, length: size - 2)
        guard stored == computed else { return nil }
        var r = LEReader(data, offset: offset)
        let isV2 = size == LogRecord.sizeV2
        var rec = LogRecord(
            tS: r.u32(), hrBpm: r.u8(), hrQuality: r.u8(),
            skinTempX100: r.s16(), skinRhX100: r.u16(), ambTempX100: r.s16(), ambRhX100: r.u16(),
            motionIndex: r.u16(), sleepState: .from(r.u8()), sweatFlag: .from(r.u8()),
            battPct: r.u8(), flags: r.u8(), dahX100: r.u16(),
            hrvMeanIbiMs: r.u16(), hrvSdnnMsX10: r.u16(), hrvRmssdMsX10: r.u16(),
            hrvPnn50Pct: r.u8(), hrvQuality: r.u8(), hrvFlags: r.u8(), vcellCv: r.u8()
        )
        if isV2 {
            // v2 tail — a v1 record parses exactly as before, ext fields stay nil.
            rec.edaX100 = r.u16()
            rec.spo2X10 = r.u16()
            rec.perfusionX100 = r.u16()
            rec.extFlags = r.u8() // reserved byte 39 is skipped
        }
        return rec
    }

    /// Encodes WITH a correct CRC — used by the demo simulator and tests.
    /// Emits 34 B when the ext fields are absent (v1) and 42 B when present (v2, ext brief §1);
    /// either way the CRC covers everything up to it and sits in the last two bytes.
    func encode() -> Data {
        var w = LEWriter()
        w.u32(tS); w.u8(hrBpm); w.u8(hrQuality)
        w.s16(skinTempX100); w.u16(skinRhX100); w.s16(ambTempX100); w.u16(ambRhX100)
        w.u16(motionIndex); w.u8(sleepState.rawValue); w.u8(sweatFlag.rawValue)
        w.u8(battPct); w.u8(flags); w.u16(dahX100)
        w.u16(hrvMeanIbiMs); w.u16(hrvSdnnMsX10); w.u16(hrvRmssdMsX10)
        w.u8(hrvPnn50Pct); w.u8(hrvQuality); w.u8(hrvFlags); w.u8(vcellCv)
        if hasExt {
            // v2 tail (ext brief §1): bytes 32–39, then CRC. Reserved byte 39 stays zero.
            w.u16(edaX100 ?? 0)
            w.u16(spo2X10 ?? 0)
            w.u16(perfusionX100 ?? 0)
            w.u8(extFlags ?? 0)
            w.u8(0)
        }
        let crc = Crc16.ccittFalse(w.data, offset: 0, length: w.data.count)
        w.u16(crc)
        return w.data
    }
}

// MARK: - Device information

struct DeviceInfo: Equatable {
    var manufacturer = ""
    var model = ""
    var hardwareRevision = ""
    var softwareRevision = ""
    var firmwareMismatch: Bool {
        !softwareRevision.isEmpty && softwareRevision != AuroraUUID.builtAgainstFirmware
    }
}

// MARK: - Control commands (FE03, spec §6 — fire-and-forget, confirm by observing)

enum PodCommand {
    case startSession                 // 0x01, confirm via FLAG_LOGGING
    case stopSession                  // 0x02, triggers FE02
    case timeSync(unixSeconds: Int64) // 0x03 — SEND FIRST, ALWAYS (spec §8.1)
    case hapticTest(millis: Int?)     // 0x04 (motor DNP on standard build)
    case fuelGaugeRelearn             // 0x05
    case replaySlot(Int)              // 0x06 + slot 0..13
    case abortReplay                  // 0x07
    case formatFlash                  // 0x08 A5 5A — DESTRUCTIVE, typed confirmation in UI
    case pushSummary                  // 0x09

    func encode() -> Data {
        var w = LEWriter()
        switch self {
        case .startSession: w.u8(0x01)
        case .stopSession: w.u8(0x02)
        case .timeSync(let t): w.u8(0x03); w.u32(t)
        case .hapticTest(let ms):
            w.u8(0x04)
            if let ms { w.u16(ms) }
        case .fuelGaugeRelearn: w.u8(0x05)
        case .replaySlot(let slot): w.u8(0x06); w.u8(max(0, min(Cadence.nightSlots - 1, slot)))
        case .abortReplay: w.u8(0x07)
        case .formatFlash: w.u8(0x08); w.u8(0xA5); w.u8(0x5A)
        case .pushSummary: w.u8(0x09)
        }
        return w.data
    }
}

// MARK: - Replay reassembly (FE04, spec §9 — "the part most likely to be got wrong")

/// frame = [uint16 seq][18 B payload]; seq 0xFFFF header, 0..N data, 0xFFFE end.
/// 18 does NOT divide 34: concatenate ALL payloads, then slice by header-derived record size.
final class ReplayAssembler {
    static let seqHeader = 0xFFFF
    static let seqEnd = 0xFFFE
    static let frameSize = 20
    static let framePayload = 18

    struct Header: Equatable {
        var totalBytes: Int64
        var recordCount: Int
        var slot: Int
        var recordSize: Int { recordCount == 0 ? 0 : Int(totalBytes) / recordCount }
        var expectedFrames: Int { Int((totalBytes + Int64(ReplayAssembler.framePayload) - 1) / Int64(ReplayAssembler.framePayload)) }
    }

    struct Progress {
        var framesReceived: Int
        var expectedFrames: Int
        var bytesReceived: Int
        var fraction: Double { expectedFrames == 0 ? 0 : min(1, Double(framesReceived) / Double(expectedFrames)) }
        var percent: Int { Int(fraction * 100) }
    }

    struct Result {
        var header: Header
        var records: [LogRecord]
        var crcFailures: Int
        var framesReceived: Int
        var framesSent: Int
        var sequenceGaps: Int
        var unsupportedFormat: Bool
        var complete: Bool { framesSent == framesReceived && sequenceGaps == 0 }
    }

    enum Event {
        case headerReceived(Header)
        case data(Progress)
        case finished(Result)
        case error(String)
    }

    private(set) var header: Header?
    private var buffer = Data()
    private var framesReceived = 0
    private var nextSeq = 0
    private var sequenceGaps = 0

    var progress: Progress {
        Progress(framesReceived: framesReceived, expectedFrames: header?.expectedFrames ?? 0, bytesReceived: buffer.count)
    }

    func reset() {
        header = nil; buffer.removeAll(); framesReceived = 0; nextSeq = 0; sequenceGaps = 0
    }

    func feed(_ frame: Data) -> Event {
        guard frame.count >= 2 else { return .error("Frame too short (\(frame.count) B)") }
        var r = LEReader(frame)
        let seq = r.u16()
        switch seq {
        case ReplayAssembler.seqHeader:
            guard frame.count >= 9 else { return .error("Header frame too short") }
            let total = r.u32(); let count = r.u16(); let slot = r.u8()
            reset()
            let h = Header(totalBytes: total, recordCount: count, slot: slot)
            header = h
            return .headerReceived(h)
        case ReplayAssembler.seqEnd:
            guard let h = header else { return .error("End frame before header") }
            let framesSent = frame.count >= 4 ? r.u16() : framesReceived
            return .finished(slice(h, framesSent: framesSent))
        default:
            guard header != nil else { return .error("Data frame before header") }
            if seq != nextSeq, seq > nextSeq { sequenceGaps += seq - nextSeq }
            nextSeq = seq + 1
            let payloadLen = min(ReplayAssembler.framePayload, frame.count - 2)
            buffer.append(frame.subdata(in: (frame.startIndex + 2)..<(frame.startIndex + 2 + payloadLen)))
            framesReceived += 1
            return .data(progress)
        }
    }

    private func slice(_ h: Header, framesSent: Int) -> Result {
        let size = h.recordSize
        // Record size comes from the header, never hard-coded. Firmware 1.0.0 writes 34-byte
        // (v1) records; ext-sensor firmware writes 42-byte (v2) records (ext brief §1).
        // Anything else is a format this build does not understand.
        guard size == LogRecord.size || size == LogRecord.sizeV2 else {
            return Result(header: h, records: [], crcFailures: 0, framesReceived: framesReceived,
                          framesSent: framesSent, sequenceGaps: sequenceGaps, unsupportedFormat: true)
        }
        var records: [LogRecord] = []
        var failures = 0
        var off = 0
        let limit = min(buffer.count, Int(h.totalBytes))
        while off + size <= limit {
            if let rec = LogRecord.parse(buffer, offset: off, size: size) { records.append(rec) } else { failures += 1 }
            off += size
        }
        return Result(header: h, records: records, crcFailures: failures, framesReceived: framesReceived,
                      framesSent: framesSent, sequenceGaps: sequenceGaps, unsupportedFormat: false)
    }

    /// Builds the frame stream for a slot image — used by the demo simulator and tests.
    static func frames(slot: Int, recordBytes: Data, recordCount: Int) -> [Data] {
        var out: [Data] = []
        var hdr = LEWriter()
        hdr.u16(seqHeader); hdr.u32(Int64(recordBytes.count)); hdr.u16(recordCount); hdr.u8(slot)
        while hdr.data.count < frameSize { hdr.u8(0) }
        out.append(hdr.data)
        var seq = 0, off = 0
        while off < recordBytes.count {
            var f = LEWriter()
            f.u16(seq)
            let n = min(framePayload, recordBytes.count - off)
            f.raw(recordBytes.subdata(in: (recordBytes.startIndex + off)..<(recordBytes.startIndex + off + n)))
            out.append(f.data)
            off += n; seq += 1
        }
        var end = LEWriter()
        end.u16(seqEnd); end.u16(seq)
        out.append(end.data)
        return out
    }

    /// Convenience over `frames(slot:recordBytes:recordCount:)` that encodes the records
    /// itself — the record size (34 v1 / 42 v2) follows from the records it is given,
    /// exactly like a slot image written by the matching firmware (ext brief §1).
    static func frames(slot: Int, records: [LogRecord]) -> [Data] {
        var image = Data()
        for r in records { image.append(r.encode()) }
        return frames(slot: slot, recordBytes: image, recordCount: records.count)
    }
}
