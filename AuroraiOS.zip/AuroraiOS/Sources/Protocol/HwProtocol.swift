// AURORA POD HARDWARE PROTOCOL v1 — the packets the real glove actually sends.
// Port of HwProtocol.kt (Android reference, unit-tested against real glove packets).
import Foundation

/*
 * Source of truth: hw/PROTOCOL.txt (STATUS: VERIFIED ON HARDWARE, 2026-09-28) and the
 * bridge's reference decoder pod_agent.py. This REPLACES the original paper spec for
 * anything that goes over the air; the rest of the app keeps its internal model
 * (LiveVitals / LogRecord / …) and `HwAdapter` translates between them.
 *
 * All integers little-endian. Every packet ends with CRC-16/CCITT-FALSE over all
 * preceding bytes; a replay RECORD carries its own CRC over its first 16 bytes.
 * The app MUST verify the CRC and discard packets that fail.
 */

/// Thrown by every hardware parser on wrong length, wrong header or CRC mismatch.
enum HwPacketError: Error, Equatable {
    case invalid(String)
}

enum HwConst {
    static let hdrVitals = 0xA1
    static let hdrSession = 0xA2
    static let hdrHrv = 0xA5
    static let lenVitals = 20
    static let lenSession = 20
    static let lenHrv = 15
    static let lenReplay = 20
    static let lenRecord = 18

    static let hrNone = 0xFFFF
    static let spo2None = 0xFF
    static let battUnknown = 0xFF
    static let tempNone = -32768

    /// Below this quality SpO2 must not be rendered (PROTOCOL §3).
    static let spo2MinQuality = 40
    /// HRV packets with fewer beats are ignored whole (PROTOCOL §4).
    static let hrvMinBeats = 5
    /// RAM log capacity (PROTOCOL §7): 8 h at the default 60 s interval.
    static let logCapacity = 480
    static let defaultLogPeriodS = 60
}

/// FE01 flags bitfield (PROTOCOL §3). Different bit meanings from the internal `PodFlags`.
enum HwFlags {
    static let finger = 0x01
    static let sessionActive = 0x02
    /// Abs humidity above the pod's own baseline. PROVISIONAL (placeholder threshold).
    static let flushActive = 0x04
    static let lowBattery = 0x08
    static let hrLocked = 0x10
    static let timeValid = 0x20

    static func has(_ flags: Int, _ bit: Int) -> Bool { (flags & bit) != 0 }
}

/// FE03 opcodes (PROTOCOL §6). Only 1–7 exist; there are no acks — confirm by observing.
enum HwOp {
    static let sessionStart = 0x01
    static let sessionStop = 0x02
    static let timeSyncOp = 0x03
    static let replayBegin = 0x04
    static let logErase = 0x05
    static let setPeriodOp = 0x06
    static let identify = 0x07

    static func simple(_ op: Int) -> Data { Data([UInt8(op & 0xFF)]) }

    /// 03 + u32 LE epoch. Big-endian would put the pod ~1500 years in the future.
    static func timeSync(_ epochS: Int64) -> Data {
        var w = LEWriter()
        w.u8(timeSyncOp)
        w.u32(epochS)
        return w.data
    }

    /// 06 + u8 seconds. Throws outside 1…240 (PROTOCOL §6).
    static func setPeriod(_ seconds: Int) throws -> Data {
        guard seconds >= 1 && seconds <= 240 else {
            throw HwPacketError.invalid("log interval must be 1..240 s")
        }
        return Data([UInt8(setPeriodOp), UInt8(seconds)])
    }
}

// MARK: - Helpers

enum HwWire {
    /// Stored CRC (LE, last two bytes of the covered block) matches the computed one.
    static func crcOk(_ b: Data, offset: Int, length: Int) -> Bool {
        let base = b.startIndex + offset
        let stored = Int(b[base + length - 2]) | (Int(b[base + length - 1]) << 8)
        return Crc16.ccittFalse(b, offset: offset, length: length - 2) == stored
    }

    static func check(_ b: Data, length: Int, header: Int, what: String) throws {
        guard b.count == length else { throw HwPacketError.invalid("\(what) len \(b.count) != \(length)") }
        let h = Int(b[b.startIndex])
        guard h == header else {
            throw HwPacketError.invalid("\(what) hdr 0x\(String(h, radix: 16)) != 0x\(String(header, radix: 16))")
        }
        guard crcOk(b, offset: 0, length: length) else { throw HwPacketError.invalid("\(what) CRC mismatch") }
    }

    /// Appends CRC-16 over bytes [from, end) of `data` (LE).
    static func seal(_ data: Data, from: Int = 0) -> Data {
        var out = data
        let crc = Crc16.ccittFalse(out, offset: from, length: out.count - from)
        out.append(UInt8(crc & 0xFF))
        out.append(UInt8((crc >> 8) & 0xFF))
        return out
    }
}

// MARK: - FE01 live vitals, 20 B @ 1 Hz

struct HwVitals: Equatable {
    var seq: Int
    var uptimeS: Int64
    /// °C ×100; nil = no reading (-32768 on the wire).
    var skinTempX100: Int?
    var skinRhX100: Int
    /// Absolute humidity at the skin, g/m³ ×100 — THE key signal.
    var absHumX100: Int
    /// bpm ×10; nil = no lock (0xFFFF) — render blank, never zero.
    var hrX10: Int?
    /// nil = invalid (0xFF). UNCALIBRATED estimate, trend only.
    var spo2Pct: Int?
    var quality: Int
    var flags: Int
    /// nil = unknown (0xFF) — show no gauge.
    var battPct: Int?

    var finger: Bool { HwFlags.has(flags, HwFlags.finger) }
    var sessionActive: Bool { HwFlags.has(flags, HwFlags.sessionActive) }
    var flushActive: Bool { HwFlags.has(flags, HwFlags.flushActive) }
    var lowBattery: Bool { HwFlags.has(flags, HwFlags.lowBattery) }
    var hrLocked: Bool { HwFlags.has(flags, HwFlags.hrLocked) }
    var timeValid: Bool { HwFlags.has(flags, HwFlags.timeValid) }

    /// HR to show: only when HR_LOCKED and present ("trust HR_LOCKED over presence of a value").
    var hrShowBpm: Double? {
        guard hrLocked, let hr = hrX10 else { return nil }
        return Double(hr) / 10.0
    }
    /// SpO2 estimate to show: present and quality ≥ 40, else greyed out.
    var spo2Show: Int? {
        guard let s = spo2Pct, quality >= HwConst.spo2MinQuality else { return nil }
        return s
    }

    func encode() -> Data {
        var w = LEWriter()
        w.u8(HwConst.hdrVitals)
        w.u8(seq)
        w.u32(uptimeS)
        w.s16(skinTempX100 ?? HwConst.tempNone)
        w.u16(skinRhX100)
        w.u16(absHumX100)
        w.u16(hrX10 ?? HwConst.hrNone)
        w.u8(spo2Pct ?? HwConst.spo2None)
        w.u8(quality)
        w.u8(flags)
        w.u8(battPct ?? HwConst.battUnknown)
        return HwWire.seal(w.data)
    }

    static func parse(_ bytes: Data) throws -> HwVitals {
        let b = Data(bytes) // rebase: slices keep their original indices
        try HwWire.check(b, length: HwConst.lenVitals, header: HwConst.hdrVitals, what: "vitals")
        var r = LEReader(b, offset: 1)
        let seq = r.u8()
        let up = r.u32()
        let t = r.s16()
        let rh = r.u16()
        let ah = r.u16()
        let hr = r.u16()
        let spo2 = r.u8()
        let q = r.u8()
        let fl = r.u8()
        let bat = r.u8()
        return HwVitals(seq: seq, uptimeS: up,
                        skinTempX100: t == HwConst.tempNone ? nil : t,
                        skinRhX100: rh, absHumX100: ah,
                        hrX10: hr == HwConst.hrNone ? nil : hr,
                        spo2Pct: spo2 == HwConst.spo2None ? nil : spo2,
                        quality: q, flags: fl,
                        battPct: bat == HwConst.battUnknown ? nil : bat)
    }
}

// MARK: - FE05 HRV, 15 B every 10 s

struct HwHrv: Equatable {
    var uptimeS: Int64
    var meanRrMs: Int
    var sdnnX10: Int
    var rmssdX10: Int
    var beats: Int
    var quality: Int

    /// Below 5 beats, ignore the whole packet (PROTOCOL §4).
    var usable: Bool { beats >= HwConst.hrvMinBeats && meanRrMs > 0 }

    func encode() -> Data {
        var w = LEWriter()
        w.u8(HwConst.hdrHrv)
        w.u32(uptimeS)
        w.u16(meanRrMs)
        w.u16(sdnnX10)
        w.u16(rmssdX10)
        w.u8(beats)
        w.u8(quality)
        return HwWire.seal(w.data)
    }

    static func parse(_ bytes: Data) throws -> HwHrv {
        let b = Data(bytes)
        try HwWire.check(b, length: HwConst.lenHrv, header: HwConst.hdrHrv, what: "hrv")
        var r = LEReader(b, offset: 1)
        let up = r.u32()
        let rr = r.u16()
        let sdnn = r.u16()
        let rmssd = r.u16()
        let beats = r.u8()
        let q = r.u8()
        return HwHrv(uptimeS: up, meanRrMs: rr, sdnnX10: sdnn, rmssdX10: rmssd, beats: beats, quality: q)
    }
}

// MARK: - FE02 session summary, 20 B

struct HwSession: Equatable {
    /// Unix seconds; nil when the clock was never set (0 on the wire).
    var startEpoch: Int64?
    /// While a session runs, this is the running duration (firmware buildSession).
    var durationS: Int64
    /// PROVISIONAL — placeholder threshold (PROTOCOL §9).
    var flushEvents: Int
    var peakAbsHumX100: Int
    var meanSkinTempX100: Int
    /// PLACEHOLDER until labelled data exists — never show as a claim.
    var score: Int
    var battPct: Int?
    /// Records available for replay, capped at 255 (the log itself holds up to 480).
    var logRecords: Int

    func encode() -> Data {
        var w = LEWriter()
        w.u8(HwConst.hdrSession)
        w.u32(startEpoch ?? 0)
        w.u32(durationS)
        w.u16(flushEvents)
        w.u16(peakAbsHumX100)
        w.s16(meanSkinTempX100)
        w.u8(score)
        w.u8(battPct ?? HwConst.battUnknown)
        w.u8(logRecords)
        return HwWire.seal(w.data)
    }

    static func parse(_ bytes: Data) throws -> HwSession {
        let b = Data(bytes)
        try HwWire.check(b, length: HwConst.lenSession, header: HwConst.hdrSession, what: "session")
        var r = LEReader(b, offset: 1)
        let start = r.u32()
        let dur = r.u32()
        let fe = r.u16()
        let peak = r.u16()
        let mean = r.s16()
        let score = r.u8()
        let bat = r.u8()
        let recs = r.u8()
        return HwSession(startEpoch: start == 0 ? nil : start, durationS: dur, flushEvents: fe,
                         peakAbsHumX100: peak, meanSkinTempX100: mean, score: score,
                         battPct: bat == HwConst.battUnknown ? nil : bat, logRecords: recs)
    }
}

// MARK: - FE04 replay frame [u16 seq][18 B record]

struct HwRecord: Equatable {
    var seq: Int
    var uptimeS: Int64
    var skinTempX100: Int?
    var skinRhX100: Int
    var absHumX100: Int
    var hrX10: Int?
    var spo2Pct: Int?
    var quality: Int
    var flags: Int
    var battPct: Int?

    func encodeFrame() -> Data {
        var w = LEWriter()
        w.u16(seq)
        w.u32(uptimeS)
        w.s16(skinTempX100 ?? HwConst.tempNone)
        w.u16(skinRhX100)
        w.u16(absHumX100)
        w.u16(hrX10 ?? HwConst.hrNone)
        w.u8(spo2Pct ?? HwConst.spo2None)
        w.u8(quality)
        w.u8(flags)
        w.u8(battPct ?? HwConst.battUnknown)
        // The record's own CRC covers its 16 bytes only (not the 2-byte seq).
        return HwWire.seal(w.data, from: 2)
    }

    /// One frame is exactly one record; the record carries its OWN CRC (PROTOCOL §7).
    static func parseFrame(_ bytes: Data) throws -> HwRecord {
        let b = Data(bytes)
        guard b.count == HwConst.lenReplay else {
            throw HwPacketError.invalid("replay len \(b.count) != \(HwConst.lenReplay)")
        }
        let seq = Int(b[0]) | (Int(b[1]) << 8)
        guard HwWire.crcOk(b, offset: 2, length: HwConst.lenRecord) else {
            throw HwPacketError.invalid("replay record \(seq) CRC mismatch")
        }
        var r = LEReader(b, offset: 2)
        let up = r.u32()
        let t = r.s16()
        let rh = r.u16()
        let ah = r.u16()
        let hr = r.u16()
        let spo2 = r.u8()
        let q = r.u8()
        let fl = r.u8()
        let bat = r.u8()
        return HwRecord(seq: seq, uptimeS: up,
                        skinTempX100: t == HwConst.tempNone ? nil : t,
                        skinRhX100: rh, absHumX100: ah,
                        hrX10: hr == HwConst.hrNone ? nil : hr,
                        spo2Pct: spo2 == HwConst.spo2None ? nil : spo2,
                        quality: q, flags: fl,
                        battPct: bat == HwConst.battUnknown ? nil : bat)
    }
}

// MARK: - Capabilities

/// What the connected pod can actually measure. The UI hides cards/panels for channels the
/// pod does not have instead of drawing empty charts or fabricated values.
/// The real glove (PROTOCOL §9): no accelerometer (no movement, no sleep staging), one
/// humidity sensor (no room climate), no skin-conductance electrode, no blood-flow index,
/// SpO2 only as an uncalibrated estimate, battery unknown until a cell is fitted.
struct PodCapabilities: Equatable {
    var skinConductance: Bool
    var spo2Estimate: Bool
    var bloodFlow: Bool
    var roomClimate: Bool
    var movement: Bool
    var sleepStaging: Bool
    var battery: Bool
    /// Optical sensor runs all the time (hardware) vs 2-min bursts every 10 min (paper spec).
    var continuousPpg: Bool
    /// Absolute humidity comes straight from the pod rather than skin-vs-room math.
    var directAbsHumidity: Bool
    /// HRV is quantisation-limited (20 ms at 50 Hz): relative trends only, never clinical.
    var hrvRelativeOnly: Bool

    /// The demo simulator models the full paper spec + extension brief.
    static let demo = PodCapabilities(
        skinConductance: true, spo2Estimate: true, bloodFlow: true, roomClimate: true,
        movement: true, sleepStaging: true, battery: true,
        continuousPpg: false, directAbsHumidity: false, hrvRelativeOnly: false)

    /// The real Aurora Pod, hardware protocol v1.
    static let hardwareV1 = PodCapabilities(
        skinConductance: false, spo2Estimate: true, bloodFlow: false, roomClimate: false,
        movement: false, sleepStaging: false, battery: false,
        continuousPpg: true, directAbsHumidity: true, hrvRelativeOnly: true)

    /// Before anything is known (not connected).
    static let none = PodCapabilities(
        skinConductance: false, spo2Estimate: false, bloodFlow: false, roomClimate: false,
        movement: false, sleepStaging: false, battery: false,
        continuousPpg: false, directAbsHumidity: false, hrvRelativeOnly: false)
}
