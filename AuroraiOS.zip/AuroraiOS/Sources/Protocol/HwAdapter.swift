// Line-for-line port of HwAdapter.kt — hardware protocol v1 → the app's internal model.
import Foundation

/// Translates the real pod's hardware protocol v1 (`HwProtocol.swift`) into the app's
/// internal model, so everything above the BLE layer — PodConnectionManager, the database,
/// charts, the Vital Sheet — keeps working unchanged. Pure Foundation, no CoreBluetooth:
/// unit-tested offline (HwProtocolTests).
///
/// The hard parts, and why:
///  - TIME: the pod reports uptime since boot; the app's model is seconds since session
///    start. The session base is the uptime at which SESSION_ACTIVE rose, or — if we
///    connected mid-session — uptime minus FE02's running duration.
///  - SWEAT: the pod measures absolute humidity at the skin directly and has no room
///    sensor, so dah = rise above a slow baseline (the same idea as the pod's own FLUSH
///    flag), and FLUSH edges become the internal START/ONGOING sweat flag.
///  - HONESTY (PROTOCOL §3): HR only when HR_LOCKED (never a zero); SpO2 only as an
///    uncalibrated estimate at quality ≥ 40; battery 0xFF → unknown; HRV < 5 beats ignored.
///  - REPLAY: the pod streams one RAM log (480 records, one per log interval, oldest
///    first, each with its own CRC). We keep the current session's rows, map them onto the
///    app's 30 s epoch grid, and re-encode them as the internal replay stream so the
///    existing ReplayAssembler / storeReplay path is reused.
///
/// Not thread-safe: use from one queue (BlePodSource uses it on main only).
final class HwAdapter {

    struct VitalsOut {
        var vitals: LiveVitals
        /// SpO2 estimate carried on the ext channel (edaValid/piValid never set by hardware).
        var ext: ExtendedVitals
        /// nil = unknown (no cell fitted).
        var batteryPct: Int?
        var raw: HwVitals
    }

    struct ReplayResult {
        var records: [LogRecord]
        var framesReceived: Int
        var crcFailures: Int
        /// Sequence numbers never received below the highest one seen.
        var missing: Int
        /// Pod rows that fell inside the session window (before 30 s-grid mapping).
        var sessionRows: Int
    }

    /// Internal (paper-spec) command → what to do on the real pod.
    enum Plan: Equatable {
        case write(Data, label: String)
        /// No opcode exists — read FE02 instead (READ property).
        case readSummary
        /// Read FE02 for the window, then 0x04 and collect FE04.
        case replay
        case unsupported
    }

    /// No room sensor on this pod: sentinels the UI/analytics must treat as "absent".
    static let NO_AMBIENT_TEMP_X100 = -32768
    static let NO_AMBIENT_RH_X100 = 0

    static func hasAmbient(_ ambTempX100: Int) -> Bool { ambTempX100 != NO_AMBIENT_TEMP_X100 }

    /// Hardware FE01 flags → internal PodFlags bits. LOGGING is reported only when the
    /// session's time base is known, so nothing is stored at a wrong session time.
    static func mapFlags(_ hw: Int, tempMissing: Bool, timeBaseKnown: Bool = true) -> Int {
        var f = PodFlags.podDetected
        if HwFlags.has(hw, HwFlags.finger) { f |= PodFlags.ppgActive }
        if HwFlags.has(hw, HwFlags.sessionActive) && timeBaseKnown { f |= PodFlags.logging }
        if HwFlags.has(hw, HwFlags.timeValid) { f |= PodFlags.timeSynced }
        if HwFlags.has(hw, HwFlags.lowBattery) { f |= PodFlags.lowBatt }
        if tempMissing { f |= PodFlags.sensorFault }
        return f
    }

    /// Kotlin `roundToInt()` semantics (ties towards +∞), so both platforms agree exactly.
    static func roundToInt(_ x: Double) -> Int {
        Int((x + 0.5).rounded(.down))
    }

    private let nowEpochS: () -> Int64

    init(nowEpochS: @escaping () -> Int64 = { Int64(Date().timeIntervalSince1970) }) {
        self.nowEpochS = nowEpochS
    }

    // MARK: - live state

    private(set) var lastVitals: HwVitals?
    private(set) var lastSession: HwSession?
    /// phone epoch − pod uptime, refreshed on every vitals packet.
    private(set) var epochOffsetS: Int64?
    private var sessionBase: Int64?
    private var wasActive = false
    private var wasFlush = false
    private var baselineAbsHum: Double?
    private var lastSkinTempX100 = 0

    // per-session trackers for the FE02 translation
    private var peakDah = 0
    private var hrSum: Int64 = 0
    private var hrN = 0
    private var hrMin = 0
    private var hrMax = 0

    /// Session running on the pod but its start is not yet known (FE02 read outstanding).
    var needsSessionPin: Bool { wasActive && sessionBase == nil }

    /// Call on every new connection. The pod keeps running; we just forget our view.
    func reset() {
        lastVitals = nil
        lastSession = nil
        epochOffsetS = nil
        sessionBase = nil
        wasActive = false
        wasFlush = false
        baselineAbsHum = nil
    }

    private func sessionRel(_ uptime: Int64) -> Int64 {
        guard let base = sessionBase else { return uptime }
        return max(uptime - base, 0)
    }

    func onVitals(_ bytes: Data) throws -> VitalsOut {
        let v = try HwVitals.parse(bytes)
        epochOffsetS = nowEpochS() - v.uptimeS

        // --- session time base
        if v.sessionActive && !wasActive {
            if lastVitals != nil {
                // Rising edge seen live: a new session starts now.
                sessionBase = v.uptimeS
                peakDah = 0; hrSum = 0; hrN = 0; hrMin = 0; hrMax = 0
                baselineAbsHum = nil
            } else if let s = lastSession {
                // First packet of a connection that joined a RUNNING session: FE02's
                // running duration pins the true start.
                sessionBase = v.uptimeS - s.durationS
            } else {
                // Joined a running session without FE02 yet: the base stays unknown and
                // LOGGING is withheld (see mapFlags) so nothing is stored at a wrong time —
                // BlePodSource re-reads FE02 while `needsSessionPin` is true.
                sessionBase = nil
            }
        }
        if !v.sessionActive && wasActive { sessionBase = nil }
        wasActive = v.sessionActive

        // --- sweat: abs humidity rise over a slow baseline (~10 min time constant,
        //     frozen during a flush so the baseline doesn't chase the event)
        let ah = Double(v.absHumX100)
        let base = baselineAbsHum ?? ah
        baselineAbsHum = v.flushActive ? base : base + (ah - base) / 600.0
        let dah = HwAdapter.roundToInt(ah - base)
        let sweat: SweatFlag
        if v.flushActive && !wasFlush { sweat = .start }
        else if v.flushActive { sweat = .ongoing }
        else { sweat = SweatFlag.none }
        wasFlush = v.flushActive

        // --- heart rate: only when locked; 0 is the internal "no reading", never shown
        var hr = 0
        if let bpm = v.hrShowBpm { hr = min(max(HwAdapter.roundToInt(bpm), 1), 255) }
        if v.sessionActive {
            peakDah = max(peakDah, dah)
            if hr > 0 {
                hrSum += Int64(hr)
                hrN += 1
                hrMin = hrMin == 0 ? hr : min(hrMin, hr)
                hrMax = max(hrMax, hr)
            }
        }

        let skin = v.skinTempX100 ?? lastSkinTempX100
        if let t = v.skinTempX100 { lastSkinTempX100 = t }

        let tS = sessionRel(v.uptimeS)
        let vitals = LiveVitals(
            tS: tS,
            hrBpm: hr,
            hrQuality: v.quality,
            skinTempX100: skin,
            skinRhX100: v.skinRhX100,
            ambTempX100: HwAdapter.NO_AMBIENT_TEMP_X100,
            ambRhX100: HwAdapter.NO_AMBIENT_RH_X100,
            motionIndex: 0,                     // no accelerometer on this pod
            sleepState: .unknown,               // no sleep staging without an IMU
            sweatFlag: sweat,
            battPct: v.battPct ?? HwConst.battUnknown,
            flags: HwAdapter.mapFlags(v.flags, tempMissing: v.skinTempX100 == nil,
                                      timeBaseKnown: sessionBase != nil),
            absHumX100: v.absHumX100,
            dahDirectX100: dah
        )
        lastVitals = v
        return VitalsOut(vitals: vitals, ext: extFor(tS, spo2: v.spo2Pct, quality: v.quality),
                         batteryPct: v.battPct, raw: v)
    }

    func onHrv(_ bytes: Data) throws -> HrvSummary {
        let h = try HwHrv.parse(bytes)
        return HrvSummary(
            windowEndTimeS: sessionRel(h.uptimeS),
            meanIbiMs: h.meanRrMs,
            sdnnMsX10: h.sdnnX10,
            rmssdMsX10: h.rmssdX10,
            pnn50Pct: 0,                        // not reported by the pod
            beatsAccepted: h.beats,
            beatsRejected: 0,
            quality: h.quality,
            flags: h.usable ? HrvFlags.valid : HrvFlags.lowBeats
        )
    }

    /// FE02 → internal summary. Also remembers the raw summary for replay windowing.
    func onSession(_ bytes: Data) throws -> SessionSummary {
        let s = try HwSession.parse(bytes)
        lastSession = s
        // While a session runs FE02 carries the RUNNING duration, which pins the true start
        // (matters when we connected mid-session and vitals arrived before this read).
        if let lv = lastVitals, lv.sessionActive {
            let pinned = lv.uptimeS - s.durationS
            if let cur = sessionBase {
                if abs(cur - pinned) > 2 { sessionBase = pinned }
            } else {
                sessionBase = pinned
            }
        }
        return SessionSummary(
            sessionLenS: s.durationS,
            epochsLogged: Int(min(s.durationS / Int64(Cadence.epochS), 0xFFFF)),
            sweatEvents: s.flushEvents,         // PROVISIONAL on the pod
            longestSweatS: 0,
            peakDahX100: max(peakDah, 0),
            hrMeanBpm: hrN > 0 ? Int(hrSum / Int64(hrN)) : 0,
            hrMinBpm: hrMin,
            hrMaxBpm: hrMax,
            pctWake: 0, pctLight: 0, pctDeep: 0, // no sleep staging on this pod
            battPct: s.battPct ?? HwConst.battUnknown,
            slot: 0                             // one RAM log, no night slots
        )
    }

    // MARK: - replay

    private var frames: [Int: HwRecord] = [:]
    private(set) var replayCrcFailures = 0
    var replayReceived: Int { frames.count }

    func beginReplay() {
        frames.removeAll()
        replayCrcFailures = 0
    }

    /// Returns false (and counts it) when the record's own CRC fails — the row is dropped.
    @discardableResult
    func onReplayFrame(_ bytes: Data) -> Bool {
        do {
            let r = try HwRecord.parseFrame(bytes)
            frames[r.seq] = r
            return true
        } catch {
            replayCrcFailures += 1
            return false
        }
    }

    /// Keep the rows of the most recent session and map them onto the app's 30 s grid.
    /// Window: [start, start + duration] in pod uptime, from FE02 start_epoch and the
    /// phone↔uptime offset; if the clock was never set, the last contiguous run of rows
    /// flagged SESSION_ACTIVE.
    func finishReplay() -> ReplayResult {
        let rows = frames.values.sorted { $0.seq < $1.seq }
        let maxSeq = rows.map { $0.seq }.max() ?? -1
        let missing = (maxSeq + 1) - rows.count

        var windowLo: Int64? = nil
        var windowHi: Int64 = 0
        if let s = lastSession, let startEpoch = s.startEpoch, let off = epochOffsetS {
            let start = startEpoch - off
            windowLo = start - 2
            windowHi = start + s.durationS + Int64(HwConst.defaultLogPeriodS)
        }

        var inSession: [HwRecord] = []
        if let lo = windowLo {
            // Rows logged during the session carry SESSION_ACTIVE; the window separates this
            // session from earlier ones still in the ring.
            inSession = rows.filter {
                $0.uptimeS >= lo && $0.uptimeS <= windowHi && HwFlags.has($0.flags, HwFlags.sessionActive)
            }
        } else if let last = rows.lastIndex(where: { HwFlags.has($0.flags, HwFlags.sessionActive) }) {
            var first = last
            while first > 0 && HwFlags.has(rows[first - 1].flags, HwFlags.sessionActive) { first -= 1 }
            inSession = Array(rows[first...last])
        }

        let startUptime: Int64
        if let lo = windowLo { startUptime = lo + 2 }
        else { startUptime = inSession.first?.uptimeS ?? 0 }

        return ReplayResult(records: toEpochGrid(inSession, startUptime: startUptime),
                            framesReceived: rows.count, crcFailures: replayCrcFailures,
                            missing: missing, sessionRows: inSession.count)
    }

    /// Sample-and-hold each pod row onto 30 s epochs until the next row (default 60 s log).
    func toEpochGrid(_ rows: [HwRecord], startUptime: Int64) -> [LogRecord] {
        let epochS = Int64(Cadence.epochS)
        var out: [LogRecord] = []
        var base: Double? = nil
        var prevFlush = false
        var lastSkin = rows.first(where: { $0.skinTempX100 != nil })?.skinTempX100 ?? 0
        for i in 0..<rows.count {
            let r = rows[i]
            let next: HwRecord? = i + 1 < rows.count ? rows[i + 1] : nil
            let rel = max(r.uptimeS - startUptime, 0)
            let e0 = rel / epochS * epochS
            var nextE: Int64? = nil
            if let n = next { nextE = max(n.uptimeS - startUptime, 0) / epochS * epochS }
            let flush = HwFlags.has(r.flags, HwFlags.flushActive)
            let ah = Double(r.absHumX100)
            let b = base ?? ah
            // Baseline tau ≈ 10 min expressed in rows of this log's real spacing.
            var spacing = Int64(HwConst.defaultLogPeriodS)
            if let n = next { spacing = max(n.uptimeS - r.uptimeS, 1) }
            base = flush ? b : b + (ah - b) * min(Double(spacing) / 600.0, 1.0)
            // Stored dah is a u16 in the internal record encoding (LogRecord / replay image):
            // a dip below baseline must clamp to 0, or it wraps to ~655 g/m³ — a fake spike.
            let dah = max(HwAdapter.roundToInt(ah - b), 0)
            let sweat: SweatFlag
            if flush && !prevFlush { sweat = .start }
            else if flush { sweat = .ongoing }
            else { sweat = SweatFlag.none }
            prevFlush = flush
            if let t = r.skinTempX100 { lastSkin = t }
            var hr = 0
            if HwFlags.has(r.flags, HwFlags.hrLocked), let hrX10 = r.hrX10 {
                hr = min(max(HwAdapter.roundToInt(Double(hrX10) / 10.0), 1), 255)
            }
            let ext = extFor(0, spo2: r.spo2Pct, quality: r.quality)
            var e = e0
            let until: Int64
            if let ne = nextE, ne > e0 { until = ne } else { until = e0 + epochS }
            while e < until {
                if out.last?.tS != e {
                    let flag: SweatFlag
                    if e == e0 { flag = sweat } else { flag = flush ? .ongoing : SweatFlag.none }
                    out.append(LogRecord(
                        tS: e,
                        hrBpm: hr,
                        hrQuality: r.quality,
                        skinTempX100: lastSkin,
                        skinRhX100: r.skinRhX100,
                        ambTempX100: HwAdapter.NO_AMBIENT_TEMP_X100,
                        ambRhX100: HwAdapter.NO_AMBIENT_RH_X100,
                        motionIndex: 0,
                        sleepState: .unknown,
                        sweatFlag: flag,
                        battPct: r.battPct ?? HwConst.battUnknown,
                        flags: HwAdapter.mapFlags(r.flags, tempMissing: r.skinTempX100 == nil),
                        dahX100: dah,
                        hrvMeanIbiMs: 0,
                        hrvSdnnMsX10: 0,
                        hrvRmssdMsX10: 0,
                        hrvPnn50Pct: 0,
                        hrvQuality: 0,
                        hrvFlags: 0,
                        vcellCv: 0,
                        edaX100: 0,
                        spo2X10: ext.spo2X10,
                        perfusionX100: 0,
                        extFlags: ext.extFlags
                    ))
                }
                e += epochS
                if e - e0 >= 240 { break } // never hold one row longer than the pod's max interval
            }
        }
        return out
    }

    /// Re-encode converted records as the internal replay stream the manager consumes.
    func internalFrames(_ records: [LogRecord], slot: Int = 0) -> [Data] {
        var image = Data()
        for r in records { image.append(r.encode()) }
        return ReplayAssembler.frames(slot: slot, recordBytes: image, recordCount: records.count)
    }

    // MARK: - commands

    /// Internal (paper-spec) command → what to do on the real pod. Opcodes differ!
    func plan(_ cmd: PodCommand) -> Plan {
        switch cmd {
        case .timeSync(let t):
            return .write(HwOp.timeSync(t), label: "time sync")
        case .startSession:
            return .write(HwOp.simple(HwOp.sessionStart), label: "start")
        case .stopSession:
            return .write(HwOp.simple(HwOp.sessionStop), label: "stop")
        case .pushSummary:
            return .readSummary
        case .replaySlot:
            return .replay
        case .hapticTest:
            // No motor; blink instead. (0x04 is REPLAY on the pod — never send it here.)
            return .write(HwOp.simple(HwOp.identify), label: "identify (blink)")
        case .formatFlash:
            return .write(HwOp.simple(HwOp.logErase), label: "erase log")
        case .fuelGaugeRelearn, .abortReplay:
            return .unsupported
        }
    }

    private func extFor(_ tS: Int64, spo2: Int?, quality: Int) -> ExtendedVitals {
        let valid = spo2 != nil && quality >= HwConst.spo2MinQuality
        return ExtendedVitals(tS: tS, edaX100: 0, spo2X10: (spo2 ?? 0) * 10, perfusionX100: 0,
                              extFlags: valid ? ExtFlags.spo2Valid : 0)
    }
}
