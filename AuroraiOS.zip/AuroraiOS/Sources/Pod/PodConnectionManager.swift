// Orchestrates whichever PodSource is active (BLE or demo) and applies the device spec's rules.
import Foundation
import Combine

/// Progress of a night download (spec §9 — needs a real percentage and a visible cancel).
enum ReplayStatus: Equatable {
    case idle
    case waitingForHeader(slot: Int)
    case downloading(slot: Int, percent: Int, frames: Int, expected: Int)
    case done(slot: Int, records: Int, crcFailures: Int, complete: Bool)
    case failed(slot: Int, messageKey: String, arg: String?)

    var isActive: Bool {
        switch self {
        case .waitingForHeader, .downloading: return true
        default: return false
        }
    }

    /// Localized failure text, coercing a numeric arg back to Int so %d format keys work.
    var failureText: String? {
        guard case let .failed(_, key, arg) = self else { return nil }
        guard let arg else { return L(key) }
        if let n = Int(arg) { return L(key, n) }
        return L(key, arg)
    }
}

/// One-shot UI messages (snackbars/toasts). `key` is a Localizable.strings key.
struct PodMessage {
    let key: String
    let args: [CVarArg]
    let isError: Bool

    init(key: String, args: [CVarArg] = [], isError: Bool = false) {
        self.key = key; self.args = args; self.isError = isError
    }

    var text: String {
        args.isEmpty ? L(key) : String(format: L10n.t(key), arguments: args)
    }
}

/// Orchestrates whichever `PodSource` is active (BLE or demo) and applies the spec's rules:
///  - CMD_TIME_SYNC first after every connection, confirmed via FLAG_TIME_SYNCED, retried (spec §8.1)
///  - commands confirmed by observing their effect, with timeout + retry (spec §15.2)
///  - wall-clock session start stored by the app (spec §8.2)
///  - provisional epochs synthesised from live vitals so charts grow while connected;
///    replaced by authoritative replay data when downloaded
///
/// iOS note: Android runs replay downloads under a foreground service; iOS has no such
/// concept — long downloads rely on the `bluetooth-central` background mode declared in
/// Info.plist, which keeps notification delivery alive while backgrounded.
///
/// All mutation happens on the main queue: every PodSource subject emits on main, and
/// SessionRepository is main-thread by contract.
final class PodConnectionManager: ObservableObject {

    let ble: BlePodSource
    let demo: DemoPodSource
    private(set) var source: PodSource
    private let repo: SessionRepository

    var isDemo: Bool { source.isDemo }

    // MARK: mirrors of the active source (swap seamlessly in useDemo)

    @Published private(set) var connectionState: ConnectionState = .disconnected
    @Published private(set) var scanResults: [ScannedPod] = []
    @Published private(set) var deviceInfo: DeviceInfo?
    @Published private(set) var batteryPct: Int?

    @Published private(set) var latestVitals: LiveVitals?
    /// Rolling window of the last ~15 minutes of 1 Hz vitals for the live chart.
    @Published private(set) var liveWindow: [LiveVitals] = []

    /// Most recent valid heart-rate reading and the pod time (t_s) it was taken.
    struct HrReading: Equatable {
        var bpm: Int
        var quality: Int
        var tS: Int64
    }
    @Published private(set) var lastHr: HrReading?

    @Published private(set) var latestHrv: HrvSummary?
    @Published private(set) var timeSynced = false
    @Published private(set) var activeSession: SessionModel?
    @Published private(set) var replayStatus: ReplayStatus = .idle

    /// One-shot messages for snackbars.
    let messages = PassthroughSubject<PodMessage, Never>()
    /// Emitted when a morning card (FE02) closes a session, so the UI can navigate to it.
    let morningCard = PassthroughSubject<UUID, Never>()

    // MARK: private state

    private var userId: UUID?
    private var cancellables = Set<AnyCancellable>()
    private let epochAgg = EpochAggregator()
    private var sensorFaultToasted = false // once per app run, matching Android
    private var firmwareWarned = false

    // replay
    private var replayAssembler: ReplayAssembler?
    private var replayFrameSub: AnyCancellable?
    private var replayHeaderTimeout: DispatchWorkItem?
    private var replayOverallTimeout: DispatchWorkItem?
    private var replaySessionId: UUID?
    private var replaySlot = 0

    private static let liveWindowCap = 900 // ~15 min at 1 Hz

    init(repo: SessionRepository) {
        self.repo = repo
        self.ble = BlePodSource()
        self.demo = DemoPodSource()
        self.source = ble
        attach()
    }

    // MARK: - Mode & user

    func setUser(_ id: UUID?) {
        userId = id
        activeSession = id.flatMap { repo.openSession(userId: $0) }
    }

    func useDemo(_ enabled: Bool) {
        guard isDemo != enabled else { return }
        source.disconnect()
        source = enabled ? demo : ble
        timeSynced = false
        latestVitals = nil
        lastHr = nil
        latestHrv = nil
        liveWindow = []
        attach()
    }

    // MARK: - Connection pass-throughs

    func startScan() { source.startScan() }
    func stopScan() { source.stopScan() }
    func connect(id: String? = nil) { source.connect(id: id) }
    func disconnect() { source.disconnect() }

    /// Rebuilds all subscriptions against the active source. The CurrentValueSubjects
    /// replay their latest value on subscribe, so the @Published mirrors refresh instantly.
    private func attach() {
        cancellables.removeAll()
        let src = source
        src.connectionState
            .sink { [weak self] in self?.onConnectionState($0) }
            .store(in: &cancellables)
        src.scanResults
            .sink { [weak self] in self?.scanResults = $0 }
            .store(in: &cancellables)
        src.deviceInfo
            .sink { [weak self] in self?.deviceInfo = $0; self?.warnIfFirmwareMismatch() }
            .store(in: &cancellables)
        src.batteryPct
            .sink { [weak self] in self?.batteryPct = $0 }
            .store(in: &cancellables)
        src.vitals
            .sink { [weak self] in self?.onVitals($0) }
            .store(in: &cancellables)
        src.hrv
            .sink { [weak self] in self?.onHrv($0) }
            .store(in: &cancellables)
        src.summary
            .sink { [weak self] in self?.onSummary($0) }
            .store(in: &cancellables)
        if let d = src as? DemoPodSource {
            d.modeEvents
                .sink { [weak self] event in self?.onDemoMode(tS: event.0, mode: event.1) }
                .store(in: &cancellables)
        }
    }

    private func onConnectionState(_ state: ConnectionState) {
        connectionState = state
        switch state {
        case .connected:
            timeSynced = false
            firmwareWarned = false
            syncTime() // spec §8.1 — FIRST thing after every connection
            warnIfFirmwareMismatch()
        case .disconnected, .error, .off:
            timeSynced = false
            if replayStatus.isActive {
                let slot = replaySlot
                tearDownReplay()
                replayStatus = .failed(slot: slot, messageKey: "app_msg_replay_connection_dropped", arg: nil)
            }
            if case let .error(key, arg) = state {
                // app_err_scan_failed / app_err_connection_lost format their arg as %d —
                // coerce numeric strings back to Int so String(format:) works.
                var coerced: [CVarArg] = []
                if let arg {
                    if let n = Int(arg) { coerced = [n] } else { coerced = [arg] }
                }
                toast(key, coerced, error: true)
            }
        default:
            break
        }
    }

    private func warnIfFirmwareMismatch() {
        guard connectionState.isConnected, !firmwareWarned,
              let info = deviceInfo, info.firmwareMismatch else { return }
        firmwareWarned = true
        toast("app_msg_firmware_mismatch", [info.softwareRevision, AuroraUUID.builtAgainstFirmware], error: true)
    }

    // MARK: - Time sync (spec §8.1 — send FIRST, confirm via FLAG_TIME_SYNCED, 3 attempts)

    private func syncTime(attempt: Int = 0) {
        let src = source
        // Subscribe BEFORE writing so a synchronously-flipped flag can't be missed.
        waitFirst(src.vitals.eraseToAnyPublisher(), timeout: 2.5, where: { $0.timeSynced }) { [weak self] v in
            guard let self else { return }
            if v != nil {
                self.timeSynced = true
            } else if attempt < 2 {
                self.syncTime(attempt: attempt + 1)
            } else {
                self.toast("app_msg_clock_sync_failed", error: true)
            }
        }
        src.write(.timeSync(unixSeconds: Int64(Date().timeIntervalSince1970)))
    }

    // MARK: - Session lifecycle

    /// Bedtime: START, confirm via FLAG_LOGGING in FE01 (≤4 s, 3 attempts), then store the
    /// wall-clock start in the DB — the pod itself has no calendar (spec §8.2, §12).
    func startSession(completion: ((Bool) -> Void)? = nil) {
        guard let uid = userId else {
            toast("app_msg_sign_in_first", error: true); completion?(false); return
        }
        guard connectionState.isConnected else {
            toast("app_msg_connect_first", error: true); completion?(false); return
        }
        if activeSession != nil {
            toast("app_msg_already_recording"); completion?(true); return
        }
        if !timeSynced { syncTime() }
        attemptStart(uid: uid, attempt: 0, completion: completion)
    }

    private func attemptStart(uid: UUID, attempt: Int, completion: ((Bool) -> Void)?) {
        let src = source
        waitFirst(src.vitals.eraseToAnyPublisher(), timeout: 4, where: { $0.logging }) { [weak self] v in
            guard let self else { return }
            if v != nil {
                let session = self.repo.startSession(userId: uid,
                                                     source: self.isDemo ? .demo : .ble,
                                                     startedAt: Date())
                self.activeSession = session
                self.epochAgg.reset()
                if self.isDemo {
                    // The demo pod emits its initial (0, mode) event synchronously inside
                    // write(.startSession), before this session row exists — onDemoMode
                    // drops it. Log the starting activity marker here instead.
                    self.repo.addActivityEvent(sessionId: session.id, tS: 0,
                                               kind: self.demo.mode.value.activityKind, source: .demo)
                }
                self.toast("app_msg_recording_started")
                completion?(true)
            } else if attempt < 2 {
                self.attemptStart(uid: uid, attempt: attempt + 1, completion: completion)
            } else {
                self.toast("app_msg_recording_not_started", error: true)
                completion?(false)
            }
        }
        src.write(.startSession)
    }

    /// Morning: STOP, wait for FE02 (≤4 s; retries nudge with CMD_PUSH_SUMMARY), then a
    /// last-resort direct read of FE02. Persistence happens in onSummary (spec §12).
    func stopSession(completion: ((Bool) -> Void)? = nil) {
        guard connectionState.isConnected else {
            toast("app_msg_connect_first", error: true); completion?(false); return
        }
        attemptStop(attempt: 0, completion: completion)
    }

    private func attemptStop(attempt: Int, completion: ((Bool) -> Void)?) {
        let src = source
        // Subscribe BEFORE writing: the demo pod emits FE02 synchronously inside write().
        waitFirst(src.summary.eraseToAnyPublisher(), timeout: 4) { [weak self] s in
            guard let self else { return }
            if s != nil { completion?(true); return } // onSummary() handled persistence
            if attempt < 2 { self.attemptStop(attempt: attempt + 1, completion: completion); return }
            // Fall back to a direct read of FE02 (READ property). The read response is
            // delivered through the same summary subject, so wait on it once more.
            if let bleSrc = src as? BlePodSource {
                self.waitFirst(src.summary.eraseToAnyPublisher(), timeout: 3) { [weak self] s2 in
                    guard let self else { return }
                    if s2 != nil { completion?(true) }
                    else { self.toast("app_msg_no_summary", error: true); completion?(false) }
                }
                bleSrc.requestSummaryRead()
            } else {
                self.toast("app_msg_no_summary", error: true)
                completion?(false)
            }
        }
        src.write(attempt == 0 ? .stopSession : .pushSummary)
    }

    /// FE02 closes the session: flush provisional epochs, persist the summary (incl. the
    /// slot byte — the only handle for replaying this night later), announce the morning card.
    private func onSummary(_ summary: SessionSummary) {
        let session = activeSession ?? userId.flatMap { repo.openSession(userId: $0) }
        guard let session else {
            toast("app_msg_summary_without_session", [summary.slot])
            return
        }
        epochAgg.flush()
        repo.endSession(session, summary: summary, endedAt: Date())
        activeSession = nil
        morningCard.send(session.id)
    }

    // MARK: - Live data

    private func onVitals(_ v: LiveVitals) {
        latestVitals = v
        if v.hasHr { lastHr = HrReading(bpm: v.hrBpm, quality: v.hrQuality, tS: v.tS) }
        // Pod time restarts at 0 when a session starts: begin a fresh rolling window.
        var window = liveWindow
        if let last = window.last, v.tS < last.tS { window = [] }
        if window.count >= Self.liveWindowCap {
            window.removeFirst(window.count - Self.liveWindowCap + 1)
        }
        window.append(v)
        liveWindow = window

        guard let session = activeSession, v.logging else { return }
        if let records = epochAgg.push(v, hrv: latestHrv) {
            for r in records { repo.appendProvisionalEpoch(sessionId: session.id, record: r) }
        }
        if v.sensorFault, !sensorFaultToasted {
            sensorFaultToasted = true
            toast("app_msg_sensor_fault", error: true)
        }
    }

    private func onHrv(_ h: HrvSummary) {
        latestHrv = h
        guard let session = activeSession else { return }
        // FE05 timestamps switch to wall clock after a time sync (spec §4): convert back
        // to session-relative seconds using the wall-clock start we stored.
        let startS = Int64(session.startedAt.timeIntervalSince1970)
        let windowEndS = h.isWallClock ? max(0, h.windowEndTimeS - startS) : h.windowEndTimeS
        repo.appendHrv(sessionId: session.id, hrv: h, windowEndS: windowEndS)
        epochAgg.markHrvFresh()
    }

    private func onDemoMode(tS: Int64, mode: DemoMode) {
        guard let session = activeSession else { return }
        repo.addActivityEvent(sessionId: session.id, tS: tS, kind: mode.activityKind, source: .demo)
    }

    // MARK: - Replay (night download, spec §9)

    func downloadNight(sessionId: UUID, slot: Int) {
        guard !replayStatus.isActive else { return }
        guard connectionState.isConnected else {
            replayStatus = .failed(slot: slot, messageKey: "app_msg_connect_first", arg: nil)
            return
        }
        let src = source
        let asm = ReplayAssembler()
        replayAssembler = asm
        replaySessionId = sessionId
        replaySlot = slot
        replayStatus = .waitingForHeader(slot: slot)

        // Subscribe BEFORE writing CMD_REPLAY_SLOT — the demo pod streams frames
        // synchronously inside write().
        replayFrameSub = src.replayFrames.sink { [weak self] frame in
            self?.onReplayFrame(frame)
        }

        // Header must arrive within ~2 s or the slot is empty (spec §9 step 3).
        let headerItem = DispatchWorkItem { [weak self] in
            guard let self, case .waitingForHeader = self.replayStatus else { return }
            self.tearDownReplay()
            src.write(.abortReplay)
            self.replayStatus = .failed(slot: slot, messageKey: "app_msg_replay_slot_empty", arg: String(slot))
        }
        replayHeaderTimeout = headerItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: headerItem)

        // Whole night: allow up to 5 minutes (slow connection intervals, spec §9).
        let overallItem = DispatchWorkItem { [weak self] in
            guard let self, self.replayStatus.isActive else { return }
            self.tearDownReplay()
            src.write(.abortReplay)
            self.replayStatus = .failed(slot: slot, messageKey: "app_msg_replay_timeout", arg: nil)
        }
        replayOverallTimeout = overallItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 5 * 60, execute: overallItem)

        src.write(.replaySlot(slot))
    }

    func cancelDownload() {
        tearDownReplay()
        source.write(.abortReplay)
        replayStatus = .idle
    }

    private func onReplayFrame(_ frame: Data) {
        guard let asm = replayAssembler else { return }
        let slot = replaySlot
        switch asm.feed(frame) {
        case .headerReceived(let header):
            replayHeaderTimeout?.cancel(); replayHeaderTimeout = nil
            replayStatus = .downloading(slot: slot, percent: 0, frames: 0, expected: header.expectedFrames)
        case .data(let p):
            replayStatus = .downloading(slot: slot, percent: p.percent,
                                        frames: p.framesReceived, expected: p.expectedFrames)
        case .finished(let result):
            finishReplay(result)
        case .error(let message):
            tearDownReplay()
            replayStatus = .failed(slot: slot, messageKey: "app_msg_raw", arg: message)
        }
    }

    private func finishReplay(_ result: ReplayAssembler.Result) {
        let slot = replaySlot
        let sessionId = replaySessionId
        tearDownReplay()
        if result.unsupportedFormat {
            // Record size comes from the header; older firmware wrote smaller records.
            replayStatus = .failed(slot: slot, messageKey: "app_msg_replay_old_firmware",
                                   arg: String(result.header.recordSize))
            return
        }
        if let sessionId {
            repo.storeReplay(sessionId: sessionId, records: result.records,
                             crcFailures: result.crcFailures, complete: result.complete)
        }
        replayStatus = .done(slot: slot, records: result.records.count,
                             crcFailures: result.crcFailures, complete: result.complete)
        if result.crcFailures > 0 { toast("app_msg_crc_dropped", [result.crcFailures]) }
    }

    private func tearDownReplay() {
        replayFrameSub?.cancel(); replayFrameSub = nil
        replayHeaderTimeout?.cancel(); replayHeaderTimeout = nil
        replayOverallTimeout?.cancel(); replayOverallTimeout = nil
        replayAssembler = nil
        replaySessionId = nil
    }

    // MARK: - Misc commands

    func hapticTest() { source.write(.hapticTest(millis: 250)); toast("app_msg_buzz_sent") }
    func fuelGaugeRelearn() { source.write(.fuelGaugeRelearn); toast("app_msg_fuel_gauge_sent") }
    func formatFlash() { source.write(.formatFlash); toast("app_msg_storage_erased") }

    // MARK: - Helpers

    private func toast(_ key: String, _ args: [CVarArg] = [], error: Bool = false) {
        messages.send(PodMessage(key: key, args: args, isError: error))
    }

    /// One-shot "first matching value or timeout" against a Combine publisher — the
    /// callback-based stand-in for Kotlin's `withTimeoutOrNull { flow.filter{}.first() }`.
    /// Runs entirely on the main queue; `completion` gets nil on timeout.
    private func waitFirst<T>(_ publisher: AnyPublisher<T, Never>,
                              timeout: TimeInterval,
                              where predicate: @escaping (T) -> Bool = { _ in true },
                              then completion: @escaping (T?) -> Void) {
        var cancellable: AnyCancellable?
        var finished = false
        let timeoutItem = DispatchWorkItem {
            guard !finished else { return }
            finished = true
            cancellable?.cancel(); cancellable = nil
            completion(nil)
        }
        cancellable = publisher.sink { value in
            guard !finished, predicate(value) else { return }
            finished = true
            timeoutItem.cancel()
            cancellable?.cancel(); cancellable = nil
            completion(value)
        }
        if finished { cancellable?.cancel(); cancellable = nil } // fired synchronously
        DispatchQueue.main.asyncAfter(deadline: .now() + timeout, execute: timeoutItem)
    }
}

// MARK: - DemoMode → ActivityKind (the manager and DemoController both log demo events)

extension DemoMode {
    var activityKind: ActivityKind {
        switch self {
        case .up: return .up
        case .lightExercise: return .lightExercise
        case .heavyExercise: return .heavyExercise
        case .sleeping: return .sleeping
        case .nightFlash: return .nightFlash
        case .nightSweats: return .nightSweats
        }
    }
}

// MARK: - EpochAggregator

/// Aggregates 1 Hz vitals into 30 s provisional records (one per epoch boundary crossed).
/// dah is computed by the app from the same physics the firmware uses; HR = best-quality
/// reading in the epoch; sweat flag START if any START seen, else ONGOING if any, else NONE.
/// At demo speeds > 30× a single tick can skip whole epochs — those are filled with the
/// latest sample so charts stay contiguous.
private final class EpochAggregator {
    private var epochIndex: Int64 = -1
    private var samples: [LiveVitals] = []
    private var hrvFresh = false

    func reset() { epochIndex = -1; samples.removeAll(); hrvFresh = false }
    func markHrvFresh() { hrvFresh = true }

    func push(_ v: LiveVitals, hrv: HrvSummary?) -> [LogRecord]? {
        let idx = v.tS / Int64(Cadence.epochS)
        if epochIndex == -1 { epochIndex = idx; samples.append(v); return nil }
        if idx == epochIndex { samples.append(v); return nil }
        // One or more boundaries crossed: close the current epoch, fill any skipped ones.
        var out: [LogRecord] = [build(epoch: epochIndex, samples: samples, hrv: hrv)]
        var e = epochIndex + 1
        while e < idx {
            out.append(build(epoch: e, samples: [v], hrv: hrv))
            e += 1
        }
        epochIndex = idx
        samples.removeAll()
        samples.append(v)
        return out
    }

    /// The final partial epoch is discarded, matching firmware behaviour.
    func flush() { samples.removeAll() }

    private func build(epoch: Int64, samples s: [LiveVitals], hrv: HrvSummary?) -> LogRecord {
        let last = s[s.count - 1]
        let hrBest = s.filter { $0.hrBpm > 0 }.max { $0.hrQuality < $1.hrQuality }
        let sweat: SweatFlag
        if s.contains(where: { $0.sweatFlag == .start }) { sweat = .start }
        else if s.contains(where: { $0.sweatFlag == .ongoing }) { sweat = .ongoing }
        else { sweat = SweatFlag.none }
        func avg(_ f: (LiveVitals) -> Int) -> Int {
            let sum = s.reduce(0) { $0 + f($1) }
            return Int((Double(sum) / Double(s.count)).rounded())
        }
        let skinT = avg { $0.skinTempX100 }
        let skinRh = avg { $0.skinRhX100 }
        let ambT = avg { $0.ambTempX100 }
        let ambRh = avg { $0.ambRhX100 }
        let fresh = hrvFresh
        hrvFresh = false
        return LogRecord(
            tS: epoch * Int64(Cadence.epochS),
            hrBpm: hrBest?.hrBpm ?? 0,
            hrQuality: hrBest?.hrQuality ?? 0,
            skinTempX100: skinT,
            skinRhX100: skinRh,
            ambTempX100: ambT,
            ambRhX100: ambRh,
            motionIndex: s.map { $0.motionIndex }.max() ?? 0,
            sleepState: last.sleepState,
            sweatFlag: sweat,
            battPct: last.battPct,
            flags: last.flags | (fresh ? PodFlags.hrvFresh : 0),
            dahX100: NightAnalytics.dahX100(skinTempC: Double(skinT) / 100,
                                            skinRh: Double(skinRh) / 100,
                                            ambTempC: Double(ambT) / 100,
                                            ambRh: Double(ambRh) / 100),
            hrvMeanIbiMs: hrv?.meanIbiMs ?? 0,
            hrvSdnnMsX10: hrv?.sdnnMsX10 ?? 0,
            hrvRmssdMsX10: hrv?.rmssdMsX10 ?? 0,
            hrvPnn50Pct: hrv?.pnn50Pct ?? 0,
            hrvQuality: hrv?.quality ?? 0,
            hrvFlags: hrv?.flags ?? 0,
            vcellCv: 0
        )
    }
}
