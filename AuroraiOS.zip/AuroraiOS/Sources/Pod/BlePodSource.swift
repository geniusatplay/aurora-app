// Real Aurora Pod over CoreBluetooth — the phone is the central, the pod the peripheral.
import Foundation
import Combine
import CoreBluetooth

/// CoreBluetooth implementation of `PodSource`.
///
/// Speaks HARDWARE PROTOCOL v1 (hw/PROTOCOL.txt, verified on hardware 2026-09-28) on the
/// wire and hands the rest of the app its internal model via `HwAdapter`: packets are
/// CRC-checked and translated here, commands are mapped to the pod's opcodes here (they
/// differ from the paper spec — e.g. 0x04 is REPLAY on the pod, not "haptic"), and the
/// pod's RAM log replay is collected, windowed to the session and re-emitted as the
/// internal replay stream. Mirrors Android's BlePodSource.
///
/// The central is created with `queue: .main`, so every delegate callback — and therefore
/// every subject emission below — happens on the main queue, satisfying the PodSource
/// threading contract without extra hops. Timers are scheduled on the main run loop.
///
/// Unlike Android there is no GATT-operation mutex: CoreBluetooth queues characteristic
/// reads/writes/notification changes internally. Nothing relies on MTU negotiation
/// (all packets are ≤ 20 B).
///
/// Reads vs notifications: CoreBluetooth delivers BOTH through `didUpdateValueFor`. For
/// FE02 the difference matters (a notify is the pod's end-of-session push → `summary`;
/// a read is us asking → routed to whoever asked), so outstanding FE02 reads are queued
/// in `pendingSummaryReads` and the next FE02 value completes the oldest one.
///
/// Background behaviour: iOS has no foreground service. Long replays and overnight
/// notifications rely on the `bluetooth-central` background mode already declared in
/// the app's Info.plist.
final class BlePodSource: NSObject, PodSource {

    let isDemo = false

    let connectionState = CurrentValueSubject<ConnectionState, Never>(.disconnected)
    let scanResults = CurrentValueSubject<[ScannedPod], Never>([])
    let deviceInfo = CurrentValueSubject<DeviceInfo?, Never>(nil)
    let batteryPct = CurrentValueSubject<Int?, Never>(nil)

    let vitals = PassthroughSubject<LiveVitals, Never>()
    let extVitals = PassthroughSubject<ExtendedVitals, Never>()
    /// Always false for the hardware-v1 glove: no conductance / blood-flow (PROTOCOL §9).
    let hasExtendedSensors = CurrentValueSubject<Bool, Never>(false)
    let hrv = PassthroughSubject<HrvSummary, Never>()
    let summary = PassthroughSubject<SessionSummary, Never>()
    let replayFrames = PassthroughSubject<Data, Never>()

    /// `.hardwareV1` while connected, `.none` otherwise.
    let capabilities = CurrentValueSubject<PodCapabilities, Never>(PodCapabilities.none)
    /// The pod streams its whole RAM log (≤ 480 frames) before we can convert and emit.
    var replayHeaderTimeout: TimeInterval { 90 }
    /// Fires when a requested replay holds nothing for this session (no records promised,
    /// or none inside the session window) so the manager fails fast instead of waiting 90 s.
    let replayEmpty = PassthroughSubject<Void, Never>()

    /// (missing, crcFailures) of the last replay — taken once by the manager.
    func takeReplayDiagnostics() -> (missing: Int, crcFailures: Int)? {
        let d = replayDiag
        replayDiag = nil
        return d
    }

    /// Count of dropped packets (CRC / length / header failures) — PROTOCOL: must be 0.
    private(set) var badPackets = 0

    // MARK: private state (main queue only)

    private let hw = HwAdapter()

    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    private var controlChar: CBCharacteristic?
    private var summaryChar: CBCharacteristic?
    private var hrvChar: CBCharacteristic?
    /// Peripherals seen during the current scan, keyed by identifier string.
    private var discovered: [String: CBPeripheral] = [:]
    private var seen: [String: ScannedPod] = [:]
    private var scanTimeout: DispatchWorkItem?
    /// startScan() was called while the central was still powering up.
    private var pendingScan = false
    private var userDisconnect = false

    // FE02 read bookkeeping (see class doc).
    private struct PendingRead {
        let id: Int
        let done: (Data?) -> Void
    }
    private var pendingSummaryReads: [PendingRead] = []
    private var readSeq = 0
    /// Reads that timed out but whose response may still arrive — drop those values
    /// instead of mistaking them for an end-of-session notify.
    private var staleSummaryReads = 0
    private static let readTimeout: TimeInterval = 3

    /// Set while we STOP a leftover pod session ourselves — its FE02 must not end the app's night.
    private var swallowNextSummary = false
    /// Set during the 1.5 s STOP→START restart of a leftover pod session: vitals are fed to
    /// the adapter but not emitted, so the manager (which subscribes BEFORE writing START)
    /// cannot mistake the OLD session's LOGGING flag for confirmation of the new one.
    private var restartingSession = false
    private var restartItem: DispatchWorkItem?
    /// Last time an FE02 re-read was issued to pin a joined session's start (needsSessionPin).
    private var pinReadAt = Date.distantPast
    /// onLinkReady is waiting for FE01's notification state before reporting `.connected`.
    private var awaitingVitalsNotify = false
    private var linkTimeout: DispatchWorkItem?

    // Replay job state.
    private var replayDiag: (missing: Int, crcFailures: Int)?
    private var replayAttempt = 0
    private var replayLastResult: HwAdapter.ReplayResult?
    private var replayCollecting = false
    private var lastReplayFrameAt = Date()
    private var replayStartedAt = Date()
    private var replayPromised = 0
    private var replayGeneration = 0
    private var replayPollTimer: Timer?

    var isPoweredOn: Bool { central?.state == .poweredOn }

    /// Created lazily so the system Bluetooth permission prompt appears on first
    /// scan/connect, not at app launch (mirrors the Android permission flow).
    private func ensureCentral() -> CBCentralManager {
        if let central { return central }
        let c = CBCentralManager(delegate: self, queue: .main)
        central = c
        return c
    }

    // MARK: - Scanning

    func startScan() {
        let c = ensureCentral()
        switch c.state {
        case .poweredOn:
            beginScan(c)
        case .unknown, .resetting:
            // The central is still powering up — start as soon as it reports poweredOn.
            pendingScan = true
        case .unsupported:
            // No scan-failure callback exists on iOS; the closest analogue to Android's
            // onScanFailed(code) is an unusable radio. Surface the state raw value as the code.
            connectionState.send(.error(messageKey: "app_err_scan_failed", arg: String(c.state.rawValue)))
        default:
            connectionState.send(.off)
        }
    }

    private func beginScan(_ c: CBCentralManager) {
        seen.removeAll()
        discovered.removeAll()
        scanResults.send([])
        connectionState.send(.scanning)
        // Filter by the Aurora service UUID that is in the advertising packet.
        // Allow duplicates so RSSI keeps updating while the sheet is open.
        c.scanForPeripherals(withServices: [AuroraUUID.service],
                             options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
        scanTimeout?.cancel()
        let item = DispatchWorkItem { [weak self] in self?.stopScan() }
        scanTimeout = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 15, execute: item)  // 15 s, like Android
    }

    func stopScan() {
        scanTimeout?.cancel(); scanTimeout = nil
        pendingScan = false
        if central?.isScanning == true { central?.stopScan() }
        if case .scanning = connectionState.value { connectionState.send(.disconnected) }
    }

    // MARK: - Connection

    func connect(id: String?) {
        let c = ensureCentral()
        guard c.state == .poweredOn else { connectionState.send(.off); return }
        guard let target = id ?? scanResults.value.first?.id else {
            connectionState.send(.error(messageKey: "app_err_no_pod", arg: nil))
            return
        }
        stopScan()
        var p = discovered[target]
        if p == nil, let uuid = UUID(uuidString: target) {
            p = c.retrievePeripherals(withIdentifiers: [uuid]).first
        }
        guard let p else {
            connectionState.send(.error(messageKey: "app_err_no_pod", arg: nil))
            return
        }
        userDisconnect = false
        deviceInfo.send(nil)
        peripheral = p
        p.delegate = self
        connectionState.send(.connecting(name: p.name ?? AuroraUUID.advertisedName))
        c.connect(p, options: nil)
    }

    func disconnect() {
        userDisconnect = true
        if let p = peripheral { central?.cancelPeripheralConnection(p) }
        cleanupPeripheral()
        connectionState.send(.disconnected)
    }

    private func cleanupPeripheral() {
        controlChar = nil
        summaryChar = nil
        hrvChar = nil
        peripheral = nil
        cancelReplayJob()
        failPendingReads()
        staleSummaryReads = 0
        swallowNextSummary = false
        restartingSession = false
        restartItem?.cancel(); restartItem = nil
        awaitingVitalsNotify = false
        linkTimeout?.cancel(); linkTimeout = nil
        // Sensor roster / capabilities are per-connection knowledge.
        if hasExtendedSensors.value { hasExtendedSensors.send(false) }
        if capabilities.value != PodCapabilities.none { capabilities.send(PodCapabilities.none) }
    }

    private func failPendingReads() {
        let pending = pendingSummaryReads
        pendingSummaryReads.removeAll()
        for r in pending { r.done(nil) }
    }

    /// Runs once the Aurora characteristics are known: learn the pod's state FIRST, then
    /// enable its notifications, then report `.connected` once FE01 notify is confirmed.
    private func onLinkReady(_ p: CBPeripheral, service: CBService) {
        let name = p.name ?? AuroraUUID.advertisedName
        hw.reset()
        badPackets = 0
        staleSummaryReads = 0
        swallowNextSummary = false
        pinReadAt = Date.distantPast
        // The glove exposes no Device Information / Battery services; nothing to read there.
        // softwareRevision left blank: the pod reports no firmware string, so no "mismatch" toast.
        deviceInfo.send(DeviceInfo(manufacturer: "Aurora", model: name,
                                   hardwareRevision: "XIAO nRF52840 · protocol v1",
                                   softwareRevision: ""))
        batteryPct.send(nil)
        var vitalsChar: CBCharacteristic?
        var notifyChars: [CBCharacteristic] = []
        for c in service.characteristics ?? [] {
            switch c.uuid {
            case AuroraUUID.control:
                controlChar = c
            case AuroraUUID.summary:
                summaryChar = c
                notifyChars.append(c)
            case AuroraUUID.hrv:
                hrvChar = c
                notifyChars.append(c)
            case AuroraUUID.vitals:
                vitalsChar = c
            case AuroraUUID.log:
                notifyChars.append(c)
            default:
                break
            }
        }
        // FIRST learn whether a session is already running (FE02 carries the RUNNING
        // duration) so the very first vitals packet already has the right session time.
        // NOT emitted as a summary — the manager treats an FE02 as "session over".
        readSummaryValue { [weak self] data in
            guard let self, self.peripheral === p else { return }
            if let data { _ = try? self.hw.onSession(data) }
            guard let vc = vitalsChar else {
                self.failLink(p)
                return
            }
            self.awaitingVitalsNotify = true
            p.setNotifyValue(true, for: vc)
            for c in notifyChars { p.setNotifyValue(true, for: c) }
            // Android waits 3 s per descriptor write; give CoreBluetooth a little longer.
            let item = DispatchWorkItem { [weak self] in
                guard let self, self.awaitingVitalsNotify, self.peripheral === p else { return }
                self.failLink(p)
            }
            self.linkTimeout = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 5, execute: item)
        }
    }

    /// FE01 notify confirmed: the link is usable.
    private func finishLinkReady(_ p: CBPeripheral) {
        awaitingVitalsNotify = false
        linkTimeout?.cancel(); linkTimeout = nil
        hasExtendedSensors.send(false) // no conductance / blood-flow on this pod (PROTOCOL §9)
        capabilities.send(PodCapabilities.hardwareV1)
        connectionState.send(.connected(name: p.name ?? AuroraUUID.advertisedName, id: p.identifier.uuidString))
    }

    /// FE01 missing or its notifications could not be enabled: not a usable Aurora pod.
    private func failLink(_ p: CBPeripheral) {
        awaitingVitalsNotify = false
        linkTimeout?.cancel(); linkTimeout = nil
        connectionState.send(.error(messageKey: "app_err_not_aurora", arg: nil))
        central?.cancelPeripheralConnection(p)
    }

    // MARK: - Commands

    /// Fire-and-forget (PROTOCOL §6: no acks — confirm by observing FE01/FE02). Internal
    /// commands are translated to the pod's opcodes by `HwAdapter.plan`.
    func write(_ command: PodCommand) {
        guard peripheral != nil else { return }
        if case .abortReplay = command {
            cancelReplayJob()
            return
        }
        let podRunning = hw.lastVitals?.sessionActive == true
        switch hw.plan(command) {
        case .write(let bytes, _):
            if case .startSession = command, podRunning {
                // A session left running on the pod (another app, the web tool): end it
                // quietly first so the new night's time base starts now.
                swallowNextSummary = true
                restartingSession = true
                writeRaw(HwOp.simple(HwOp.sessionStop))
                restartItem?.cancel()
                let item = DispatchWorkItem { [weak self] in
                    guard let self else { return }
                    self.restartItem = nil
                    self.swallowNextSummary = false
                    self.restartingSession = false
                    guard self.peripheral != nil else { return }
                    self.writeRaw(bytes)
                }
                restartItem = item
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: item)
            } else {
                writeRaw(bytes)
            }
        case .readSummary:
            // Stop retry: while the pod still logs, the STOP didn't land — send it again (its
            // FE02 notify follows); only a stopped pod's summary may be read directly.
            if podRunning {
                writeRaw(HwOp.simple(HwOp.sessionStop))
            } else {
                requestSummaryRead()
            }
        case .replay:
            startReplay()
        case .unsupported:
            break
        }
    }

    /// `.withResponse` mirrors Android's WRITE_TYPE_DEFAULT.
    @discardableResult
    private func writeRaw(_ bytes: Data) -> Bool {
        guard let p = peripheral, let c = controlChar else { return false }
        p.writeValue(bytes, for: c, type: .withResponse)
        return true
    }

    /// Direct read of FE02 (READ property); the value is emitted on `summary`, so callers
    /// just wait on the subject after calling this (used by the manager's stop fallback
    /// and by `.pushSummary`, which has no opcode on the pod).
    func requestSummaryRead() {
        readSummaryValue { [weak self] data in
            guard let self, let data else { return }
            do {
                let s = try self.hw.onSession(data)
                self.summary.send(s)
            } catch {
                self.badPackets += 1
            }
        }
    }

    /// Direct read of FE05 — delivered via the `hrv` subject (same path as a notify).
    func requestHrvRead() {
        guard let p = peripheral, let c = hrvChar else { return }
        p.readValue(for: c)
    }

    /// Reads FE02 and hands the raw value (nil on failure / 3 s timeout) to `done` —
    /// without emitting it on `summary`.
    private func readSummaryValue(_ done: @escaping (Data?) -> Void) {
        guard let p = peripheral, let c = summaryChar else { done(nil); return }
        readSeq += 1
        let id = readSeq
        pendingSummaryReads.append(PendingRead(id: id, done: done))
        p.readValue(for: c)
        DispatchQueue.main.asyncAfter(deadline: .now() + Self.readTimeout) { [weak self] in
            guard let self else { return }
            guard let idx = self.pendingSummaryReads.firstIndex(where: { $0.id == id }) else { return }
            let entry = self.pendingSummaryReads.remove(at: idx)
            self.staleSummaryReads += 1
            entry.done(nil)
        }
    }

    // MARK: - Replay (PROTOCOL §7)

    /// Read FE02 (how many records, and the session window), send 0x04, collect FE04 until
    /// the promised count arrives or the stream goes quiet, then convert the session's rows
    /// and emit them as the internal replay stream. Missing sequence numbers or record CRC
    /// failures re-issue 0x04 once (2 attempts). When the session has no rows `replayEmpty`
    /// fires instead, so the manager reports "nothing stored" rather than replacing the live
    /// epochs with an empty night.
    private func startReplay() {
        cancelReplayJob()
        replayDiag = nil
        replayLastResult = nil
        let gen = replayGeneration
        readSummaryValue { [weak self] data in
            guard let self, gen == self.replayGeneration, self.peripheral != nil else { return }
            var promised = 0
            if let data, (try? self.hw.onSession(data)) != nil {
                promised = self.hw.lastSession?.logRecords ?? 0
            }
            if promised == 0 {
                self.replayEmpty.send(())
                return
            }
            self.replayPromised = promised
            self.replayAttempt = 0
            self.beginReplayAttempt(generation: gen)
        }
    }

    private func beginReplayAttempt(generation gen: Int) {
        hw.beginReplay()
        replayCollecting = true
        lastReplayFrameAt = Date()
        guard writeRaw(HwOp.simple(HwOp.replayBegin)) else {
            replayCollecting = false
            completeReplay(replayLastResult)
            return
        }
        replayStartedAt = Date()
        replayPollTimer?.invalidate()
        let timer = Timer(timeInterval: 0.25, repeats: true) { [weak self] _ in
            self?.pollReplay(generation: gen)
        }
        RunLoop.main.add(timer, forMode: .common)
        replayPollTimer = timer
    }

    private func pollReplay(generation gen: Int) {
        guard gen == replayGeneration, replayCollecting else {
            replayPollTimer?.invalidate(); replayPollTimer = nil
            return
        }
        let now = Date()
        let quiet = now.timeIntervalSince(lastReplayFrameAt)
        var done = false
        // log_records is capped at 255 while the ring holds up to 480: at the cap, wait for quiet.
        if replayPromised < 255 && hw.replayReceived >= replayPromised && quiet > 0.4 { done = true }
        if quiet > 3 { done = true }
        // Stay under the manager's 90 s header timeout.
        if now.timeIntervalSince(replayStartedAt) >= 80 { done = true }
        guard done else { return }

        replayPollTimer?.invalidate(); replayPollTimer = nil
        replayCollecting = false
        let result = hw.finishReplay()
        replayLastResult = result
        // PROTOCOL §7: missing sequence numbers mean dropped notifications — re-issue 0x04 once.
        if (result.missing > 0 || result.crcFailures > 0) && replayAttempt < 1 {
            replayAttempt += 1
            beginReplayAttempt(generation: gen)
            return
        }
        completeReplay(result)
    }

    private func completeReplay(_ result: HwAdapter.ReplayResult?) {
        guard let r = result, !r.records.isEmpty else {
            replayEmpty.send(())
            return
        }
        NSLog("BlePodSource replay: %ld frames, %ld CRC failures, %ld missing, %ld session rows -> %ld epochs",
              r.framesReceived, r.crcFailures, r.missing, r.sessionRows, r.records.count)
        replayDiag = (missing: r.missing, crcFailures: r.crcFailures)
        for f in hw.internalFrames(r.records) { replayFrames.send(f) }
    }

    private func cancelReplayJob() {
        replayGeneration += 1
        replayPollTimer?.invalidate(); replayPollTimer = nil
        replayCollecting = false
    }
}

// MARK: - CBCentralManagerDelegate

extension BlePodSource: CBCentralManagerDelegate {

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            if pendingScan { pendingScan = false; beginScan(central) }
        case .unknown, .resetting:
            break // transient — wait for a definitive state
        default:
            // Bluetooth off / unauthorized / unsupported: everything is torn down by the system.
            pendingScan = false
            cleanupPeripheral()
            connectionState.send(.off)
        }
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let key = peripheral.identifier.uuidString
        let name = (advertisementData[CBAdvertisementDataLocalNameKey] as? String)
            ?? peripheral.name ?? AuroraUUID.advertisedName
        discovered[key] = peripheral
        seen[key] = ScannedPod(id: key, name: name, rssi: RSSI.intValue)
        scanResults.send(seen.values.sorted { $0.rssi > $1.rssi })
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        // The glove exposes only the Aurora service (no 180A Device Information, no 180F Battery).
        peripheral.discoverServices([AuroraUUID.service])
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        cleanupPeripheral()
        let code = error.map { String(($0 as NSError).code) }
        connectionState.send(.error(messageKey: "app_err_connection_lost", arg: code))
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        let wasUser = userDisconnect
        cleanupPeripheral()
        if wasUser {
            // disconnect() already published .disconnected.
            return
        }
        if let error {
            connectionState.send(.error(messageKey: "app_err_connection_lost", arg: String((error as NSError).code)))
        } else {
            connectionState.send(.disconnected)
        }
    }
}

// MARK: - CBPeripheralDelegate

extension BlePodSource: CBPeripheralDelegate {

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        let auroraService = peripheral.services?.first { $0.uuid == AuroraUUID.service }
        guard error == nil, let service = auroraService else {
            // Passed the scan filter but doesn't expose the Aurora service — not our device.
            connectionState.send(.error(messageKey: "app_err_not_aurora", arg: nil))
            central?.cancelPeripheralConnection(peripheral)
            return
        }
        // FE06 does not exist on the hardware-v1 glove; only the five PROTOCOL §2 characteristics.
        peripheral.discoverCharacteristics(
            [AuroraUUID.vitals, AuroraUUID.summary, AuroraUUID.control, AuroraUUID.log, AuroraUUID.hrv],
            for: service)
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil, service.uuid == AuroraUUID.service else { return }
        guard peripheral === self.peripheral else { return }
        onLinkReady(peripheral, service: service)
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic,
                    error: Error?) {
        guard characteristic.uuid == AuroraUUID.vitals, awaitingVitalsNotify, peripheral === self.peripheral else { return }
        if error != nil || !characteristic.isNotifying {
            failLink(peripheral)
        } else {
            finishLinkReady(peripheral)
        }
    }

    /// Both notifications and read responses land here — one dispatch point per
    /// characteristic UUID, mirroring the Android dispatch(). A packet failing its
    /// length / header / CRC check is dropped and counted (never crashes the link).
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if characteristic.uuid == AuroraUUID.summary {
            handleSummaryValue(error == nil ? characteristic.value : nil, failed: error != nil)
            return
        }
        guard error == nil, let data = characteristic.value else { return }
        switch characteristic.uuid {
        case AuroraUUID.vitals:
            do {
                let out = try hw.onVitals(data)
                // Joined a running session but FE02 hasn't told us when it began: ask again
                // (not emitted as a summary), at most every 3 s.
                if hw.needsSessionPin && Date().timeIntervalSince(pinReadAt) > 3 {
                    pinReadAt = Date()
                    readSummaryValue { [weak self] d in
                        guard let self, let d else { return }
                        _ = try? self.hw.onSession(d)
                    }
                }
                if batteryPct.value != out.batteryPct { batteryPct.send(out.batteryPct) } // nil = unknown: no gauge
                if !restartingSession {
                    vitals.send(out.vitals)
                    extVitals.send(out.ext)  // SpO2 estimate rides the ext channel
                }
            } catch {
                badPackets += 1
            }
        case AuroraUUID.hrv:
            do {
                hrv.send(try hw.onHrv(data))
            } catch {
                badPackets += 1
            }
        case AuroraUUID.log:
            // FE04 frames only mean something while a replay we started is running.
            if replayCollecting {
                lastReplayFrameAt = Date()
                if !hw.onReplayFrame(data) { badPackets += 1 }
            }
        default:
            break
        }
    }

    /// FE02: complete the oldest outstanding read, else drop a late (timed-out) read,
    /// else it is the pod's end-of-session NOTIFY — that is the morning card.
    private func handleSummaryValue(_ data: Data?, failed: Bool) {
        if !pendingSummaryReads.isEmpty {
            let entry = pendingSummaryReads.removeFirst()
            entry.done(data)
            return
        }
        if staleSummaryReads > 0 {
            staleSummaryReads -= 1
            if let data { _ = try? hw.onSession(data) } // still refreshes the replay window
            return
        }
        guard !failed, let data else { return }
        do {
            let s = try hw.onSession(data)
            // The FE02 of a leftover session we stopped ourselves: fed to the adapter only.
            if swallowNextSummary {
                swallowNextSummary = false
            } else {
                summary.send(s)
            }
        } catch {
            badPackets += 1
        }
    }
}
