// Real Aurora Pod over CoreBluetooth — the phone is the central, the pod the peripheral (spec §1).
import Foundation
import Combine
import CoreBluetooth

/// CoreBluetooth implementation of `PodSource`.
///
/// The central is created with `queue: .main`, so every delegate callback — and therefore
/// every subject emission below — happens on the main queue, satisfying the PodSource
/// threading contract without extra hops.
///
/// Unlike Android there is no GATT-operation mutex: CoreBluetooth queues characteristic
/// reads/writes/notification changes internally. Nothing relies on MTU negotiation
/// (all packets are ≤ 20 B, spec §2).
///
/// Background behaviour: iOS has no foreground service. Long replays and overnight
/// notifications rely on the `bluetooth-central` background mode already declared in
/// the app's Info.plist — active CBPeripheral notifications keep delivering while
/// the app is backgrounded.
final class BlePodSource: NSObject, PodSource {

    let isDemo = false

    let connectionState = CurrentValueSubject<ConnectionState, Never>(.disconnected)
    let scanResults = CurrentValueSubject<[ScannedPod], Never>([])
    let deviceInfo = CurrentValueSubject<DeviceInfo?, Never>(nil)
    let batteryPct = CurrentValueSubject<Int?, Never>(nil)

    let vitals = PassthroughSubject<LiveVitals, Never>()
    let hrv = PassthroughSubject<HrvSummary, Never>()
    let summary = PassthroughSubject<SessionSummary, Never>()
    let replayFrames = PassthroughSubject<Data, Never>()

    // MARK: private state (main queue only)

    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    private var controlChar: CBCharacteristic?
    private var summaryChar: CBCharacteristic?
    private var hrvChar: CBCharacteristic?
    /// Peripherals seen during the current scan, keyed by identifier string.
    private var discovered: [String: CBPeripheral] = [:]
    private var seen: [String: ScannedPod] = [:]
    private var scanTimeout: DispatchWorkItem?
    /// startScan() was called while the central was still powering up.
    private var pendingScan = false
    private var userDisconnect = false
    /// Device-info strings accumulate as the four 180A reads come back one by one.
    private var pendingInfo = DeviceInfo()

    var isPoweredOn: Bool { central?.state == .poweredOn }

    /// Created lazily so the system Bluetooth permission prompt appears on first
    /// scan/connect, not at app launch (mirrors the Android permission flow).
    private func ensureCentral() -> CBCentralManager {
        if let central { return central }
        let c = CBCentralManager(delegate: self, queue: .main)
        central = c
        return c
    }

    // MARK: - Scanning

    func startScan() {
        let c = ensureCentral()
        switch c.state {
        case .poweredOn:
            beginScan(c)
        case .unknown, .resetting:
            // The central is still powering up — start as soon as it reports poweredOn.
            pendingScan = true
        case .unsupported:
            // No scan-failure callback exists on iOS; the closest analogue to Android's
            // onScanFailed(code) is an unusable radio. Surface the state raw value as the code.
            connectionState.send(.error(messageKey: "app_err_scan_failed", arg: String(c.state.rawValue)))
        default:
            connectionState.send(.off)
        }
    }

    private func beginScan(_ c: CBCentralManager) {
        seen.removeAll()
        discovered.removeAll()
        scanResults.send([])
        connectionState.send(.scanning)
        // Filter by the Aurora service UUID that is in the advertising packet (spec §1).
        // Allow duplicates so RSSI keeps updating while the sheet is open.
        c.scanForPeripherals(withServices: [AuroraUUID.service],
                             options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
        scanTimeout?.cancel()
        let item = DispatchWorkItem { [weak self] in self?.stopScan() }
        scanTimeout = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 15, execute: item)  // 15 s, like Android
    }

    func stopScan() {
        scanTimeout?.cancel(); scanTimeout = nil
        pendingScan = false
        if central?.isScanning == true { central?.stopScan() }
        if case .scanning = connectionState.value { connectionState.send(.disconnected) }
    }

    // MARK: - Connection

    func connect(id: String?) {
        let c = ensureCentral()
        guard c.state == .poweredOn else { connectionState.send(.off); return }
        guard let target = id ?? scanResults.value.first?.id else {
            connectionState.send(.error(messageKey: "app_err_no_pod", arg: nil))
            return
        }
        stopScan()
        var p = discovered[target]
        if p == nil, let uuid = UUID(uuidString: target) {
            p = c.retrievePeripherals(withIdentifiers: [uuid]).first
        }
        guard let p else {
            connectionState.send(.error(messageKey: "app_err_no_pod", arg: nil))
            return
        }
        userDisconnect = false
        pendingInfo = DeviceInfo()
        deviceInfo.send(nil)
        peripheral = p
        p.delegate = self
        connectionState.send(.connecting(name: p.name ?? AuroraUUID.advertisedName))
        c.connect(p, options: nil)
    }

    func disconnect() {
        userDisconnect = true
        if let p = peripheral { central?.cancelPeripheralConnection(p) }
        cleanupPeripheral()
        connectionState.send(.disconnected)
    }

    private func cleanupPeripheral() {
        controlChar = nil
        summaryChar = nil
        hrvChar = nil
        peripheral = nil
    }

    // MARK: - Commands

    /// Fire-and-forget write to FE03 (spec §6: no acks — confirm by observing FE01/FE02).
    /// `.withResponse` mirrors Android's WRITE_TYPE_DEFAULT.
    func write(_ command: PodCommand) {
        guard let p = peripheral, let c = controlChar else { return }
        p.writeValue(command.encode(), for: c, type: .withResponse)
    }

    /// Direct read of FE02 (READ property) — the value arrives through
    /// `didUpdateValueFor` and is dispatched on the same `summary` subject,
    /// so callers just wait on the subject after calling this.
    func requestSummaryRead() {
        guard let p = peripheral, let c = summaryChar else { return }
        p.readValue(for: c)
    }

    /// Direct read of FE05 — delivered via the `hrv` subject.
    func requestHrvRead() {
        guard let p = peripheral, let c = hrvChar else { return }
        p.readValue(for: c)
    }
}

// MARK: - CBCentralManagerDelegate

extension BlePodSource: CBCentralManagerDelegate {

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            if pendingScan { pendingScan = false; beginScan(central) }
        case .unknown, .resetting:
            break // transient — wait for a definitive state
        default:
            // Bluetooth off / unauthorized / unsupported: everything is torn down by the system.
            pendingScan = false
            cleanupPeripheral()
            connectionState.send(.off)
        }
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let key = peripheral.identifier.uuidString
        let name = (advertisementData[CBAdvertisementDataLocalNameKey] as? String)
            ?? peripheral.name ?? AuroraUUID.advertisedName
        discovered[key] = peripheral
        seen[key] = ScannedPod(id: key, name: name, rssi: RSSI.intValue)
        scanResults.send(seen.values.sorted { $0.rssi > $1.rssi })
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        // Discover the three services we use: Aurora, Device Information (180A), Battery (180F).
        peripheral.discoverServices([AuroraUUID.service, AuroraUUID.deviceInfoService, AuroraUUID.batteryService])
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        cleanupPeripheral()
        let code = error.map { String(($0 as NSError).code) }
        connectionState.send(.error(messageKey: "app_err_connection_lost", arg: code))
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        let wasUser = userDisconnect
        cleanupPeripheral()
        if wasUser {
            // disconnect() already published .disconnected.
            return
        }
        if let error {
            connectionState.send(.error(messageKey: "app_err_connection_lost", arg: String((error as NSError).code)))
        } else {
            connectionState.send(.disconnected)
        }
    }
}

// MARK: - CBPeripheralDelegate

extension BlePodSource: CBPeripheralDelegate {

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        let auroraService = peripheral.services?.first { $0.uuid == AuroraUUID.service }
        guard error == nil, auroraService != nil else {
            // Passed the scan filter but doesn't expose the Aurora service — not our device.
            connectionState.send(.error(messageKey: "app_err_not_aurora", arg: nil))
            central?.cancelPeripheralConnection(peripheral)
            return
        }
        for service in peripheral.services ?? [] {
            switch service.uuid {
            case AuroraUUID.service:
                peripheral.discoverCharacteristics(
                    [AuroraUUID.vitals, AuroraUUID.summary, AuroraUUID.control, AuroraUUID.log, AuroraUUID.hrv],
                    for: service)
            case AuroraUUID.deviceInfoService:
                peripheral.discoverCharacteristics(
                    [AuroraUUID.manufacturerName, AuroraUUID.modelNumber,
                     AuroraUUID.hardwareRevision, AuroraUUID.softwareRevision],
                    for: service)
            case AuroraUUID.batteryService:
                peripheral.discoverCharacteristics([AuroraUUID.batteryLevel], for: service)
            default:
                break
            }
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil else { return }
        switch service.uuid {
        case AuroraUUID.service:
            for c in service.characteristics ?? [] {
                switch c.uuid {
                case AuroraUUID.control:
                    controlChar = c
                case AuroraUUID.vitals, AuroraUUID.log:
                    peripheral.setNotifyValue(true, for: c)
                case AuroraUUID.summary:
                    summaryChar = c
                    peripheral.setNotifyValue(true, for: c)
                case AuroraUUID.hrv:
                    hrvChar = c
                    peripheral.setNotifyValue(true, for: c)
                default:
                    break
                }
            }
            // The link is usable once the Aurora characteristics are known; device info and
            // battery reads finish in the background (they arrive via didUpdateValueFor).
            connectionState.send(.connected(name: peripheral.name ?? AuroraUUID.advertisedName,
                                            id: peripheral.identifier.uuidString))
        case AuroraUUID.deviceInfoService:
            for c in service.characteristics ?? [] { peripheral.readValue(for: c) }
        case AuroraUUID.batteryService:
            for c in service.characteristics ?? [] where c.uuid == AuroraUUID.batteryLevel {
                peripheral.readValue(for: c)
                peripheral.setNotifyValue(true, for: c)
            }
        default:
            break
        }
    }

    /// Both notifications and read responses land here — one dispatch point per
    /// characteristic UUID, mirroring the Android dispatch(). All parsers are optional
    /// returns; a malformed packet is silently dropped (never crashes the link).
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil, let data = characteristic.value else { return }
        switch characteristic.uuid {
        case AuroraUUID.vitals:
            if let v = LiveVitals.parse(data) {
                batteryPct.send(v.battPct) // FE01 carries battery too — keep it fresh
                vitals.send(v)
            }
        case AuroraUUID.hrv:
            if let h = HrvSummary.parse(data) { hrv.send(h) }
        case AuroraUUID.summary:
            if let s = SessionSummary.parse(data) { summary.send(s) }
        case AuroraUUID.log:
            replayFrames.send(data) // raw 20 B frames; ReplayAssembler runs upstream
        case AuroraUUID.batteryLevel:
            if let b = data.first { batteryPct.send(Int(b)) }
        case AuroraUUID.manufacturerName:
            pendingInfo.manufacturer = Self.decodeString(data); deviceInfo.send(pendingInfo)
        case AuroraUUID.modelNumber:
            pendingInfo.model = Self.decodeString(data); deviceInfo.send(pendingInfo)
        case AuroraUUID.hardwareRevision:
            pendingInfo.hardwareRevision = Self.decodeString(data); deviceInfo.send(pendingInfo)
        case AuroraUUID.softwareRevision:
            pendingInfo.softwareRevision = Self.decodeString(data); deviceInfo.send(pendingInfo)
        default:
            break
        }
    }

    private static func decodeString(_ data: Data) -> String {
        // Some stacks pad GATT strings with NULs — trim them like the Android trimEnd('\0').trim().
        String(data: data, encoding: .utf8)?
            .trimmingCharacters(in: CharacterSet(charactersIn: "\0").union(.whitespacesAndNewlines)) ?? ""
    }
}
