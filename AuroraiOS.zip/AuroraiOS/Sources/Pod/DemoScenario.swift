// Demo physiological model + seeded RNG — port of DemoScenario.kt.
import Foundation

// MARK: - Seeded RNG

/// SplitMix64 — a tiny, fast, seedable generator. SystemRandomNumberGenerator cannot be
/// seeded, and the demo (and especially DemoHistory) needs reproducible nights, so we keep
/// our own. Statistical quality is more than enough for simulation noise.
struct SplitMix64: RandomNumberGenerator {
    private var state: UInt64

    init(seed: UInt64) { state = seed }

    mutating func next() -> UInt64 {
        state &+= 0x9E37_79B9_7F4A_7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58_476D_1CE4_E5B9
        z = (z ^ (z >> 27)) &* 0x94D0_49BB_1331_11EB
        return z ^ (z >> 31)
    }

    /// Uniform in [0, 1) — the Kotlin Random.nextFloat() analogue.
    mutating func nextDouble() -> Double {
        Double(next() >> 11) * (1.0 / 9_007_199_254_740_992.0) // 53 random bits / 2^53
    }

    /// Uniform integer in 0..<bound (bound > 0) — the Kotlin Random.nextInt(bound) analogue.
    mutating func nextInt(_ bound: Int) -> Int {
        min(bound - 1, Int(nextDouble() * Double(bound)))
    }

    /// Uniform integer in from..<until — the Kotlin Random.nextInt(from, until) analogue.
    mutating func nextInt(from: Int, until: Int) -> Int {
        from + nextInt(until - from)
    }
}

// MARK: - Demo modes

/// Demo activity modes — the chips on the Demo sheet. User-visible text lives in
/// Localizable.strings; this enum only knows the keys (demo_mode_up / demo_mode_up_desc, …).
enum DemoMode: String, CaseIterable, Identifiable, Equatable {
    case up
    case lightExercise
    case heavyExercise
    case sleeping
    case nightFlash
    case nightSweats

    var id: String { rawValue }

    /// Localization key for the chip label, e.g. L("demo_mode_up").
    var titleKey: String {
        switch self {
        case .up: return "demo_mode_up"
        case .lightExercise: return "demo_mode_light_exercise"
        case .heavyExercise: return "demo_mode_heavy_exercise"
        case .sleeping: return "demo_mode_sleeping"
        case .nightFlash: return "demo_mode_night_flash"
        case .nightSweats: return "demo_mode_night_sweats"
        }
    }

    /// Localization key for the one-line description, e.g. L("demo_mode_up_desc").
    var blurbKey: String { titleKey + "_desc" }

    var emoji: String {
        switch self {
        case .up: return "🚶"
        case .lightExercise: return "🧘"
        case .heavyExercise: return "🏃"
        case .sleeping: return "😴"
        case .nightFlash: return "🔥"
        case .nightSweats: return "💧"
        }
    }
}

// MARK: - Scenario model

/// A small physiological model that eases each signal toward mode-specific targets with
/// organic noise so the live chart looks like a real person. Pure Swift, no Foundation timers.
///
/// All temperatures °C, humidity %RH, motion = unitless activity counts per 30 s epoch.
final class DemoScenario {
    private var rnd: SplitMix64

    // ----- state (current values) -----
    private(set) var hr: Double = 72
    private(set) var skinTemp: Double = 33.4
    private(set) var skinRh: Double = 30
    private(set) var ambTemp: Double = 21.5
    private(set) var ambRh: Double = 42
    private(set) var motion: Double = 20
    private(set) var sleepState: SleepState = .wake
    private(set) var sweating = false
    private(set) var battPct = 92

    private(set) var mode: DemoMode = .up

    /// Scales how much a flash/sweat event raises skin humidity and temperature (per-person variation).
    var sweatGain: Double = 1

    private var modeElapsedS: Double = 0
    private var sleepCycleS: Double = 0
    private var flashPhaseS: Double = 0
    private var baselineSkin: Double = 33.4
    private var baselineHr: Double = 62
    private var battAccumS: Double = 0

    init(seed: UInt64 = DispatchTime.now().uptimeNanoseconds) {
        rnd = SplitMix64(seed: seed)
    }

    func setMode(_ m: DemoMode) {
        if m == mode { return }
        mode = m
        modeElapsedS = 0
        flashPhaseS = 0
        if m == .sleeping { sleepCycleS = 0 }
    }

    private struct Target {
        var hr: Double
        var hrJitter: Double
        var skinTemp: Double
        var skinRh: Double
        var motionLo: Double
        var motionHi: Double
        var sweat: Bool
    }

    private func target() -> Target {
        switch mode {
        case .up:
            return Target(hr: 72, hrJitter: 4, skinTemp: 33.4, skinRh: 30, motionLo: 30, motionHi: 120, sweat: false)
        case .lightExercise:
            return Target(hr: 105, hrJitter: 6, skinTemp: 33.9, skinRh: 42, motionLo: 200, motionHi: 420, sweat: false)
        case .heavyExercise:
            return Target(hr: 148, hrJitter: 8, skinTemp: 34.6, skinRh: 70, motionLo: 500, motionHi: 950, sweat: true)
        case .sleeping:
            let deep = sleepState == .deep
            return Target(hr: deep ? 54 : 59, hrJitter: 2, skinTemp: baselineSkin - 0.5, skinRh: 28,
                          motionLo: 0, motionHi: deep ? 6 : 18, sweat: false)
        case .nightFlash:
            // Rise over ~90 s, plateau ~2 min, recover over ~6 min.
            let p = flashPhaseS
            let env: Double
            if p < 90 { env = p / 90 }
            else if p < 210 { env = 1 }
            else { env = exp(-(p - 210) / 150) }
            return Target(hr: 58 + 26 * env, hrJitter: 3,
                          skinTemp: baselineSkin + (0.8 + 0.5 * sweatGain) * env,
                          skinRh: 30 + 22 * env * sweatGain,
                          motionLo: 20 + 60 * env, motionHi: 40 + 100 * env,
                          sweat: env > 0.45)
        case .nightSweats:
            // Longer, heavier: rise 2 min, sweat plateau ~9 min, slow recovery.
            let p = flashPhaseS
            let env: Double
            if p < 120 { env = p / 120 }
            else if p < 660 { env = 1 }
            else { env = exp(-(p - 660) / 240) }
            return Target(hr: 62 + 30 * env, hrJitter: 4,
                          skinTemp: baselineSkin + (1.0 + 0.6 * sweatGain) * env,
                          skinRh: 30 + 38 * env * sweatGain,
                          motionLo: 40 + 90 * env, motionHi: 70 + 160 * env,
                          sweat: env > 0.35)
        }
    }

    /// Advance the model by dt simulated seconds.
    func step(_ dtS: Double) {
        modeElapsedS += dtS
        if mode == .nightFlash || mode == .nightSweats { flashPhaseS += dtS }

        // Sleep-stage cycling while sleeping: ~90-min cycles of light → deep → light, with brief wakes.
        if mode == .sleeping {
            sleepCycleS += dtS
            let cycle = sleepCycleS.truncatingRemainder(dividingBy: 5400)
            if modeElapsedS < 240 { sleepState = .wake }              // falling asleep
            else if cycle < 1500 { sleepState = .light }
            else if cycle < 3600 { sleepState = .deep }
            else if cycle < 5100 { sleepState = .light }
            else if cycle < 5250 { sleepState = rnd.nextDouble() < 0.6 ? .wake : .light }
            else { sleepState = .light }
        } else if mode == .nightFlash || mode == .nightSweats {
            sleepState = flashPhaseS < 40 ? .light : (flashPhaseS < 600 ? .wake : .light)
        } else {
            sleepState = .wake
        }

        let t = target()
        // Time constants (s): HR fast, skin temp slow, RH medium.
        hr = ease(hr, t.hr + noise(t.hrJitter), dtS, 25)
        skinTemp = ease(skinTemp, t.skinTemp + noise(0.05), dtS, 120)
        skinRh = ease(skinRh, t.skinRh + noise(1.2), dtS, 60)
        ambTemp = ease(ambTemp, 21.5 + noise(0.03), dtS, 600)
        ambRh = ease(ambRh, 42 + noise(0.5), dtS, 600)
        let motionTarget = t.motionLo + rnd.nextDouble() * (t.motionHi - t.motionLo)
        let burst: Double = (mode == .sleeping && rnd.nextDouble() < 0.01) ? 60 : 0
        motion = ease(motion, motionTarget + burst, dtS, 15)
        sweating = t.sweat

        battAccumS += dtS
        if battAccumS > 1500 {
            battAccumS = 0
            battPct = max(5, battPct - 1)
        }
    }

    /// Skin-minus-ambient absolute humidity, ×100, computed exactly as the firmware does.
    func dahX100() -> Int {
        NightAnalytics.dahX100(skinTempC: skinTemp, skinRh: skinRh, ambTempC: ambTemp, ambRh: ambRh)
    }

    func motionIndex() -> Int { min(65535, max(0, Int(motion))) }

    /// Heart-rate quality: worse with motion.
    func hrQuality() -> Int {
        min(100, max(20, Int(96 - min(60, motion / 12) + noise(3))))
    }

    private func ease(_ current: Double, _ target: Double, _ dtS: Double, _ tauS: Double) -> Double {
        let a = 1 - exp(-dtS / tauS)
        return current + (target - current) * a
    }

    private func noise(_ amp: Double) -> Double { (rnd.nextDouble() * 2 - 1) * amp }

    /// Gaussian-ish jitter for HRV numbers (Irwin–Hall sum of 6 uniforms).
    func gauss(_ mean: Double, _ sd: Double) -> Double {
        var s: Double = 0
        for _ in 0..<6 { s += rnd.nextDouble() }
        return mean + (s - 3) * sd
    }

    /// Uniform in [0, 1) from the scenario's own seeded stream.
    func nextDouble() -> Double { rnd.nextDouble() }
}
