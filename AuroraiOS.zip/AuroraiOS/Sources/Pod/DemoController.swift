// The "Demo" button's brain: swaps in the simulated pod, drives demo nights, seeds history.
import Foundation
import Combine

/// Switches the manager to the simulated pod, connects, starts a session and lets the
/// user pick activity modes; can also seed 14 nights of history. Every demo action goes
/// through the real command path (write → confirm-by-observing), so the whole pipeline
/// is exercised exactly like the hardware.
final class DemoController: ObservableObject {

    private let pod: PodConnectionManager
    private let repo: SessionRepository
    private let settings: AppSettings

    /// Non-nil while a long demo action runs. Holds a LOCALIZATION KEY (render with `L(busy)`).
    @Published private(set) var busy: String?

    /// Mirrors of the demo source's current activity mode and speed multiplier.
    @Published private(set) var mode: DemoMode
    @Published private(set) var speed: Int

    private var cancellables = Set<AnyCancellable>()

    init(pod: PodConnectionManager, repo: SessionRepository, settings: AppSettings) {
        self.pod = pod
        self.repo = repo
        self.settings = settings
        self.mode = pod.demo.mode.value
        self.speed = pod.demo.speed.value
        // Demo subjects emit on the main queue, so plain sinks are safe here.
        pod.demo.mode
            .sink { [weak self] in self?.mode = $0 }
            .store(in: &cancellables)
        pod.demo.speed
            .sink { [weak self] in self?.speed = $0 }
            .store(in: &cancellables)
    }

    // MARK: - Mode switching

    /// Enter demo mode: simulated pod, connected, ready.
    func enable() {
        settings.demoMode = true
        pod.useDemo(true)
        pod.connect(id: DemoPodSource.demoId)
    }

    /// Back to Bluetooth. Real nights are kept — only the source is swapped.
    func disable() {
        settings.demoMode = false
        pod.useDemo(false)
    }

    // MARK: - Demo night

    /// Start a demo night: connect if needed, then START through the real command path.
    func startDemoNight(initialMode: DemoMode = .sleeping) {
        if !pod.isDemo {
            settings.demoMode = true
            pod.useDemo(true)
        }
        if pod.connectionState.isConnected {
            pod.demo.setMode(initialMode)
            pod.startSession()
        } else {
            whenConnected { [weak self] in
                guard let self else { return }
                self.pod.demo.setMode(initialMode)
                self.pod.startSession()
            }
            pod.connect(id: DemoPodSource.demoId)
        }
    }

    func setMode(_ mode: DemoMode) { pod.demo.setMode(mode) }
    func setSpeed(_ speed: Int) { pod.demo.setSpeed(speed) }

    /// Stop → FE02 → morning card, exactly like the real pod.
    func stopDemoNight() { pod.stopSession() }

    // MARK: - History seeding

    /// Seed 14 realistic nights so Trends and the home hero have something to show.
    /// Generation runs on a background queue (it synthesises ~1000 records per night);
    /// database writes and slot installs hop back to the main queue, where the
    /// repository lives.
    func seedHistory(nights: Int = Cadence.nightSlots) {
        guard busy == nil else { return }
        guard let uidString = settings.userId, let uid = UUID(uuidString: uidString) else { return }
        busy = "demo_working"
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let history = DemoHistory.generateHistory(now: Date(), nights: nights)
            DispatchQueue.main.async {
                guard let self else { return }
                for (i, night) in history.enumerated() {
                    // Slots wrap at 14, like the pod's ring of night slots (spec §9).
                    let slot = i % Cadence.nightSlots
                    let events: [(Int64, ActivityKind)] = night.events.map { ($0.0, $0.1.activityKind) }
                    self.repo.insertGeneratedNight(userId: uid,
                                                   startedAt: night.startedAt,
                                                   records: night.records,
                                                   events: events,
                                                   slot: slot)
                    // Install into the simulated pod too, so "download night" replays it.
                    self.pod.demo.installSlot(slot: slot, records: night.records)
                }
                self.busy = nil
            }
        }
    }

    // MARK: - Helpers

    /// One-shot wait for the manager to report a connection (the demo source connects
    /// quickly, but the state still flows Connecting → Connected asynchronously).
    private func whenConnected(timeout: TimeInterval = 10, _ then: @escaping () -> Void) {
        var cancellable: AnyCancellable?
        var finished = false
        let timeoutItem = DispatchWorkItem {
            guard !finished else { return }
            finished = true
            cancellable?.cancel(); cancellable = nil
        }
        cancellable = pod.$connectionState.sink { state in
            guard !finished, state.isConnected else { return }
            finished = true
            timeoutItem.cancel()
            cancellable?.cancel(); cancellable = nil
            then()
        }
        if finished { cancellable?.cancel(); cancellable = nil } // fired synchronously
        DispatchQueue.main.asyncAfter(deadline: .now() + timeout, execute: timeoutItem)
    }
}
