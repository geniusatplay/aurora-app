// One-button hardware check for the custom-page `hardware_check` section — the iOS port
// of the verified web routine (web/aurora-live.src.html, hardwareCheck()), driven through
// PodConnectionManager so the app's own command paths (clock sync, START/STOP confirmed by
// observing FE01/FE02, replay download) are what gets tested.
//
// Sequence: clock confirmed → (real pod) 5 s bench log interval → session START via the
// manager → ~40 s live stream counting packets / CRC failures / sequence gaps / HR locks /
// HRV windows → STOP and await the FE02 summary → download the log → restore the 60 s log
// interval. Every row is pass / fail / skipped and a pass is only ever reported with the
// evidence that earns it. The short test night is removed afterwards (it is not a real
// night: no morning card, nothing left in the history).
//
// Refuses to start while a real night is recording (the check would end it), while a log
// download runs, or without a connected pod.

import Foundation
import Combine

/// One row of the hardware-check result list (strings already localized).
struct HardwareCheckStep: Identifiable, Equatable {
    enum Status: Equatable { case pass, fail, skipped }

    let id: Int
    let title: String
    let status: Status
    let detail: String?
}

/// Owned by PodConnectionManager (`pod.hardwareCheck`). All state changes happen on the
/// main actor: `run()` is called from the UI and the routine itself is @MainActor.
final class HardwareCheckRunner: ObservableObject {

    enum Phase: Equatable {
        case idle
        /// Localized progress line ("Streaming live vitals… 32 s").
        case running(status: String)
        case finished(passed: Int, failed: Int, skipped: Int)
    }

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var steps: [HardwareCheckStep] = []
    /// Localized reason the last Run tap was refused; nil when it was not.
    @Published private(set) var refusal: String?

    var isRunning: Bool {
        if case .running = phase { return true }
        return false
    }

    static let streamSeconds = 40
    static let benchLogIntervalS = 5
    static let defaultLogIntervalS = HwConst.defaultLogPeriodS

    private unowned let pod: PodConnectionManager
    private let repo: SessionRepository
    private var task: Task<Void, Never>?

    // Live-stream evidence (main queue).
    private var hrLocked = 0
    private var hrMin = 0
    private var hrMax = 0
    private var rawSummary: SessionSummary?
    private var nextStepId = 0

    init(pod: PodConnectionManager, repo: SessionRepository) {
        self.pod = pod
        self.repo = repo
    }

    /// Why a run cannot start right now (localized), or nil when it can.
    func refusalReason() -> String? {
        if isRunning { return L("hc_refuse_running") }
        if !pod.connectionState.isConnected { return L("hc_refuse_not_connected") }
        if pod.activeSession != nil { return L("hc_refuse_recording") }
        if pod.replayStatus.isActive { return L("hc_refuse_downloading") }
        return nil
    }

    /// Start the check (main thread). A refused start only sets `refusal`.
    func run() {
        if let reason = refusalReason() {
            refusal = reason
            return
        }
        refusal = nil
        steps = []
        nextStepId = 0
        phase = .running(status: L("hc_status_clock"))
        task = Task { @MainActor [weak self] in
            await self?.execute()
        }
    }

    // MARK: - The routine

    @MainActor
    private func execute() async {
        pod.setTestRun(true)
        let hardware = pod.isHardwareLink
        var testSessionId: UUID?

        // 1. Clock set on connect (FLAG_TIME_SYNCED / TIME_VALID), confirmed by the manager.
        setStatus(L("hc_status_clock"))
        let synced = await waitFor(seconds: 10) { self.pod.timeSynced }
        add(L("hc_step_clock"), synced ? .pass : .fail, synced ? nil : L("hc_detail_clock_fail"))

        // 2. Bench log interval so a 40 s session leaves rows to download (real pod only).
        if hardware {
            let ok = pod.setLogInterval(HardwareCheckRunner.benchLogIntervalS)
            add(L("hc_step_interval_bench", HardwareCheckRunner.benchLogIntervalS), ok ? .pass : .fail,
                ok ? nil : L("hc_detail_write_failed"))
            if ok { await pause(0.5) }
        } else {
            add(L("hc_step_interval_bench", HardwareCheckRunner.benchLogIntervalS), .skipped,
                L("hc_detail_demo_no_interval"))
        }

        // 3. Session start through the manager (START confirmed via the LOGGING flag).
        setStatus(L("hc_status_starting"))
        let startedAt = Date()
        var started = false
        if pod.connectionState.isConnected { started = await startSession() }
        testSessionId = pod.activeSession?.id
        add(L("hc_step_session_start"), (started && testSessionId != nil) ? .pass : .fail,
            started ? nil : L("hc_detail_session_not_started"))

        if started, let sid = testSessionId {
            // 4. Live stream.
            hrLocked = 0
            hrMin = 0
            hrMax = 0
            let base = pod.linkStats
            let streamStart = Date()
            let hrSub = pod.$latestVitals
                .dropFirst()
                .sink { [weak self] v in self?.countHr(v) }
            var left = HardwareCheckRunner.streamSeconds
            while left > 0 {
                if Task.isCancelled || !pod.connectionState.isConnected { break }
                setStatus(L("hc_status_streaming", left))
                await pause(1)
                left -= 1
            }
            hrSub.cancel()
            let secs = Date().timeIntervalSince(streamStart)
            let now = pod.linkStats
            let packets = now.vitalsPackets - base.vitalsPackets
            let crc = now.crcFailures - base.crcFailures
            let gaps = now.seqGaps - base.seqGaps
            let hrvWindows = now.hrvPackets - base.hrvPackets
            let wholeSecs = max(Int(secs.rounded()), 1)
            add(L("hc_step_rate"), Double(packets) >= secs * 0.8 ? .pass : .fail,
                L("hc_detail_rate", packets, wholeSecs))
            if hardware {
                add(L("hc_step_crc"), crc == 0 ? .pass : .fail, "\(crc)")
                add(L("hc_step_gaps"), gaps == 0 ? .pass : .fail, "\(gaps)")
            } else {
                // The simulator has no radio link and no sequence counter: nothing to prove.
                add(L("hc_step_crc"), .skipped, L("hc_detail_demo_no_crc"))
                add(L("hc_step_gaps"), .skipped, L("hc_detail_demo_no_seq"))
            }
            if hrLocked > 0 {
                add(L("hc_step_hr"), .pass, L("hc_detail_hr", hrLocked, hrMin, hrMax))
            } else {
                // No fingertip on the sensor is not a fault of the pod.
                add(L("hc_step_hr"), .skipped, L("hc_detail_hr_skipped"))
            }
            if hrvWindows > 0 {
                add(L("hc_step_hrv"), .pass, L("hc_detail_hrv", hrvWindows))
            } else if hardware {
                add(L("hc_step_hrv"), .fail, L("hc_detail_hrv_none"))
            } else {
                // The demo closes an HRV window only every 10 simulated minutes.
                add(L("hc_step_hrv"), .skipped, L("hc_detail_hrv_demo"))
            }
            if !pod.connectionState.isConnected {
                add(L("hc_step_link_lost"), .fail, nil)
            }

            // 5. STOP and await the FE02 summary (subscribe before the write — the demo
            //    answers synchronously).
            setStatus(L("hc_status_stopping"))
            rawSummary = nil
            let stopRequestedAt = Date()
            let sumSub = pod.source.summary.sink { [weak self] s in self?.rawSummary = s }
            var stopped = false
            if pod.connectionState.isConnected { stopped = await stopSession() }
            sumSub.cancel()
            if stopped, let s = rawSummary {
                add(L("hc_step_summary"), .pass, L("hc_detail_summary", Fmt.durationShort(s.sessionLenS)))
                if hardware {
                    // The pod timed START → STOP itself; compare with the phone's clock.
                    let expected = stopRequestedAt.timeIntervalSince(startedAt)
                    let ok = abs(Double(s.sessionLenS) - expected) <= 6
                    add(L("hc_step_duration"), ok ? .pass : .fail,
                        L("hc_detail_duration", Int(s.sessionLenS), Int(expected.rounded())))
                }
            } else {
                add(L("hc_step_summary"), .fail, L("hc_detail_summary_none"))
            }

            // 6. Download the log into the test night.
            if stopped && pod.connectionState.isConnected {
                setStatus(L("hc_status_download"))
                let slot = repo.session(id: sid)?.slot ?? rawSummary?.slot ?? 0
                pod.downloadNight(sessionId: sid, slot: slot)
                let finished = await waitFor(seconds: 150) { !self.pod.replayStatus.isActive }
                if !finished { pod.cancelDownload() }
                switch pod.replayStatus {
                case .done(_, let records, let crcFails, let complete):
                    let ok = records > 0 && crcFails == 0 && complete
                    add(L("hc_step_log"), ok ? .pass : .fail, L("hc_detail_log", records, crcFails))
                case .failed:
                    add(L("hc_step_log"), .fail, pod.replayStatus.failureText)
                default:
                    add(L("hc_step_log"), .fail, finished ? nil : L("hc_detail_log_timeout"))
                }
            } else {
                add(L("hc_step_log"), .skipped, L("hc_detail_log_skipped"))
            }
        }

        // 7. Restore the normal log interval (always attempted on the real pod).
        if hardware {
            let ok = pod.connectionState.isConnected
                && pod.setLogInterval(HardwareCheckRunner.defaultLogIntervalS)
            add(L("hc_step_interval_restore", HardwareCheckRunner.defaultLogIntervalS), ok ? .pass : .fail,
                ok ? nil : L("hc_detail_restore_fail", HardwareCheckRunner.defaultLogIntervalS))
        } else {
            add(L("hc_step_interval_restore", HardwareCheckRunner.defaultLogIntervalS), .skipped,
                L("hc_detail_demo_no_interval"))
        }

        // 8. Remove the test night. If it is somehow still recording, the manager's
        //    deletion hook also stops the pod and discards that FE02.
        if let sid = testSessionId {
            repo.deleteSession(id: sid)
        }
        pod.setTestRun(false)

        let passed = steps.filter { $0.status == .pass }.count
        let failed = steps.filter { $0.status == .fail }.count
        let skipped = steps.filter { $0.status == .skipped }.count
        phase = .finished(passed: passed, failed: failed, skipped: skipped)
        task = nil
    }

    // MARK: - Helpers

    private func countHr(_ v: LiveVitals?) {
        guard let v, v.hasHr else { return }
        hrLocked += 1
        hrMin = hrMin == 0 ? v.hrBpm : min(hrMin, v.hrBpm)
        hrMax = max(hrMax, v.hrBpm)
    }

    @MainActor
    private func setStatus(_ text: String) {
        phase = .running(status: text)
    }

    @MainActor
    private func add(_ title: String, _ status: HardwareCheckStep.Status, _ detail: String?) {
        nextStepId += 1
        steps.append(HardwareCheckStep(id: nextStepId, title: title, status: status, detail: detail))
    }

    @MainActor
    private func pause(_ seconds: Double) async {
        try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
    }

    /// Polls `predicate` every 0.2 s until it holds or `seconds` elapse.
    @MainActor
    private func waitFor(seconds: Double, _ predicate: () -> Bool) async -> Bool {
        let deadline = Date().addingTimeInterval(seconds)
        while Date() < deadline {
            if predicate() { return true }
            if Task.isCancelled { break }
            await pause(0.2)
        }
        return predicate()
    }

    @MainActor
    private func startSession() async -> Bool {
        await withCheckedContinuation { (cont: CheckedContinuation<Bool, Never>) in
            self.pod.startSession { ok in cont.resume(returning: ok) }
        }
    }

    @MainActor
    private func stopSession() async -> Bool {
        await withCheckedContinuation { (cont: CheckedContinuation<Bool, Never>) in
            self.pod.stopSession { ok in cont.resume(returning: ok) }
        }
    }
}
