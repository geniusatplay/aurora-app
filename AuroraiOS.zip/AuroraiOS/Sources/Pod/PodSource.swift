import Foundation
import Combine

enum ConnectionState: Equatable {
    case off                      // Bluetooth off / unauthorized
    case disconnected
    case scanning
    case connecting(name: String)
    case connected(name: String, id: String)
    case error(messageKey: String, arg: String?)   // localization key + optional argument

    var isConnected: Bool { if case .connected = self { return true }; return false }
}

struct ScannedPod: Equatable, Identifiable {
    var id: String        // peripheral identifier UUID string (demo: fixed)
    var name: String
    var rssi: Int
}

/// One abstraction for "a pod". The CoreBluetooth implementation and the demo simulator
/// both emit the SAME packet types, so every parser, database path and chart runs the
/// real code path in demo mode.
///
/// Threading: all subjects emit on the main queue.
protocol PodSource: AnyObject {
    var isDemo: Bool { get }

    var connectionState: CurrentValueSubject<ConnectionState, Never> { get }
    var scanResults: CurrentValueSubject<[ScannedPod], Never> { get }
    var deviceInfo: CurrentValueSubject<DeviceInfo?, Never> { get }
    var batteryPct: CurrentValueSubject<Int?, Never> { get }

    /// FE01 — 1 Hz while connected.
    var vitals: PassthroughSubject<LiveVitals, Never> { get }
    /// FE06 — 1 Hz, only from pods with extended sensors (ext brief §1). Silent otherwise.
    var extVitals: PassthroughSubject<ExtendedVitals, Never> { get }
    /// True once FE06 is known to exist: always for demo, after discovery for BLE.
    var hasExtendedSensors: CurrentValueSubject<Bool, Never> { get }
    /// What this pod can actually measure. Screens hide cards/panels for absent channels
    /// instead of drawing empty charts. Demo = full paper spec (`.demo`); real glove =
    /// `.hardwareV1`; not connected = `.none`.
    var capabilities: CurrentValueSubject<PodCapabilities, Never> { get }
    /// How long the manager waits for the first internal replay frame (seconds). The demo
    /// answers instantly; the real pod streams its whole RAM log first and the BLE layer
    /// converts it, so the first frame can take tens of seconds. Default 2.5 s.
    var replayHeaderTimeout: TimeInterval { get }
    /// Fires (main queue) when a requested replay turned out to hold nothing for this
    /// session (real pod). The demo never fires it.
    var replayEmpty: PassthroughSubject<Void, Never> { get }
    /// Link-level problems of the LAST replay that the internal re-encoded stream cannot
    /// show (real pod: dropped FE04 notifications, record CRC failures). Taken once by the
    /// manager when the replay finishes; nil when there is nothing to report.
    func takeReplayDiagnostics() -> (missing: Int, crcFailures: Int)?
    /// FE05 — periodic HRV summaries.
    var hrv: PassthroughSubject<HrvSummary, Never> { get }
    /// FE02 — on stop / on demand.
    var summary: PassthroughSubject<SessionSummary, Never> { get }
    /// FE04 — raw 20-byte replay frames.
    var replayFrames: PassthroughSubject<Data, Never> { get }
    /// Link-level counters for the Diagnostics sections (packets, CRC failures, sequence
    /// gaps, FE01 rate). Reset on every new connection. Real pod: counted per notification;
    /// demo: its own simple counts.
    var linkStats: CurrentValueSubject<LinkStats, Never> { get }
    /// Ring buffer of the most recent raw packets (newest last, `LinkRecorder.ringCapacity`).
    var rawPackets: CurrentValueSubject<[RawPacket], Never> { get }

    func startScan()
    func stopScan()
    func connect(id: String?)
    func disconnect()

    /// Fire-and-forget write to FE03 (spec: no acks — confirm by observing FE01/FE02).
    func write(_ command: PodCommand)
}

extension PodSource {
    var replayHeaderTimeout: TimeInterval { 2.5 }
    func takeReplayDiagnostics() -> (missing: Int, crcFailures: Int)? { nil }
}

// MARK: - Link diagnostics (custom pages: link_health / packet_inspector / hardware_check)

/// Link-level counters of the current connection.
struct LinkStats: Equatable {
    /// Packets that passed their length / header / CRC checks (every characteristic).
    var packets = 0
    /// FE01 live-vitals packets among them (≈ 1 Hz on a healthy link).
    var vitalsPackets = 0
    /// FE05 HRV packets among them.
    var hrvPackets = 0
    /// Packets dropped by the length / header / CRC check (PROTOCOL: must stay 0).
    var crcFailures = 0
    /// FE01 notifications missing according to the pod's 8-bit sequence counter
    /// (real pod only — the demo pod has no counter and reports 0).
    var seqGaps = 0
    /// FE01 arrival rate over the last ~10 s; nil until two packets have arrived.
    var rateHz: Double?
    /// Wall-clock time of the most recent packet (valid or not).
    var lastPacketAt: Date?
}

/// What a raw packet decoded to — formatted (and localized) by the UI, never here.
enum RawPacketKind: Equatable {
    case vitals(seq: Int?, hrBpm: Double?, absHumX100: Int?, skinTempX100: Int?)
    case hrv(rmssdX10: Int, beats: Int)
    case summary(durationS: Int64)
    case replay(seq: Int)
    /// The decoder rejected the packet; `reason` is the decoder's technical message.
    case invalid(reason: String)
}

/// One entry of the raw-packet ring buffer.
struct RawPacket: Identifiable, Equatable {
    let id: Int
    let time: Date
    /// Characteristic short name ("FE01", "FE02", "FE04", "FE05").
    let characteristic: String
    /// Bytes as spaced upper-case hex ("A1 0C 3F …").
    let hex: String
    /// Passed the length / header / CRC checks.
    let ok: Bool
    let decoded: RawPacketKind
}

/// Shared bookkeeping behind `PodSource.linkStats` / `rawPackets`. Main queue only, like
/// every PodSource subject.
final class LinkRecorder {
    static let ringCapacity = 50

    enum Counted { case vitals, hrv, other }

    let stats = CurrentValueSubject<LinkStats, Never>(LinkStats())
    let packets = CurrentValueSubject<[RawPacket], Never>([])

    private var nextId = 0
    private var lastSeq: Int?
    private var arrivals: [Date] = []

    /// Call on every new connection.
    func reset() {
        lastSeq = nil
        arrivals = []
        stats.send(LinkStats())
        packets.send([])
    }

    /// Count one packet and append it to the ring buffer. `seq` is the FE01 8-bit
    /// sequence counter when the pod sends one (gaps = notifications that never arrived).
    func record(_ characteristic: String, _ data: Data, ok: Bool, _ decoded: RawPacketKind,
                seq: Int? = nil, counted: Counted = .other, now: Date = Date()) {
        var s = stats.value
        if ok {
            s.packets += 1
            switch counted {
            case .vitals:
                s.vitalsPackets += 1
                if let seq {
                    if let last = lastSeq, seq != last {
                        let expected = (last + 1) & 0xFF
                        if seq != expected { s.seqGaps += (seq - expected + 256) & 0xFF }
                    }
                    lastSeq = seq
                }
                arrivals.append(now)
                arrivals.removeAll { now.timeIntervalSince($0) > 10 }
                if arrivals.count > 1, let first = arrivals.first, now > first {
                    s.rateHz = Double(arrivals.count - 1) / now.timeIntervalSince(first)
                }
            case .hrv:
                s.hrvPackets += 1
            case .other:
                break
            }
        } else {
            s.crcFailures += 1
        }
        s.lastPacketAt = now
        stats.send(s)

        nextId += 1
        var ring = packets.value
        ring.append(RawPacket(id: nextId, time: now, characteristic: characteristic,
                              hex: LinkRecorder.hex(data), ok: ok, decoded: decoded))
        if ring.count > LinkRecorder.ringCapacity {
            ring.removeFirst(ring.count - LinkRecorder.ringCapacity)
        }
        packets.send(ring)
    }

    static func hex(_ data: Data) -> String {
        data.map { String(format: "%02X", $0) }.joined(separator: " ")
    }

    /// The decoder's message without the enum wrapper, for the packet inspector.
    static func reason(_ error: Error) -> String {
        if let e = error as? HwPacketError, case let .invalid(msg) = e { return msg }
        return String(describing: error)
    }
}
