import Foundation
import Combine

enum ConnectionState: Equatable {
    case off                      // Bluetooth off / unauthorized
    case disconnected
    case scanning
    case connecting(name: String)
    case connected(name: String, id: String)
    case error(messageKey: String, arg: String?)   // localization key + optional argument

    var isConnected: Bool { if case .connected = self { return true }; return false }
}

struct ScannedPod: Equatable, Identifiable {
    var id: String        // peripheral identifier UUID string (demo: fixed)
    var name: String
    var rssi: Int
}

/// One abstraction for "a pod". The CoreBluetooth implementation and the demo simulator
/// both emit the SAME packet types, so every parser, database path and chart runs the
/// real code path in demo mode.
///
/// Threading: all subjects emit on the main queue.
protocol PodSource: AnyObject {
    var isDemo: Bool { get }

    var connectionState: CurrentValueSubject<ConnectionState, Never> { get }
    var scanResults: CurrentValueSubject<[ScannedPod], Never> { get }
    var deviceInfo: CurrentValueSubject<DeviceInfo?, Never> { get }
    var batteryPct: CurrentValueSubject<Int?, Never> { get }

    /// FE01 — 1 Hz while connected.
    var vitals: PassthroughSubject<LiveVitals, Never> { get }
    /// FE06 — 1 Hz, only from pods with extended sensors (ext brief §1). Silent otherwise.
    var extVitals: PassthroughSubject<ExtendedVitals, Never> { get }
    /// True once FE06 is known to exist: always for demo, after discovery for BLE.
    var hasExtendedSensors: CurrentValueSubject<Bool, Never> { get }
    /// FE05 — periodic HRV summaries.
    var hrv: PassthroughSubject<HrvSummary, Never> { get }
    /// FE02 — on stop / on demand.
    var summary: PassthroughSubject<SessionSummary, Never> { get }
    /// FE04 — raw 20-byte replay frames.
    var replayFrames: PassthroughSubject<Data, Never> { get }

    func startScan()
    func stopScan()
    func connect(id: String?)
    func disconnect()

    /// Fire-and-forget write to FE03 (spec: no acks — confirm by observing FE01/FE02).
    func write(_ command: PodCommand)
}
