// Software Aurora Pod — port of DemoPodSource.kt onto Combine + Timer.
import Foundation
import Combine

/// A software Aurora Pod. Emits byte-identical FE01/FE02/FE04/FE05 packets so the whole
/// app — parsers, CRC, replay reassembly, database, charts — runs the real code path.
///
/// Time model: every real second the simulation advances `speed` simulated seconds
/// (in sub-steps of at most 5 simulated seconds for numeric stability).
///
/// Threading: all public methods are expected on the main thread (they are driven by the UI
/// and by main-runloop timers); every subject emits on the main queue.
final class DemoPodSource: PodSource {

    static let demoId = "DEMO-POD"
    static let demoName = "AuroraPod (demo)"

    let isDemo = true

    // ----- PodSource subjects -----
    let connectionState = CurrentValueSubject<ConnectionState, Never>(.disconnected)
    let scanResults = CurrentValueSubject<[ScannedPod], Never>([])
    let deviceInfo = CurrentValueSubject<DeviceInfo?, Never>(nil)
    let batteryPct = CurrentValueSubject<Int?, Never>(nil)
    let vitals = PassthroughSubject<LiveVitals, Never>()
    let extVitals = PassthroughSubject<ExtendedVitals, Never>()
    /// The demo pod always carries the extended sensors (ext brief §2).
    let hasExtendedSensors = CurrentValueSubject<Bool, Never>(true)
    let hrv = PassthroughSubject<HrvSummary, Never>()
    let summary = PassthroughSubject<SessionSummary, Never>()
    let replayFrames = PassthroughSubject<Data, Never>()

    // ----- demo controls -----
    let mode = CurrentValueSubject<DemoMode, Never>(.up)
    let speed = CurrentValueSubject<Int, Never>(10)

    /// (t_s, mode) whenever the mode changes during a session — used to log activity markers.
    let modeEvents = PassthroughSubject<(Int64, DemoMode), Never>()

    // ----- internal pod state -----
    private let scenario = DemoScenario()
    private var timeSynced = false
    private var logging = false
    private var simT: Double = 0          // seconds since session start
    private var lastEpochT: Int64 = 0
    private var lastHrvT: Int64 = 0
    private var lastHrv: HrvSummary?
    private var hrvFreshPending = false
    private var sweatWasOn = false
    private var records: [LogRecord] = []
    private var slots = [Data?](repeating: nil, count: Cadence.nightSlots)
    private var slotCounts = [Int](repeating: 0, count: Cadence.nightSlots)
    private var nextSlot = 0
    private var lastSlot = 0
    private var tickTimer: Timer?
    private var tickEmitVitals = true
    private var replayGeneration = 0
    private var previewT: Int64 = 0
    private var lastPreviewHrvT: Int64 = 0
    private var lastSweatFlagForVitals = SweatFlag.none

    deinit {
        tickTimer?.invalidate()
    }

    // ------------------------------------------------------------------ demo controls

    func setMode(_ m: DemoMode) {
        if mode.value == m { return }
        mode.send(m)
        scenario.setMode(m)
        if logging { modeEvents.send((Int64(simT), m)) }
    }

    func setSpeed(_ s: Int) { speed.send(min(120, max(1, s))) }

    var currentTs: Int64 { Int64(simT) }
    var isLogging: Bool { logging }

    // ------------------------------------------------------------------ PodSource

    func startScan() {
        connectionState.send(.scanning)
        scanResults.send([ScannedPod(id: DemoPodSource.demoId, name: DemoPodSource.demoName, rssi: -58)])
    }

    func stopScan() {
        if case .scanning = connectionState.value { connectionState.send(.disconnected) }
    }

    func connect(id: String?) {
        connectionState.send(.connecting(name: DemoPodSource.demoName))
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            guard let self else { return }
            self.deviceInfo.send(DeviceInfo(manufacturer: "Aurora Pod",
                                            model: "MSG-RevA",
                                            hardwareRevision: "AURORA-POD-CARRIER-RevA",
                                            softwareRevision: "1.0.0"))
            self.batteryPct.send(self.scenario.battPct)
            self.connectionState.send(.connected(name: DemoPodSource.demoName, id: DemoPodSource.demoId))
            self.startTicking()
        }
    }

    func disconnect() {
        stopTicking()
        abortReplay()
        connectionState.send(.disconnected)
        // Like the real pod: recording continues in "flash" while disconnected.
        if logging { startTicking(emitVitals: false) }
    }

    /// FE03 is fire-and-forget on the real pod too — confirm by observing FE01/FE02.
    func write(_ command: PodCommand) {
        switch command {
        case .timeSync:
            timeSynced = true
        case .startSession:
            if !logging {
                logging = true
                simT = 0; lastEpochT = 0; lastHrvT = 0; lastHrv = nil; hrvFreshPending = false
                sweatWasOn = false
                records = []
                modeEvents.send((0, mode.value))
                if tickTimer == nil { startTicking(emitVitals: connectionState.value.isConnected) }
            }
        case .stopSession:
            if logging {
                logging = false
                finishSession()
            }
        case .pushSummary:
            if let s = lastSummary() { summary.send(s) }
        case .replaySlot(let slot):
            startReplay(slot: slot)
        case .abortReplay:
            abortReplay()
        case .formatFlash:
            slots = [Data?](repeating: nil, count: Cadence.nightSlots)
            slotCounts = [Int](repeating: 0, count: Cadence.nightSlots)
            nextSlot = 0
        case .hapticTest, .fuelGaugeRelearn:
            break
        }
    }

    /// On-demand FE02/FE05 reads (the demo analogue of a GATT read).
    func readSummary() -> SessionSummary? { lastSummary() }
    func readHrv() -> HrvSummary? { lastHrv }

    // ------------------------------------------------------------------ ticking

    private func startTicking(emitVitals: Bool = true) {
        tickTimer?.invalidate()
        tickEmitVitals = emitVitals
        let timer = Timer(timeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            self.tick(emitVitals: self.tickEmitVitals && self.connectionState.value.isConnected)
        }
        RunLoop.main.add(timer, forMode: .common)
        tickTimer = timer
    }

    private func stopTicking() {
        tickTimer?.invalidate()
        tickTimer = nil
    }

    private func tick(emitVitals: Bool) {
        let speed = self.speed.value
        // Sub-step for numeric stability; at most 5 simulated seconds per step.
        let steps = max(1, (speed + 4) / 5)
        let dt = Double(speed) / Double(steps)
        for _ in 0..<steps {
            scenario.step(dt)
            if logging {
                simT += dt
                let t = Int64(simT)
                // One epoch every 30 simulated seconds
                if t - lastEpochT >= Int64(Cadence.epochS) {
                    lastEpochT = (t / Int64(Cadence.epochS)) * Int64(Cadence.epochS)
                    records.append(buildRecord(lastEpochT))
                }
                // HRV window closes 120 s into every 600 s cycle: first at t=120, then every 600 s.
                let due = lastHrv == nil ? t >= Int64(Cadence.ppgBurstS) : t - lastHrvT >= Int64(Cadence.hrvPeriodS)
                if due {
                    lastHrvT = t
                    let h = buildHrv(windowEndS: t)
                    lastHrv = h
                    hrvFreshPending = true
                    if emitVitals { hrv.send(h) }
                }
            }
        }
        if !logging && emitVitals {
            // Not recording yet: still give the live screen an HRV preview every 2 simulated minutes.
            previewT += Int64(speed)
            if previewT - lastPreviewHrvT >= Int64(Cadence.ppgBurstS) {
                lastPreviewHrvT = previewT
                let h = buildHrv(windowEndS: previewT)
                lastHrv = h
                hrv.send(h)
            }
        }
        batteryPct.send(scenario.battPct)
        if emitVitals {
            let t = logging ? Int64(simT) : previewT
            vitals.send(buildVitals(t))
            // FE06 rides the same tick as FE01 (ext brief §1) — the demo pod always has it.
            extVitals.send(buildExtVitals(t))
        }
    }

    // ------------------------------------------------------------------ packet builders

    private func flags(_ t: Int64) -> Int {
        var f = 0
        if ppgActive(t) { f |= PodFlags.ppgActive }
        f |= PodFlags.podDetected
        if logging { f |= PodFlags.logging }
        if timeSynced { f |= PodFlags.timeSynced }
        if scenario.battPct <= 15 { f |= PodFlags.lowBatt }
        return f
    }

    /// The real pod runs its optical sensor 2 min in every 10 to save battery. The demo pod is
    /// mains-free and exists to show data, so it keeps the optical sensor on continuously: heart
    /// rate updates every second and the first HRV window closes after 2 minutes, then every 10.
    private func ppgActive(_ t: Int64) -> Bool { true }

    private func sweatFlagNow() -> SweatFlag {
        let on = scenario.sweating
        let flag: SweatFlag
        if on && !sweatWasOn { flag = .start }
        else if on { flag = .ongoing }
        else { flag = .none }
        sweatWasOn = on
        return flag
    }

    private func buildVitals(_ t: Int64) -> LiveVitals {
        let ppg = ppgActive(t)
        // Vitals mirror the most recent epoch's sweat flag (START fires once, on the epoch it began).
        var sf = SweatFlag.none
        if let last = records.last?.sweatFlag {
            // START must fire once: after we have emitted it (and then ONGOING), keep
            // emitting ONGOING while the latest epoch's flag is still START.
            sf = (last == .start && lastSweatFlagForVitals != .none) ? .ongoing : last
        }
        lastSweatFlagForVitals = sf
        return LiveVitals(
            tS: t,
            hrBpm: ppg ? Int(scenario.hr.rounded()) : 0,
            hrQuality: ppg ? scenario.hrQuality() : 0,
            skinTempX100: Int((scenario.skinTemp * 100).rounded()),
            skinRhX100: Int((scenario.skinRh * 100).rounded()),
            ambTempX100: Int((scenario.ambTemp * 100).rounded()),
            ambRhX100: Int((scenario.ambRh * 100).rounded()),
            motionIndex: scenario.motionIndex(),
            sleepState: logging ? scenario.sleepState : .unknown,
            sweatFlag: sf,
            battPct: scenario.battPct,
            flags: flags(t)
        )
    }

    private func buildExtVitals(_ t: Int64) -> ExtendedVitals {
        ExtendedVitals(tS: t,
                       edaX100: scenario.edaX100(),
                       spo2X10: scenario.spo2X10(),
                       perfusionX100: scenario.perfusionX100(),
                       extFlags: scenario.extFlags())
    }

    private func buildRecord(_ t: Int64) -> LogRecord {
        let ppg = ppgActive(t)
        let h = lastHrv
        let fresh = hrvFreshPending
        hrvFreshPending = false
        return LogRecord(
            tS: t,
            hrBpm: ppg ? Int(scenario.hr.rounded()) : 0,
            hrQuality: ppg ? scenario.hrQuality() : 0,
            skinTempX100: Int((scenario.skinTemp * 100).rounded()),
            skinRhX100: Int((scenario.skinRh * 100).rounded()),
            ambTempX100: Int((scenario.ambTemp * 100).rounded()),
            ambRhX100: Int((scenario.ambRh * 100).rounded()),
            motionIndex: scenario.motionIndex(),
            sleepState: scenario.sleepState,
            sweatFlag: sweatFlagNow(),
            battPct: scenario.battPct,
            flags: flags(t) | (fresh ? PodFlags.hrvFresh : 0),
            dahX100: scenario.dahX100(),
            hrvMeanIbiMs: h?.meanIbiMs ?? 0,
            hrvSdnnMsX10: h?.sdnnMsX10 ?? 0,
            hrvRmssdMsX10: h?.rmssdMsX10 ?? 0,
            hrvPnn50Pct: h?.pnn50Pct ?? 0,
            hrvQuality: h?.quality ?? 0,
            hrvFlags: h?.flags ?? 0,
            vcellCv: DemoPodSource.vcellCv(battPct: scenario.battPct),
            // The demo pod writes v2 (42-byte) records — same values FE06 is notifying.
            edaX100: scenario.edaX100(),
            spo2X10: scenario.spo2X10(),
            perfusionX100: scenario.perfusionX100(),
            extFlags: scenario.extFlags()
        )
    }

    /// Fuel-gauge cell voltage: volts = 2.50 + cv/100 (spec §10); 0 means "no reading".
    static func vcellCv(battPct: Int) -> Int {
        let cv = Int(((3.3 + 0.9 * Double(battPct) / 100 - 2.5) * 100).rounded())
        return min(255, max(1, cv))
    }

    private func buildHrv(windowEndS: Int64) -> HrvSummary {
        let motionHigh = scenario.motionIndex() > 150
        let ibi = Int((60_000.0 / scenario.hr).rounded())
        let restful = scenario.sleepState != .wake
        let rmssd = min(120, max(8, scenario.gauss(restful ? 48 : 32, 6)))
        let sdnn = min(140, max(8, rmssd * 1.15 + scenario.gauss(0, 4)))
        let quality = motionHigh ? Int(30 + scenario.nextDouble() * 25) : Int(78 + scenario.nextDouble() * 20)
        var f = 0 // relative (session-start) timestamps in demo, so WALL_CLOCK is not set
        f = motionHigh ? (f | HrvFlags.motion) : (f | HrvFlags.valid)
        if !motionHigh && scenario.nextDouble() < 0.06 { f = HrvFlags.lowPerf } // occasional weak-pulse window
        return HrvSummary(
            windowEndTimeS: windowEndS,
            meanIbiMs: ibi,
            sdnnMsX10: Int((sdnn * 10).rounded()),
            rmssdMsX10: Int((rmssd * 10).rounded()),
            pnn50Pct: min(100, max(0, Int((rmssd / 2.2).rounded()))),
            beatsAccepted: motionHigh ? 40 : 110,
            beatsRejected: motionHigh ? 60 : 6,
            quality: quality,
            flags: f
        )
    }

    // ------------------------------------------------------------------ session end + slots

    private func finishSession() {
        let slot = nextSlot
        var image = Data()
        for r in records { image.append(r.encode()) }
        slots[slot] = image
        slotCounts[slot] = records.count
        lastSlot = slot
        nextSlot = (nextSlot + 1) % Cadence.nightSlots
        let s = NightAnalytics.summarize(records, slot: slot)
        summary.send(s)
        stopTicking()
        if connectionState.value.isConnected { startTicking() }
    }

    private func lastSummary() -> SessionSummary? {
        guard let image = slots[lastSlot] else {
            return logging ? NightAnalytics.summarize(records, slot: nextSlot) : nil
        }
        // Slot images are v2 (42 B) records now; derive the stride like the replay header does.
        let size = slotCounts[lastSlot] > 0 ? image.count / slotCounts[lastSlot] : LogRecord.size
        var recs: [LogRecord] = []
        var off = 0
        while off + size <= image.count {
            if let r = LogRecord.parse(image, offset: off, size: size) { recs.append(r) }
            off += size
        }
        return NightAnalytics.summarize(recs, slot: lastSlot)
    }

    // ------------------------------------------------------------------ replay

    private func startReplay(slot: Int) {
        replayGeneration += 1
        guard slot >= 0, slot < Cadence.nightSlots, let image = slots[slot] else {
            return // empty slot: no header ever arrives (spec §9 step 3)
        }
        let frames = ReplayAssembler.frames(slot: slot, recordBytes: image, recordCount: slotCounts[slot])
        emitReplayFrame(frames, index: 0, generation: replayGeneration)
    }

    private func abortReplay() {
        replayGeneration += 1
    }

    /// Streams one frame then re-arms itself 4 ms later — faster than hardware (15 ms) but
    /// still visibly progressive. A bumped generation (abort/new replay/disconnect) stops it.
    private func emitReplayFrame(_ frames: [Data], index: Int, generation: Int) {
        guard generation == replayGeneration, index < frames.count else { return }
        replayFrames.send(frames[index])
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(4)) { [weak self] in
            self?.emitReplayFrame(frames, index: index + 1, generation: generation)
        }
    }

    /// Preload a slot with a generated night so "download" works in demo.
    func installSlot(slot: Int, records: [LogRecord]) {
        guard slot >= 0, slot < Cadence.nightSlots else { return }
        var image = Data()
        for r in records { image.append(r.encode()) }
        slots[slot] = image
        slotCounts[slot] = records.count
        lastSlot = slot
        nextSlot = (slot + 1) % Cadence.nightSlots
    }
}
