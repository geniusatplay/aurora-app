// Generates whole demo nights of realistic log records — port of DemoHistory.kt.
import Foundation

/// One generated night, ready to store.
struct GeneratedNight {
    var startedAt: Date
    var records: [LogRecord]
    /// (t_s since session start, mode) activity markers, in order.
    var events: [(Int64, DemoMode)]
}

/// Generates whole nights of realistic records by scripting the same DemoScenario model:
/// fall asleep → cycles → 2–7 flashes/sweats scattered through the night → wake.
enum DemoHistory {

    static func generateNight(startedAt: Date, seed: UInt64, intensity: Double = 0.5) -> GeneratedNight {
        var rnd = SplitMix64(seed: seed)
        let scenario = DemoScenario(seed: seed)
        scenario.sweatGain = 0.7 + rnd.nextDouble() * 0.6 + intensity * 0.3
        let lengthS = Int((6.4 + rnd.nextDouble() * 1.9) * 3600)   // 6.4–8.3 h
        let nEvents = min(6, max(1, 1 + Int((intensity * 5 * (0.5 + rnd.nextDouble() * 0.8)).rounded())))

        // Schedule events at least 40 min apart, mostly in the second half of the night.
        var eventStarts: [Int] = []
        var attempts = 0
        while eventStarts.count < nEvents && attempts < 200 {
            attempts += 1
            let t = Int(1800 + rnd.nextDouble() * Double(lengthS - 3600)) / Cadence.epochS * Cadence.epochS
            if eventStarts.allSatisfy({ abs($0 - t) > 2400 }) { eventStarts.append(t) }
        }
        eventStarts.sort()
        let eventKinds: [DemoMode] = eventStarts.map { _ in rnd.nextDouble() < 0.45 ? .nightSweats : .nightFlash }

        var records: [LogRecord] = []
        records.reserveCapacity(lengthS / Cadence.epochS)
        var events: [(Int64, DemoMode)] = []
        scenario.setMode(.up)
        var sweatWasOn = false
        var lastHrvT: Int64 = -1
        var hrvFresh = false
        var hrv: (ibi: Int, sdnnX10: Int, rmssdX10: Int)? = nil
        var hrvFlags = 0
        var hrvQ = 0
        var mode = DemoMode.up
        var modeEndsAt = 0

        // Warm-up: model settles for 5 min before "session start".
        for _ in 0..<60 { scenario.step(5) }
        scenario.setMode(.sleeping)
        mode = .sleeping
        events.append((0, .sleeping))

        var t = 0
        while t < lengthS {
            // Enter / leave events
            if let idx = eventStarts.firstIndex(of: t) {
                mode = eventKinds[idx]
                scenario.setMode(mode)
                modeEndsAt = t + (mode == .nightSweats ? 900 + rnd.nextInt(300) : 420 + rnd.nextInt(180))
                events.append((Int64(t), mode))
            } else if mode != .sleeping && t >= modeEndsAt {
                mode = .sleeping
                scenario.setMode(mode)
                events.append((Int64(t), .sleeping))
            }

            for _ in 0..<(Cadence.epochS / 5) { scenario.step(5) }
            t += Cadence.epochS

            // History mimics the REAL duty cycle (unlike the live demo pod): PPG runs the
            // first 2 min of every 10-min cycle and the HRV window closes as the burst ends.
            let cycle = t % Cadence.hrvPeriodS
            let ppg = cycle < Cadence.ppgBurstS
            if cycle >= Cadence.ppgBurstS && Int64(t / Cadence.hrvPeriodS) != lastHrvT {
                lastHrvT = Int64(t / Cadence.hrvPeriodS)
                let motionHigh = scenario.motionIndex() > 150
                let rmssd = min(120, max(8, scenario.gauss(scenario.sleepState == .deep ? 52 : 40, 7)))
                let sdnn = min(140, max(8, rmssd * 1.15 + scenario.gauss(0, 4)))
                hrv = (ibi: Int((60_000.0 / scenario.hr).rounded()),
                       sdnnX10: Int((sdnn * 10).rounded()),
                       rmssdX10: Int((rmssd * 10).rounded()))
                hrvFlags = motionHigh ? HrvFlags.motion : (rnd.nextDouble() < 0.05 ? HrvFlags.lowPerf : HrvFlags.valid)
                hrvQ = HrvFlags.has(hrvFlags, HrvFlags.valid) ? 75 + rnd.nextInt(24) : 25 + rnd.nextInt(30)
                hrvFresh = true
            }

            let on = scenario.sweating
            let sf: SweatFlag = (on && !sweatWasOn) ? .start : (on ? .ongoing : .none)
            sweatWasOn = on

            var flags = PodFlags.podDetected | PodFlags.logging | PodFlags.timeSynced
            if ppg { flags |= PodFlags.ppgActive }
            if hrvFresh { flags |= PodFlags.hrvFresh; hrvFresh = false }

            records.append(LogRecord(
                tS: Int64(t),
                hrBpm: ppg ? Int(scenario.hr.rounded()) : 0,
                hrQuality: ppg ? scenario.hrQuality() : 0,
                skinTempX100: Int((scenario.skinTemp * 100).rounded()),
                skinRhX100: Int((scenario.skinRh * 100).rounded()),
                ambTempX100: Int((scenario.ambTemp * 100).rounded()),
                ambRhX100: Int((scenario.ambRh * 100).rounded()),
                motionIndex: scenario.motionIndex(),
                sleepState: scenario.sleepState,
                sweatFlag: sf,
                battPct: scenario.battPct,
                flags: flags,
                dahX100: scenario.dahX100(),
                hrvMeanIbiMs: hrv?.ibi ?? 0,
                hrvSdnnMsX10: hrv?.sdnnX10 ?? 0,
                hrvRmssdMsX10: hrv?.rmssdX10 ?? 0,
                hrvPnn50Pct: hrv.map { min(100, max(0, $0.rmssdX10 / 22)) } ?? 0,
                hrvQuality: hrvQ,
                hrvFlags: hrvFlags,
                vcellCv: DemoPodSource.vcellCv(battPct: scenario.battPct)
            ))
        }
        events.append((Int64(lengthS), .up))
        return GeneratedNight(startedAt: startedAt, records: records, events: events)
    }

    /// 14 nights ending last night, bedtime ~22:30–23:45 local, with a gentle downward trend in intensity.
    static func generateHistory(now: Date = Date(), nights: Int = 14, seed: UInt64 = 42) -> [GeneratedNight] {
        var rnd = SplitMix64(seed: seed)
        let cal = Calendar.current
        // Last night = yesterday 23:00 local.
        let startOfToday = cal.startOfDay(for: now)
        let yesterday = cal.date(byAdding: .day, value: -1, to: startOfToday) ?? startOfToday.addingTimeInterval(-86_400)
        let lastBed = cal.date(bySettingHour: 23, minute: 0, second: 0, of: yesterday) ?? yesterday.addingTimeInterval(23 * 3600)
        return (0..<nights).map { i in
            let bed = lastBed.addingTimeInterval(
                Double(-(nights - 1 - i)) * 86_400 + Double(rnd.nextInt(from: -30, until: 45)) * 60
            )
            let intensity = min(1, max(0.15, 0.75 - 0.35 * Double(i) / Double(nights) + rnd.nextDouble() * 0.3))
            return generateNight(startedAt: bed, seed: seed &+ UInt64(i) &* 7919, intensity: intensity)
        }
    }

    /// Convenience for tests / previews.
    static func summaryOf(_ night: GeneratedNight) -> SessionSummary {
        NightAnalytics.summarize(night.records)
    }
}
