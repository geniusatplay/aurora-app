# Aurora for iPhone (SwiftUI)

Native iOS port of the Aurora menopause sleep-monitoring app: Swift 5.9, SwiftUI, Swift Charts,
SwiftData, CoreBluetooth. Same features as the Android app — pink/light/high-contrast/dark themes,
English/Spanish/Vietnamese, Low/Medium/High guides, the Demo button with six activity modes,
continuous demo heart rate, and the full pod protocol (time-sync-first, CRC-checked replay,
HRV validity gating). Demo sign-in: `aurorademo@gmail.com` / `pswd`. iOS 17.0+.

> **Status: BUILT AND GREEN.** This project compiles — it was built on GitHub's cloud Macs
> from the repo `github.com/geniusatplay/aurora-app` (public), and the compiled unsigned app
> is saved as `Aurora-unsigned.ipa` next to this folder. To install it on an iPhone from
> Windows: install Sideloadly (https://sideloadly.io) + iTunes (non-Store build), plug the
> iPhone in, drag the IPA into Sideloadly, enter your Apple ID, Start, then trust the
> certificate in Settings ▸ General ▸ VPN & Device Management. Free-Apple-ID installs last
> 7 days; re-run Sideloadly to renew. To rebuild after code changes: re-zip the AuroraiOS
> folder, replace `AuroraiOS.zip` in the repo (web upload), and the build reruns itself.

## The hard rule Apple sets

iPhone apps can only be compiled and signed by Xcode on macOS. From a Windows-only setup you
cannot build this locally — but you CAN build it on a free cloud Mac and install the result
from Windows. That's the path below.

## Path A — no Mac (your setup): GitHub Actions + Sideloadly

**One-time setup (~20 minutes):**

1. Create a free account at https://github.com and create a new **private** repository
   (name it e.g. `aurora-app`).
2. Install Git for Windows (https://git-scm.com) if you don't have it, then in
   `D:\Claude Design\Aurora App` run:
   ```
   git init
   git add AuroraiOS
   git commit -m "Aurora iOS"
   git branch -M main
   git remote add origin https://github.com/<your-username>/aurora-app.git
   git push -u origin main
   ```
   (GitHub's web UI "upload files" also works: upload the whole `AuroraiOS` folder.)
3. On github.com open your repo → **Actions** tab → the "Build Aurora iOS" workflow runs
   automatically (or press **Run workflow**). First run takes ~10–15 min on Apple's side.
4. When it's green, open the run → **Artifacts** → download **Aurora-unsigned-ipa** →
   unzip it to get `Aurora-unsigned.ipa`.
   If the run is red: open the failed step, copy the error text, paste it to me — I'll fix
   the code and you push again.
5. On Windows install **Sideloadly** (https://sideloadly.io) and **iTunes** (the non-Microsoft-Store
   build Sideloadly's site links to, for the iPhone driver).
6. Plug in your iPhone (tap **Trust** on the phone), open Sideloadly, drag
   `Aurora-unsigned.ipa` in, enter your Apple ID, press **Start**. Sideloadly signs the app
   with a free personal certificate and installs it.
7. On the iPhone: **Settings ▸ General ▸ VPN & Device Management** → trust your developer
   certificate. Launch Aurora.

**Living with a free Apple ID:** apps signed this way run for **7 days**, then the icon greys
out — just re-run Sideloadly (same IPA, 2 minutes) to re-sign. A paid Apple Developer account
($99/yr) extends this to 1 year and unlocks TestFlight.

## Path B — with a Mac

```
brew install xcodegen
cd AuroraiOS
xcodegen                # generates Aurora.xcodeproj from project.yml
open Aurora.xcodeproj
```
Set your Team under Signing & Capabilities, plug in the iPhone, press Run. Free Apple ID = 7-day
installs; developer account = 1 year + TestFlight.

## Project layout

```
AuroraiOS/
├── project.yml                 XcodeGen definition (no .xcodeproj is checked in)
├── Sources/
│   ├── App/                    entry point, settings store, L10n, formatting
│   ├── Protocol/               BLE packets, CRC-16, commands, replay assembler (ported 1:1)
│   ├── Domain/                 night analytics (ΔAH physics, sweat spans), L/M/H ranges
│   ├── Pod/                    PodSource protocol · CoreBluetooth source · demo simulator ·
│   │                           connection manager (time-sync-first, replay, epoch aggregation)
│   ├── Data/                   SwiftData models + repositories (local accounts, sessions)
│   └── UI/                     theme, components, Swift Charts panels, all screens
├── Resources/{en,es,vi}.lproj/ 441 localized strings per language
├── Tests/                      the 9 protocol tests (same vectors as Android)
└── .github/workflows/ios.yml   cloud-Mac build → unsigned IPA artifact
```

## iOS-specific notes

* Bluetooth permission is requested by iOS automatically on first use
  (`NSBluetoothAlwaysUsageDescription` is set); the `bluetooth-central` background mode keeps
  a night download alive when the screen locks — no foreground service needed.
* Charts use Apple's Swift Charts; storage is SwiftData; there are **zero third-party
  dependencies**, which keeps the cloud build simple and fast.
* CSV share uses the system share sheet (ShareLink).
* Everything stays on-device, same as Android; the server seam is Android-side for now.
