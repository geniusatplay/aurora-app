import XCTest
@testable import Aurora

/// Hardware protocol v1 (hw/PROTOCOL.txt, verified on hardware). Port of Android's
/// HwProtocolTest.kt. The hex vectors were produced by the web app's encoder, which agrees
/// field-for-field with the bridge's reference decoder pod_agent.py on 1600 fuzzed packets —
/// so these pin all four implementations (web, bridge, Android, iOS).
final class HwProtocolTests: XCTestCase {

    // MARK: - helpers

    private func hex(_ s: String) -> Data {
        var out = Data()
        var i = s.startIndex
        while i < s.endIndex {
            let j = s.index(i, offsetBy: 2)
            out.append(UInt8(String(s[i..<j]), radix: 16)!)
            i = j
        }
        return out
    }

    private func toHex(_ d: Data) -> String {
        d.map { String(format: "%02x", $0) }.joined()
    }

    private func vit(_ seq: Int, _ up: Int64, _ flags: Int, ah: Int = 1450, hr: Int? = 700,
                     spo2: Int? = 97, q: Int = 60, skin: Int? = 3300) -> Data {
        HwVitals(seq: seq, uptimeS: up, skinTempX100: skin, skinRhX100: 5500, absHumX100: ah,
                 hrX10: hr, spo2Pct: spo2, quality: q, flags: flags, battPct: nil).encode()
    }

    private func hwSession(_ start: Int64?, _ dur: Int64, _ flush: Int, _ peak: Int, _ mean: Int,
                           _ score: Int, _ batt: Int?, _ recs: Int) -> HwSession {
        HwSession(startEpoch: start, durationS: dur, flushEvents: flush, peakAbsHumX100: peak,
                  meanSkinTempX100: mean, score: score, battPct: batt, logRecords: recs)
    }

    private func hwRecord(_ seq: Int, _ up: Int64, _ skin: Int?, _ rh: Int, _ ah: Int, _ hr: Int?,
                          _ spo2: Int?, _ q: Int, _ flags: Int, _ batt: Int?) -> HwRecord {
        HwRecord(seq: seq, uptimeS: up, skinTempX100: skin, skinRhX100: rh, absHumX100: ah,
                 hrX10: hr, spo2Pct: spo2, quality: q, flags: flags, battPct: batt)
    }

    private func writeBytes(_ p: HwAdapter.Plan) -> [UInt8]? {
        if case .write(let d, _) = p { return [UInt8](d) }
        return nil
    }

    // MARK: - wire format

    func testTimeSyncMatchesSpecWorkedExample() throws {
        // PROTOCOL §6: epoch 1786579200 → 03 00 09 7D 6A
        XCTAssertEqual(toHex(HwOp.timeSync(1_786_579_200)), "0300097d6a")
        XCTAssertEqual(try toHex(HwOp.setPeriod(30)), "061e")
        XCTAssertThrowsError(try HwOp.setPeriod(0))
        XCTAssertThrowsError(try HwOp.setPeriod(241))
    }

    func testVitalsReferenceRowFromTheLiveRun() throws {
        let v = try HwVitals.parse(hex("a10364000000050ab317a905d902642833ffdb36"))
        XCTAssertEqual(v.seq, 3); XCTAssertEqual(v.uptimeS, 100)
        XCTAssertEqual(v.skinTempX100, 2565); XCTAssertEqual(v.skinRhX100, 6067); XCTAssertEqual(v.absHumX100, 1449)
        XCTAssertEqual(v.hrX10, 729); XCTAssertEqual(v.spo2Pct, 100); XCTAssertEqual(v.quality, 40); XCTAssertEqual(v.flags, 51)
        XCTAssertNil(v.battPct, "0xFF battery = unknown")
        XCTAssertTrue(v.finger && v.sessionActive && v.hrLocked && v.timeValid && !v.flushActive)
        XCTAssertEqual(v.hrShowBpm!, 72.9, accuracy: 0.001)
        XCTAssertEqual(v.spo2Show, 100)
    }

    func testSentinelsDecodeAsAbsentNeverZero() throws {
        let v = try HwVitals.parse(hex("a1ff00286bee008000000000ffffff00204dbd87"))
        XCTAssertEqual(v.uptimeS, 4_000_000_000) // u32 above Int32.max
        XCTAssertNil(v.skinTempX100); XCTAssertNil(v.hrX10); XCTAssertNil(v.spo2Pct); XCTAssertNil(v.hrShowBpm)
        XCTAssertEqual(v.battPct, 77)
        let w = try HwVitals.parse(hex("a10934050000f3fd17189b05ffff622701ff71db"))
        XCTAssertEqual(w.skinTempX100, -525)
        XCTAssertEqual(w.spo2Pct, 98)
        XCTAssertNil(w.spo2Show, "quality 39 < 40 → SpO2 hidden")
        XCTAssertNil(w.hrShowBpm, "no HR_LOCKED → no HR")
    }

    func testCorruptedPacketsAreRejected() {
        var b = hex("a10364000000050ab317a905d902642833ffdb36")
        b[7] ^= 0x10
        XCTAssertThrowsError(try HwVitals.parse(b))
        XCTAssertThrowsError(try HwVitals.parse(hex("a2" + String(repeating: "00", count: 19))), "wrong header")
        XCTAssertThrowsError(try HwVitals.parse(Data(count: 19)), "wrong length")
    }

    func testHrvSessionReplayReferenceVectors() throws {
        let h = try HwHrv.parse(hex("a596000000720353049c03402d619e"))
        XCTAssertEqual(h.uptimeS, 150); XCTAssertEqual(h.meanRrMs, 882); XCTAssertEqual(h.sdnnX10, 1107)
        XCTAssertEqual(h.rmssdX10, 924); XCTAssertEqual(h.beats, 64); XCTAssertEqual(h.quality, 45); XCTAssertTrue(h.usable)
        let s = try HwSession.parse(hex("a26bbbb96a3c0000000000ad05cd0964ff02dfb8"))
        XCTAssertEqual(s.startEpoch, 1_790_557_035); XCTAssertEqual(s.durationS, 60); XCTAssertEqual(s.peakAbsHumX100, 1453)
        XCTAssertEqual(s.meanSkinTempX100, 2509); XCTAssertEqual(s.score, 100); XCTAssertNil(s.battPct); XCTAssertEqual(s.logRecords, 2)
        let r = try HwRecord.parseFrame(hex("0700100e0000c20bae1554066402614236ffd046"))
        XCTAssertEqual(r.seq, 7); XCTAssertEqual(r.uptimeS, 3600); XCTAssertEqual(r.skinTempX100, 3010); XCTAssertEqual(r.hrX10, 612)
        XCTAssertEqual(r.flags, 0x36)
        var bad = hex("0700100e0000c20bae1554066402614236ffd046")
        bad[5] = 1
        XCTAssertThrowsError(try HwRecord.parseFrame(bad))
    }

    func testEncodersRoundTrip() throws {
        let v = HwVitals(seq: 200, uptimeS: 12345, skinTempX100: nil, skinRhX100: 5000, absHumX100: 1500,
                         hrX10: nil, spo2Pct: nil, quality: 12, flags: 0x20, battPct: nil)
        XCTAssertEqual(try HwVitals.parse(v.encode()), v)
        let s = hwSession(nil, 5, 1, 1800, -120, 0, nil, 255)
        XCTAssertEqual(try HwSession.parse(s.encode()), s)
        let r = hwRecord(479, 99999, -1, 1, 2, 655, 95, 80, 0x3F, 50)
        XCTAssertEqual(try HwRecord.parseFrame(r.encodeFrame()), r)
        let h = HwHrv(uptimeS: 4_000_000_000, meanRrMs: 882, sdnnX10: 1107, rmssdX10: 924, beats: 64, quality: 45)
        XCTAssertEqual(try HwHrv.parse(h.encode()), h)
    }

    /// Data slices keep their parent's indices; the parsers must not care.
    func testParsersAcceptDataSlices() throws {
        let padded = hex("ffff" + "a10364000000050ab317a905d902642833ffdb36")
        let slice = padded[2..<22]
        XCTAssertEqual(try HwVitals.parse(slice).uptimeS, 100)
        let paddedFrame = hex("00" + "0700100e0000c20bae1554066402614236ffd046")
        XCTAssertEqual(try HwRecord.parseFrame(paddedFrame[1..<21]).seq, 7)
    }

    // MARK: - adapter

    func testAdapterMapsHonestlyAndPinsSessionTime() throws {
        var now: Int64 = 1_790_000_000
        let a = HwAdapter(nowEpochS: { now })
        let idle = try a.onVitals(vit(1, 500, HwFlags.timeValid | HwFlags.finger, hr: 700))
        XCTAssertEqual(idle.vitals.hrBpm, 0, "no HR_LOCKED → 0 (internal 'no reading')")
        XCTAssertFalse(idle.vitals.logging); XCTAssertTrue(idle.vitals.timeSynced); XCTAssertTrue(idle.vitals.ppgActive)
        XCTAssertEqual(idle.vitals.tS, 500)
        XCTAssertNil(idle.batteryPct)
        XCTAssertFalse(HwAdapter.hasAmbient(idle.vitals.ambTempX100))
        XCTAssertEqual(a.epochOffsetS, Int64(1_790_000_000 - 500))

        now += 1
        let s0 = try a.onVitals(vit(2, 501, HwFlags.timeValid | HwFlags.finger | HwFlags.hrLocked | HwFlags.sessionActive))
        XCTAssertTrue(s0.vitals.logging); XCTAssertEqual(s0.vitals.tS, 0); XCTAssertEqual(s0.vitals.hrBpm, 70)
        XCTAssertTrue(s0.ext.spo2Valid); XCTAssertEqual(s0.ext.spo2X10, 970)
        let s1 = try a.onVitals(vit(3, 531, HwFlags.sessionActive | HwFlags.hrLocked, q: 30))
        XCTAssertEqual(s1.vitals.tS, 30)
        XCTAssertFalse(s1.ext.spo2Valid, "quality 30 → SpO2 not valid")
        XCTAssertEqual(s1.vitals.absHumX100, 1450)

        // flush edges → internal sweat flag
        let f1 = try a.onVitals(vit(4, 532, HwFlags.sessionActive | HwFlags.flushActive, ah: 1750))
        XCTAssertEqual(f1.vitals.sweatFlag, .start); XCTAssertTrue(f1.vitals.dahDirectX100! > 250)
        let f2 = try a.onVitals(vit(5, 533, HwFlags.sessionActive | HwFlags.flushActive, ah: 1760))
        XCTAssertEqual(f2.vitals.sweatFlag, .ongoing)
        let f3 = try a.onVitals(vit(6, 534, HwFlags.sessionActive, ah: 1460))
        XCTAssertEqual(f3.vitals.sweatFlag, SweatFlag.none)

        let sum = try a.onSession(hwSession(1_790_000_001, 33, 1, 1760, 3300, 100, nil, 2).encode())
        XCTAssertEqual(sum.sessionLenS, 33); XCTAssertEqual(sum.sweatEvents, 1); XCTAssertEqual(sum.hrMeanBpm, 70)
        XCTAssertTrue(sum.peakDahX100 > 250); XCTAssertEqual(sum.pctDeep + sum.pctLight + sum.pctWake, 0)
    }

    func testJoiningARunningSessionUsesFe02RunningDuration() throws {
        let a = HwAdapter(nowEpochS: { 2_000_000_000 })
        let first = try a.onVitals(vit(1, 10_000, HwFlags.sessionActive | HwFlags.timeValid))
        // Start unknown yet → LOGGING withheld so nothing is stored at a wrong session time.
        XCTAssertFalse(first.vitals.logging); XCTAssertTrue(a.needsSessionPin)
        // FE02 read after connecting: session has been running 3600 s
        _ = try a.onSession(hwSession(1_999_996_400, 3600, 0, 1500, 3300, 0, nil, 60).encode())
        let v = try a.onVitals(vit(2, 10_001, HwFlags.sessionActive | HwFlags.timeValid))
        XCTAssertEqual(v.vitals.tS, 3601); XCTAssertTrue(v.vitals.logging); XCTAssertFalse(a.needsSessionPin)
        let h = try a.onHrv(HwHrv(uptimeS: 10_001, meanRrMs: 900, sdnnX10: 500, rmssdX10: 400, beats: 12, quality: 70).encode())
        XCTAssertEqual(h.windowEndTimeS, 3601); XCTAssertTrue(h.isValid)
        XCTAssertFalse(try a.onHrv(HwHrv(uptimeS: 10_002, meanRrMs: 900, sdnnX10: 500, rmssdX10: 400, beats: 4, quality: 70).encode()).isValid)
    }

    func testReplayKeepsTheSessionWindowAndFillsThe30sGrid() throws {
        let now: Int64 = 1_800_000_000
        let a = HwAdapter(nowEpochS: { now })
        _ = try a.onVitals(vit(1, 20_000, HwFlags.timeValid))              // offset = now − 20000
        let start: Int64 = 20_000 - 3000                                   // session started 3000 s ago
        _ = try a.onSession(hwSession(now - 3000, 600, 0, 1500, 3300, 0, nil, 30).encode())
        a.beginReplay()
        // 30 rows at 60 s: 10 before the session, 11 inside (0..600 s), 9 after
        var seq = 0
        for k in -10..<20 {
            let up = start + Int64(k) * 60
            let inside = k >= 0 && k <= 10
            let flags = HwFlags.timeValid | (inside ? (HwFlags.sessionActive | HwFlags.hrLocked) : 0)
            let rec = hwRecord(seq, up, 3300, 5500, 1500 + (k == 5 ? 300 : 0), 650, 97, 70,
                               flags | (k == 5 ? HwFlags.flushActive : 0), nil)
            seq += 1
            XCTAssertTrue(a.onReplayFrame(rec.encodeFrame()))
        }
        var bad = hwRecord(seq, start, 1, 1, 1, 1, 1, 1, 1, 1).encodeFrame()
        bad[10] = 0x55
        XCTAssertFalse(a.onReplayFrame(bad))
        let res = a.finishReplay()
        XCTAssertEqual(res.framesReceived, 30); XCTAssertEqual(res.crcFailures, 1)
        XCTAssertEqual(res.sessionRows, 11)
        // 11 rows at 60 s → 0..600 s held onto 30 s epochs = 21 or 22 epochs, starting at 0
        XCTAssertEqual(res.records.first?.tS, 0)
        XCTAssertTrue(res.records.count >= 21 && res.records.count <= 22)
        for i in 1..<res.records.count {
            XCTAssertEqual(res.records[i].tS - res.records[i - 1].tS, 30)
        }
        XCTAssertTrue(res.records.allSatisfy { $0.hrBpm == 65 && $0.hasExt && $0.spo2Pct == 97 && $0.edaUs == nil })
        let at300 = res.records.first { $0.tS == 300 }
        XCTAssertEqual(at300?.sweatFlag, .start)
        XCTAssertTrue((at300?.dahX100 ?? 0) >= 250)

        // round-trip through the internal replay path the manager uses
        let frames = a.internalFrames(res.records)
        let asm = ReplayAssembler()
        var result: ReplayAssembler.Result? = nil
        for f in frames {
            if case .finished(let r) = asm.feed(f) { result = r }
        }
        XCTAssertNotNil(result)
        guard let result else { return }
        XCTAssertTrue(result.complete)
        XCTAssertEqual(result.header.recordSize, 42)
        XCTAssertEqual(result.records, res.records)
    }

    func testReplayWithoutClockFallsBackToLastSessionRun() throws {
        let a = HwAdapter(nowEpochS: { 1_000 })
        _ = try a.onVitals(vit(1, 900, 0))
        _ = try a.onSession(hwSession(nil, 120, 0, 1500, 3300, 0, nil, 5).encode())
        a.beginReplay()
        let flagsList = [0, 0, HwFlags.sessionActive, HwFlags.sessionActive, HwFlags.sessionActive]
        for (i, f) in flagsList.enumerated() {
            a.onReplayFrame(hwRecord(i, 600 + Int64(i) * 60, 3300, 5500, 1500, nil, nil, 0, f, nil).encodeFrame())
        }
        let res = a.finishReplay()
        XCTAssertEqual(res.sessionRows, 3); XCTAssertEqual(res.records.first?.tS, 0)
        XCTAssertTrue(res.records.allSatisfy { $0.hrBpm == 0 && $0.spo2Pct == nil }, "no lock → hr 0")
    }

    func testCommandsTranslateToHardwareOpcodes() {
        let a = HwAdapter()
        XCTAssertEqual(writeBytes(a.plan(.startSession)), [0x01])
        XCTAssertEqual(writeBytes(a.plan(.stopSession)), [0x02])
        XCTAssertEqual(writeBytes(a.plan(.timeSync(unixSeconds: 1_786_579_200))), [0x03, 0x00, 0x09, 0x7D, 0x6A])
        // The paper spec's 0x04 was "haptic"; on hardware 0x04 is REPLAY — must map to identify.
        XCTAssertEqual(writeBytes(a.plan(.hapticTest(millis: 250))), [0x07])
        XCTAssertEqual(writeBytes(a.plan(.formatFlash)), [0x05])
        XCTAssertEqual(a.plan(.replaySlot(3)), .replay)
        XCTAssertEqual(a.plan(.pushSummary), .readSummary)
        XCTAssertEqual(a.plan(.fuelGaugeRelearn), .unsupported)
        XCTAssertEqual(a.plan(.abortReplay), .unsupported)
    }

    // MARK: - REAL pod packets
    // Captured from the glove over Web Bluetooth on 2026-09-28 (hardware check: 11/11 pass,
    // 76 packets, 0 CRC failures, all re-decoded by pod_agent.py with 0 mismatches).

    func testRealPodPacketsDecode() throws {
        let v = try HwVitals.parse(hex("a130ae030000ed096718c0057c02632833ff1179"))
        XCTAssertEqual(v.seq, 48); XCTAssertEqual(v.uptimeS, 942); XCTAssertEqual(v.skinTempX100, 2541)
        XCTAssertEqual(v.skinRhX100, 6247); XCTAssertEqual(v.absHumX100, 1472); XCTAssertEqual(v.hrX10, 636)
        XCTAssertEqual(v.spo2Pct, 99); XCTAssertEqual(v.quality, 40); XCTAssertEqual(v.flags, 51); XCTAssertNil(v.battPct)
        let h = try HwHrv.parse(hex("a5b6030000a30356039004402bbc77"))
        XCTAssertEqual(h.uptimeS, 950); XCTAssertEqual(h.meanRrMs, 931); XCTAssertEqual(h.sdnnX10, 854); XCTAssertEqual(h.rmssdX10, 1168)
        let s = try HwSession.parse(hex("a2b7beb96a290000000000e405f00964ff1809fc"))
        XCTAssertEqual(s.startEpoch, 1_790_557_879); XCTAssertEqual(s.durationS, 41); XCTAssertEqual(s.peakAbsHumX100, 1508)
        XCTAssertEqual(s.meanSkinTempX100, 2544); XCTAssertEqual(s.logRecords, 24); XCTAssertNil(s.battPct)
        let r = try HwRecord.parseFrame(hex("00003c000000cd095418a105ffffff0000ff0a54"))
        XCTAssertEqual(r.seq, 0); XCTAssertEqual(r.uptimeS, 60); XCTAssertNil(r.hrX10); XCTAssertNil(r.spo2Pct)
    }

    func testRealPodReplayIsWindowedToTheSession() throws {
        let a = HwAdapter(nowEpochS: { 1_790_557_924 })
        _ = try a.onVitals(hex("a15cda030000f109f818e505b702622831ffc6c9"))   // uptime 986 → offset
        _ = try a.onSession(hex("a2b7beb96a290000000000e405f00964ff1809fc"))  // 41 s session, 24 records
        a.beginReplay()
        let frames = [
            "00003c000000cd095418a105ffffff0000ff0a54",
            "010078000000cb097d18a905ffffff0022ff9331",
            "0200b4000000cf096018a605ffffff0020ff448a",
            "0300f0000000cd096018a405ffffff0020fff20f",
            "04002c010000ca096218a205ffffff0020ff00c1",
            "050068010000ce095618a305ffffff0020ff5387",
            "0600a4010000d0093a189d05ffffff0020ff3fc1",
            "0700e0010000d0095c18a505ffffff0020ff6bad",
            "08001c020000d0096f18aa05ffffff0020ffc8fb",
            "090058020000d2095318a505ffffff2821ffa97e",
            "0a0094020000d5094a18a505ffffff0020ff22ce",
            "0b00d0020000d6094618a505ffffff0020ff3920",
            "0c000c030000d6093918a2056102622831fffe46",
            "0d0048030000df09bc18c8058902632831ff9798",
            "0e0084030000ee096f18c2057c02632831ffaa27",
            "0f00ad030000ed096718c0057c02642831ff4049",
            "1000b2030000ef096318c0057c02632b33ff90d6",
            "1100b7030000ee097718c4057c02623533ff0be5",
            "1200bc030000f0097218c5058902633533ffaf1a",
            "1300c1030000f209c118d9059702633533ff4482",
            "1400c6030000f009d218db05a702633533ff4269",
            "1500cb030000f109ea18e205b602623533ffd182",
            "1600d0030000f009ec18e105b702643533ff9582",
            "1700d5030000f109ee18e305b702633533ff17a9"
        ]
        for f in frames { XCTAssertTrue(a.onReplayFrame(hex(f))) }
        let res = a.finishReplay()
        XCTAssertEqual(res.framesReceived, 24); XCTAssertEqual(res.crcFailures, 0); XCTAssertEqual(res.missing, 0)
        XCTAssertEqual(res.sessionRows, 8, "rows 16..23 carry SESSION_ACTIVE inside the window")
        XCTAssertEqual(res.records.map { $0.tS }, [0, 30])
        XCTAssertTrue(res.records.allSatisfy {
            $0.hrBpm >= 60 && $0.hrBpm <= 70 && $0.spo2Pct != nil && !HwAdapter.hasAmbient($0.ambTempX100)
        })
    }

    func testStoredDahNeverWrapsBelowZero() throws {
        let a = HwAdapter(nowEpochS: { 1_000_000 })
        _ = try a.onVitals(vit(1, 1000, HwFlags.timeValid))
        _ = try a.onSession(hwSession(1_000_000 - 900, 300, 0, 1500, 3300, 0, nil, 10).encode())
        a.beginReplay()
        // humidity falls below its starting baseline — must store 0, not wrap to ~655 g/m³
        for (i, ah) in [1600, 1500, 1400, 1300].enumerated() {
            a.onReplayFrame(hwRecord(i, 100 + Int64(i) * 60, 3300, 5500, ah, nil, nil, 0, HwFlags.sessionActive, nil).encodeFrame())
        }
        let res = a.finishReplay()
        XCTAssertFalse(res.records.isEmpty)
        let frames = a.internalFrames(res.records)
        let asm = ReplayAssembler()
        var out: ReplayAssembler.Result? = nil
        for f in frames {
            if case .finished(let r) = asm.feed(f) { out = r }
        }
        XCTAssertNotNil(out)
        XCTAssertTrue((out?.records ?? []).allSatisfy { $0.dahX100 >= 0 && $0.dahX100 <= 500 })
    }

    // MARK: - capabilities

    func testCapabilityPresetsMatchAndroid() {
        XCTAssertTrue(PodCapabilities.demo.skinConductance && PodCapabilities.demo.roomClimate && PodCapabilities.demo.battery)
        XCTAssertFalse(PodCapabilities.demo.continuousPpg || PodCapabilities.demo.directAbsHumidity || PodCapabilities.demo.hrvRelativeOnly)
        let hw = PodCapabilities.hardwareV1
        XCTAssertTrue(hw.spo2Estimate && hw.continuousPpg && hw.directAbsHumidity && hw.hrvRelativeOnly)
        XCTAssertFalse(hw.skinConductance || hw.bloodFlow || hw.roomClimate || hw.movement || hw.sleepStaging || hw.battery)
        XCTAssertNotEqual(PodCapabilities.none, hw)
        XCTAssertFalse(PodCapabilities.none.spo2Estimate)
    }
}
