import XCTest
@testable import Aurora

final class ProtocolTests: XCTestCase {

    func testCrc16CcittFalseKnownVector() {
        // Standard check value for CRC-16/CCITT-FALSE over "123456789" is 0x29B1.
        XCTAssertEqual(Crc16.ccittFalse(Data("123456789".utf8)), 0x29B1)
    }

    func testTimeSyncCommandMatchesSpecExample() {
        // Spec §6 example bytes "03 00 6E 8D 6A" decode (LE) to 1787653632.
        let bytes = PodCommand.timeSync(unixSeconds: 1_787_653_632).encode()
        XCTAssertEqual([UInt8](bytes), [0x03, 0x00, 0x6E, 0x8D, 0x6A])
    }

    func testHapticReplayFormatMatchSpecExamples() {
        XCTAssertEqual([UInt8](PodCommand.hapticTest(millis: 250).encode()), [0x04, 0xFA, 0x00])
        XCTAssertEqual([UInt8](PodCommand.replaySlot(3).encode()), [0x06, 0x03])
        XCTAssertEqual([UInt8](PodCommand.formatFlash.encode()), [0x08, 0xA5, 0x5A])
    }

    func testLiveVitalsRoundTripSignedTemperature() {
        let v = LiveVitals(
            tS: 3600, hrBpm: 64, hrQuality: 88, skinTempX100: -150, skinRhX100: 6250,
            ambTempX100: 2105, ambRhX100: 4400, motionIndex: 12, sleepState: .deep,
            sweatFlag: .start, battPct: 77, flags: PodFlags.logging | PodFlags.timeSynced
        )
        let parsed = LiveVitals.parse(v.encode())
        XCTAssertEqual(parsed, v)
        XCTAssertEqual(parsed!.skinTempC, -1.5, accuracy: 0.001)
        XCTAssertTrue(parsed!.logging && parsed!.timeSynced)
    }

    func testLogRecordCrcVerifiedAndCorruptionDropped() {
        let rec = sampleRecord(tS: 30)
        var bytes = rec.encode()
        XCTAssertEqual(bytes.count, 34)
        XCTAssertNotNil(LogRecord.parse(bytes))
        bytes[7] ^= 0x10 // flip a temperature bit
        XCTAssertNil(LogRecord.parse(bytes), "corrupted record must be dropped")
    }

    func testHrvGateOnlyValidFlag() {
        var bad = HrvSummary(windowEndTimeS: 600, meanIbiMs: 900, sdnnMsX10: 452, rmssdMsX10: 452,
                             pnn50Pct: 20, beatsAccepted: 90, beatsRejected: 3, quality: 80, flags: HrvFlags.motion)
        XCTAssertFalse(bad.isValid)
        bad.flags = HrvFlags.valid | HrvFlags.wallClock
        XCTAssertTrue(bad.isValid)
        XCTAssertEqual(bad.rmssdMs, 45.2, accuracy: 0.001)
        XCTAssertEqual(HrvSummary.parse(bad.encode()), bad)
    }

    func testReplayReassemblesMisalignedFramesAndDerivesRecordSize() {
        let records = (0..<25).map { sampleRecord(tS: Int64($0) * 30) }
        var image = Data()
        records.forEach { image.append($0.encode()) }
        let frames = ReplayAssembler.frames(slot: 5, recordBytes: image, recordCount: records.count)
        let asm = ReplayAssembler()
        var finished: ReplayAssembler.Result?
        for f in frames {
            switch asm.feed(f) {
            case .headerReceived(let h):
                XCTAssertEqual(h.recordSize, 34)
                XCTAssertEqual(h.slot, 5)
            case .finished(let r): finished = r
            case .error(let m): XCTFail(m)
            case .data: break
            }
        }
        guard let r = finished else { return XCTFail("no end frame") }
        XCTAssertTrue(r.complete)
        XCTAssertEqual(r.records.count, 25)
        XCTAssertEqual(r.crcFailures, 0)
        XCTAssertEqual(r.records, records)
    }

    func testReplayFlagsOlderRecordFormatInsteadOfMisparsing() {
        let image = Data(count: 24 * 10) // 24-byte records: an earlier firmware build
        let frames = ReplayAssembler.frames(slot: 0, recordBytes: image, recordCount: 10)
        let asm = ReplayAssembler()
        var result: ReplayAssembler.Result?
        for f in frames { if case .finished(let r) = asm.feed(f) { result = r } }
        XCTAssertTrue(result!.unsupportedFormat)
        XCTAssertTrue(result!.records.isEmpty)
    }

    func testSessionSummaryRoundTrip() {
        let s = SessionSummary(sessionLenS: 28800, epochsLogged: 960, sweatEvents: 4, longestSweatS: 720,
                               peakDahX100: 655, hrMeanBpm: 61, hrMinBpm: 52, hrMaxBpm: 88,
                               pctWake: 12, pctLight: 55, pctDeep: 33, battPct: 64, slot: 9)
        XCTAssertEqual(SessionSummary.parse(s.encode()), s)
        XCTAssertEqual(s.peakDah, 6.55, accuracy: 0.001)
    }

    private func sampleRecord(tS: Int64) -> LogRecord {
        LogRecord(
            tS: tS, hrBpm: 60, hrQuality: 85, skinTempX100: 3340, skinRhX100: 4500,
            ambTempX100: 2100, ambRhX100: 4200, motionIndex: 5, sleepState: .light,
            sweatFlag: .none, battPct: 80, flags: PodFlags.logging | PodFlags.timeSynced,
            dahX100: 120, hrvMeanIbiMs: 1000, hrvSdnnMsX10: 500, hrvRmssdMsX10: 420,
            hrvPnn50Pct: 25, hrvQuality: 90, hrvFlags: HrvFlags.valid, vcellCv: 130
        )
    }
}
