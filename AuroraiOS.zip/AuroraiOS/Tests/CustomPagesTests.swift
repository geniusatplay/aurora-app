import XCTest
@testable import Aurora

/// CustomPagesStore: page numbering, section ordering, JSON shape and persistence.
/// Every test runs against its own UserDefaults suite (never the app's defaults).
final class CustomPagesTests: XCTestCase {

    private var suiteName = ""
    private var defaults: UserDefaults!

    override func setUp() {
        super.setUp()
        suiteName = "CustomPagesTests-\(UUID().uuidString)"
        defaults = UserDefaults(suiteName: suiteName)
    }

    override func tearDown() {
        defaults.removePersistentDomain(forName: suiteName)
        defaults = nil
        super.tearDown()
    }

    private func makeStore() -> CustomPagesStore {
        CustomPagesStore(defaults: defaults)
    }

    private func storedJson() -> String? {
        defaults.string(forKey: CustomPagesStore.defaultsKey)
    }

    // MARK: - Pages

    func testStartsEmptyWithNothingStored() {
        let store = makeStore()
        XCTAssertTrue(store.pages.isEmpty)
        XCTAssertTrue(store.canCreatePage)
        XCTAssertNil(storedJson())
    }

    func testCreatesLowestUnusedNumberUpToFive() {
        let store = makeStore()
        XCTAssertEqual(store.createNextPage(), 1)
        XCTAssertEqual(store.createNextPage(), 2)
        XCTAssertEqual(store.createNextPage(), 3)
        store.deletePage(2)
        XCTAssertEqual(store.pages.map { $0.n }, [1, 3])
        // The gap is reused before 4.
        XCTAssertEqual(store.createNextPage(), 2)
        XCTAssertEqual(store.createNextPage(), 4)
        XCTAssertEqual(store.createNextPage(), 5)
        XCTAssertFalse(store.canCreatePage)
        XCTAssertNil(store.createNextPage())
        XCTAssertEqual(store.pages.map { $0.n }, [1, 2, 3, 4, 5])
    }

    func testDeleteUnknownPageIsANoOp() {
        let store = makeStore()
        store.createNextPage()
        store.deletePage(4)
        XCTAssertEqual(store.pages.map { $0.n }, [1])
    }

    // MARK: - Sections

    func testAddAppendsOncePerPageButAllowsOtherPages() {
        let store = makeStore()
        store.createNextPage()
        store.createNextPage()
        XCTAssertTrue(store.addSection("live_hr", to: 1))
        XCTAssertTrue(store.addSection("night_timeline", to: 1))
        XCTAssertFalse(store.addSection("live_hr", to: 1), "the same section may not be added twice to one page")
        XCTAssertTrue(store.addSection("live_hr", to: 2), "but it may be on several pages")
        XCTAssertFalse(store.addSection("live_hr", to: 3), "page 3 does not exist")
        XCTAssertEqual(store.sections(of: 1), ["live_hr", "night_timeline"])
        XCTAssertEqual(store.sections(of: 2), ["live_hr"])
        XCTAssertTrue(store.contains("night_timeline", on: 1))
        XCTAssertFalse(store.contains("night_timeline", on: 2))
    }

    func testRemoveSection() {
        let store = makeStore()
        store.createNextPage()
        store.addSection("live_hr", to: 1)
        store.addSection("live_moisture", to: 1)
        store.removeSection("live_hr", from: 1)
        XCTAssertEqual(store.sections(of: 1), ["live_moisture"])
        store.removeSection("not_there", from: 1)
        XCTAssertEqual(store.sections(of: 1), ["live_moisture"])
    }

    func testMoveFollowsListOnMoveSemantics() {
        let store = makeStore()
        store.createNextPage()
        for id in ["live_hr", "live_moisture", "live_chart", "live_status"] {
            store.addSection(id, to: 1)
        }
        // Drag the first row below the second (toOffset points BEFORE the row it lands on).
        store.move(page: 1, fromOffsets: IndexSet(integer: 0), toOffset: 2)
        XCTAssertEqual(store.sections(of: 1), ["live_moisture", "live_hr", "live_chart", "live_status"])
        // Drag the last row to the top.
        store.move(page: 1, fromOffsets: IndexSet(integer: 3), toOffset: 0)
        XCTAssertEqual(store.sections(of: 1), ["live_status", "live_moisture", "live_hr", "live_chart"])
        // Drag to the very end.
        store.move(page: 1, fromOffsets: IndexSet(integer: 1), toOffset: 4)
        XCTAssertEqual(store.sections(of: 1), ["live_status", "live_hr", "live_chart", "live_moisture"])
    }

    func testMovedMatchesArrayMoveForMultipleOffsets() {
        let items = ["a", "b", "c", "d", "e"]
        XCTAssertEqual(CustomPagesStore.moved(items, fromOffsets: IndexSet([0, 2]), toOffset: 4),
                       ["b", "d", "a", "c", "e"])
        XCTAssertEqual(CustomPagesStore.moved(items, fromOffsets: IndexSet([3, 4]), toOffset: 1),
                       ["a", "d", "e", "b", "c"])
        XCTAssertEqual(CustomPagesStore.moved(items, fromOffsets: IndexSet(integer: 2), toOffset: 2), items)
        XCTAssertEqual(CustomPagesStore.moved(items, fromOffsets: IndexSet(integer: 9), toOffset: 0), items)
    }

    func testMoveUpDownAccessibilityActions() {
        let store = makeStore()
        store.createNextPage()
        for id in ["live_hr", "live_moisture", "live_chart"] { store.addSection(id, to: 1) }
        store.moveSection("live_hr", by: 1, on: 1)
        XCTAssertEqual(store.sections(of: 1), ["live_moisture", "live_hr", "live_chart"])
        store.moveSection("live_chart", by: -1, on: 1)
        XCTAssertEqual(store.sections(of: 1), ["live_moisture", "live_chart", "live_hr"])
        store.moveSection("live_moisture", by: -1, on: 1) // already first
        XCTAssertEqual(store.sections(of: 1), ["live_moisture", "live_chart", "live_hr"])
    }

    // MARK: - Unknown IDs (written by a newer version)

    func testUnknownIdsArePreservedButNotRendered() {
        defaults.set(#"[{"n":1,"sections":["live_hr","future_widget","night_timeline"]}]"#,
                     forKey: CustomPagesStore.defaultsKey)
        let store = makeStore()
        XCTAssertEqual(store.sections(of: 1), ["live_hr", "future_widget", "night_timeline"])
        XCTAssertEqual(store.visibleSections(of: 1), [.liveHr, .nightTimeline])

        // Reorder the visible rows: the unknown ID keeps its stored slot.
        store.move(page: 1, fromOffsets: IndexSet(integer: 1), toOffset: 0)
        XCTAssertEqual(store.sections(of: 1), ["night_timeline", "future_widget", "live_hr"])

        // Delete by visible offset: only the known row goes.
        store.removeSections(at: IndexSet(integer: 1), from: 1)
        XCTAssertEqual(store.sections(of: 1), ["night_timeline", "future_widget"])

        // Still written back.
        XCTAssertEqual(storedJson(), #"[{"n":1,"sections":["night_timeline","future_widget"]}]"#)
    }

    // MARK: - JSON

    func testPersistsSharedJsonShapeSortedByPage() {
        let store = makeStore()
        store.createNextPage()
        store.createNextPage()
        store.addSection("live_hr", to: 2)
        store.addSection("live_hr", to: 1)
        store.addSection("night_timeline", to: 1)
        XCTAssertEqual(storedJson(),
                       #"[{"n":1,"sections":["live_hr","night_timeline"]},{"n":2,"sections":["live_hr"]}]"#)
    }

    func testReloadsAfterRestart() {
        let first = makeStore()
        first.createNextPage()
        first.createNextPage()
        first.addSection("vital_sheet", to: 2)
        first.addSection("trends_flashes", to: 2)
        first.move(page: 2, fromOffsets: IndexSet(integer: 1), toOffset: 0)

        let second = makeStore()
        XCTAssertEqual(second.pages, first.pages)
        XCTAssertEqual(second.sections(of: 2), ["trends_flashes", "vital_sheet"])
    }

    func testDecodeSortsAndSanitises() {
        let json = #"""
        [{"n":3,"sections":["live_hr","live_hr","pod_log"]},
         {"n":1},
         {"n":7,"sections":["live_hr"]},
         {"n":3,"sections":["dup_page"]},
         {"n":0,"sections":[]}]
        """#
        let pages = CustomPagesStore.decode(json)
        XCTAssertEqual(pages.map { $0.n }, [1, 3], "out-of-range and duplicate page numbers are dropped")
        XCTAssertEqual(pages[0].sections, [], "a page without a list is an empty page")
        XCTAssertEqual(pages[1].sections, ["live_hr", "pod_log"], "duplicate IDs within a page are dropped")
    }

    func testGarbageDecodesToNoPages() {
        XCTAssertEqual(CustomPagesStore.decode("not json"), [])
        XCTAssertEqual(CustomPagesStore.decode(#"{"n":1}"#), [])
        defaults.set("[{", forKey: CustomPagesStore.defaultsKey)
        XCTAssertTrue(makeStore().pages.isEmpty)
    }

    func testEncodeDecodeRoundTrip() {
        let pages = [CustomPage(n: 2, sections: ["link_health"]),
                     CustomPage(n: 1, sections: ["live_hr", "hardware_check"])]
        let json = CustomPagesStore.encode(pages)
        XCTAssertEqual(json, #"[{"n":1,"sections":["live_hr","hardware_check"]},{"n":2,"sections":["link_health"]}]"#)
        XCTAssertEqual(CustomPagesStore.decode(json), pages.sorted { $0.n < $1.n })
    }

    // MARK: - Catalogue

    func testCatalogueIdsAreTheSharedOnes() {
        let expected = [
            "live_hr", "live_moisture", "live_skin_temp", "live_skin_rh", "live_spo2", "live_quality",
            "live_status", "live_chart", "live_hrv", "live_conductance", "session_controls",
            "last_night", "morning_card", "night_timeline", "vital_sheet", "recent_nights", "sweat_events",
            "trends_overview", "trends_flashes", "trends_hr", "trends_time_in_bed", "trends_sleep",
            "pod_connection", "pod_info", "pod_log", "pod_controls", "demo_controls",
            "link_health", "packet_inspector", "hardware_check",
        ]
        XCTAssertEqual(SectionId.allCases.map { $0.rawValue }, expected)
        // Library groups appear in the brief's order and cover every section exactly once.
        let grouped = SectionCategory.allCases.flatMap { SectionId.inCategory($0) }
        XCTAssertEqual(grouped, SectionId.allCases)
        XCTAssertEqual(SectionCategory.allCases, [.live, .nights, .trends, .pod, .diagnostics])
    }
}
