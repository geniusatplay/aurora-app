// Bundle detection, pattern flags and protocol-v2 round trips — port of NightAnalyticsTest.kt
// plus the v2 cases from ProtocolTest.kt (ext brief §1/§3), on hand-built synthetic nights so
// every threshold is exercised deliberately rather than through the demo simulator's noise.
import XCTest
@testable import Aurora

final class AnalyticsTests: XCTestCase {

    private let allValid = ExtFlags.edaValid | ExtFlags.spo2Valid | ExtFlags.piValid

    /// One quiet 30 s epoch: light sleep, HR 58, 33.4 °C, EDA 3.0 µS, SpO2 96.8 %.
    private func epoch(_ i: Int,
                       hr: Int = 58,
                       tempX100: Int = 3340,
                       edaX100: Int = 300,
                       spo2X10: Int = 968,
                       sleep: SleepState = .light,
                       motion: Int = 5,
                       sweat: SweatFlag = .none,
                       ambTempX100: Int = 2100,
                       ambRhX100: Int = 4200) -> LogRecord {
        LogRecord(tS: Int64(i) * 30, hrBpm: hr, hrQuality: 85, skinTempX100: tempX100, skinRhX100: 4500,
                  ambTempX100: ambTempX100, ambRhX100: ambRhX100, motionIndex: motion, sleepState: sleep,
                  sweatFlag: sweat, battPct: 80, flags: PodFlags.logging, dahX100: 120,
                  hrvMeanIbiMs: 1000, hrvSdnnMsX10: 500, hrvRmssdMsX10: 420, hrvPnn50Pct: 25,
                  hrvQuality: 90, hrvFlags: HrvFlags.valid, vcellCv: 130,
                  edaX100: edaX100, spo2X10: spo2X10, perfusionX100: 200, extFlags: allValid)
    }

    /// Strip the ext fields — a v1-shaped record, exactly as a 34-byte parse produces.
    private func v1(_ r: LogRecord) -> LogRecord {
        var out = r
        out.edaX100 = nil
        out.spo2X10 = nil
        out.perfusionX100 = nil
        out.extFlags = nil
        return out
    }

    /// Two obvious bundles (sweat + temp + HR) and one sweat-ONLY spike that lacks the
    /// temperature/HR confirmation — the spike must NOT count (a blanket is not a flash).
    private func syntheticNight() -> [LogRecord] {
        (0..<200).map { i in
            switch i {
            // Bundle 1: epochs 40–45. EDA +5 µS; temp +0.6 °C and HR +15 confirm; a wake inside.
            case 40...45:
                return epoch(i, hr: i >= 42 ? 73 : 58,
                             tempX100: i >= 41 ? 3400 : 3340,
                             edaX100: 800,
                             sleep: i == 44 ? .wake : .light)
            // Bundle 2: epochs 100–107. EDA +6 µS; temp +0.8 °C and HR +20 confirm; NO wake.
            case 100...107:
                return epoch(i, hr: 78, tempX100: 3420, edaX100: 900)
            // Sweat-only spike: epochs 160–163. Same EDA rise but temp and HR stay flat.
            case 160...163:
                return epoch(i, edaX100: 900)
            default:
                return epoch(i)
            }
        }
    }

    // MARK: - Bundle detection (ext brief §3)

    func testDetectBundlesConfirmsTwoRejectsSweatOnlySpike() {
        let bundles = NightAnalytics.detectBundles(syntheticNight())
        XCTAssertEqual(bundles.count, 2, "temp/HR must confirm a sweat spike before it counts")

        let b1 = bundles[0]
        XCTAssertEqual(b1.startTs, 40 * 30)
        XCTAssertEqual(b1.endTs, 46 * 30, "span end is exclusive: last elevated epoch + 30 s")
        XCTAssertEqual(b1.peakEdaDeltaX100, 500, "8.0 − 3.0 µS over the pre-onset baseline")
        XCTAssertGreaterThanOrEqual(b1.tempDeltaX100, 30)
        XCTAssertGreaterThanOrEqual(b1.hrDelta, 8)
        XCTAssertTrue(b1.hadWake, "wake epoch inside the bundle")
        XCTAssertFalse(b1.longSoak, "3 min is no long soak")

        let b2 = bundles[1]
        XCTAssertEqual(b2.startTs, 100 * 30)
        XCTAssertEqual(b2.peakEdaDeltaX100, 600)
        XCTAssertFalse(b2.hadWake, "no wake and no motion near bundle 2")
    }

    func testDetectBundlesEmptyAndQuietNights() {
        XCTAssertTrue(NightAnalytics.detectBundles([]).isEmpty)
        XCTAssertTrue(NightAnalytics.detectBundles((0..<100).map { epoch($0) }).isEmpty)
    }

    func testDetectBundlesMergesSpansWithShortGap() {
        // Two elevated spans 10 epochs apart (< 20-epoch merge gap) = ONE event that dipped.
        let records = (0..<120).map { i in
            switch i {
            case 50...54, 65...69: return epoch(i, hr: 73, tempX100: 3400, edaX100: 800)
            default: return epoch(i)
            }
        }
        let bundles = NightAnalytics.detectBundles(records)
        XCTAssertEqual(bundles.count, 1)
        XCTAssertEqual(bundles[0].startTs, 50 * 30)
        XCTAssertEqual(bundles[0].endTs, 70 * 30)
    }

    func testDetectBundlesV1FallbackUsesSweatFlags() {
        // No ext channel at all: records are v1-shaped; the sweat_flag span drives the onset.
        let records = (0..<120).map { i -> LogRecord in
            switch i {
            case 50: return v1(epoch(i, hr: 73, tempX100: 3400, sweat: .start))
            case 51...55: return v1(epoch(i, hr: 73, tempX100: 3400, sweat: .ongoing))
            default: return v1(epoch(i))
            }
        }
        let bundles = NightAnalytics.detectBundles(records)
        XCTAssertEqual(bundles.count, 1)
        XCTAssertEqual(bundles[0].peakEdaDeltaX100, 0,
                       "v1 has no conductance channel — delta is 0 by definition")
    }

    // MARK: - Night score (ext brief §3)

    func testNightScoreBoundaries() {
        func bundle(longSoak: Bool = false) -> FlashBundle {
            FlashBundle(startTs: 0, endTs: 300, peakEdaDeltaX100: 400, tempDeltaX100: 50,
                        hrDelta: 10, hadWake: false, longSoak: longSoak)
        }
        XCTAssertEqual(NightAnalytics.nightScore([]), .quiet)
        XCTAssertEqual(NightAnalytics.nightScore([bundle()]), .quiet)
        XCTAssertEqual(NightAnalytics.nightScore(Array(repeating: bundle(), count: 2)), .mild)
        XCTAssertEqual(NightAnalytics.nightScore(Array(repeating: bundle(), count: 4)), .mild)
        XCTAssertEqual(NightAnalytics.nightScore(Array(repeating: bundle(), count: 5)), .meaningful)
        // Any long soak promotes the night regardless of count.
        XCTAssertEqual(NightAnalytics.nightScore([bundle(longSoak: true)]), .meaningful)
    }

    // MARK: - Pattern flags (ext brief §3)

    func testNotFlashPatternHrUpO2DownNoSweatSetsFlag() {
        // Three separate 5-min windows: HR +12 bpm, SpO2 −4 %, EDA flat → not-a-flash pattern.
        let records = (0..<150).map { i in
            switch i {
            case 40...49, 70...79, 100...109: return epoch(i, hr: 70, spo2X10: 928)
            default: return epoch(i)
            }
        }
        let flags = NightAnalytics.nightFlags(records)
        XCTAssertTrue(flags.notFlashPattern)
        XCTAssertFalse(flags.warmRoom)
        XCTAssertFalse(flags.allNightHighHr)
    }

    func testNotFlashPatternNotRaisedWithoutO2DropOrWithSweat() {
        // HR rises alone (no desaturation) — flag must stay down.
        let hrOnly = (0..<150).map { i in
            (40...49 ~= i || 70...79 ~= i || 100...109 ~= i) ? epoch(i, hr: 70) : epoch(i)
        }
        XCTAssertFalse(NightAnalytics.nightFlags(hrOnly).notFlashPattern)
        // Same windows but sweat is elevated too — that is flash territory, not this flag.
        let withSweat = (0..<150).map { i in
            (40...49 ~= i || 70...79 ~= i || 100...109 ~= i)
                ? epoch(i, hr: 70, edaX100: 800, spo2X10: 928) : epoch(i)
        }
        XCTAssertFalse(NightAnalytics.nightFlags(withSweat).notFlashPattern)
    }

    func testWarmRoomAndAllNightHighHr() {
        let warm = (0..<100).map { i in epoch(i, ambTempX100: i < 60 ? 2700 : 2100) }
        XCTAssertTrue(NightAnalytics.nightFlags(warm).warmRoom)
        let rising = (0..<90).map { i in epoch(i, hr: i >= 60 ? 70 : 58) }
        XCTAssertTrue(NightAnalytics.nightFlags(rising).allNightHighHr)
    }

    // MARK: - Quiet vs event columns (ext brief §4)

    func testQuietVsEventSplitsChannelsByBundleSpans() {
        let records = syntheticNight()
        let bundles = NightAnalytics.detectBundles(records)
        let cmp = NightAnalytics.quietVsEvent(records, bundles: bundles)
        XCTAssertEqual(cmp.hrBpm.quietMedian!, 58, accuracy: 0.01)
        XCTAssertNotNil(cmp.hrBpm.eventMedian)
        XCTAssertGreaterThan(cmp.hrBpm.eventMedian!, cmp.hrBpm.quietMedian!,
                             "HR runs higher inside bundles")
        XCTAssertEqual(cmp.edaUs.quietMedian!, 3.0, accuracy: 0.05)
        XCTAssertGreaterThanOrEqual(cmp.edaUs.eventPeak!, 8)
        // v1 night: ext channels must come back nil on both sides, so the sheet skips the rows.
        let v1Records = records.map { v1($0) }
        let v1Cmp = NightAnalytics.quietVsEvent(v1Records, bundles: NightAnalytics.detectBundles(v1Records))
        XCTAssertTrue(v1Cmp.edaUs.isEmpty)
        XCTAssertTrue(v1Cmp.spo2Pct.isEmpty)
        XCTAssertNil(v1Cmp.perfusionPct.eventPeak)
        XCTAssertFalse(v1Cmp.hrBpm.isEmpty)
    }

    // MARK: - Protocol v2 (ext brief §1)

    private func sampleRecord(tS: Int64) -> LogRecord {
        LogRecord(tS: tS, hrBpm: 60, hrQuality: 85, skinTempX100: 3340, skinRhX100: 4500,
                  ambTempX100: 2100, ambRhX100: 4200, motionIndex: 5, sleepState: .light,
                  sweatFlag: .none, battPct: 80, flags: PodFlags.logging | PodFlags.timeSynced,
                  dahX100: 120, hrvMeanIbiMs: 1000, hrvSdnnMsX10: 500, hrvRmssdMsX10: 420,
                  hrvPnn50Pct: 25, hrvQuality: 90, hrvFlags: HrvFlags.valid, vcellCv: 130)
    }

    func testExtendedVitalsRoundTripAndValidGating() {
        let v = ExtendedVitals(tS: 7200, edaX100: 435, spo2X10: 968, perfusionX100: 210,
                               extFlags: ExtFlags.edaValid | ExtFlags.piValid)
        let bytes = v.encode()
        XCTAssertEqual(bytes.count, 20)
        XCTAssertEqual(ExtendedVitals.parse(bytes), v)
        // A field is shown ONLY when its VALID bit is set (ext brief §1).
        XCTAssertEqual(v.edaUs!, 4.35, accuracy: 0.001)
        XCTAssertNil(v.spo2Pct, "SPO2_VALID not set — must not surface a number")
        XCTAssertEqual(v.perfusionPct!, 2.10, accuracy: 0.001)
        // Wrong length → nil, not a crash (ext brief §1).
        XCTAssertNil(ExtendedVitals.parse(Data(count: 11)))
    }

    func testLogRecordV2RoundTripCrcCorruptionDroppedV1StillParses() {
        var v2 = sampleRecord(tS: 60)
        v2.edaX100 = 812
        v2.spo2X10 = 955
        v2.perfusionX100 = 320
        v2.extFlags = allValid
        let bytes = v2.encode()
        XCTAssertEqual(bytes.count, 42)
        XCTAssertEqual(LogRecord.parse(bytes, offset: 0, size: LogRecord.sizeV2), v2)
        XCTAssertEqual(v2.edaUs!, 8.12, accuracy: 0.001)
        // CRC now sits at bytes 40–41 and covers 0–39: corruption anywhere must drop the record.
        var corrupt = bytes
        corrupt[35] ^= 0x01 // spo2 byte
        XCTAssertNil(LogRecord.parse(corrupt, offset: 0, size: LogRecord.sizeV2),
                     "corrupted v2 record must be dropped")
        // Unsupported size → nil, never a misparse.
        XCTAssertNil(LogRecord.parse(bytes, offset: 0, size: 38))
        // v1 records are untouched by the extension: 34 B, ext fields absent.
        let v1Rec = sampleRecord(tS: 90)
        let v1Bytes = v1Rec.encode()
        XCTAssertEqual(v1Bytes.count, 34)
        let parsed = LogRecord.parse(v1Bytes)
        XCTAssertEqual(parsed, v1Rec)
        XCTAssertFalse(parsed!.hasExt)
        XCTAssertNil(parsed!.edaUs)
    }

    func testReplayReassembles42ByteRecordsAndDerivesSize() {
        let records = (0..<25).map { i -> LogRecord in
            var r = sampleRecord(tS: Int64(i) * 30)
            r.edaX100 = 300 + i
            r.spo2X10 = 970
            r.perfusionX100 = 180
            r.extFlags = allValid
            return r
        }
        // frames(slot:records:) derives the record size (42) from the records it is given.
        let frames = ReplayAssembler.frames(slot: 2, records: records)
        let asm = ReplayAssembler()
        var finished: ReplayAssembler.Result?
        for f in frames {
            switch asm.feed(f) {
            case .headerReceived(let header):
                XCTAssertEqual(header.recordSize, 42)
            case .finished(let result):
                finished = result
            case .error(let message):
                XCTFail(message)
            case .data:
                break
            }
        }
        guard let r = finished else { XCTFail("no end frame"); return }
        XCTAssertTrue(r.complete)
        XCTAssertFalse(r.unsupportedFormat)
        XCTAssertEqual(r.crcFailures, 0)
        XCTAssertEqual(r.records, records)
    }
}
